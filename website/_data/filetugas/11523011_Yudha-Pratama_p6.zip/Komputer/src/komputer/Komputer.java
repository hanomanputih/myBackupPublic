/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class Komputer {

  String id_komp;
  Prosesor p;
  RAM r;
  public Komputer(String komp){
    id_komp = komp;
    if (id_komp.equals("1")) {
        p = new Prosesor ("i3");
        r = new RAM ("2 GB");
    }
        
    }
    
   
   
    public static void main(String[] args) {
       
        Komputer komp= new Komputer("1");
        Komputer merk=new Komputer("1");
        System.out.println("Prosesor  " +komp.p.nama);
        System.out.println("RAM  " +komp.r.RAM);
        System.out.println("Prosesor  " +merk.p.nama);
        System.out.println("RAM  " +merk.r.RAM);
        
        
        
       
    }
}
