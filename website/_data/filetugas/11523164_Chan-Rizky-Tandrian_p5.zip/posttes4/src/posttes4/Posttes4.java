/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttes4;

/**
 *
 * @author Praktikan
 */
public class Posttes4 {



 
    public static void main(String[] args) {
        karyawan kar = new karyawan();

        kar.setNama("chan");
        kar.setNip("12345");
            kar.setGaji(-3000);
        System.out.println("nip :"+kar.getNip());
        System.out.println("nama :"+kar.getNama());
        System.out.println("gaji setahun :"+kar.getGaji());
    }
}
