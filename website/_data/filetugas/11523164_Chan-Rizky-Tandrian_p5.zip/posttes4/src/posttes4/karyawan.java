/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttes4;

/**
 *
 * @author Praktikan
 */
public class karyawan {
    private String nip;
    private String nama;
    private int gaji;

public void setNip (String nip1){
nip = nip1;
}
public void setNama (String nama1){
    nama = nama1;
}
public void setGaji (int gaji1){
   if (gaji1 < 0){
        System.out.println("gaji tidak ter definisi");
    }
   else{
    gaji =gaji1 * 12;
   }
   }
public String getNip(){
return nip;
}
public String getNama(){
return nama;
}
public int getGaji(){
return gaji;
}

}