/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest5;

/**
 *
 * @author Praktikan
 */
public class ram {
    String besarMemori;

    public ram(String besarMemori) {
        this.besarMemori = besarMemori;
    }

    
}
