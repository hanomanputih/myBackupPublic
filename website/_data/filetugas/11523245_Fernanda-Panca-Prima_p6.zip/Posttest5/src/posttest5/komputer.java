/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest5;

/**
 *
 * @author Praktikan
 */
public class komputer {

    /**
     * @param args the command line arguments
     */
    ram r;
    prosesor p;

    public komputer() {
            r= new ram("4gb");
            p= new prosesor("Dual-Core");
    }
    
    public static void main(String[] args) {
        // TODO code application logic here;
        komputer k = new komputer();
        System.out.println("Komputer ini RAM:"+k.r.besarMemori+" dan Prosesor: "+k.p.jenis);
    }
}
