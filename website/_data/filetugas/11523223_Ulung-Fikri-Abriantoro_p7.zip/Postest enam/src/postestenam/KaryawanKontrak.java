/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package postestenam;

/**
 *
 * @author Praktikan
 */
public class KaryawanKontrak extends Karyawan{
    String nama = "Gery";


    public void gaji() {
        System.out.println ("Nama Karyawan  " + nama);
        System.out.println("Gaji "+(gajiPokok+bonus));
    }
}
