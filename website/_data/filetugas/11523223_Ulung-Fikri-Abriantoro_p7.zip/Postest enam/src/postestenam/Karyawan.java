/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package postestenam;

/**
 *
 * @author Praktikan
 */
public abstract class Karyawan {
    int gajiPokok =  3000000;
    
    int bonus = 10000 ;


    public abstract void gaji ();

}

