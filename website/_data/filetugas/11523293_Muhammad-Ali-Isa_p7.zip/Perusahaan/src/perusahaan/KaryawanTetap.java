/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perusahaan;

/**
 *
 * @author Praktikan
 */
public class KaryawanTetap extends Karyawan {
      int gaji;
      int tunjangan;
      int bonus;

    public KaryawanTetap(int gajiPokok) {
    this.gajiPokok = gajiPokok;
    }
      
      

    @Override
    public void gaji(int gajiPokok) {
        tunjangan = 20/100 * gajiPokok;
        gaji=tunjangan+gajiPokok+bonus;
       System.out.println("tunj"+tunjangan);
//        System.out.println("Gaji karyawan tetap = "+gaji);
    }

}
