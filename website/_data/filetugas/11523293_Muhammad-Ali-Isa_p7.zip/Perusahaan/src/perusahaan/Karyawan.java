/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perusahaan;

/**
 *
 * @author Praktikan
 */
public abstract class Karyawan {
    int gajiPokok = 3000000;
  
    
    public abstract void gaji(int gajiPokok);
  
}
    
    
