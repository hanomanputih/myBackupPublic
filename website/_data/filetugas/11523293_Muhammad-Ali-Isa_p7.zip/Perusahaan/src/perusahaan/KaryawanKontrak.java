/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perusahaan;

/**
 *
 * @author Praktikan
 */
public class KaryawanKontrak extends Karyawan {
    int bonus=10/100 * gajiPokok;
    int gaji;
    int tunjangan;

    @Override
    public void gaji(int gajiPokok) {
        gaji=gajiPokok+bonus;
        System.out.println("Gaji karyawan kontrak = "+gaji);
    }
    
}
