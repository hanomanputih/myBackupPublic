/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perusahaan;

/**
 *
 * @author Praktikan
 */
public class Perusahaan {

    /**
     * @param args the command line arguments
     */
    int tunjangan;
    int gaji;
    public static void main(String[] args) {
        // TODO code application logic here
        
        KaryawanTetap kt = new KaryawanTetap(3000000);
        //kt.setTunjangan(3000000);
        kt.gaji(3000000);
//        KaryawanKontrak kk = new KaryawanKontrak();
//        kk.gaji();
    }
}
