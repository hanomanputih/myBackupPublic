/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package kelasutama;

/**
 *
 * @author PRAKTIKAN
 */
public class KelasUtama {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Karyawan k = new Karyawan ();
        k.setGaji(444000);
        k.setNama("Muhammad Ridwan Dwiangga");
        k.setNip("1152325644");
        
        System.out.println("Nama Karyawan   : "+k.getNama());
        System.out.println("Nip Karyawan    : "+k.getNip());
        System.out.println("Gaji pertahun   : "+k.getGaji()*12);
    }
}
