/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package kelasutama;

/**
 *
 * @author PRAKTIKAN
 */
public class Karyawan {
    private String nip, nama;
    private int gaji;
    
    public String getNama() {
        return nama;
    }

    public void setNama(String nm) {
        if (nm.length() >= 8){
        this.nama = nm;
        }
        else {
            System.out.println("Nama tidak sesuai !!");
        }
    }

    public String getNip() {
        return nip;
    }

    public void setNip(String np) {
        if (np.length() == 10){
        this.nip = np;
        }
        else {
            System.out.println("NIP tidak sesuai !!");
        }
    }

    public int getGaji() {
        return gaji;
    }

    public void setGaji(int gj) {
        if ((gj >= 100000) && (gj <=500000)){
            this.gaji=gj;
        }
        else {
            System.out.println("Gaji tidak sesuai");
        }
    }

    
}
