/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cpu;

/**
 *
 * @author Praktikan
 */
public class CPU {
    private String kode;
    private RAM r;
    private PROCESSOR p;
    
    public CPU(String kode) {
        this.kode = kode;
        if (kode.equals("1"))
            
            r = new RAM();
            p = new PROCESSOR();
 
    }
    public static void main(String[] args) {
        CPU cpu = new CPU("1");

        System.out.println(cpu.r.ram);
        System.out.println(cpu.p.p);
    }
}
    
    

