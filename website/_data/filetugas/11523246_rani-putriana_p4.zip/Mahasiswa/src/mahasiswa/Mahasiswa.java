package mahasiswa;

public class Mahasiswa {

        String nama;
        String nim;
        String fakultas;
        String jurusan;
        String angkatan;
        int hitung;
    
    public void cetak(){
        
        Mahasiswa mhs = new Mahasiswa();
        mhs.nama="rani";
        mhs.nim="11523246";
        mhs.fakultas="fti";
        mhs.jurusan="t.informatika";
        mhs.angkatan="2011/2012";
        System.out.println("nama adalah: "+mhs.nama);
        System.out.println("nama adalah: "+mhs.nim);
        System.out.println("nama adalah: "+mhs.fakultas);
        System.out.println("nama adalah: "+mhs.jurusan);
        System.out.println("nama adalah: "+mhs.angkatan);
        mhs.hitung=mhs.nama.length();
        System.out.println("jumlah karakter: "+mhs.hitung);
        mhs.hitung=mhs.nim.length();
        System.out.println("jumlah karakter: "+mhs.hitung);
        mhs.hitung=mhs.fakultas.length();
        System.out.println("jumlah karakter: "+mhs.hitung);
        mhs.hitung=mhs.jurusan.length();
        System.out.println("jumlah karakter: "+mhs.hitung);
        mhs.hitung=mhs.angkatan.length();
        System.out.println("jumlah karakter: "+mhs.hitung);
       
    }

    public static void main(String[] args) {
        Mahasiswa mhs = new Mahasiswa();
        System.out.println("jadi data mahasiswanya adalah:");
        mhs.cetak();

    }
}

