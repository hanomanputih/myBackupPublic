
package postest;


public class Komputer {
    String nama;


    private Prosesor p;
    private Ram rm;

    public Komputer (String nama) {
     this.nama = nama;
     if (nama.equals ("Toxibeha")) {
         p = new Prosesor (324);
         rm = new Ram (32);
     }
    }

    void Tampil (){
        System.out.println("Nama Komputer :" + nama);
        System.out.println("Tipe Prosesor : " +p.type);
        System.out.println("Tipe RAM : " + rm.type);
    }

 }

