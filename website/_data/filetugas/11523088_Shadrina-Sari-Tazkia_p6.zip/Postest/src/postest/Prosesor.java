
package postest;


public class Prosesor {

    int type;

    void cetak (){
        System.out.println (" Tipe prosesor : " +type);
}
    public Prosesor (int tipe){
     this.type = tipe;
    }
 }