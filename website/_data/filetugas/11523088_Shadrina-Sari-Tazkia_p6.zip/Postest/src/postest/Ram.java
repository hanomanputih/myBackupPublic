
package postest;


public class Ram {
    int type;

    void cetak (){
        System.out.println (" Tipe RAM : " +type);
}
    public Ram (int tipe){
     this.type = tipe;
    }

}