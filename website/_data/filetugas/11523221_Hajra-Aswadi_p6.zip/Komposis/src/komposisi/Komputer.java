/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komposisi;

/**
 *
 * @author Praktikan
 */
public class Komputer {
    int hargaBeli;
    Prosesor M1;
    Ram M2;
    
    public Komputer(int harga, String M, String K, String N, String U, String T) {
        this.hargaBeli = harga;
        M1 = new Prosesor(M, K);
        M2 = new Ram (N, U, T);
    }
        
        public void tampil(){
            System.out.println("Harga Komputer: " +hargaBeli);
            System.out.println("Merk Prosesor : "+M1.merk);
            System.out.println("Kecepatan Prosesor: "+M1.kecepatan);
            System.out.println("Merk RAM : "+M2.merk);
            System.out.println("Ukuran RAM : "+M2.kapasitas);
            System.out.println("Type RAM : "+M2.type );
        }
    
}
