/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komposisi;

/**
 *
 * @author Praktikan
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Komputer komputer1 = new Komputer (8000000, "AMD", "3,4MHz", "VGEN", "8GB", "DDR3");
        
        komputer1.tampil();
    }
}
