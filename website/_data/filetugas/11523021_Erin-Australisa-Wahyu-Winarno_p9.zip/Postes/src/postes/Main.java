/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Main {
    public static void main(String[] args) {
        List mahasiswa = new ArrayList();
        Scanner pembaca = new Scanner(System.in);
        
       String nama;
       String nim;
       
       nama = pembaca.nextLine();
       nim = pembaca.nextLine();
        
        mahasiswa.add(mahasiswa);
        mahasiswa.add(nim);
        mahasiswa.add(nama);
        System.out.println(mahasiswa);
        System.out.println(mahasiswa.size());
        System.out.println("___________");
        
        for(Object zz : mahasiswa){
            System.out.println(zz);
        }
        System.out.println("___________");
        
        Iterator itt = mahasiswa.iterator();
        while(itt.hasNext()){
            System.out.println(itt.next());
        }
        for(int i =0; i<mahasiswa.size();i++){
            System.out.println(mahasiswa.get(i));
            
            Map<Integer,String> lalala = new HashMap<Integer,String>();
        
        lalala.put(1, nama);
        lalala.put(2, nim);
        
        
        for(Map.Entry<Integer,String> ee : lalala.entrySet()){
            System.out.println(ee.getKey()+"--"+ee.getValue());
    }
}
    }
}
