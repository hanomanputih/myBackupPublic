/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Praktikan
 */
public class Ram {
    
    String ukuran;
    
    public Ram(String u){
        this.ukuran=u;
    }
    
}
