/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Praktikan
 */
public class Processor {
    String nmPro;
    
    public Processor(String nm){
        this.nmPro=nm;
    }
    
}
