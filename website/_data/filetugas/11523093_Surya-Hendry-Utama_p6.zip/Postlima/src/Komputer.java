/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Praktikan
 */
public class Komputer {
    
    String nmKomputer;
    Processor p;
    Ram r;
    
    public Komputer(String nm, String pro, String ram){
        this.nmKomputer=nm;
        p = new Processor(pro);
        r = new Ram(ram);
    }
    
    void tampil(){
        System.out.println("Nama Komputer   :"+nmKomputer);
        System.out.println("Processor       :"+p.nmPro);        
        System.out.println("RAM             :"+r.ukuran+" MB");
    }
    
    public static void main(String[] args){
        Komputer k=new Komputer("Ace","Intel I3","2048");
        k.tampil();
    }
    
}
