/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest8;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Main {
    public static void main(String[] args) {
        List program = new ArrayList();
        Scanner ts = new Scanner(System.in);
        Map<Integer,String> tes = new HashMap<Integer,String>();
        
        String nim;
        String nama;
        System.out.println("Masukkan nim :");
        nim = ts.next();
        System.out.println("Masukkan nama :");
        nama = ts.next();
      program.add(nim);
        program.add(nama);
        
        System.out.println(program);
        System.out.println(program.size());
        System.out.println("**************");
        
        for(Object zz : program){
            System.out.println(zz);
        }
        System.out.println("**************");
        
        Iterator itr = program.iterator();
        while(itr.hasNext()){
            System.out.println(itr.next());
        }
        System.out.println("**************");
        for(int i = 0; i<program.size();i++){
            System.out.println(program.get(i));
        }
        System.out.println("****************");
        for(Map.Entry<Integer,String> ee : tes.entrySet()){
            System.out.println(ee.getKey()+"."+ee.getValue());
    }
        
        
    }
            
}
