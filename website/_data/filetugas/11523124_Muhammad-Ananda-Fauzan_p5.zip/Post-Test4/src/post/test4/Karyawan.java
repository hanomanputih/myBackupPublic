/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package post.test4;

/**
 *
 * @author praktikan
 */
public class Karyawan {
    private String nip;
    private String nama;
    private int gaji;
    
    public void setNip(String setNip){
        if(setNip.length()==6){
            nip=setNip;
        }else{
            System.out.println("Error");
        }
    }
    
    public void setNama(String getNama){
        nama=getNama;
        
    }
    public void setGaji(int getGaji){
        getGaji=100000;
        gaji=getGaji;
    }
    
    public String getNip(){
        return nip;
    }
    public String getNama(){
        return nama;
    }
    public int getGaji(){
        return gaji;
    }
    
}

    /**
     * @param args the command line arguments
     */
    