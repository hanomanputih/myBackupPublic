/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package post.test4;

/**
 *
 * @author praktikan
 */
public class Pemanggil {
    public static void main(String[] args) {
        // TODO code application logic here
        Karyawan kry = new Karyawan();
        
        kry.setNama("Ananda");
        kry.setNip("109120");
        kry.setGaji(100000);
        
        System.out.println("nama :"+kry.getNama());
        System.out.println("nip :"+kry.getNip());
        System.out.println("gaji :"+kry.getGaji()*12);
    }
}


