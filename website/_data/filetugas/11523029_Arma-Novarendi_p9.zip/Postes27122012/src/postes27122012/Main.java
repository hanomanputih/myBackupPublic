/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package postes27122012;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 *
 * @author praktikan
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        List<String> list1 = new ArrayList<String>();
        List list2 = new ArrayList();

        list1.add("Arma");
        list1.add("Norman");
        list1.add("Kemal");

        list2.add(11523029);
        list2.add(11523154);
        list2.add(11523156);

        for (int i = 0; i < list1.size(); i++){
            System.out.println("Nama "+i+" "+" : "+list1.get(i));
            System.out.println("NIM "+i+" "+" : "+list2.get(i));
        }

        Map<Integer,String> map = new HashMap<Integer, String>();
        map.put(11523029, "Arma");
        map.put(11523154, "Norman");
        map.put(11523156, "Kemal");

        System.out.println("****************");
        System.out.println(map.get(11523156));
        System.out.println("****************");


        Iterator<String> ite = list1.iterator();
        while (ite.hasNext()){
            String s = ite.next();
            System.out.println(s);
        }

    }

}
