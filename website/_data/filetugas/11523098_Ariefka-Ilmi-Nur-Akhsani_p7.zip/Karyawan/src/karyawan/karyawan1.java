/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public abstract class karyawan1 {
    protected int gajiPokok = 2000000;
    protected int Gaji = 1500000 ;
    protected int bonus = 50000;
    
public abstract void Gaji();    
}
