/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class karyawanTetap extends karyawan1{
    int Tunjangan = gajiPokok * 20/100;
    
     @Override
    public void Gaji(){
//         System.out.println("Tunjangan  : "+Tunjangan);
         Gaji = gajiPokok + Tunjangan + bonus; 
         System.out.println("Gaji karyawanTetap   : "+Gaji);
     }
    
}
