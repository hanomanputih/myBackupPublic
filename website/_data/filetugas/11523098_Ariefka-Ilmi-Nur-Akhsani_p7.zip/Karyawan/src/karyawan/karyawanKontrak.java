/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class karyawanKontrak extends karyawan1 {
    
    @Override
    public void Gaji(){
    Gaji = gajiPokok + bonus;
    System.out.println ("Gaji karyawanKontrak  : "+Gaji);
    
    
}
}