/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class Karyawan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        karyawanTetap kt  = new karyawanTetap();
     karyawanKontrak kk  = new karyawanKontrak();
     
        System.out.println("");
     kt.Gaji();
        System.out.println("");
     kk.Gaji ();
        // TODO code application logic here
    }
}
