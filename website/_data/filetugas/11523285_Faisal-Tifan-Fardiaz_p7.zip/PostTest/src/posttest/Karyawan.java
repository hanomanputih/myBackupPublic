/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author PRAKTIKAN
 */
public abstract class Karyawan {
    public int gajipokok = 3000000;
    public int bonus = 500000;
    public int gaji;
    
    public void gaji(){
}
    public void tampilgaji(){
        System.out.println("Gaji Karyawan = "+gaji);
    }
}