/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttestpertemuan4;

/**
 *
 * @author PRAKTIKAN
 */
public class KARYAWAN {
    
}
