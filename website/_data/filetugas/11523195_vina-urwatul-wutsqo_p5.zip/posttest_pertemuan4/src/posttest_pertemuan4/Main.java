/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest_pertemuan4;

/**
 *
 * @author Praktikan
 */
public class Main {
   public static void main(String[] args) {
        Karyawan kr = new Karyawan();
        kr.setNIP ("11523195 ");
        System.out.println("NIPnya adalah "+kr.getNIP());
        kr.setNAMA(" vina urwatul wutsqo");
        System.out.println("NAMAnya adalah "+kr.getNAMA());
        kr.setGAJI(20000*12);
        System.out.println("GAJInya adalah "+kr.getGAJI());
   }
    
}
