/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest_pertemuan4;

/**
 *
 * @author Praktikan
 */
public class karyawan {
    private String nip;
    private String nama;
    private int gaji;
    
   public class Main {
    public static void main(String[] args) {
        Karyawan kr =new Karyawan();
        kr.setNIP (" ");
        System.out.println("NIPnya adalah "+kr.getNIP);
        kr.setNAMA(" ");
        System.out.println("NAMAnya adalah "kr.getNAMA);
        kr.setGAJI;
        System.out.println("GAJInya adalah "kr.getGAJI);
        
    }
    
    
}

    public int getGaji() {
        return gaji;
    }

    public String getNama() {
        return nama;
    }

    public String getNip() {
        return nip;
    }
    
} 

