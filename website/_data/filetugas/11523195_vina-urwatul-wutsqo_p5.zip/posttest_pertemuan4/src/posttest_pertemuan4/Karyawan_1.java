/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest_pertemuan4;

/**
 *
 * @author Praktikan
 */
class Karyawan {
    
}
