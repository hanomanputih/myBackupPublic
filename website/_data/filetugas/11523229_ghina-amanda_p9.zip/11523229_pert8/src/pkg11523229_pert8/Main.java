/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg11523229_pert8;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

/**
 *
 * @author Praktikan
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         List nama=new ArrayList();
         List nim=new ArrayList();
         Iterator itt= nama.iterator();
         
         

        nama.add(nama);
        nama.add("ghina");
        nim.add(nim);
        nim.add(11523229);
        
        

       System.out.println(nama);
        
        System.out.println(nim);
   
        while(itt.hasNext()){
            System.out.println(itt.next());
            
      //Set set=new HashSet();
      //set.add(set);
      //set.add("Ghina");
      //set.add(11523229);

       // System.out.println(set);
    }  }
        

