/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication4;

/**
 *
 * @author PRAKTIKAN
 */
public class karyawanTetap extends karyawan {
        
  

    @Override
    public void gaji() {
        gaji = gajiPokok + gajiTunjangan + gajiBonus;
        System.out.println("Gaji Karyawan Tetap = "+gaji);
    }
    
}
