/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication4;

/**
 *
 * @author PRAKTIKAN
 */
public class karyawanKontrak extends karyawan {

    
   
    @Override
    public void gaji() {
       gaji = gajiPokok + gajiBonus;
       System.out.println("Gaji Karyawan Kontrak = "+gaji);
    }
    
}
