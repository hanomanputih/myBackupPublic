/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication4;

/**
 *
 * @author PRAKTIKAN
 */
public class mainGaji {
    public static void main(String[] args) {
        karyawanTetap kt = new karyawanTetap();
        kt.gaji();
        System.out.println("Gaji Pokok "+kt.gajiPokok);
        System.out.println("Gaji Tunjangan "+kt.gajiTunjangan);
        System.out.println("Gaji Bonus "+kt.gajiBonus);
        System.out.println("_________________________________");
        karyawanKontrak kk = new karyawanKontrak();
        kt.gaji();
        System.out.println("Gaji Pokok "+kk.gajiBonus);
        System.out.println("Gaji Bonus "+kk.gajiPokok);
        
    }
    
}
