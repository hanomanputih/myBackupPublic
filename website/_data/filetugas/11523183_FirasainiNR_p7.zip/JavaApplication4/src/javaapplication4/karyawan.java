/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication4;

/**
 *
 * @author PRAKTIKAN
 */
public abstract class karyawan {
    public int gajiPokok = 3000000;
    public int gajiTunjangan = 600000;
    public int gajiBonus = 300000;
    int gaji;
    
    
    public void view(){
        
    }
    public abstract void gaji();
    
}
