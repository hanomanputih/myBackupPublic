/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan1;

/**
 *
 * @author praktikan
 */
class Static {
    
}
