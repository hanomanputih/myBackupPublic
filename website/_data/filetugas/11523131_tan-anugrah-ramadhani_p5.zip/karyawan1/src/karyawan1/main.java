/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan1;

/**
 *
 * @author praktikan
 */
public class main {
    public static void main (String[] args){
        Karyawan1 K = new Karyawan1();
        K.setNip("11523131");
        System.out.println("nip anda " +K.getNip());
        K.setNama("tan");
        System.out.println("nama anda" +K.getNama());
        K.setGaji(50000);
        System.out.println("gaji anda setahun " +K.getGaji());
    }
    
}
