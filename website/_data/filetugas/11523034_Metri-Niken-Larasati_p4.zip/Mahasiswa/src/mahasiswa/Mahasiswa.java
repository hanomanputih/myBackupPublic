
package mahasiswa;

import java.util.Scanner;

public class Mahasiswa {
 String nama;
 String nim;
 String fakultas;
 String jurusan;
 String angkatan;
 
    public void cetak(){
        Mahasiswa m = new Mahasiswa ();
        Scanner reader = new Scanner(System.in);
        System.out.println("Masukkan nama anda: ");
        m.nama = reader.nextLine();
        System.out.println("Masukkan nim anda: ");
        m.nim = reader.nextLine();
        System.out.println("Dari fakultas mana: ");
        m.fakultas = reader.nextLine();
        System.out.println("Dari jurusan mana: ");
        m.jurusan = reader.nextLine();
        System.out.println("Anda angkatan berapa: ");
        m.angkatan = reader.nextLine();

        System.out.println("Nama: "+m.nama);
        System.out.println("NIM: " +m.nim);
        System.out.println("Fakultas: "+m.fakultas);
        System.out.println("Jurusan: "+ m.jurusan);
        System.out.println("Angkatan: " +m.angkatan);
        
    }
    public static void main(String[] args) {
      Mahasiswa mhs = new Mahasiswa();
      mhs.cetak();
    }
}
