/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postespertemuan4;

/**
 *
 * @author Praktikan
 */
public class Karyawan {
    private String nip;
    private String nama;
    private int gaji;
    
    public static void main(String[] args) {
        
    }

    public void setGaji(int gaji) {
        this.gaji = gaji;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public void setNip(String nip) {
        this.nip = nip;
    }

    public int getGaji() {
        return gaji;
    }

    public String getNama() {
        return nama;
    }

    public String getNip() {
        return nip;
    }

   
}
