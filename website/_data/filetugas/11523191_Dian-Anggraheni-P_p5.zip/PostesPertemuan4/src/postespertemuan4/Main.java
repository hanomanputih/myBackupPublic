/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postespertemuan4;

/**
 *
 * @author Praktikan
 */
public class Main {
    public static void main(String[] args) {
        Karyawan ka = new Karyawan();
        
        ka.setNip("115231911");
        System.out.println("NIM ="+ka.getNip());
        
        ka.setNama("Dian");
        System.out.println("Nama ="+ka.getNama());
        
        ka.setGaji(10000000*12);
        System.out.println("Gaji Setahun ="+ka.getGaji());
    }
    
}
