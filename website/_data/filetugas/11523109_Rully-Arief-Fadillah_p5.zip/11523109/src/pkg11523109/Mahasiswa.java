/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg11523109;

/**
 *
 * @author PRAKTIKAN
 */
public class Mahasiswa {
    public int nim;
    public String nama;
    
}
    public static void main(String[] args) {
   Mahasiswa = new mahasiswa(); 
   m.nim=5;
   m.nama="Fadil";
}
