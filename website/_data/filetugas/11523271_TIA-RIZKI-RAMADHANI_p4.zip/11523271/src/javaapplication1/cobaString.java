/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author Praktikan
 */
public class cobaString {
   String Kelakuan = "Lagi tidur ni";
   
    public static void main(String[] args) {
        cobaString cs = new cobaString ();
        
        System.out.println("diawali "+cs.Kelakuan.startsWith ("Lagi")); 
        System.out.println("diakhiri "+cs.Kelakuan.endsWith ("ni"));
        System.out.println("Panjang "+cs.Kelakuan.length());
        
        System.out.println(cs.Kelakuan.charAt(2));
    }
    
}
