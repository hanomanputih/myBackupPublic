/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
    
        String nama;
        String nim;
        String Jurusan;
        String Fakultas;
        
        float jumlah1;
        float jumlah2;
        float jumlah3;
        float jumlah4;
        float hitung;
        
        void cetak (){
            System.out.println("Nama : "+nama);
            System.out.println("Nim : "+nim);
            System.out.println("Jurusan : "+Jurusan);
            System.out.println("Fakultas : "+Fakultas);
        }
        
        public static void main(String[] args) {
        Mahasiswa mhs = new Mahasiswa ();
        mhs.nama = "Ririe";
        mhs.nim = "11523271";
        mhs.Jurusan = "Tek.Informatika";
        mhs.Fakultas = "Teknologi Industri";
//        
            mhs.jumlah1 = mhs.nama.length();
            mhs.jumlah2= mhs.nim.length();
            mhs.jumlah3 = mhs.Jurusan.length();
            mhs.jumlah4 = mhs.Fakultas.length();
           
      
           float hitung = mhs.jumlah1 + mhs.jumlah2 + mhs.jumlah3 + mhs.jumlah4;
            

           mhs.cetak();
//            
            System.out.println("Jumlah karakter : "+hitung);
          
            
        
    }
        
        

       
    
}
