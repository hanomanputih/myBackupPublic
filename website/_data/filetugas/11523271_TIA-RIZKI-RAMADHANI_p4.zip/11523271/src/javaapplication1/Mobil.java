/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author Praktikan
 */
public class Mobil {
    
    int ban;
    int spion;
    String merk;
    String plat;

    public static void main(String[] args) {
       Mobil mb = new Mobil();
       
       mb.merk = "Honda";
       mb.plat = "AB 123";
       mb.ban = 4;
       mb.spion = 2;
       
        System.out.println("merk : "+mb.merk);
        System.out.println("plat : "+mb.plat);
        System.out.println("Jumlah ban : "+mb.ban);
        System.out.println("Jumlah spion : "+mb.spion);
    }
    
}
