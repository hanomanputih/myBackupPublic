/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package multiclass;

/**
 *
 * @author PRAKTIKAN
 */
public class Prosesor {
    String merk;
    String tipe;
    public Prosesor(String nama , String typ){
        this.merk = nama;
        this.tipe = typ;
    }
    
}
