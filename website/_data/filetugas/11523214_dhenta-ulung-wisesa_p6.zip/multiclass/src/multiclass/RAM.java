/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package multiclass;

/**
 *
 * @author PRAKTIKAN
 */
public class RAM {
    String merk;
    String kapasitas;
    
    public RAM (String nama , String besar){
        this.merk = nama;
        this.kapasitas = besar;
    }
}

    
    
   