/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package multiclass;

import multiclass.Prosesor;

/**
 *
 * @author PRAKTIKAN
 */
public class Komputer {
    Prosesor pro;
    RAM ram;
    String spesifikasi;
    String jenis;
            
    public Komputer(String j , String sps){
        this.jenis = j;
        this.spesifikasi = sps;
        pro = new Prosesor("intel prosesor","core i7");
        ram = new RAM("AMD","4 GB");
    }

public void tampil(){
    System.out.println("jenis komputer  :"+jenis);
    System.out.println("Spesifikasi     :"+spesifikasi);
    System.out.println("Prosesor        :"+pro.merk);
    System.out.println("Type Prosesor   :"+pro.tipe);
    System.out.println("Kapasitas RAM   :"+ram.kapasitas);
    System.out.println("Merk RAM        :"+ram.merk);
    
}
 public static void main(String[] args) {
     Komputer K = new Komputer("gaming","minimum");
     K.tampil();
 }
    
}
