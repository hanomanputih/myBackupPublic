/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pt;

import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;


public class main {

    
    public static void masukkan (List<String> list, String masuk){
        list.add(masuk);
    }
            
    
    public static void main(String[] args) {
    Scanner sc = new Scanner(System.in); 
    List <String> list = new ArrayList <String>();
    HashMap map = new HashMap ();
    
        System.out.println("NIM Anda       :");
        String NIM = sc.next();
        masukkan(list,NIM);
        System.out.println("Nama Anda      :");
        String nama = sc.next();
        masukkan (list, nama);        
        
    }

}