/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package lanjutan;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
/**
 *
 * @author PRAKTIKAN
 */
public class Lanjutan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         List alamat= new ArrayList();
        
        alamat.add("Papua");
        alamat.add("Jakarta");
        alamat.add("Bandung");
        
        System.out.println(alamat);
        
        for(Object o :alamat){
        System.out.println(o);
    }
        
        System.out.println("+++++++++++++++++++++++++++++++++++++++++++++");
        Iterator it =alamat.iterator();
        while(it.hasNext()){
            System.out.println(it.next());
        }
  
    }
}
