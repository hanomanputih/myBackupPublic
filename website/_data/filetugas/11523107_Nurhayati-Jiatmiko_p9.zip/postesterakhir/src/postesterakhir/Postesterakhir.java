/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postesterakhir;

import java.util.Map;
import java.util.HashMap;
/**
 *
 * @author PRAKTIKAN
 */
public class Postesterakhir {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
          Map<String,String> nm= new HashMap<String,String>();
        
        nm.put("Papua","rifka");
        nm.put("Jakarta","Surya");
        nm.put("Balikpapan","Hantu");
        
        System.out.println(nm);
        
        System.out.println(nm.get("Hantu"));
        
        for (Map.Entry<String,String>e :nm.entrySet()){
            System.out.println(e.getKey()+" , "+e.getValue());
      
        }
        // TODO code application logic here
    
    }
}
