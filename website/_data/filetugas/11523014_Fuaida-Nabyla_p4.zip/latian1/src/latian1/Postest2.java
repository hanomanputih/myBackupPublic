/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package latian1;


/**
 *
 * @author PRAKTIKAN
 */
public class Postest2 {
    String nama = "nabyla";
    int nim = 11523014;
    
    public static void main (String[]args){
        Postest2 p = new Postest2() ;
        p.cetak();
       
    
    }
    public void cetak(){
        System.out.println("nama saya "+nama);
        System.out.println("nim saya "+nim);
    }
}
    
    
        

