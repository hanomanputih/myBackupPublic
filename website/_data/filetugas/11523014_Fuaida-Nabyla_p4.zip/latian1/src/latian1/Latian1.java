/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package latian1;

import java.util.Scanner;
/**
 *
 * @author PRAKTIKAN
 */
public class Latian1 {

    /**
     * @param args the command line arguments
     */
    String nama;
    int jumlah;
    
    public static void main(String[] args) {
       Latian1 l = new Latian1();
       Scanner baca = new Scanner (System.in);
        System.out.println("Masukkan nama anda: ");
        l.nama = baca.next();
        l.jumlah = l.nama.length();
        System.out.println("Panjang karakter nama Anda: "+l.jumlah);
    }
    
    
}
