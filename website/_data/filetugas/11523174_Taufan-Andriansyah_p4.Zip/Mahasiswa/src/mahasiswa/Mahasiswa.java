/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

import java.util.Scanner;

public class Mahasiswa {
String Nama;
String NIM;
String Fakultas;
String Jurusan;
String Angkatan;
int jumlah, jumlah2, jumlah3, jumlah4, jumlah5, total;

    public static void main(String[] args) {
    Mahasiswa c = new Mahasiswa();
    Scanner pembaca = new Scanner(System.in);
        System.out.println("Masukan Nama Anda: ");
        c.Nama = pembaca.next();
        c.jumlah = c.Nama.length();
        System.out.println("Masukan NIM Anda: ");
        c.NIM = pembaca.next();
        c.jumlah2 = c.NIM.length();
        System.out.println("Masukan Nama Fakultas Anda: ");
        c.Fakultas = pembaca.next();
        c.jumlah3 = c.Fakultas.length();
        System.out.println("Masukan Nama Jurusan Anda: ");
        c.Jurusan = pembaca.next();
        c.jumlah4 = c.Jurusan.length();
        System.out.println("Masukan Angkatan ke berapa Anda: ");
        c.Angkatan = pembaca.next();
        c.jumlah5 = c.Angkatan.length();
        c.total = c.jumlah+c.jumlah2+c.jumlah3+c.jumlah4+c.jumlah5;
        System.out.println("Panjang karakter nama Anda: "+c.total);
    }
}
