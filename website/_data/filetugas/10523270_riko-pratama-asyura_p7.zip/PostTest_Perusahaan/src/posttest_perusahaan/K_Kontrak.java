/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest_perusahaan;

/**
 *
 * @author PRAKTIKAN
 */
public abstract class K_Kontrak extends Karyawan {
    int gajiKontrak = (+gajiPokok + +bonus);

    @Override
    public void totalgaji() {
        System.out.println("Status Karyawan : Kontrak");
        super.viewGaji();
        System.out.println("=================================");
        System.out.println("Total Gaji      : " + gajiKontrak);

    }
}