/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest_perusahaan;

/**
 *
 * @author PRAKTIKAN
 */
public abstract class Karyawan {
    
    protected int gajiPokok = 3000000;
    protected int tunjangan = gajiPokok / 5;
    protected int bonus = 250000;

    
    
    public abstract void totalgaji();
    
    public void viewGaji(){
        System.out.println("Gaji Pokok      : "+gajiPokok);
        System.out.println("Bonus           : "+bonus);
    }
    

   
    
//    void view(){
//        System.out.println("Gaji Anda Bulan Ini : "+);
//    }
}
