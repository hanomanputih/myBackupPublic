/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest_perusahaan;

/**
 *
 * @author PRAKTIKAN
 */
public class PostTest_Perusahaan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        K_Tetap kt = new K_Tetap();
        kt.totalgaji();
        
        K_Kontrak kk = new K_Kontrak() {};
        kk.totalgaji();
        
        
    }
}
