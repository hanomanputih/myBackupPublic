/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest_perusahaan;

/**
 *
 * @author PRAKTIKAN
 */
public class K_Tetap extends Karyawan{
    int gajiTetap = (+gajiPokok + +tunjangan + +bonus);
    

    @Override
    public void totalgaji() {
        System.out.println("Status Karyawan : Tetap");
        super.viewGaji();
        System.out.println("Tunjangan       : "+tunjangan);
        System.out.println("=================================");
        System.out.println("Total Gaji      : "+gajiTetap);
        System.out.println("\n");
    }
    
}
