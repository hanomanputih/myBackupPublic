/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest.pkg5;

/**
 *
 * @author PRAKTIKAN
 */
public class komputer {
prosesor p;
ram c;
public String nama;
public komputer(String ini){
   nama=ini; 
if(nama.equals("1")){
   p=new prosesor("intel");

   c=new ram ("simbada");
}

}

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        komputer z=new komputer("1");
        System.out.println("jadi prosesor ini ini "+z.p.tipe);
        System.out.println("jadi ram ini "+z.c.merek);
    }
}
