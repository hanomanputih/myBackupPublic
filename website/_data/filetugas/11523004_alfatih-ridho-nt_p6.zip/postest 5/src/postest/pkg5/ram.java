/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest.pkg5;

/**
 *
 * @author PRAKTIKAN
 */
public class ram {
    public  String merek;
          public ram(String mrk){
              merek=mrk;
          }  
    

public void tampil(){
System.out.println("jenisnya"+merek);
}
    
}
