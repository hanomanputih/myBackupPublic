/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Komputer;

/**
 *
 * @author PRAKTIKAN
 */
public class Panggil {
    public static void main(String[] args) {
        RAM sanyo = new RAM ();
        sanyo.setKecepatan(50);
        PROSESOR axio = new PROSESOR();
        axio.setKapasitas(2000);
        
        Komputer SONY = new Komputer (axio,sanyo);
        System.out.println("kapasitas"+SONY.getProsesor().getKapasitas());
        System.out.println("kecepatan"+SONY.getRam().getKecepatan());
        
        
    }
}
