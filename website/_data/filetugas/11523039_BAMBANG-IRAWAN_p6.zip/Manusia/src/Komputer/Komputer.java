/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Komputer;

    
    

/**
 *
 * @author PRAKTIKAN
 */
public class Komputer {
     
     private PROSESOR prosesor;
     private RAM ram;
     public Komputer (PROSESOR a, RAM b){
         this.prosesor = a;
         this.ram = b;
         
     
     }

    public PROSESOR getProsesor() {
        return prosesor;
    }

    public void setProsesor(PROSESOR prosesor) {
        this.prosesor = prosesor;
    }

    public RAM getRam() {
        return ram;
    }

    public void setRam(RAM ram) {
        this.ram = ram;
    }

        
    }
}
