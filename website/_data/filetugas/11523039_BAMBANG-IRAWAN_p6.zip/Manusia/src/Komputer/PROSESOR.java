/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Komputer;

    
   
/**
 *
 * @author PRAKTIKAN
 */
public class PROSESOR {
    private int kapasitas;

    public int getKapasitas() {
        return kapasitas;
    }

    public void setKapasitas(int kapasitas) {
        this.kapasitas = kapasitas;
    }
    

   
    
    
    
    }

