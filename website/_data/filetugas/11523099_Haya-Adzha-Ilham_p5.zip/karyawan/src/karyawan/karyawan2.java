/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author PRAKTIKAN
 */
public class karyawan2 {
    public static void main(String[] args) {
        Karyawan krywn = new Karyawan();
        krywn.setGaji(60000000);
        krywn.setNama("haya");
        krywn.setNip("11523099");
        System.out.println("Gaji setahun anda adalah " + krywn.getGaji());
        System.out.println("Nama anda adalah " + krywn.getNama());
        System.out.println("Nip anda adalah " + krywn.getNip());
        
        
    }
}
