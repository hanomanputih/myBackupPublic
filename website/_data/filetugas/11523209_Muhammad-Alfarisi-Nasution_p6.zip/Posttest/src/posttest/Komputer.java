/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Komputer {
    String id_kom;
    Prosesor P;
    RAM R;
    public Komputer (String kom){
        this.id_kom = kom;
        if(id_kom.equals("ucok")){
            P = new Prosesor("CORE i7");
            R = new RAM ("8 GB");
        }
    }    
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        System.out.println("masukkan komputer milik siapa : ");
        Komputer kom = new Komputer(sc.next());
        
        System.out.println("Jenis PROSESOR"+kom.P.nama);
        System.out.println("Jumlah RAM"+kom.R.nama);
    }
}
