/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package testsatu;

/**
 *
 * @author Praktikan
 */
import java.util.Scanner;
public class Mahasiswa {
    String nama;
    String NIM, fakultas, jurusan,angkatan;
 
    void cetak(){
        System.out.println("Nama : "+nama);
        System.out.println("NIM : "+NIM);
        System.out.println("Fakultas : "+fakultas);
        System.out.println("Jurusan : "+jurusan);
        System.out.println("Angkatan : "+angkatan);
    }
    public static void main(String[] args) {
        Mahasiswa ys=new Mahasiswa();
        Scanner zz=new Scanner(System.in);
        System.out.print("Nama saya:");
        ys.nama = zz.nextLine();
        System.out.print("NIM saya: ");
        ys.NIM = zz.nextLine();
        System.out.print("Fakultas: ");
        ys.fakultas = zz.nextLine();
        System.out.print("Jurusan: ");
        ys.jurusan = zz.nextLine();
        System.out.print("Angkatan: ");
        ys.angkatan=zz.nextLine();
        ys.cetak();
        System.out.println("");
    }
    
}
