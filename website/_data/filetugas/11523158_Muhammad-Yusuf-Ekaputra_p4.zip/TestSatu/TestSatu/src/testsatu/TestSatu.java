/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package testsatu;

/**
 *
 * @author Praktikan
 */
public class TestSatu {
    String nama = "Yusuf Eka";
    public static void main(String[] args) {
        TestSatu ys=new TestSatu();
        System.out.println("karakter ke 6 : "+ys.nama.charAt(7));
        System.out.println("Kata depan nama saya "+ys.nama.startsWith("Yusuf"));
        System.out.println("Kata terakhir saya "+ys.nama.endsWith("Eka"));
        System.out.println("Panjang karakter nama saya "+ys.nama.length());
        for (int i=8;i<ys.nama.length();i--){
            System.out.println(ys.nama.charAt(i));
        }
    }
}
