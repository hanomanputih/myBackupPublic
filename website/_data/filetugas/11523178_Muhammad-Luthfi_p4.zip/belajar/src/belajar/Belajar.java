/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package belajar;
import java.util.Scanner;
/**
 *
 * @author Praktikan
 */
public class Belajar {
    String jenis;
    int harga;

    void isi(){
        Scanner read=new Scanner(System.in);
        System.out.println("inputkan jenis hp :");
        jenis = read.next();
        System.out.println("masukan harga hp");
        harga=read.nextInt();
    }
    void cetak(){
        System.out.println("jenis hp anda "+jenis);
        System.out.println("harga hp anda "+harga);
    }

    public static void main(String[] args){
        Belajar hp=new Belajar();
        hp.isi();
        hp.cetak();
    }
}
