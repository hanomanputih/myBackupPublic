/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package belajar;

/**
 *
 * @author Praktikan
 */
public class Coba {

    public static void main(String[] args){
        String nama="nico bryan franata";
        System.out.println("kata terakhir : "+nama.endsWith("franata"));
        System.out.println("kata pertama : "+nama.startsWith("nico"));
        System.out.println("ini buat apa ? "+nama.charAt(6));
        System.out.println("panjang karakter : "+nama.length());
    }

}
