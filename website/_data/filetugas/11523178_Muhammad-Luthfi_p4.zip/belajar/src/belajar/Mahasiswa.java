/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package belajar;
import java.util.Scanner;

public class Mahasiswa {
    String nama, nim, fakultas, jurusan, angkatan;
    int kar;
    void isi(){
        Scanner baru = new Scanner(System.in);
        System.out.println("Masukan Nama: ");
        nama = baru.nextLine();
        System.out.println("Masukan NIM: ");
        nim = baru.next();
        System.out.println("Masukan Fakultas: ");
        fakultas = baru.next();
        System.out.println("Masukan Jurusan: ");
        jurusan = baru.next();
        System.out.println("Masukan Angkatan: ");
        angkatan = baru.next();
    }

    void cetak(){
        System.out.println("Nama: "+nama);
        System.out.println("NIM : "+nim);
        System.out.println("Fakultas : "+fakultas);
        System.out.println("Jurusan : "+jurusan);
        System.out.println("Angkatan : "+angkatan);

    }
    void hitung(){
        System.out.println("jumlah karakter Nama anda "+nama.length());
        System.out.println("jumlah karakter NIM anda "+nim.length());
        System.out.println("jumlah karakter Fakultas "+fakultas.length());
        System.out.println("jumlah karakter Jurusan "+jurusan.length());
        System.out.println("jumlah karakter Angkatan "+angkatan.length());
    }
    public static void main(String[] args){
        Mahasiswa mh =new Mahasiswa();
        mh.isi();
        mh.cetak();
        mh.hitung();


    }
}
