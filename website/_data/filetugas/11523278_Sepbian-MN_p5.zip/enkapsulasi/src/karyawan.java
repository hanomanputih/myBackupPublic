/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Praktikan
 */
//ini BIAN
//NIM saya 11523278
 class karyawan {
   private String nama, nip;
   private int gaji;
    
       public void setnip(String fnip){
    nip=fnip;
   }
       public void setnama(String myname){
       nama=myname;
   }
         public void setgaji(){
       gaji=123546847;
   }
    public String getnama(){
   return(nama);
   }
   public String getnip(){   
   return(nip);
   } 
     public int getgaji(){
   return(gaji);
   }
   
}
