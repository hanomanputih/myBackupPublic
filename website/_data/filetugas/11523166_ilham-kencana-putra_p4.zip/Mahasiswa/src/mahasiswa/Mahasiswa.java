/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

/**
 *
 * @author PRAKTIKAN
 */
import java.util.Scanner;

public class Mahasiswa {
    String nama;
    String nim;
    String fakultas;
    String jurusan;
    String angkatan;
    int jumlah;
    
    void cetak(){
        Scanner pembaca = new Scanner(System.in);
        System.out.println("nama : ");
         nama = pembaca.nextLine();
        System.out.println("nim : ");
        nim = pembaca.nextLine();
        System.out.println("fakultas : ");
        fakultas = pembaca.nextLine();
        System.out.println("jurusan : ");
        jurusan = pembaca.nextLine();
        System.out.println("angkatan : ");
        angkatan = pembaca.nextLine();
        System.out.println("jumlah karakter : ");
        jumlah = nama.length()+ nim.length() + fakultas.length()+ jurusan.length()+ angkatan.length();

        System.out.println("nama : "+nama);
          System.out.println("nim : "+nim);
        System.out.println("fakultas : "+fakultas);
        System.out.println("jurusan : "+jurusan);
      System.out.println("angkatan : "+angkatan);
            System.out.println("jumlah karakter : "+jumlah);
    }
    
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Mahasiswa M = new Mahasiswa();
        M.cetak();
       
        // TODO code application logic here
    }
}
