/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

/**
 *
 * @author Praktikan
 */
public class Posttest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        List<String> list = new ArrayList();
        Scanner n = new Scanner(System.in);
        System.out.print("masukkan nama : ");
        list.add(n.next());
        System.out.println("masukkan nim: ");
        list.add(n.next());

        for (Iterator<String> iterator = list.iterator();
                iterator.hasNext();) {//untuk melihat isi List
            String isi = iterator.next();
            System.out.println(isi);
            System.out.println("index ke 2" + list.get(1));

            HashMap map = new HashMap();
            map.put("nama", n.next());
            map.put("nim", n.next());
            System.out.println("nama  : " + map.get("nama"));
            System.out.println("nim : " + map.get("nim"));

        }

    }
}
