/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication36;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class main {
    public static void main(String[] args) {
        List tes = new ArrayList();
        Scanner ts = new Scanner (System.in);
        Map<Integer,String> la = new HashMap<Integer, String>();
        String nama;
        String nim;
        System.out.print("Masukan Nama :");
        nama = ts.next();
        System.out.print("Masukan NIM :");
        nim = ts.next();
        
        tes.add(nama);
        tes.add(nim);
        
        la.put(1, nama);
        la.put(2, nim);
        
        System.out.println(tes);
        System.out.println(tes.size());
        System.out.println("--------------");
        
        for(Object zz : tes){
            System.out.println(zz);
        }
        System.out.println("---------------");
        Iterator it = tes.iterator();
        while(it.hasNext()){
            System.out.println(it.next());
        }
        
        for(int i = 0; i<tes.size();i++){
            System.out.println(tes.get(i));
        }
        
        for(Map.Entry<Integer,String> ee : la.entrySet()){
            System.out.println("----------------");
            System.out.println(ee.getKey()+"."+ee.getValue());
        }
    }
}
