/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest_3;

import java.util.Scanner;

/**
 *
 * @author PRAKTIKAN
 */
public class mahasiswa {
   String nama;
   String nim;
   String fakultas;
   String jurusan;
   String angkatan;
void cetak() {
    System.out.println("nama anda "+nama +" nim anda "+nim + " fakultas anda " +fakultas +" jurusan anda "+jurusan +" angkatan anda "+angkatan) ;
    
}
    public static void main(String[] args) {
        Scanner baca = new Scanner (System.in);
        mahasiswa mhs1= new mahasiswa ();
        System.out.println("nama anda = ");
        mhs1.nama = baca.next();
        System.out.println("nim anda = ");
        mhs1.nim = baca.next();
        System.out.println("fakultas anda = ");
        mhs1.fakultas = baca.next();
        System.out.println("jurusan anda = ");
        mhs1.jurusan = baca.next();
        System.out.println("angkatan anda = ");
        mhs1.angkatan = baca.next();
        System.out.println("selamat anda tampan ");
        mhs1.cetak();
    }
    }

