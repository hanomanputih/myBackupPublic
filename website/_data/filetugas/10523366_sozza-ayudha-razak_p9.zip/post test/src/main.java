
import java.util.HashMap;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author PRAKTIKAN
 */
public class main {
    
      public static void main(String[] args) {
        HashMap map = new HashMap ();
        
        map.put("Nama ", "soza");
        map.put("NIM ", new Integer(10523366));
          System.out.println("==========");
        System.out.println(map);
        System.out.println("ukuran map :"+map.size());
       
        
    
      }
}
