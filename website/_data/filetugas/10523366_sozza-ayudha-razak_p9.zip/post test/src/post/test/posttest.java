/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package post.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

/**
 *
 * @author PRAKTIKAN
 */
public class posttest {
    
    String nama;
    int nim;

   
    public static void main(String[] args) {
        ArrayList list = new ArrayList();
        list.add("nama :soza");
        list.add("NIM :10523366");
        System.out.println("ukuran list "+list.size ());
       
       
        for(Iterator iterator = list.iterator(); iterator.hasNext();) {
            String ii = (String) iterator.next();
            System.out.println("isi : "+ ii);
        
             HashMap map = new HashMap ();
        
        map.put("Nama ", "soza");
        map.put("NIM ", new Integer(10523366));
          System.out.println("==========");
        System.out.println(map);
        System.out.println("ukuran map :"+map.size());
       
        
    }
    }
        
}
}

