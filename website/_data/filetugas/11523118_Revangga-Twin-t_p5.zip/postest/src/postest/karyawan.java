/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

/**
 *
 * @author Praktikan
 */
public class karyawan {
    private String nip;
    private String nama;
    private int gaji;

    void setNIP(String nip){
        if(nip.length() > 5){
            this.nip = nip;
        }else{
            System.out.println("eror");
            
        }
    
    }
    String getNIP(){
    return nip;}
    
    void setNAMA(String nama){
        if(nama.length() >= 6){
          this.nama = nama;
        }else{
            System.out.println("eror");
        }
  
    }String getNAMA(){
    return nama;}
    
void setGAJI(int gaji){
    if(gaji  < 10000000){
        this.gaji = gaji;
    }else{
        System.out.println("eror");
    }
}
int getGAJI(){
    return gaji;
}}


