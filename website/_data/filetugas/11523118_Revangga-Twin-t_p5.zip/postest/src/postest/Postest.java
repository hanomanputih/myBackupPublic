/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

/**
 *
 * @author Praktikan
 */
public class Postest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        karyawan a = new karyawan();
        karyawan b = new karyawan();
        karyawan c = new karyawan();
        
        
        a.setNIP("123456");
        System.out.println("nip              =" +a.getNIP());
        b.setNAMA("revangga");
        System.out.println("nama             ="+ b.getNAMA());
        c.setGAJI(110000 * 12);
        System.out.println("gaji satu tahun  =Rp"+ c.getGAJI());
        
     
        
    }
}
