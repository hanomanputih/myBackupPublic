/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest8;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
/**
 *
 * @author PRAKTIKAN
 */
public class PostTest8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Map <String,Integer>nama = new HashMap<String,Integer>();
       
       nama.put("Krisna",11523040);
       nama.put("Djaka", 11523005);
       nama.put("Endro", 11523003);
       
       for (Map.Entry<String,Integer> e : nama.entrySet()){
            System.out.println(e.getKey()+", " +e.getValue());
        }
        System.out.println(nama.get("Krisna"));
    }
}
