/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package PostTest4;

/**
 *
 * @author Praktikan
 */
public class mainTest {
    public static void main(String[] args)
    {
        Karyawan kry = new Karyawan();
        kry.setGaji(50000000);
        kry.setNip("12523208");
        kry.setNama("Avif Ardiansyah");
        
       System.out.println("Nip anda " +kry.getNip()+"  "+kry.getNama()+" dengan gaji " +kry.getGaji());
    }
    
}
