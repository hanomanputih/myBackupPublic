/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class Karyawan {
    private String nip;
    private String nama;
    private int gaji;
    
    public void setGAJI ( double jiga){
        gaji = (int) jiga;
    }
    public double getGAJI (){
        return gaji;
    }
        
    }
    

    /**
     * @param args the command line arguments
     */
public class Karyawan {
    
    public static void main(String[] args) {
        Karyawan yahya = new Karyawan ();
    }
}
