/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class Karyawan {
private String nip, nama;
private int gaji;
  
 
public void setNip(String nip){
   this.nip = nip; 
}
    
public void setNama(String nama){
this.nama = nama;
}

public void setGaji (int gaji){
  this.gaji = gaji*12;
}

public String getNip()
{
    return nip;
}
public String getNama()
{       return nama;
}
public int getGaji()
{        return gaji;
}
}
