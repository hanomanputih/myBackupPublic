/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;


public class Main {
    public static void main(String[] args) {
        
        Karyawan m=new Karyawan();
        m.setNip("1000");
        m.setNama("Hajimete");
        m.setGaji(20000);
        System.out.println("nip anda adalah :" +m.getNip());
        System.out.println("nama kowe :" +m.getNama());
        System.out.println("gaji kowe :" +m.getGaji());
    }
}
