package postestpertemuan4;

public class Karyawan {

    private String nip;
    private String nama;
    private int gaji;

    void setNIP(String nip) {
        if (nip.length() == 8) {
            this.nip = nip;
        } else {
            System.out.println("Error !!!!!!!");
        }
    }

    void setNama(String nama) {
        this.nama = nama;
    }

    void setGaji(int gaji) {
        this.gaji = gaji;
    }

    String getNIP() {
        return nip;
    }

    String getNama() {
        return nama;
    }

    int getGaji() {
        return gaji;
    }
    
    int gajiSetahun() {
        int setahun = getGaji() * 12;
        return setahun;
    }
}
