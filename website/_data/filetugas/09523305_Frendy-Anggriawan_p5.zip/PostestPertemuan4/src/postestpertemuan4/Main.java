package postestpertemuan4;

public class Main {

    public static void main(String[] args) {
        Karyawan karyawan = new Karyawan();
        karyawan.setNIP("09523305");
        karyawan.setNama("Frendy Anggriawan");
        karyawan.setGaji(15000000);

        System.out.println("NIP             : " + karyawan.getNIP());
        System.out.println("Nama            : " + karyawan.getNama());
        System.out.println("Gaji Setahun    : " + karyawan.gajiSetahun());
    }
}
