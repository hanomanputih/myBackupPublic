/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komposisi;

/**
 *
 * @author PRAKTIKAN
 */
public class ram {
    String jenisRam;

    public ram (String merk) {
        this.jenisRam = merk;
    }
}