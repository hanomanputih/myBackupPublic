/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komposisi;

/**
 *
 * @author PRAKTIKAN
 */
public class Prosesor {
   String jenisProsesor;
  
   public Prosesor (String merk){
       this.jenisProsesor = merk;
   }
}
