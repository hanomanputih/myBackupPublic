/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komposisi;

/**
 *
 * @author PRAKTIKAN
 */
public class Komputer {
    String jenisKom;
    Prosesor P;
    ram R;
    
    public Komputer (String k,String p, String r){
        this.jenisKom = k;
        P = new Prosesor (p);
        R = new ram (r);
    }
    
    public void tampilKomp(){
        System.out.println("Jenis komputer  :"+jenisKom);
        System.out.println("Kecepatan       :"+P.jenisProsesor);
        System.out.println("Merk            :"+R.jenisRam);
    }
    public static void main(String[] args) {
        Komputer k = new Komputer ("Gaming", "A", "2Gb");
        //k.P.jenisProsesor = "2Gb";
        //k.R.jenisRam = "AMD";
        
        k.tampilKomp();
        // TODO code application logic here
    }
}
