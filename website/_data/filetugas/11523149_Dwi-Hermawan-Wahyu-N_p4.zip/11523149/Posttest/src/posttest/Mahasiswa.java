/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {

    static String nama ;
    static String nim ;
    static String fakultas ;
    static String jurusan ;
    static String angkatan ;

    static void cetak() {
        System.out.println("Nama = " + nama);
        System.out.println("Nim = " + nim);
        System.out.println("Fakultas = " + fakultas);
        System.out.println("Jurusan = " + jurusan);
        System.out.println("Angkatan = " + angkatan);

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner s = new Scanner (System.in);
        System.out.println("Masukkan Nama");
        nama = s.nextLine();
        System.out.println("Masukkan NIM");
        nim = s.nextLine();
        System.out.println("Masukkan Fakultas");
        fakultas = s.nextLine();
        System.out.println("Masukkan Jurusan");
        jurusan = s.nextLine();
        System.out.println("Masukkan angkatan");
        angkatan = s.nextLine();
        cetak();
    


}}
