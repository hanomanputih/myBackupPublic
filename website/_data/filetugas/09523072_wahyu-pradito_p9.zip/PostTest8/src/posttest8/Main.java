/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest8;

import	Perkuliahan.Mahasiswa;
import	java.util.HashSet;
import java.util.Set;

/**
 *
 * @author Praktikan
 */
public class Main {
    public static void main(String[] args) {
        Set<Mahasiswa> set = newHashSet<Mahasiswa>();
        Mahasiswa a = new Mahasiswa();
        a.setNama("Wahyu pradito");
        a.setNim (072);
        set.add(a);
        
        Mahasiswa b = new Mahasiswa ();
        a.setNama("Wahyu aja");
        a.setNim (007);
        
         for(Mahasiswa m : set){
            System.out.println("Nim     : "+m.getNim());
            System.out.println("Nama    : "+m.getNama());
        
    }
}
}