/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package posttest;

/**
 *
 * @author Praktikan
 */
public class Mahasisa {
    String nama, nim;

    void isi(){
        nama = "Gatot Saida";
        nim = "09523251";
    }

    void cetak(){
        System.out.println("nama eyke"+nama);
        System.out.println("nim eyke"+nim);
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Mahasisa ms = new Mahasisa();
       
ms.isi();
        ms.cetak();

        // TODO code application logic here
    }

}
