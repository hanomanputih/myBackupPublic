/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javamain;

import java.util.ArrayList;
import java.util.List;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.HashMap;

public class JavaMain {

    private static void loadData(List<String> list) {
        list.add("nol");
        list.add("satu");
    }

    private static void tampilkanList(List<String> list) {
        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i) + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        List<String> list = new ArrayList<String>();
        loadData(list);
        tampilkanList(list);

        System.out.println("list di index ke 1 = " + list.get(0));
        HashMap map = new HashMap();
        map.put("Nama ", "Fadil");
        map.put("NIM ", new Integer(9523257));
        System.out.println(map);
        System.out.println("Ukuran Map : " + map.size());
        boolean containKey = map.containsKey("NIM");
        System.out.println("Has key (NIM) : " + containKey);
        Object removed = map.remove("NIM");
        System.out.println("Removed : " + removed);
        System.out.println(map);
        System.out.println("Ukuran Map baru : " + map.size());


    }
}
