/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

/**
 *
 * @author PRAKTIKAN
 */
public class Mahasiswa {

 String nama = "Pandu Pramudito";
 String Nim = "11523257";
 String Fakultas = "Teknik industr";
 String Jurusan = "Teknin informatika";
 String Angkatan = "2011";
 String Hobi = "Futsal";
 void cetak()
 {
     System.out.println("Nami kula yaiku = " +nama);
     System.out.println("Nim kula yaiku = " + Nim );
     System.out.println("fakultas kula yaiku = " + Fakultas);
     System.out.println("Jurusan kula yaiku = " + Jurusan);
     System.out.println("Angkatan kula yaiku = "+ Angkatan);
     System.out.println("Hobi kula yaiku = " + Hobi);
     
 }
         
    public static void main(String[] args) {
        
        Mahasiswa mhs = new Mahasiswa ();
        mhs.cetak();
        
        
        
    }
}
