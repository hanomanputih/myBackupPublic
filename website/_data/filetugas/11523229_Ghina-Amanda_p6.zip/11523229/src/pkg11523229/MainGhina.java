/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg11523229;

/**
 *
 * @author Praktikan
 */
public class MainGhina {
    public static void main(String[] args) {
        Ram ra = new Ram("100 GB");
        Prosesor ps = new Prosesor("Intel");
        Cpu cp = new Cpu("biru", ra, ps);
        cp.tampil(ra, ps);
            
    }
    
}
