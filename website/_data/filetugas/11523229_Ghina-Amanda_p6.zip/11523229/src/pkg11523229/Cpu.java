/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg11523229;

/**
 *
 * @author Praktikan
 */
public class Cpu {
    String warna;
    Ram rm;
    Prosesor pr;
    public Cpu (String warna, Ram rm, Prosesor pr) {
        this.warna = warna;
        this.rm = rm;
        this.pr = pr;
    }
    public void tampil(Ram rm, Prosesor pr) {
        System.out.println("Warna CPU : " + warna);
        System.out.println("Kapasitas RAM : " + rm.kapasitas);
        System.out.println("Merk prosesor : " + pr.merk);
}
}
