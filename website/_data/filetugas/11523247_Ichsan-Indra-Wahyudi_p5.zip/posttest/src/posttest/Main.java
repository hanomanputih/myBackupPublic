
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

 
public class Main {
    
    public static void main(String[] args) {
      Karyawan kry = new Karyawan();
      
      kry.setNip("11523247");
      kry.setNama("Ichsan Indra Wahyudi");
      kry.setGaji(2000000);
      
        System.out.println("NIP anda adalah "+kry.getNIP());
        System.out.println("Nama anda adalah "+kry.getNama());
        System.out.println("Gaji anda adalah "+kry.getGaji());
    }
}
