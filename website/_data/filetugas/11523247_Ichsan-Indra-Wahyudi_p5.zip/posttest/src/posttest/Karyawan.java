/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author Praktikan
 */
public class Karyawan {
    
       private String nip ;
       private String nama;
       private int gaji;   

public void setNip(String n){
nip = n;
}
public void setNama(String n){
nama = n;
}
public void setGaji(int n){
gaji = n*12;
}
public String getNama(){
return nama;
}       
public String getNIP(){
return nip;
}
public int getGaji(){
return gaji;
}
}