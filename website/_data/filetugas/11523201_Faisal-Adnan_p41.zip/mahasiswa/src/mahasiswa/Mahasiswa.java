/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
    String nama, nim, fakultas, angkatan, jurusan;
    
    void masukan(){
        Scanner z =new Scanner(System.in);
        
        System.out.println("siapa nama:");
        nama=z.next();
        System.out.println("berapa nim:");
        nim=z.next();
        System.out.println("apa fakultas:");
        fakultas=z.next();
        System.out.println("berapa angkatan:");
        angkatan=z.next();
        System.out.println("apa jurusan:");
        jurusan=z.next();
        
        
        
    }
    
    void cetak(){
        System.out.println("siapa nama anda: "+nama);
        System.out.println("berapa nim anda: "+nim);
        System.out.println("apa fakultas anda: "+fakultas);
        System.out.println("apa jurusan:"+jurusan);
        System.out.println("angkatan berapa anda:"+angkatan);
        System.out.println("panhang karakter nama: "+nama.length());
        System.out.println("panjang nim"+nim.length());
        System.out.println("panjang fakultas"+fakultas.length());
        System.out.println("panjang jurusan"+jurusan.length());
        System.out.println("panjang angkatan"+angkatan.length());
    }

    public static void main(String[] args) {
        Mahasiswa mhs=new Mahasiswa();
        mhs.masukan();
        mhs.cetak();
        
        
        
    }
}
