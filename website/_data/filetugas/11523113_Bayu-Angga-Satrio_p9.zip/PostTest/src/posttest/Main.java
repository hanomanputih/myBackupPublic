/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;  

/**
 *
 * @author PRAKTIKAN
 */
public class Main {
    
    public static void main(String[] args){
        
        ArrayList program = new ArrayList();
        Scanner s =new Scanner(System.in);
        Map<Integer,String> lalala = new HashMap<Integer, String>();
        
        String nama;
        String nim;
        System.out.println("Masukkan nim");
        nim = s.next();
        System.out.println("Masukkan nama");
        nama = s.next();
        program.add(nim);
        program.add(nama);
        
        System.out.println(program);
        System.out.println(program.size());
        
        Iterator itt = program.iterator();
        while(itt.hasNext()){
            System.out.println(itt.hasNext());
        }
        
        
    }
}
