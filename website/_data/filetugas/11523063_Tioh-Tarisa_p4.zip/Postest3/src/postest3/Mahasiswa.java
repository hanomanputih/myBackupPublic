/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest3;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
    
    /**
 *
 * @author Praktikan
 */
    String nama;
    String nim;
    void cetak(){
        System.out.println("nama anda =" +nama+ "nim anda ="+nim );
    }
    
        public static void main(String[] args) {
        // TODO code application logic here
            Scanner pembaca = new Scanner(System.in);
            Mahasiswa mhs = new Mahasiswa();
            System.out.print("siapa nama anda?");
            mhs.nama = pembaca.next();
            System.out.print("berapa nim anda?");
            mhs.nim = pembaca.next();
           mhs.cetak();
    
                
    }}
    

