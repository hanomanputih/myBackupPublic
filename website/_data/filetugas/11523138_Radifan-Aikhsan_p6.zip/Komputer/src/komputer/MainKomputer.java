/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class MainKomputer {
    public static void main(String[] args) {
    RAM ram = new RAM ("2 ggya");
    Prosesor pro = new Prosesor ("i5");
    Komputer kom = new Komputer ("Windows 8", ram ,pro);
    kom.tampil(ram);
    
}
}