/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class Komputer {
    String namaKomputer;
    RAM ra;
    Prosesor pr;
    
    public Komputer (String namaKomputer, RAM ra ,Prosesor pr){
        this.namaKomputer = namaKomputer;
        this.ra= ra;
        this.pr= pr;
    }
    public void tampil(RAM ra){
        System.out.println("Nama Komputer : "+namaKomputer);
        System.out.println("Besaran : "+ra.Besaran);
        System.out.println("Kecepatan :"+pr.kecepatan);
    }
    public void tampil(Prosesor pr){
        System.out.println("Nama Komputer : "+namaKomputer);
        System.out.println("Kecepatan : "+pr.kecepatan);
        System.out.println("Besaran :"+ra.Besaran);
    }
}
