/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan3;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
    String nama,NIM,fakultas,jurusan,angkatan;
    
    void isiData(){
        Scanner n = new Scanner(System.in);
        System.out.println("masukkan nama= ");
        nama=n.next();
        System.out.println("masukkan nim= ");
        NIM=n.next();
        System.out.println("masukkan fakultas= ");
        fakultas=n.next();
        System.out.println("masukkan jurusan= ");
        jurusan=n.next();
        System.out.println("masukkan angkatan= ");
        angkatan=n.next();
        
    }  
    void cetak(){    
        System.out.println("nama = "+nama);
        System.out.println("NIM = "+NIM);
        System.out.println("fakultas ="+fakultas);
        System.out.println("jurusan ="+jurusan);
        System.out.println("angkatan ="+angkatan);
        
        
    }
    public static void main(String[] args) {
        Mahasiswa m = new Mahasiswa();
        m.isiData();
        m.cetak();
        
        
    }
}
