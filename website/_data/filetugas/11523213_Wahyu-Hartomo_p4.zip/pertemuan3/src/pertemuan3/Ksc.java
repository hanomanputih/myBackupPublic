/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan3;

/**
 *
 * @author Praktikan
 */
public class Ksc {
    String belajar = "aku ingin belajar";
    public static void main(String[] args) {
        Ksc ksc = new Ksc();
        System.out.println("kata pertama = " +ksc.belajar.startsWith("aku"));
        System.out.println("kata kedua ="+ksc.belajar.endsWith("belajar"));
        System.out.println("kata panjang karakter ="+ksc.belajar.length());
    }
    
}
