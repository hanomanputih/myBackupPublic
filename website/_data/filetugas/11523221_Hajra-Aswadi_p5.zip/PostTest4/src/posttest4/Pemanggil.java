/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package posttest4;

/**
 *
 * @author Praktikan
 */
public class Pemanggil {
    public static void main(String[] args) {
        Karyawan karyawan1 = new Karyawan ();

        karyawan1.setNip("11523221");
        karyawan1.setNama("Hajra Aswadi");
        karyawan1.setGaji(5000000);


        System.out.println("Nip : " +karyawan1.getNip());
        System.out.println("Nama: " +karyawan1.getNama());
        System.out.println("Gaji: " +karyawan1.getGaji()*12);

    }

}
