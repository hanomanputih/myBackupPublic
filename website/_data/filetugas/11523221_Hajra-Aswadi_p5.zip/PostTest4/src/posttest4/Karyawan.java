/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package posttest4;

public class Karyawan {
    private String nip;
    private String nama;
    private int gaji;

    public void setNip(String nipAnda){
        if (nipAnda.length()==8){
            nip=nipAnda;
        } else {
            System.out.println("Error");
        }
    }
    public void setNama (String namaAnda) {
        if (namaAnda.length()>=15){
        nama=namaAnda;
    } else {
            System.out.println("Error");
    }
    }
    public void setGaji (int gajiAnda) {
        gaji=gajiAnda;
    }
    public String getNip(){
        return nip;
    }
    public String getNama(){
        return nama;
    }
    public int getGaji () {
        return gaji;
    }
    public static void main(String[] args) {
        // TODO code application logic here
    }

}
