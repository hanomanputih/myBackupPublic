
package main;

public class Main {

    
    public static void main(String[] args) {
        
         public static void main (String[] args){
        List<String> list = new LinkedList();//deklarasi
        list.add("-2.  NAMA");
        list.add("-1. NIM");//memasukan data
        
        System.out.println("NAMA & NIM --> " + list.size());//jumlah data
        Collections.sort(list);//mensortit data
        
        for (Iterator<String> iterator = list.iterator ();
                iterator.hasNext();) {//untuk melihat isi list
            String isi = iterator.next();
            System.out.println(isi);
        
    }
    }
}

//