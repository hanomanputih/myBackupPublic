/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package swalaayan;

/**
 *
 * @author Praktikan
 */
public class tokoAgung extends Swalaayan{
    
    void menghitung(){
        sisa = (int) (harga % 25);
        bayar = (int) (harga - sisa);
        System.out.println("Harga bayar tokoAgung : "+bayar);
        
    }
    
    @Override
    void tampil(){
        menghitung();
    }
  
}
