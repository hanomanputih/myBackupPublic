/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package swalaayan;

/**
 *
 * @author Praktikan
 */
public class indomaret extends Swalaayan {
    
    
    
    void perhitungan(){
    if( harga % 25 == 0){
    System.out.println("Harga bayar indomaret : "+harga);
    }else
    {
    sisa =  (int) (25 - (harga % 25));
    bayar = (int) (harga+sisa);
        System.out.println("Harga bayar indomaret : "+ bayar);
    }
        
    }
    
    @Override
    void tampil(){
        perhitungan();
    }
}
