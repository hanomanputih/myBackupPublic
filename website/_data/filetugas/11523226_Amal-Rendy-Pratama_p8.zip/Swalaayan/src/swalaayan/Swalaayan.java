/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package swalaayan;

/**
 *
 * @author Praktikan
 */
public class Swalaayan {
    
    float harga;
    int sisa;
    int bayar;
    
void tampil(){
    
}   

   
}
