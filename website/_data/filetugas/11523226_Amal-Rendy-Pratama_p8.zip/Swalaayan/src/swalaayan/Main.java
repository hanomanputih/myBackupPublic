/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package swalaayan;

/**
 *
 * @author Praktikan
 */
public class Main {
    
    public static void main(String[] args) {
        Swalaayan s;
        indomaret i = new indomaret();
        s = i;
        s.harga = 19212;
        s.tampil();
        
        tokoAgung t = new tokoAgung();
        s = t;
        s.harga = 19212;
        s.tampil();
        
       
    }
}
