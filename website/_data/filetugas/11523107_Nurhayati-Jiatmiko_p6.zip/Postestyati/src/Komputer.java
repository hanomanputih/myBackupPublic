/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Praktikan
 */
public class Komputer {
     String nmKomputer;
     Prosesor pa;
     Ram ram;
     
     
     public Komputer(String nmKomputer, String pa, String ram){
         this.nmKomputer=nmKomputer;
         this.pa= new Prosesor(pa);
         this.ram= new Ram(ram);
         
         
     }
     public void tampil(){
         System.out.println("Nama komputer:"+nmKomputer);
         System.out.println("Kecepatan prosesor :"+pa.kecepatan);
         System.out.println("Ukuran RAM :"+ram.ukuran);
     }
     
     public static void main(String[] args){
         Komputer k=new Komputer("Yati","1779","2000");
         k.tampil();
     }
}
