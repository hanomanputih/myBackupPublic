/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package praktikum8;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author PRAKTIKAN
 */
public class Main {
    
    public static void main(String[] args) {
        
         List<String> list1 = new ArrayList<String>();
        
         list1.add("nim: 11523195");
         list1.add("nama MHS : vina");
         
}
    }
    

