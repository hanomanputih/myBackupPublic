/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package posttest;

/**
 *
 * @author praktikan
 */
public class karyawan {
private String nama;
private String nip;
private int gaji;

public void setNIP(String nip){
    this.nip=nip;
    }
public void setNAMA(String nama){
    this.nama=nama;
    }
public void setGaji(int gaji){
    this.gaji=gaji;
}
    public String getNIP(){
        return nip;
    }
    public String getNAMA(){
        return nama;

    }
    public int getGaji(){
        return gaji;
    }
}


