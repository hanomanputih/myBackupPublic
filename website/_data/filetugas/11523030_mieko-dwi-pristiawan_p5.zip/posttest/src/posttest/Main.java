/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package posttest;

/**
 *
 * @author praktikan
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        karyawan kry=new karyawan();
        String NIP ="11523030";
        String nama = " mieko ";
        int gaji = 5400000;
        kry.setNIP("11523030");
        kry.setNAMA(" mieko");
        kry.setGaji(gaji);
        System.out.println("NIP : "+kry.getNIP());
        System.out.println("Nama : "+kry.getNAMA());
        System.out.println("gaji : RP "+kry.getGaji());

    }

}
