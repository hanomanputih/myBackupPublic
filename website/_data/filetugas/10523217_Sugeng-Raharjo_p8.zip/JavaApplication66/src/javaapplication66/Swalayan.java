/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javaapplication66;

import java.util.Scanner;

/**
 *
 * @author praktikan
 */
public class Swalayan {
    Scanner s = new Scanner(System.in);
    public float harga;
    int bayar, sisa;

public void carapembayaran(){
    
}
}
