/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javaapplication66;

/**
 *
 * @author praktikan
 */
public class Indomart extends Swalayan {

    @Override
public void carapembayaran(){
        System.out.println("Masukan Pemabayaran : ");
        harga=s.nextFloat();
        if(harga % 25 == 0){
        bayar = (int) harga;
        System.out.println("Anda harus membayar : "+bayar);
    }else{
         sisa = (int) (25 - (harga % 25));
         bayar = (int) (harga + sisa);
         System.out.println("anda harus membayar : "+bayar);
         System.out.println("");
    }
}
}
