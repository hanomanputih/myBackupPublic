/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javaapplication66;

/**
 *
 * @author praktikan
 */
public class Toko_agung extends Swalayan{

    @Override
    public void carapembayaran(){

        System.out.println("masukkan harga barang :");
        harga = s.nextFloat();
        harga = super.harga;
        sisa = (int) (harga % 25);
        bayar = (int) (harga - sisa);
        System.out.println("andaharus membayar : " + bayar);
    
    }
}
