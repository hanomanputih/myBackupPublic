/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package multiclass;

/**
 *
 * @author PRAKTIKAN
 */
public class CPU {
    public int ProdukNumber;
    public PROSESOR p;
    public RAM r;
   
    public CPU (int ProdukNumber) {
        this.ProdukNumber = ProdukNumber;
        if (ProdukNumber ==1){
            p = new PROSESOR ("AMD");
            r = new RAM ("gigabyte");
          
        }
        }
    public void  tampilCPU(){
        System.out.println("Nama PROSESOR :  " +p.nama );
        System.out.println("Kapasitas RAM :  " +r.nama);
    }
    public static void main (String[] args){
        CPU com = new CPU(1);
        com.tampilCPU();
        
    }
}
    
    
        
     
