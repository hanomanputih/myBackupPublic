/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package multiclass;

/**
 *
 * @author PRAKTIKAN
 */
public class PROSESOR {
    String nama;
    
    public PROSESOR (String name){
        nama = name;
    }
    public void PROSESOR (){
        PROSESOR AMD = new PROSESOR("AMD");
        System.out.println("Nama PROSESOR :     " + AMD);
    }
}
