/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg11523228;

/**
 *
 * @author PRAKTIKAN
 */
public class putra {
    public static void main (String[] args){
        karyawan k=new karyawan();
        k.setNip("11523228");
        System.out.println("nip anda" +k.getNip());
        k.setNama("putra");
        System.out.println("nama anda" +k.getNama());
        k.setGaji(2000);
        System.out.println("gaji anda" +k.getGaji());
        
        
    }
}
