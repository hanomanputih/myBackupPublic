/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

/**
 *
 * @author PRAKTIKAN
 */
public class Main {

    
     
    public static void main(String[] args) {
        karyawan kry = new karyawan();
        kry.setnip("1234567890");
        kry.setnama("amaliaaa");
        kry.setgaji(500000);
        
        System.out.println("nama: "+kry.getnama());
        System.out.println("nip : "+kry.getnip());
        System.out.println("gaji setahun: "+kry.getgaji());
    }
}
