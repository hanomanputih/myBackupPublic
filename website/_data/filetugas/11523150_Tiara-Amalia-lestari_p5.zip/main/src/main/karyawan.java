/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

/**
 *
 * @author PRAKTIKAN
 */
public class karyawan {
    private String nip;
    private String nama;
    private int gaji;
    
    
   void setnip(String n) {
       nip = n;
       if (n.length()==10) {
           nip = n;
       }else{
           System.out.println("nip idak sesuai");
       }
   }
   
   String getnip() {
       return nip;
   }
   
   void setnama(String a) {
       nama = a;
       if (a.length()>=8) {
           nama = a;
       }else{
           System.out.println("nama anda berlebihan");
       }
   }
   String getnama(){
       return nama;
   }
   
   void setgaji (int g) {
       gaji = g;
       if (g>100000&&g<=500000) {
           gaji = g;
       }else{
           System.out.println("gaji anda berlebihan");
       }
   }
   
   int getgaji(){
       return gaji;
   }
}
