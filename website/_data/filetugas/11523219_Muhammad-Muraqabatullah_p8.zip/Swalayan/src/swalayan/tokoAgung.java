/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package swalayan;

/**
 *
 * @author Praktikan
 */
public class tokoAgung extends Swalayan {
    
    
    @Override
    void tampil (){
        sisa = (int) (harga % 25);
        System.out.println("rincian toko Agung");
        System.out.println("Sisa :"+sisa);
        bayar = (int) (harga - sisa);
        System.out.println("Bayar :"+ bayar);
    }

}
