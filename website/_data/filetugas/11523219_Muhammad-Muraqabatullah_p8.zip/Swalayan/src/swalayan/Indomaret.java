/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package swalayan;

/**
 *
 * @author Praktikan
 */
public class Indomaret extends Swalayan{
    
    @Override
    void tampil (){
        if (harga % 25 ==0){
            System.out.println("Rincian indomaret");
            System.out.println("harga :"+harga);
           } else{
            sisa= (int) (25-(harga % 25));
            System.out.println("Sisa :"+sisa);
            bayar = (int) (harga + sisa);
            System.out.println("Bayar :"+ bayar);
        }
            
}

 
    
}
