/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package swalayan;

/**
 *
 * @author Praktikan
 */
public class Swalayan {
    float harga = 19212;
    int sisa;
    int bayar;
    
    
    void tampil (){
        
    }
}
   
    /**
     * @param args the command line arguments
     */

