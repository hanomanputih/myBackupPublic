/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package swalayan;

/**
 *
 * @author Praktikan
 */
public class Pemanggil {
    
        public static void main(String[] args) {
        // TODO code application logic here
        Swalayan  s = new Swalayan ();
        
        Indomaret i = new Indomaret ();
        s=i;
        s.tampil();
        tokoAgung t = new tokoAgung ();
        s=t;
        s.tampil();
        
}
    
}
