/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;

/**
 *
 * @author Praktikan
 */
public class JavaApplication {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
 
        ArrayList list = new ArrayList();
        LinkedList list2 = new LinkedList();
        list.add("NIM: 11523163");
        list.add("NAMA: Devina");
        list2.add("NIM");
        list2.add("Nama");
        System.out.println("ukuran list "+list.size());
        
        for (Iterator iterator = list.iterator(); iterator.hasNext();) {
            String ii = (String) iterator.next();
            System.out.println(ii);
           
            
       Map<Integer, String> map = new HashMap<Integer, String>();
       
       map.put(11, "11523163");
       map.put(22, "Devina");
       
      System.out.println(map.get(1));
      
            System.out.println("-------------------");
            
            for (Integer i : map.keySet()) {
                
                System.out.println(i +" : " + map.get(i));
            }
            System.out.println("---------------------");
            for (Map.Entry<Integer, String> entry : map.entrySet()) {
                System.out.println(entry.getKey() + ", " + entry.getValue());
                
            }
        }
    }
}
 