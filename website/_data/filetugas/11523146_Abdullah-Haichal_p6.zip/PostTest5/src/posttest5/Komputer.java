/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest5;

/**
 *
 * @author PRAKTIKAN
 */
public class Komputer {
    String NamaKomputer;
    private RAM R;
    private Processor P;
    
    public Komputer (String Komp){
        this.NamaKomputer = Komp; 
        if (Komp.equals ("ALien Ware")) {
       
        R = new RAM ("V-gen");
        P = new Processor ("Core i7");
        
    }
}
    public void TampilKomp(){
        System.out.println("Merk RAM: " +R.NamaRAM);
        System.out.println("Merk Processor: "+P.NamaPros);
        System.out.println("Nama Komputer : " +NamaKomputer);
    }
   
}
