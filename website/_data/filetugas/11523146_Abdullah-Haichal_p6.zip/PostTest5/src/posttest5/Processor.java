/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest5;

/**
 *
 * @author PRAKTIKAN
 */
public class Processor {
    String NamaPros;
    
   public Processor (String NamaPros){
       this.NamaPros = NamaPros;
   }
}