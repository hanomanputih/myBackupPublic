/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest5;

/**
 *
 * @author PRAKTIKAN
 */
public class PostTest5 {
    
    public static void main(String[] args) {
        Komputer komp1 = new Komputer ("ALien Ware");
                komp1.TampilKomp();
    }
}
