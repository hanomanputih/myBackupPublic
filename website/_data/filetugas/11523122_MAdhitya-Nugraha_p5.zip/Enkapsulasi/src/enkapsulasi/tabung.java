/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package enkapsulasi;

/**
 *
 * @author Praktikan
 */
public class tabung {
  public class Tabung {

 

    private double jariJari;

    private double tinggi;

    double PHI = 22/7;

    

    public double luasAlas(){

        double luasAlas;

        luasAlas = this.PHI*this.jariJari*this.jariJari;

        return luasAlas;

    }


    public double volume(){

        double volume;

        volume = this.luasAlas()*this.tinggi;

        return volume;

    }

 

    public double getJariJari() {

        return jariJari;
       
    }

 

    public void setJariJari(double jariJari) {

        this.jariJari = jariJari;

    }

 

    public double getTinggi() {

        return tinggi;

    }

 

    public void setTinggi(double tinggi) {

        this.tinggi = tinggi;
        

   

}


    }

}
  

