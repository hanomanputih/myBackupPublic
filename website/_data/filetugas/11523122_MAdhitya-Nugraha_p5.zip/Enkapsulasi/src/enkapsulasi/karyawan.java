/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package enkapsulasi;

/**
 *
 * @author Praktikan
 */
public class karyawan {
    private String Nip;
    private String Nama;
    private int Gaji;

    public karyawan (){
        Nip = "11523122";
        Nama = "Adhitya";
        Gaji = 2500000;
    }
    public void setNip (String Nip){
           this.Nip = Nip;
        }
    public String getNip(){
        return Nip;
    }
     public void setNama (String Nama){
            this.Nama=Nama;
     }
    public String getnama(){
        return Nama;
    }
    public void setGaji(int newGaji){
        Gaji=newGaji;
    }
    public int getGaji(){
        return Gaji;
    } 
}

    

