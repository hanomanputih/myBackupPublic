/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package enkapsulasi;

/**
 *
 * @author Praktikan
 */
public class mahasiswa {
    private String nim;
    public String nama;
    
    public mahasiswa(String nama) {
        this.nama = nama;
    } 
             
    public void isinim(String n) {
       
        if (n.length() == 8){
           nim = n;
        }else {
            System.out.println ("Error....!!");
        }
    }
    
    public void Info () {
        System.out.println("nama " + nama);
        System.out.println("nim " + nim);
        
        
    }
}
