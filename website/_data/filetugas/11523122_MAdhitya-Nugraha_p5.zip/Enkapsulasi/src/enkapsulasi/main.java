/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package enkapsulasi;

/**
 *
 * @author Praktikan
 */
public class main {
    public static void main(String [] args) {
        karyawan krym = new karyawan ();
        
        krym.setNip("11523122");
        krym.setNama("Adhitya");
        krym.setGaji(2500000);
        
        System.out.println("Nip :" + krym.getNip());
        System.out.println("Nama :" + krym.getnama());
        System.out.println("Gaji :" + krym.getGaji());
    }
    
}
