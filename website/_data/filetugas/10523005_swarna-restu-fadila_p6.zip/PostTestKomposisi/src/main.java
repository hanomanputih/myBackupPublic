/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Praktikan
 */
public class main {

    public static void main(String[] args) {
        prosesor p= new prosesor("intel");
        ram rm = new ram();
        komputer k = new komputer(p,rm);
        k.r.kapasitas = "asdasd";
        System.out.println(k.r.kapasitas);
    }
}
