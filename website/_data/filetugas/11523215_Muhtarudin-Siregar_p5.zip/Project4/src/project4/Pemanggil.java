
package project4;

public class Pemanggil {
    public static void main(String[] args) {
        Karyawan pegawai = new Karyawan();
        
        
        
        pegawai.setNip("123456789");
        System.out.println("NIP Anda Adalah : "+pegawai.getNip());
        pegawai.setNama("Ardin");
        System.out.println("Nama Anda adalah : "+pegawai.getNama());
        pegawai.setGaji(5120000);
        System.out.println("Gaji Anda adalah : "+pegawai.getGaji());
        System.out.println("Gaji anda 1 tahun adalah : "+pegawai.getGaji()*12);
        
    }
}
