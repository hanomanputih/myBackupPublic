
package project4;


public class Karyawan {

    public String nip;
    private String nama;
    private int gaji;
    
    
    public String getNip(){
        return nip;
    }
    
    public void setNip(String nip){
        if(nip.length()== 8){
            this.nip=nip;
        }
        else{
            System.out.println("Errorrrrr....");
        }
    }
    
    
    
    public String getNama(){
        return nama;
    }
    
    public void setNama(String nama){
        if(nama.length()== 0){
            this.nama = nama;
        }
        else {
            System.out.println("Nama anda tidak diketahui");
        }
    }
        
    public int getGaji(){
        return gaji;
    }
        
    public void setGaji(int gaji){
        if(gaji >= 0){
            this.gaji = gaji;
        }
        else{
            System.out.println("Salah dalam pemasukan gaji");
        }
    }
           
    
}