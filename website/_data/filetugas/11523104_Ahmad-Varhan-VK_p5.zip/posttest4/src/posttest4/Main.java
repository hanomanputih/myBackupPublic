/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest4;

/**
 *
 * @author Praktikan
 */
public class Main {
    
    public static void main(String[] args) {
        Karyawan p = new Karyawan();
        p.setNIP("11523104");
        p.setN("varhan");
        p.setNI(2500000);
        System.out.println("NIP anda  : "+p.getNIP());
        System.out.println("Nama anda : "+p.getN());
        System.out.println("Gaji anda : "+p.getNI());
    }
}
