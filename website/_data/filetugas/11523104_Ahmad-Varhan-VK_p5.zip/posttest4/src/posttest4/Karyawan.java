/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest4;

/**
 *
 * @author Praktikan
 */
public class Karyawan {

    /**
     * @param args the command line arguments
     */
    private String nip;
    private String nama;
    private int gaji;
    void setNIP(String nip){
      if(nip.length() == 8){
          this.nip = nip;
         
      }else {
          System.out.println("error");
      }
  }
  String getNIP(){
      return nip;
  }
  void setN(String nama){
      if(nama.length() > 4){
          this.nama = nama;
         
      }else {
          System.out.println("nama terlalu singkat");
      }
  }
  String getN(){
      return nama;
  }
  
  void setNI(int gaji){
      if( gaji > 999999 && gaji < 10000000){
          this.gaji = gaji;
         
      }else {
          System.out.println("error. bukan kategori gaji");
      }
  }
  int getNI(){
      return gaji;
  }
  
}