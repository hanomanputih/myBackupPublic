
package karyawan;

public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Karyawan k = new Karyawan();
        k.setNip ("15232558");
        k.setNama ("zaini");
        k.setGaji(50000000);
        System.out.println("Jadi nip anda adalah" +k.getNip());
        System.out.println("jadi nama anda adalah " +k.getNama());
        System.out.println("Jadi gaji anda sebesar Rp." +k.getGaji());
    }

}
