
package karyawan;

/**
 *
 * @author Praktikan
 */
public class Karyawan {
    private String nip;
    private String nama;
    private int gaji;

     public void setNip(String nip) {
        if (nip.length() == 8)
        {
            this.nip = nip;
        }else{
            System.out.println("panjang tidak sesuai terimakasih");
        }
    }
     public void setNama(String nama) {
        if (nama.length() != 0)
        {
            this.nama = nama;
        }else{
            System.out.println("tidak boleh kosong");
        }
    }
     public void setGaji(int gaji) {
        if (gaji != 0)
        {
            this.gaji = gaji;
        }else{
            System.out.println("Harus ada isian");
        }

    }
     public String getNip() {
        return nip;
    }
     public String getNama() {
        return nama;
    }
     public int getGaji() {
         int hasil;
         hasil = gaji*12;
        return hasil;
    }
}
