/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;
import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
/**
 *
 * @author Praktikan
 */
public class Postest {
    public static void main(String[] args) {
        
        Map<String,String> mhs = new HashMap<String,String>();
      mhs.put("M.Rizqon Satrio","Jakal KM. 12,5");
      mhs.put("Fastabiq","Jakal deket WS");
      mhs.put("Murod","Masjid Ulil");
       
        
      
      
        System.out.println("=================================");
        for (Map.Entry<String,String> e : mhs.entrySet())
            System.out.println(e.getKey()+" , "+e.getValue());
        
        
        System.out.println("====================================");
      List<String> nama = new ArrayList<String>();
      
        nama.add("Fasta");
        nama.add("Rizqon");
        nama.add("Murod");
        
        Iterator it = nama.iterator();
            while(it.hasNext()){
                System.out.println(it.next());
    }            
            System.out.println("==================");
            System.out.println(nama.get(1));
}
}  
        
    

