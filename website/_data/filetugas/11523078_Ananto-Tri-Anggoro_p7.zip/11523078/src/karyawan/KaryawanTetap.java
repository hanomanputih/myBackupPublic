/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class KaryawanTetap extends Karyawan {
int gaji;
    @Override
    public void gaji() {

        gaji = Tunjangan+gajiBonus+gajipokok;
        System.out.println("Gaji Karyawan Tetap :" +gaji);
        
    }
    
    
}
