/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class KaryawanKontrak extends Karyawan {
int gaji;
    @Override
    public void gaji() {

    
    gaji = gajipokok+gajiBonus;
        System.out.println("Gaji Karyawan Kontrak adalah "+gaji);
    }
    
}
