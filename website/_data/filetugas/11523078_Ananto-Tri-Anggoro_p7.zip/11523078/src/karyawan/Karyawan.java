/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public abstract class Karyawan {
    int gajipokok = 3000000;
    int gajiBonus = 1000000;
   int Tunjangan = 3000000/20;
        
    
    
    public abstract void gaji();
    
    
}
