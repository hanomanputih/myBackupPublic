/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public abstract class Karyawan {

    protected String nama;
    protected String Nip;
    protected float gajiPokok;
    protected float bonus;
    
    public abstract void bertugas();
    
    public void view(){
        System.out.println("Nama        : "+nama);
        System.out.println("Nomor IP    : "+Nip);
        System.out.println("gajiPokok   : "+gajiPokok);
        System.out.println("Bonus       : "+bonus);
    }
}
