/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class Main {
    public static void main(String[] args) {
        karyawanTetap kt = new karyawanTetap();
        kt.nama = "Novi Peye";
        kt.Nip = "11511";
        kt.gajiPokok= 3000000;
        kt.bonus=200000;
        kt.view();
        kt.getGaji();
        kt.setGaji(3000000, 200000);
        kt.bertugas();
        
        System.out.println("");
        
        karyawanKontrak kk = new karyawanKontrak();
        kk.nama = "Tiwi Marista";
        kk.Nip="11522";
        kk.gajiPokok=2500000;
        kk.bonus=1500000;
        kk.view();
        kk.getGaji();
        kk.setGaji(2500000, 1500000);
        kk.bertugas();
        
    }
}
