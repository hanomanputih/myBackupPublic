/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class karyawanKontrak extends Karyawan{
    private float gaji;

    
    
    public void view(){
        
        super.view();
    }

    public float getGaji() {
        return gaji;
    }

    public void setGaji(float gajipokokku, float bonusku) {
        gajiPokok=gajipokokku;
        bonus=bonusku;
        gaji=gajiPokok+bonus;
        System.out.println("Gaji bersih adalah "+gaji);
       
    }

    @Override
    public void bertugas() {
        System.out.println("Tugasnya gak tetap");
    }
    
    
}

    

