/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class karyawanTetap extends Karyawan{
    private float gaji;
    private float tunjangan ;
    
    public void view(){
        super.view();
    }

    public float getGaji() {
        return gaji;
    }

    public void setGaji(float gajipokokku, float bonusku) {
        gajiPokok=gajipokokku;
        bonus=bonusku;
        tunjangan = gajiPokok*0.5f;
        gaji=tunjangan+gajiPokok+bonus;
        System.out.println("Gaji bersih adalah "+gaji);
       
    }

    @Override
    public void bertugas() {
        System.out.println("Tugasnya tetap");
    }
    
    
}
