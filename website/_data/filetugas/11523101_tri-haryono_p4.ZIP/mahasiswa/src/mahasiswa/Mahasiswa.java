/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;
import java.util.Scanner;/**
 *
 * @author PRAKTIKAN
 */
public class Mahasiswa {
String nama;
String NIM;
int jumlah; 
int hasil;

public void cetak(){}
 
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Mahasiswa aryo = new Mahasiswa();
        Scanner baca = new Scanner (System.in);
        System.out.println("Masukkan Nama Anda: ");
        aryo.nama = baca.next();
        aryo.jumlah = aryo.nama.length();
        System.out.println("Panjang karakter nama anda : "+aryo.jumlah);
        System.out.print("masukan NIM anda: ");
        aryo.NIM = baca.next();
        aryo.hasil = aryo.NIM.length();
        System.out.println("Panjang karakter NIM anda : "+aryo.hasil);;
        // TODO code application logic here
    }
}
