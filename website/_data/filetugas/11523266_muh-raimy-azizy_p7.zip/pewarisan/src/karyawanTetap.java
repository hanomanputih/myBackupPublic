/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Praktikan
 */
public class karyawanTetap extends Karyawan{
double tunjangan= 0.2*3000000;
int bonus = 200000;
double gaji = tunjangan + bonus + gajiP;
    @Override
public void lihat(){
        System.out.println("gaji pokok : "+ gajiP);
        System.out.println("tunjangan : "+ tunjangan);
        System.out.println("bonus : "+ bonus);
        System.out.println("gaji : "+ gaji);
}
    }
    

