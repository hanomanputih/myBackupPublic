package pc;

public class Komputer
{
    public int harga;
    public Prosesor p;
    public Ram r;

    public Komputer(int harga)
    {
        if (harga <= 5000000)
        {
            this.harga = harga;
            p = new Prosesor("intel", "i3");
            r = new Ram("vgen", "512 MB");
        }
        else
        {
            this.harga = harga;
            p = new Prosesor("intel", "i7");
            r = new Ram("kingstone", "1 GB");
        }
    }

    public void tampilData()
    {
        System.out.println("");
        System.out.println(this);
        System.out.println("Harga : Rp." + harga);
        System.out.println("Merk Prosesor : " + p.merk);
        System.out.println("Jenis Prosesor : " + p.jenis);
        System.out.println("Merk Ram : " + r.merk);
        System.out.println("Ukuran Ram : " + r.ukuran);
        System.out.println("");
    }
}
