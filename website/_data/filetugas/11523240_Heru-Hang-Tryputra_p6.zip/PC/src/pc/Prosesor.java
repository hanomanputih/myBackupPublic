package pc;

public class Prosesor
{
    public String merk, jenis;

    public Prosesor(String merk, String jenis)
    {
        this.merk = merk;
        this.jenis = jenis;
    }

}
