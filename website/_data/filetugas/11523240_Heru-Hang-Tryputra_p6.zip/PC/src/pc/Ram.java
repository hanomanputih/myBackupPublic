package pc;

public class Ram
{
    public  String merk, ukuran;

    public Ram(String merk, String ukuran)
    {
        this.merk = merk;
        this.ukuran = ukuran;
    }
}
