package pc;

public class Main {

    public static void main(String[] args)
    {
        Komputer k1 = new Komputer(5000000);
        k1.tampilData();

        Komputer k2 = new Komputer(10000000);
        k2.tampilData();

    }
}
