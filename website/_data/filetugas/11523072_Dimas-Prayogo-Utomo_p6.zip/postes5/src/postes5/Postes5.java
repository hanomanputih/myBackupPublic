/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes5;

/**
 *
 * @author Praktikan
 */
public class Postes5 {
String namaPostes5;
private Komputer K;
private Prosesosr P;
private Ram R;

public Postes5(String post){
    this.namaPostes5 = post;
    K = new Komputer("canggih");
    P = new Prosesosr("i3");
    R = new Ram(512);
}
public void tampilPost(){
        System.out.println("nama komputer" +K.namaKomputer);
        System.out.println("Jenis Prosesor" +P.jenisProsesosr);
        System.out.println("kapasitas RAM"+R.kapasitasRam);
}
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
Postes5 pos= new Postes5("5");
pos.tampilPost();

        // TODO code application logic here
    }
}
