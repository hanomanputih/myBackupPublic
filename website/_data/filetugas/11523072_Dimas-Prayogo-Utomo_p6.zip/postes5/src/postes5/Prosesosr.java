/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes5;

/**
 *
 * @author Praktikan
 */
public class Prosesosr {
        String jenisProsesosr;
    
    public Prosesosr(String jenisProsesosr){
        this.jenisProsesosr = jenisProsesosr;
    } 
    public void tampilProesesosr(){
    System.out.println("nama Prosesosr" +jenisProsesosr);
}
}
