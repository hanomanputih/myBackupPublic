/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes5;

/**
 *
 * @author Praktikan
 */
public class Komputer {
    String namaKomputer;
    
    public Komputer(String namaKomputer){
        this.namaKomputer = namaKomputer;
    } 
    public void tampilKomputer(){
    System.out.println("nama komputer" +namaKomputer);
}
}
