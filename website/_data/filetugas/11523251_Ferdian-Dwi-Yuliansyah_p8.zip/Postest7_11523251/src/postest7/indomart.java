/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest7;

/**
 *
 * @author PRAKTIKAN
 */
public class indomart extends swalayan{
    
    @Override
    void tampil(){
        System.out.println("Indomart");
        if (harga % 25 == 0){
        bayar=(int) harga;
            System.out.println("Harga belanja anda = "+harga);
            System.out.println("Total belanja anda = "+bayar);
        }else{
        sisa=(int) (25-(harga % 25));
        bayar=(int) (harga+sisa);
            System.out.println("Harga belanja anda = "+harga);
            System.out.println("Total belanja anda = "+bayar);
        }
                          
    
    }
    
}
