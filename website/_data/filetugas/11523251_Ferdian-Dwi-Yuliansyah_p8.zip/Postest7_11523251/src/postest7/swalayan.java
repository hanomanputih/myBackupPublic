/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest7;

/**
 *
 * @author PRAKTIKAN
 */
public class swalayan {
    float harga;
    int bayar;
    int sisa;
    
    void tampil(){
        
    }
    
}
