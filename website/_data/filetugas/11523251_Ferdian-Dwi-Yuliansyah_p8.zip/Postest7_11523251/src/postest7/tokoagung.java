/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest7;

/**
 *
 * @author PRAKTIKAN
 */
public class tokoagung extends swalayan {
    
    @Override
    void tampil(){
            System.out.println("Toko Agung");
    
        if (harga %25 == 0){
            System.out.println("Harga belanja anda = "+harga);
            System.out.println("Total belanja anda = "+harga);
        }else{
        sisa =(int) (harga % 25);
        bayar =(int) (harga - sisa);
            System.out.println("Harga belanja anda = "+harga);
            System.out.println("Total belanja anda = "+bayar);
    }
    
    
}}
