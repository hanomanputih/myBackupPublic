
package main;


public class karyawanKontrak extends Karyawan {
    @Override
    public void gaji() {
    super.view();
    gaji=tunjangan+gajipokok;
        System.out.println("Gaji karyawan Kontrak :Rp. "+gaji);
        System.out.println("");
    }

    @Override
    public void berlari() {
    }
    
}
