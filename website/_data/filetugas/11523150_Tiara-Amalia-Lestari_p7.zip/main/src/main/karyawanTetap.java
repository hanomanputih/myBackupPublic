
package main;


public class karyawanTetap extends Karyawan implements manusia {

    @Override
    public void gaji() {
    super.view();
        bonus = 250000;
        gaji = tunjangan+bonus;
        System.out.println("Gaji karyawan tetap :Rp. "+gaji);
        System.out.println("=================================");
    }

    @Override
    public void berlari() {
        
    }

    
    
}
