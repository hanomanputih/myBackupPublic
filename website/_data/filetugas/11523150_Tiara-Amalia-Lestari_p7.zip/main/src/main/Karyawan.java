
package main;


public abstract class Karyawan implements manusia {
    int gaji;
    protected int gajipokok = 3000000 , bonus;
    protected int tunjangan = (int) (0.2*gajipokok);
    
    public abstract void gaji();
    
    public void view(){
        System.out.println("gaji pokok : "+gajipokok);
        
        
    }
}
