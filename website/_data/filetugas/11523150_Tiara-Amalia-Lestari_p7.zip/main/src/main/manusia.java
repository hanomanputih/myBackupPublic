
package main;


public interface manusia {
    public void berlari();
    
}
