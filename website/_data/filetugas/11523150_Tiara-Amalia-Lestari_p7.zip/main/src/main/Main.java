
package main;


public class Main {

    
    public static void main(String[] args) {
        karyawanTetap kt = new karyawanTetap();
        kt.gaji();
        karyawanKontrak kk = new karyawanKontrak();
        kk.gaji();
        
        
    }
}
