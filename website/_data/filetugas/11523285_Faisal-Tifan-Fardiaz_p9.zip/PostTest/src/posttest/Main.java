/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class Main {
    
    public static void main(String[] args) {
            List list = new ArrayList();
            list.add ("Nama");
            list.add ("NIM");
            for(Iterator<String> iterator = list.iterator(); 
            iterator.hasNext();){//untuk melihat isi List
            String isi = iterator.next();
            System.out.println(isi);
            }
            Scanner s =new Scanner(System.in); 
            Map map = new HashMap();
            System.out.println("Masukkan Nama : ");
            map.put(list.get(0),s.next());
            System.out.println("Masukkan NIM : ");
            map.put(list.get(1),s.next());
            
            System.out.println("Nama = "+ map.get("Nama"));
            System.out.println("NIM = "+ map.get("NIM"));
    }
}
