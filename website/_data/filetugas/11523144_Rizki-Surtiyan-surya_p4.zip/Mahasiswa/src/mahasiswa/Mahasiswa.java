/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;
import java.util.Scanner;
/**
 *
 * @author Praktikan
 */
public class Mahasiswa {

    String nama;
    String nim;
    String fakultas;
    String jurusan;
    String angkatan;
    
    void cetak() {
         Scanner sn = new Scanner(System.in);
        
        System.out.println("nama =");
        nama= sn.next();
        System.out.println("nim =");
        nim= sn.next();
        System.out.println("fakultas");
        fakultas= sn.next();
        System.out.println("jurusan");
        jurusan= sn.next();
        System.out.println("angkatan");
        angkatan=sn.next();
        System.out.println("nama =" + nama);
        System.out.println("nim =" +nim);
        System.out.println("fakultas =" +fakultas);
        System.out.println("jurusan =" +jurusan);
        System.out.println("angkatan =" +angkatan);
    }
    public static void main(String[] args) {
        // TODO code application logic here
        Mahasiswa msh = new Mahasiswa();
       msh.cetak();
    }
}
