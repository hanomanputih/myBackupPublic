/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg11523130;


public class Mahasiswa {
    String nama="ridho";
    String NIM="11523130";
    String fakultas="teknologi industri";
    String jurusan="informatika";
    String angkatan="2011";
    
            
    
 void cetak(){
     System.out.println("nama"+nama);
     System.out.println("NIM"+NIM);
     System.out.println("fakultas"+fakultas);
     System.out.println("jurusan"+jurusan);
     System.out.println("angkatan"+angkatan);
     
          
 
 }
    
    
    public static void main(String[] args) {
        Mahasiswa ok=new Mahasiswa();
        ok.cetak();
       
       
        
        
    }
}
