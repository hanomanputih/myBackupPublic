/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Praktikan
 */
public class CPU {
   int nomerProduksi;
   Prosesor namaPross;
   RAM ukuran;
   
   public CPU (int nP) {
       nP = nomerProduksi;
    if (nP == 2)  {
        namaPross = new Prosesor("NVIDIA");
        ukuran = new RAM (512);
        }
}
   public void muncul () {
       System.out.println(namaPross.namaProsesor);
       System.out.println(ukuran.ukuranRAM);
   }
   
}