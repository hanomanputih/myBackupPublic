/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

import java.util.Scanner;
 
public class Mahasiswa {
    String nama;
    String nim;
    String fakultas;
    String jurusan;
    String angkatan;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Mahasiswa c = new Mahasiswa();
        Scanner baca = new Scanner(System.in);
        System.out.println("Masukkan nama anda: ");
        System.out.println("Masukkan nim anda: ");
        System.out.println("Masukkan fakultas anda: ");
        System.out.println("Masukkan angkatan anda: ");
        c.nama = baca.nextLine();
        c.nim = baca.nextLine();
        c.fakultas = baca.nextLine();
        c.jurusan = baca.nextLine();
        c.angkatan = baca.nextLine();
        System.out.println("nama anda : "+c.nama);
        System.out.println("nim anda : "+c.nim);
        System.out.println("fakultas anda : "+c.jurusan);
        System.out.println("angkatan anda : "+c.angkatan);
        
        
        
        
        
        
    }
}
