/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttes3;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
    String nama, nim, fakultas, jurusan, angkatan;
    
     void cetak(){
     System.out.println("nama:" +nama+ " "+"panjang karakter :"+ nama.length());
     System.out.println("nim:" +nim+ " "+ "angka pertama:"+ nim.substring(0, 1));
     System.out.println("fakultas:" +fakultas+ " "+ "kata terakhir " +" " +fakultas.endsWith("fti"));
     System.out.println("jurusan:" +jurusan+ " " +"huruf ke-4:" + jurusan.charAt(4));
     System.out.println("angkatan:" +angkatan+ " "+"kata terakhir"+ angkatan.equals("11"));
     }
     
     public static void main(String[] args){
         Mahasiswa m = new Mahasiswa();
         Scanner sc = new Scanner(System.in);
         System.out.println("inputkan nama kamu:");
         m.nama = sc.next();
         System.out.println("inputkan nim kamu:");
         m.nim = sc.next();
         System.out.println("inputkan fakultas kamu:");
         m.fakultas = sc.next();
         System.out.println("inputkan jurusan kamu:");
         m.jurusan = sc.next();
         System.out.println("inputkan angkatan kamu:");
         m.angkatan = sc.next();
         m.cetak();
     }
}
