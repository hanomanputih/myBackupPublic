/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

/**
 *
 * @author Praktikan
 */
public class Karyawan {
    private String nip,nama;
    private int gaji;
    
    void setnip(String ni){
        if(ni.length()==6){
            nip=ni;
        }else{
            System.out.println("Error :P");
        }
    }
    String getnip(){
        return nip;
    }
    
    
  void setnama(String na){
        if(na.length()<=30){
            nama=na;
        }else{
            System.out.println("Error :P");
        }
    }
    String getnama(){
        return nama;
    }  
    
    void setgaji(int ga){
        if(ga>=100000){
            gaji=ga;
        }else{
            System.out.println("Error :P");
        }
    }
    int getgaji(){
        return gaji;
    }
}
