/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

/**
 *
 * @author Praktikan
 */
public class Main {
    public static void main(String[] args) {
        Karyawan aku=new Karyawan();
        aku.setnip("123456");
        aku.setnama("Namaku ciyus");
        aku.setgaji(200000);
        System.out.println("NIP:"+aku.getnip());
        System.out.println("Nama:"+aku.getnama());
        System.out.println("Gaji:"+aku.getgaji());
    }
    
}
