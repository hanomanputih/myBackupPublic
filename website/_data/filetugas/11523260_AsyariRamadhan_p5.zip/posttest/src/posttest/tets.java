/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author Praktikan
 */
public class tets {
    
    public static void main(String[] args) {
        karyawan kry1 = new karyawan();
        kry1.setNama("Ari");
        System.out.println ("Nama = " + kry1.getNama());
        kry1.setNip ("11523260");
        System.out.println ("Nip = " + kry1.getNip());
        kry1.setGaji ("10000000");
        System.out.println ("Gaji = " + kry1.getGaji() + "juta");
                
        // TODO code application logic here
    }
}
