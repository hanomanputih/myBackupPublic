/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Praktikan
 */
public class TokoAgung extends Swalayan{
        @Override
    public void tampil() {

        if (harga % 25 == 0) {
            bayar = (int) harga;
             System.out.println(" Bayar TokoAgung: "+bayar);
        }
        
        
        else {
            sisa = (int) (harga%25);
            bayar = (int) (harga - sisa);
            System.out.println("Bayar TokoAgung: "+bayar);
            
                    
        }
       }
    
    
}
