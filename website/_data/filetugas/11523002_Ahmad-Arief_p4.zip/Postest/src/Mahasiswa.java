/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author PRAKTIKAN
 */
  import java.util.Scanner;
public class Mahasiswa {
    
        static String nama ;
        static String nim ;
        static String fakultas;
        static String jurusan;
        static String angkatan;
      
        void cetak (){
            Scanner sc = new Scanner (System.in);
            System.out.println("NIM: ");
            nim = sc.next();
            System.out.println("NAMA: ");
            nama = sc.next();
            System.out.println("FAKULTAS: ");
            fakultas = sc.next();
            System.out.println("JURUSAN: ");
            jurusan = sc.next();
            System.out.println("ANGKATAN: ");
            angkatan = sc.next();
        }
            public static void main(String[] args){
            
                Mahasiswa mhs = new Mahasiswa();
                mhs.cetak();
                       System.out.println("Mahasiswa bernama "+nama);
                       System.out.println("panjang karakter : "+nama.length());
                       System.out.println("nim nya : "+nim);
                       System.out.println("panjang karakter : "+nim.length());
                       System.out.println("fakultas : "+fakultas);
                       System.out.println("panjang karakter : "+fakultas.length());
                       System.out.println("jurusan : "+jurusan);
                       System.out.println("panjang karakter : "+jurusan.length());
                       System.out.println("angkatan : "+angkatan);
                       System.out.println("panjang karakter : "+angkatan.length());
                       
                      
                       
                       
            }
            
    }    
    
    



       