/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest4;

/**
 *
 * @author Praktikan
 */
public class Postest4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        karyawan kr= new karyawan ();
        kr.setnip("nip123456");
        System.out.println("nip ku = "+kr.getnip());
        
        kr.setnama("Budi");
        System.out.println("nama ku = "+kr.getnama());
        
        kr.setgaji(500000);
        System.out.println("gaji ku = "+kr.getgaji());
        
  
}}
