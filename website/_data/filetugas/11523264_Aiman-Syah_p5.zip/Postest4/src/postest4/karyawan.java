/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest4;

/**
 *
 * @author Praktikan
 */
public class karyawan {
    private String nip;
    private String nama;
    private int gaji;
   
    void setnip(String nip) {
            this.nip = nip;}
    void setnama(String nama) {
            this.nama = nama;}
    void setgaji(int gaji) {
            this.gaji = gaji;}
    String getnip(){
        return nip;
    }
    String getnama(){
        return nama;
    }
    int getgaji(){
        return gaji;
    }
    
        }
        
    