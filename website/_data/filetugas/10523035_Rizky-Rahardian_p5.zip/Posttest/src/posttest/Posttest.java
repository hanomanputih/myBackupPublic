/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author PRAKTIKAN
 */
public class Posttest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       karyawan kry=new karyawan();
       String NIP ="1253527";
       String nama = "rizky";
       int gaji = 5400000;
       kry.setNIP(NIP);
       kry.setNAMA(nama);
       kry.setGaji(gaji);
        System.out.println("NIP : "+kry.getNIP());
        System.out.println("Nama : "+kry.getNAMA());
        System.out.println("gaji : RP "+kry.getGaji());
       
    }
}
