/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author Praktikan
 */
public class ram {
    String nama;
        public ram (String nama) {
            this.nama=nama;
}
}