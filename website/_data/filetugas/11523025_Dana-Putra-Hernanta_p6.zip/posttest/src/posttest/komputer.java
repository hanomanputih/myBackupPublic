/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author Praktikan
 */
public class komputer {
    String id_komp;
    String id_ram;
    ram r ;
    prosesor p;
    public komputer(String komp ) {
        id_komp=komp;
      
        if(id_komp.equals("1")){
           r= new ram("1gb") ;
         
            p=new prosesor("intel") ;       
    
                   
                   
                  }
    }
    public static void main(String[] args) {
      komputer komp=new komputer("1");
     System.out.println("kapasitas ram"+komp.r.nama);
     System.out.println("nama prosesor"+komp.p.nama);
}
  
    
}

