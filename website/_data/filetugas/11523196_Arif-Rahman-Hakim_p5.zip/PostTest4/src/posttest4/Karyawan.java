/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest4;
import java.util.Scanner;
/**
 *
 * @author PRAKTIKAN
 */
public class Karyawan {
    
    private String nip;
    private String nama;
    private int gaji;
    
    
    
    void setNIP (){
        Scanner pembaca = new Scanner (System.in);
        System.out.println("Masukkan NIP anda: ");
        nip = pembaca.next();}
        
    void setNAMA () {
        Scanner pembaca = new Scanner (System.in);
        System.out.println("Masukkan NAMA anda: ");
        nama = pembaca.next();
        
    
    }    

    void setGAJI (){
        Scanner pembaca = new Scanner (System.in);
        System.out.println("Gaji anda: ");
        gaji = pembaca.nextInt();


    }
    
    String getNIP (){
        return nip;
    }
    String getNAMA (){
        return nama;
       
    }
    int getGAJI (){
        return gaji;
    }
}



