/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest4;

/**
 *
 * @author PRAKTIKAN
 */
public class Main {
    public static void main(String[] args) {
        Karyawan ky = new Karyawan ();
        ky.setNIP ();
        ky.setNAMA ();
        ky.setGAJI ();
        System.out.println("nip ku = "+ky.getNIP());
        System.out.println("nama ku = "+ky.getNAMA());
        System.out.println("gaji setahun = "+ky.getGAJI()*12);
        
    

    }
}
