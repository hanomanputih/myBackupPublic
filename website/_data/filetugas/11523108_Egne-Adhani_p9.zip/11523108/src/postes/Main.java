package postes;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public class Main {
  

    public static void main(String[] args) {
        List<String> list = new ArrayList<String>();
        list.add("11523108");
        list.add("mpek");
        list.add("11523088");
        list.add("mbal");
        list.add("11523034");
        list.add("mmet");
        
        for (Iterator<String> iterator = list.iterator(); 
        iterator.hasNext();) {
        String isi = iterator.next();
        System.out.println(isi);
        }
        
        HashMap map = new HashMap();
        map.put("11523108", "mpek");
        System.out.println("data "+map.get("11523108"));
    }
}
