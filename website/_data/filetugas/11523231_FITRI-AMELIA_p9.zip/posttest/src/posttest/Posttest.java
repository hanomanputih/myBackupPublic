/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Posttest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input=new Scanner(System.in);
        
        Map<Integer, String> m=new HashMap<Integer, String> ();
       
               
        m.put(11222, "abe");
        m.put(11333, "ace");
        m.put(11444, "ade");
        System.out.println(m.get(2));
          
        System.out.println("-------------");
        Iterator<Entry<Integer,String>> it=m.entrySet().iterator();
        while(it.hasNext()){
            System.out.println(it.next());
        }
    }
}
