/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {

    /**
     * @param args the command line arguments
     */
   static String nama;
    static String nim;
    static String jurusan;
    static String fakultas;
    static String angkatan;
    
    void cetak(){
        Scanner sc = new Scanner(System.in);
        System.out.println("NIM: ");
        nim = sc.next();
        System.out.println("NAMA: ");
        nama = sc.next();
        System.out.println("JURUSAN: ");
        jurusan = sc.next();
        System.out.println("FAKULTAS: ");
        fakultas = sc.next();
        System.out.println("ANGKATAN: ");
        angkatan = sc.next();
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
Mahasiswa mhs = new Mahasiswa();
mhs.cetak();
        System.out.println(" ");
        System.out.println(" ");
        System.out.println("nama anda: " + nama);
        System.out.println("panjang karakter  " +nama.length());
        System.out.println("NIM anda: " + nim);
        System.out.println("");
        System.out.println("jurusan anda: "+ jurusan);
        System.out.println("");
        System.out.println("fakultas anda: "+ fakultas);
        System.out.println("");
        System.out.println("anda mahasiswa angkatan: "+ angkatan);
        System.out.println("");
        
        

    }
}
