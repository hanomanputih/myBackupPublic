package mahasiswa;

import java.util.Scanner;

public class Mahasiswa {

static String nama;
static int nim;
static String fakultas;
static String jurusan;
static int angkatan;

    public static void main(String[] args) {
        Mahasiswa m = new Mahasiswa();
        Scanner baca = new Scanner(System.in);
        System.out.println("masukan nama mahasiswa= ");
        nama = baca.nextLine();
        
        System.out.println("masukan nim mahasiswa= ");
        nim = baca.nextInt();
        
        System.out.println("masukan fakultas= ");
        fakultas = baca.next();

        System.out.println("masukan jurusan= ");
        jurusan = baca.next();
        
        System.out.println("masukan angkatan= ");
        angkatan = baca.nextInt();

        
         System.out.println(nama);
         System.out.println(nim);
         System.out.println(fakultas);
         System.out.println(jurusan);
         System.out.println(angkatan);
    }
    
    }


        
                