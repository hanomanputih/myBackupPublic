/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Komputer;

/**
 *
 * @author PRAKTIKAN
 */
public class Prosesor {
    int Kecepatan;

    public int getKecepatan() {
        return Kecepatan;
    }

    public void setKecepatan(int Kecepatan) {
        this.Kecepatan = Kecepatan;
    }

   

    
}
