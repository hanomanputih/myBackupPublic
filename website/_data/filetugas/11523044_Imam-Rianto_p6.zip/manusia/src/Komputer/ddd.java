/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Komputer;

/**
 *
 * @author PRAKTIKAN
 */
public class ddd {
    public static void main(String[] args) {
        RAM adidas = new RAM ();
        adidas.setKapasitas(4);
        Prosesor nike = new Prosesor ();
        nike.setKecepatan(100);
        
        Komputer Toshiba = new Komputer(nike,adidas);
        System.out.println("kecepatan "+Toshiba.getProsesor().getKecepatan());
        System.out.println("kapasitas "+Toshiba.getRam().getKapasitas());
        
        
    }
}
