/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Komputer;

/**
 *
 * @author PRAKTIKAN
 */
public class Komputer {

    private String merk;
    private Prosesor prosesor;
    private RAM ram;

    public Komputer (Prosesor a, RAM b){
        this.prosesor=a;
        this.ram=b;
    }
    public String getMerk() {
        return merk;
    }

    public void setMerk(String merk) {
        this.merk = merk;
    }

    public Prosesor getProsesor() {
        return prosesor;
    }

    public void setProsesor(Prosesor prosesor) {
        this.prosesor = prosesor;
    }

    public RAM getRam() {
        return ram;
    }

    public void setRam(RAM ram) {
        this.ram = ram;
    }
    
    

    

   
    
}
