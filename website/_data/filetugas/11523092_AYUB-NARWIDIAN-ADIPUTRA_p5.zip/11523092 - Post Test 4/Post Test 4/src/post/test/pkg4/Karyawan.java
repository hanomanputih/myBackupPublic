/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package post.test.pkg4;

/**
 *
 * @author PRAKTIKAN
 */
public class Karyawan {

    /**
     * @param args the command line arguments
     */
    private String nip;
    private String nama;
    private int gaji;
    
    
    public static void main(String[] args) {
        // TODO code application logic here
    }
}
