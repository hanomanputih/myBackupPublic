/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package java.collection;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
//import java.util.Iterator;

/**
 *
 * @author PRAKTIKAN
 */
public class hairyPotter {
    
    static int i;
    private static List List;
    static void LoadData(List list){
        list.add("nama");
        list.add("NIM");
        
    }
    
    String Nama;
    int NIM;
    
    public static void TampilkanList(List list) {
        for(int i = 0; i<List.size();i++);{
        System.out.println(list.get(i)+"");
    }
        System.out.println();
    }
      public static void main(String[] args) {
        HashMap map = new HashMap();
        List list = new ArrayList();
        Scanner pembaca = new Scanner (System.in);
        map.put("Nama", "Hairy Potter");
        map.put("NIM", new Integer(10523666));
        LoadData(list);
        TampilkanList(list);
        
          System.out.println("map");
          System.out.println("Ukuran Map: "+map.size());
          boolean containKey = map.containsKey("NIM");
          System.out.println("Has pul(NIM): "+containKey);
          Object removed = map.remove("NIM");
          System.out.println("Removed : "+removed);
          System.out.println(map);
          System.out.println("UKuran Map baru: "+map.size());
    }
    
}
