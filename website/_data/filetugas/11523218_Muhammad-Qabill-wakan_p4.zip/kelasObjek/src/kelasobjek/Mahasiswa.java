/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package kelasobjek;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
    String nama = "Muhammad Qabil wakan";
    int nim = 11523218;
  void cetak ()
    {
        System.out.println("nama saya adalah : "+nama);
         System.out.println("nim saya adalah : "+nim);
    }   

    public static void main(String[] args) {
        Mahasiswa ct = new Mahasiswa();
       
        ct.cetak();
 
    }
}