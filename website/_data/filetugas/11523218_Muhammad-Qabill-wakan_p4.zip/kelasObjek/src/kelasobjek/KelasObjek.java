/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package kelasobjek;

/**
 *
 * @author Praktikan
 */
public class KelasObjek {
    String nama = "abill mohammad";
    
    public static void main(String[] args) {
        KelasObjek cetak = new KelasObjek();
        System.out.println("karakter ke 4 adalah "+cetak.nama.charAt(5));
        System.out.println("nama depan saya "+cetak.nama.startsWith("abill"));
        System.out.println("nama terakhir saya "+cetak.nama.endsWith("mohammad"));
        System.out.println("panjang karakter nama saya"+cetak.nama.length());
    }
}
