/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class Pemanggil {
    
    public static void main(String[] args) {
        Karyawan krn = new Karyawan();
        krn.setNama ("Arip");
        krn.setNip ("11523002");
        krn.setGaji (10000);
        
        System.out.println("Nama = "+krn.getNama());
        System.out.println("NIP = "+krn.getNip());
        System.out.println("Gaji pertahun = "+krn.getGaji());
        
        
        
        
        
    }
}
