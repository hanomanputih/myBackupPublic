/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest11523234;

import java.util.Scanner;

/**
 *
 * @author PRAKTIKAN
 */
public class Mahasiswa {

    Scanner sc = new Scanner(System.in);
    String nama, nim, fakultas, jurusan, angkatan;

    void isi() {
        System.out.println("Isi data");
        System.out.print("Nama      : ");
        nama = sc.nextLine();
        System.out.print("NIM       : ");
        nim = sc.nextLine();
        System.out.print("Fakultas  : ");
        fakultas = sc.nextLine();
        System.out.print("Jurusan   : ");
        jurusan = sc.nextLine();
        System.out.print("Angkatan  : ");
        angkatan = sc.nextLine();
    }

    void cetak() {
        System.out.println("");
        System.out.println("Cetak data");
        System.out.println("Nama      : " + nama);
        System.out.println("NIM       : " + nim);
        System.out.println("Fakultas  : " + fakultas);
        System.out.println("Jurusan   : " + jurusan);
        System.out.println("Angkatan  : " + angkatan);
    }

    void jumlahKarakter() {
        System.out.println("");
        System.out.println("Jumlah karakter");
        System.out.println("Nama      : " + nama.length());
        System.out.println("NIM       : " + nim.length());
        System.out.println("Fakultas  : " + fakultas.length());
        System.out.println("Jurusan   : " + jurusan.length());
        System.out.println("Angkatan  : " + angkatan.length());
    }

public static void main(String[] args) {
        Mahasiswa mhs = new Mahasiswa();
        mhs.isi();
        mhs.cetak();
        mhs.jumlahKarakter();
      }
}
