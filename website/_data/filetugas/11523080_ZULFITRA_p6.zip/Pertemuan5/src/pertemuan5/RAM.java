/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan5;

/**
 *
 * @author PRAKTIKAN
 */
public class RAM {
    String nama;
    
    public RAM (String name){
        nama= name;
    }
    public void RAM(){
           RAM gigaByte = new RAM("Giga Byte ");
           System.out.println("Nama prosesor : " + gigaByte.nama);
                   
}
    }
