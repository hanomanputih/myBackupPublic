/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan5;

/**
 *
 * @author PRAKTIKAN
 */
public class Prosesor {
    String nama;
    
    public Prosesor (String name){
        nama= name;
    }
    public void prosesor () {
           Prosesor intelAtom = new Prosesor("Intel Atom 1");
           System.out.println("Nama prosesor : " + intelAtom.nama);
                   
}

}