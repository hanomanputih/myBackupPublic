/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan5;

/**
 *
 * @author PRAKTIKAN
 */
public class CPU {
    public int producNumber;
    public Prosesor p;
    public RAM r;
    
    public CPU (int producNumber){
        this.producNumber = producNumber;
        if (producNumber ==1){
            p = new Prosesor ("Intel Atom 1");
            r = new RAM ("Giga Byte");
        }
        
        }
    public void TampilCPU() {
        System.out.println("Nama prosesor : "+ p.nama);
        System.out.println("kapasitas RAM : "+ r.nama);
     
    }
    public static void main(String[] args) {
        CPU com = new CPU(1);
        com.TampilCPU();
    }
}
