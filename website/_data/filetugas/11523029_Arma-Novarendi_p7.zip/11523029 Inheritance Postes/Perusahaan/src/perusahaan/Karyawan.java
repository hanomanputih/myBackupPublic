/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perusahaan;

/**
 *
 * @author Praktikan
 */
public abstract class Karyawan {

    public int gajiPokok=3000000;
    public double tunjangan = 0.2*gajiPokok;
    public double bonus= 0.1*gajiPokok;
    
public void gaji(){
    System.out.println("Jumlah Tunjangan: "+tunjangan);
    System.out.println("Jumlah Bonus: "+bonus);
}
}