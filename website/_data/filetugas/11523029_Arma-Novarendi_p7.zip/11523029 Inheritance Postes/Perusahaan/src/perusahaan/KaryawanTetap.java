/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perusahaan;

/**
 *
 * @author Praktikan
 */
public class KaryawanTetap extends Karyawan{
    public double gaji;
    
public void gajiKtet(){
    gaji = tunjangan+gajiPokok+bonus;
    System.out.println("Gaji Pokok: "+gajiPokok);
    System.out.println("Jumlah Tunjangan: "+tunjangan);
    System.out.println("Bonus: "+bonus);
    System.out.println("Gaji: "+gaji);
}
}
