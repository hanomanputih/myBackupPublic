/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perusahaan;

/**
 *
 * @author Praktikan
 */
public class Perusahaan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        KaryawanTetap katet = new KaryawanTetap();
        katet.gajiKtet();
        //System.out.println("Gaji Karyawan Tetap: "+k);
        
        System.out.println("");
        System.out.println("");
        
        KaryawanKontrak kakon = new KaryawanKontrak();
        kakon.gajiKkont();
        //System.out.println("Gaji Karyawan Kontrak: "+gaji);
    }
}
