/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perusahaan;

/**
 *
 * @author Praktikan
 */
public class KaryawanKontrak extends Karyawan{
    public double gaji;
    
public void gajiKkont(){
    gaji = gajiPokok+bonus;
    System.out.println("Gaji Pokok: "+gajiPokok);
    System.out.println("Bonus: "+bonus);
    System.out.println("Gaji: "+gaji);
}
}
