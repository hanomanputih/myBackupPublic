/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

/**
 *
 * @author Praktikan
 */
public abstract class Karyawan {
    String nama;
    int gaji;
    int gajipokok = 3000000;
    int bonus;
    
    public void jumlahGaji(){
        gaji = gajipokok + bonus; 
    }
    
    protected void view(){
        System.out.println("Nama: " + nama);
        System.out.println("Gaji: "+ gaji);
    }
    
}
