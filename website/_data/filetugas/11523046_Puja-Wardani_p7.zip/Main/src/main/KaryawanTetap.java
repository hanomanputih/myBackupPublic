/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

/**
 *
 * @author Praktikan
 */
public class KaryawanTetap extends Karyawan {
    int tunjangan;
    
    public void hitungtunjangan() {
        tunjangan = 20/100*gajipokok;
    }
    
    @Override
    public void jumlahGaji(){
        gaji = gajipokok + bonus + tunjangan;
    }
        
    @Override
    public void view() {
        System.out.println("Nama: " + nama);
        System.out.println("Gaji: " + gaji);
    }
    
}
