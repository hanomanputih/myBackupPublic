/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

/**
 *
 * @author Praktikan
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        KaryawanTetap Jono = new KaryawanTetap();
        KaryawanKontrak Borno = new KaryawanKontrak();
        Borno.nama = "Borno";
        Borno.bonus= 150000;
        Borno.jumlahGaji();
        Borno.view();
        Jono.nama = "Jono";
        Jono.bonus = 200000;
        Jono.jumlahGaji();
        Jono.view();
    }
}
