/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;
public class Mahasiswa {
    String nama="zakiardiansyah",nim="11523288";
    void cetak(String nama) 
    {
       System.out.println("nama saya adalah: "+nama);
       
    }
    void nim()
    {
    System.out.println("nim saya adalah : ");    
    }
    public static void main(String[]args){
        Mahasiswa ct = new Mahasiswa();
        Mahasiswa ct2 = new Mahasiswa();
        ct.cetak("zakiardiansyah");
        ct2.nim("11523288");
        
      
       
    }

    private void nim(String string) {
        throw new UnsupportedOperationException("Not yet implemented");
    }
    
}
