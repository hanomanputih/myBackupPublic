/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
String nama;
String nim;
String fakultas;
String jurusan;
String angkatan;

void cetak () {
    nama="Aiman";
    nim="11523264";
    fakultas="FTI";
    jurusan="informatika";
    angkatan="2011";
    System.out.println(nama);
    System.out.println(nim);
    System.out.println(fakultas);
    System.out.println(jurusan);
    System.out.println(angkatan);
}

     public static void main (String[] args){
        Mahasiswa m = new  Mahasiswa();
        m.cetak();
        
        
        
    
    
           
}
    
    
}
