/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
    String nama;
    String nim;
    String fakultas;
    String jurusan;
    String angkatan;
    //string nama1 = new String ();
    
    void cetak (){
        System.out.println("Nama = " + nama);
        System.out.println("NIM = " + nim);
        System.out.println("Fakultas= " + fakultas);
        System.out.println("Jurusan= " + jurusan);
        System.out.println("Angkatan= " + angkatan);
    }
    public static void main(String[] args) {
        Mahasiswa mhs1 = new Mahasiswa ();
        Scanner sc = new Scanner(System.in);
        System.out.println("Masukkan nama = ");
        mhs1.nama = sc.nextLine();
        System.out.println("Masukkan NIM = ");
        mhs1.nim = sc.nextLine();
        System.out.println("Masukkan Fakultas = ");
        mhs1.nama = sc.nextLine();
        System.out.println("Masukkan jurusan = ");
        mhs1.jurusan = sc.nextLine();
        System.out.println("Masukkan angkatan = ");
        mhs1.angkatan = sc.nextLine();
        
        mhs1.cetak();
    }
}
