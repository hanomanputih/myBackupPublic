/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class PostTest {

    /**
     * @param args the command line arguments
     */
    String nama,fakultas,jurusan;
    int nim,angkatan;
   
    void Cetak (){
    Scanner c = new Scanner (System.in);
        System.out.println("Masukkan nama anda ");
        nama = c.next();
        System.out.println("Masukkan fakultas anda ");
        fakultas = c.next();
        System.out.println("Masukkan jurusan anda ");
        jurusan = c.next();
        System.out.println("Masukkan nim anda");
        nim = c.nextInt();
        System.out.println("Angkatan berapa anda?");
        angkatan = c.nextInt();
        System.out.println("Nama anda adalah "+nama);
        System.out.println("Fakultas anda adalah "+fakultas);
        System.out.println("Jurusan anda adalah "+jurusan);
        System.out.println("Nim anda adalah "+nim);
        System.out.println("Angkatan anda adalah "+angkatan);
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        PostTest n = new PostTest ();
        n.Cetak ();
        
    }
}
