/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
    String nama;
    String nim;
    String fakultas;
    String jurusan;
    String angkatan;
      
    public static void main(String[] args) {
        
        Mahasiswa m = new Mahasiswa();
        m.cetak();
        
    }
    
    void cetak () {
        Scanner baca = new Scanner(System.in);
        System.out.println("Nama Anda");
        nama = baca.next();
        System.out.println("NIM Anda");
        nim = baca.next();
        System.out.println("Fakultas Anda");
        fakultas = baca.next();
        System.out.println("Jurusan Anda");
        jurusan = baca.next();
        System.out.println("Angkatan Anda");
        angkatan = baca.next();
    System.out.println("nama"+nama+" NIM"+nim+" fakultas"+fakultas+" jurusan"+jurusan+" angkatan"+angkatan);
    }
}