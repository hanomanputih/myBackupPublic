/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest3;
import java.util.Scanner;
/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
    Scanner s=new Scanner(System.in);
    String nama, nim,jurusan,fakultas;
    void cetak (){
       System.out.println("masukkan nama :");
       nama=s.next();
       System.out.println("masukkan nim : ");
       nim=s.next();
       System.out.println("masukkan fakultas :");
       fakultas=s.next();
       System.out.println("masukkan jurusan : ");
       jurusan=s.next();
    }
    public static void main(String[]args){
        Mahasiswa m=new Mahasiswa();
        m.cetak();
        System.out.println("====Data anda====");
        System.out.println("nama : "+m.nama);
        System.out.println("nim : "+m.nim);
        System.out.println("fakultas : "+m.fakultas);
        System.out.println("jurusan : "+m.jurusan);
     
        
    }
}
