/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;
import java.util.Scanner;
   

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
    String nama, nim, fakultas, jurusan, angkatan;
    
    
    
    void isiData(){
        Scanner isi=new Scanner (System.in);
        System.out.println("nama ");
        nama= isi.next();
        System.out.println("nim ");
        nim= isi.next();
        System.out.println("fakultas ");
        fakultas= isi.next();
        System.out.println("jurusan ");
        jurusan= isi.next();
        System.out.println("angkatan ");
        angkatan= isi.next();
    }
    
    void cetak(){
        System.out.println("nama "+nama);
        System.out.println("nim "+nim);
        System.out.println("fakultas "+fakultas);
        System.out.println("jurusan "+jurusan);
        System.out.println("angkatan "+angkatan);
    }
        
  
    public static void main(String[] args) {
        Mahasiswa mhs=new Mahasiswa();
        
        mhs.isiData();
        mhs.cetak();
    }
}
