/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest5;

import org.omg.PortableInterceptor.SYSTEM_EXCEPTION;

/**
 *
 * @author Praktikan
 */
public class Prosesor {
    String NamaPros;
    public Prosesor (String Namapros){
        this.NamaPros = Namapros;
        
    }
    public void tampilpros() {
        System.out.println("Namanya prosesor yaitu:"+NamaPros);
        
    }
}
