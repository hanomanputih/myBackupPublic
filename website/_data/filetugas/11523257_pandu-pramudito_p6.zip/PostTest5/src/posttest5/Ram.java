/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest5;

/**
 *
 * @author Praktikan
 */
public class Ram {
    String NamaRam;
    
    public Ram (String NamaRam) {
        this.NamaRam = NamaRam;
    }
    public void tampilRam() {
        System.out.println ("Namanya Ram yaitu:"+NamaRam);
    }
}
