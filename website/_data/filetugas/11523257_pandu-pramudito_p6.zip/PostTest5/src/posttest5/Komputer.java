/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest5;

/**
 *
 * @author Praktikan
 */
public class Komputer {

   Ram rm;
   Prosesor pros;
 
   public Komputer (String namarm, String namapros){
       if(namarm.equals("1.5"))
       {
           rm = new Ram ("1536");
       }
       if(namapros.equals("core i7")) {
           pros = new Prosesor ("core intel i7");
   }
   }
       public static void main (String[] args){
           Komputer kom = new Komputer ("1.5","core i7");
           kom.rm.tampilRam();
           kom.pros.tampilpros();
       }
     }

