/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

/**
 *
 * @author praktikan
 */
public class Mahasiswa {

   String nama = "Miftakhurrokhman";
   String nim = "11523259";
   String fakultas = "FTI";
   String jurusan = "T.INF";
   String angkatan = "2011";      
   
   void cetak (){
       
       
       System.out.println ("Nama saya adalah : " + nama);
       System.out.println ("NIM saya adalah : " + nim);
       System.out.println("Fakultas Saya adalah : " + fakultas);
       System.out.println("Jurusan saya adalah : " + jurusan);
       System.out.println("Angkatan saya adalah : " + angkatan);
   }
   
   public static void main(String[] args){
        Mahasiswa cc = new Mahasiswa ();
        cc.cetak();
       
   }
}
