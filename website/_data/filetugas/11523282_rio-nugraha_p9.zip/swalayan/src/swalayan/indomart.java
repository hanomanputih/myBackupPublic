/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package swalayan;

/**
 *
 * @author Praktikan
 */
public class indomart {
      String namasekolah;
    
    public pelajar (String bayar,int harga, String swalayan) {
        Super (nama, umur);
        this swalayan =swalayan;
    }
}
