
package swalayan;


public class Swalayan {
    String harga;
    int bayar;


    public static void main(String[] args) {
        
    }
void informasi (){
    System.out.println("harga");
    System.out.println("bayar");
}
}
