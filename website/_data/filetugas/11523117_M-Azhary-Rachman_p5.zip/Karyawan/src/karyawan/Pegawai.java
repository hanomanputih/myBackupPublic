/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author PRAKTIKAN
 */
public class Pegawai {
        public static void main(String[] args) {
        Karyawan kry1 = new Karyawan ();
        kry1.setNama ("udin");
            System.out.println("nama " + kry1.getNama());
        kry1.setNip ("456123");
            System.out.println("nip " + kry1.getNip());
        kry1.setGaji ("Rp.12.000.000");
            System.out.println("gaji setahun " + kry1.getGaji());

}
}