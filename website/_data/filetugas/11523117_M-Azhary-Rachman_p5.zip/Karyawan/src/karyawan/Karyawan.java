/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;


public class Karyawan {
private String nip,nama,gaji;

    
    public void setNip (String nip) {
    this.nip =nip;
    } 
    public String getNip (){
        return nip;
 }
    public void setNama (String nama ){
    this.nama = nama;
    }
    public String getNama (){
        return nama;
    }
     public void setGaji (String gaji ){
    this.gaji = gaji;
    } 
    public String getGaji (){
        return gaji;
    }
}
   