/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package prototype;

/**
 *
 * @author PRAKTIKAN
 */
import java.util.Scanner;
public class Calculator {
    float x, y, hasil;
void tambah (){
    hasil = x+y;
}
void kurang(){
    hasil = x-y;
}
void kali(){
    hasil = x*y;
}
void bagi () {
    hasil = x/y;
}

public static void main (String [] args) {
    System.out.println("");
}
}
