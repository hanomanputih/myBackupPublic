/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package prototype;

/**
 *
 * @author PRAKTIKAN
 */

import java.util.Scanner;
public class Prototype1 {
    
    String kuda = "Berkaki empat";
   
    public static void main (String [] args) {
        Prototype1 str = new Prototype1();
    
        System.out.println(str.kuda.startsWith("kaki"));
        System.out.println(str.kuda.charAt(9));
        System.out.println(str.kuda.endsWith("at"));
        System.out.println(str.kuda);
    
    }
}
