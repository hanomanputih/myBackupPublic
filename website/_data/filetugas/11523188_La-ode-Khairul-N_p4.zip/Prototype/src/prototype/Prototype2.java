/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package prototype;

/**
 *
 * @author PRAKTIKAN
 */
import java.util.Scanner;
public class Prototype2 {
    String nama;
    int jumlah;
    
    public static void main (String [] args){
        Prototype2 test = new Prototype2();
        Scanner cin = new Scanner(System.in);
        System.out.print("input nama : ");
        test.nama = cin.next();
        test.jumlah = test.nama.length();
        System.out.println("panjang karakter = "+test.jumlah);
    }
    
}
