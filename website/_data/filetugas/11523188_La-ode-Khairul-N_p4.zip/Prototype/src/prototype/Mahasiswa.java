/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package prototype;

/**
 *
 * @author PRAKTIKAN
 */
import java.util.Scanner;
public class Mahasiswa {
    String nama;
    String nim ;
    String jurusan;
    String fakultas;
    String angkatan ;
    int jumlah;
   
    
    
    void cetak(){
        System.out.println("Nama : "+nama);
        System.out.println("NIM : " +nim);
        System.out.println("Jurusan : "+jurusan);
        System.out.println("Fakultas : "+fakultas);
        System.out.println("angkatan : "+angkatan);
        System.out.println("Panjang karakter nama : " +nama.length());
        System.out.println("Panjang karakter nim : "+nim.length());
        System.out.println("Panjang karakter jurusan : "+jurusan.length());
        System.out.println("Panjang karakter fakultas : "+fakultas.length());
        System.out.println("Panjang karakter angkatan : "+angkatan.length());
        jumlah =nama.length()+nim.length()+jurusan.length()+fakultas.length()+angkatan.length();
        System.out.println("total karakter"+jumlah);
        
    }
    public static void main (String [] args){
        
       Mahasiswa m = new Mahasiswa();
       Scanner cin = new Scanner(System.in);
        System.out.print("input nama anda : ");
        m.nama = cin.next();
        System.out.print("input NIM anda : ");
        m.nim = cin.next();
        System.out.print("input jurusan : ");
        m.jurusan = cin.next();
        System.out.print("input fakultas : ");
        m.fakultas = cin.next();
        System.out.print("input angkatan : ");
        m.angkatan = cin.next();
       
        m.cetak();
        
    }    
    
}
