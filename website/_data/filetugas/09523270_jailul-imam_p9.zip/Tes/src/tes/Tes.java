/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tes;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Tes {
    private static String i;

    private static String mextLine() {
        throw new UnsupportedOperationException("Not yet implemented");
    }
    
    String nama,nim;

    
    public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);
        System.out.println("Masukan Nama");
        String nama=sc.nextLine();
        System.out.println("Masukan Nama");
        String nim= sc.nextLine();
        ArrayList list = new ArrayList();
        list.add (nama);
        list.add (nim);
        
        for (Iterator<String> iterator = list.iterator ();iterator.hasNext(); ){
            String ii = (String) iterator.next();
            System.out.println("isi :"+ii);
        }
        Map<Integer,String> map = new HashMap ();
        map.put(1, nama);
        map.put(2, nim);
        
        for(Map.Entry<Integer,String> entry : map.entrySet()){
            System.out.println(entry.getKey() +","+entry.getValue());
            
        }
        
  
    }
}
