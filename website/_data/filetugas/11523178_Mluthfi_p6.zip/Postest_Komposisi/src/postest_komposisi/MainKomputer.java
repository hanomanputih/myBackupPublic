/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest_komposisi;

/**
 *
 * @author Praktikan
 */
public class MainKomputer {
    public static void main(String[] args) {
        Prosesor ps = new Prosesor("3.0 GHZ");
        Ram rm = new Ram("4 GB");
        Komputer km = new Komputer ("Asus", ps , rm);
        km.tampil(ps, rm);      
    }
}
