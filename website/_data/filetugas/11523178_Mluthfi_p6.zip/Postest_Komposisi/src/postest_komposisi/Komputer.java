/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest_komposisi;

/**
 *
 * @author Praktikan
 */
public class Komputer {
    String merekKomputer;
    Prosesor ps;
    Ram rm;
    
    public Komputer(String merekKomputer, Prosesor ps, Ram rm){
        this.merekKomputer = merekKomputer;
        this.ps = ps;
        this.rm = rm;
    }


    public void tampil(Prosesor ps, Ram rm){
        System.out.println("Merek Komputer : "+merekKomputer);
        System.out.println("Kecepatan Prosesor : "+ps.kecepatan);
        System.out.println("Besar RAM : "+rm.besar);
        
    }
}
