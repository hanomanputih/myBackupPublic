/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author PRAKTIKAN
 * 
 */
public class Shadrina {
    public static void main (String [] args) {
   Karyawan kr = new Karyawan ();
   kr.setNip(" 11523088");
   kr.setNama(" Shadrina Sari Tazkia ");
   kr.setGaji(1200000);
  
   System.out.println ("nip karyawan adalah "+kr.getNip());
    System.out.println ("nama karyawan adalah "+kr.getNama());
    System.out.println ("gaji karyawan dalam setahun adalah "+kr.getGaji());
    
    
}}
