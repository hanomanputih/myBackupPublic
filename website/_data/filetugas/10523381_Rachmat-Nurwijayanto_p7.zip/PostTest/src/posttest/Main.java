/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author praktikan
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     karyawantetap kt =new karyawantetap ();
     
     
     kt.nama="acad";
     kt.jabatan="dirut";
     kt.bertugas();
     kt.status="janda";
     kt.view();
     
        System.out.println("");
        
      karyawankontrak kk =new karyawankontrak ();
     
     
     kk.nama="acad";
     kk.jabatan="anggota";
     kk.bertugas();
     kk.status="duda";
     kk.view();
     
     
    }
}
