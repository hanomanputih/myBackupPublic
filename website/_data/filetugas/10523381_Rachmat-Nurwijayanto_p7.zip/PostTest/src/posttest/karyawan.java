/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author praktikan
 */

    public abstract class karyawan{
        protected String nama;
        protected String jabatan;
        
        
        public abstract void bertugas();
        
        public void view (){
            System.out.println("Nama : "+nama);
            System.out.println("Jabatan : "+jabatan);
     
        }
        
    }

