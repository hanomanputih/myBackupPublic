/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author praktikan
 */
public class karyawantetap extends karyawan {
    public String status; 
            protected int gaji;
    protected int gajipokok = 3000000;
    protected int tunjangan = gajipokok*20/100;
    protected int bonus = 250000;
   public int gajitotal = gajipokok+tunjangan+bonus;
    
    @Override
    public void view(){
    super.view();
        System.out.println("Status : "+status);
}
    
    @Override
    public void bertugas (){
        System.out.println("gaji pokok : "+gajipokok);
        System.out.println("total gaji : "+gajitotal);
  
    }
}
