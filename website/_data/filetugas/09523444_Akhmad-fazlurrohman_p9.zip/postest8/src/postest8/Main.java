/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package postest8;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

/**
 *
 * @author praktikan
 */
public class Main {

    public static void main(String[] args) {

    ArrayList list = new ArrayList();
    list.add ("nama : ifaz");
    list.add ("nim : 09523444");
    list.add ("KSMK");
    System.out.println("ukuran list "+list.size());

    for (Iterator iterator = list.iterator(); iterator.hasNext();){
        String ii = (String) iterator.next();
        System.out.println(""+ii);

         HashMap map = new HashMap();
         map.put ("nama ", "ifaz");
         map.put("NIM", new Integer (9523444));
         System.out.println("===============");
        System.out.println(map);
        System.out.println("Ukuran map : "+ map.size());
        
        
    }
    }
}
