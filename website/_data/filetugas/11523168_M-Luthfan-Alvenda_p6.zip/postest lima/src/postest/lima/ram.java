/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest.lima;

/**
 *
 * @author PRAKTIKAN
 */
public class ram {
    String memori;
}
