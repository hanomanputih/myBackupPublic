/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest.lima;

/**
 *
 * @author PRAKTIKAN
 */
public class cpu {
    public ram r;
    public prosesor p;
    
   
    public cpu(){
        r = new ram();
        p = new prosesor();
        
    }
    
    public static void main(String[] args) {
        cpu c = new cpu();
        c.p = new prosesor();
        c.r = new ram();
        c.p.jenis = "Intel i7";
        c.r.memori = "16 GB";
        System.out.println("Jenis prosesor = "+ c.p.jenis);
        System.out.println("Kapasitas RAM = "+c.r.memori);
    }
        
}
