/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komposisi5;

/**
 *
 * @author PRAKTIKAN
 */
public class komputer {
    String nama;
    komputer k;
    prosesor p;
    ram rm;
    public komputer(String nama){
        this.nama=nama;
        
        p=new prosesor("AMD");
        rm=new ram("4GB");
        System.out.println("merk komputer "+nama);
        System.out.println("mempumyai prosesor "+p.id_pro);
        System.out.println("mumpunyai kapasitas ram "+rm.kapasitas);
    }
    public static void main(String[] args) {
        komputer k=new komputer("ASUS");
    }
}
