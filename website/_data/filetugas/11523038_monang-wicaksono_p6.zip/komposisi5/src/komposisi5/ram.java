/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komposisi5;

/**
 *
 * @author PRAKTIKAN
 */
public class ram {
    String kapasitas ;
    
    public ram(String kapasitas){
        this.kapasitas=kapasitas;
    }
    
}
