/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes7;

/**
 *
 * @author praktikan
 */
public class TokoAgung extends Swalayan {
    
        @Override
    void tampil(){
        System.out.println("Toko Agung");
        if(harga%25==0){
            System.out.println("Harga   : "+harga);
            System.out.println("Bayar   : "+harga);
        
    }else{
        sisa=(int) (harga%25);
        bayar=(int) (harga-sisa);
            System.out.println("Harga   : "+harga);
            System.out.println("Bayar   : "+bayar);       
}
    
}
}
