/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes7;

/**
 *
 * @author praktikan
 */
public class PosTes7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Swalayan swl;
        Indomaret ind = new Indomaret();
        TokoAgung ta = new TokoAgung();
        
        swl=ind;
        ind.tampil();
        
        System.out.println("*****************");
        
        swl=ta;
        ta.tampil();
        
    }
}
