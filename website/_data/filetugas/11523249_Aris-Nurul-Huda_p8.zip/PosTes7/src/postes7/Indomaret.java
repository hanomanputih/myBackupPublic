/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes7;

/**
 *
 * @author praktikan
 */
public class Indomaret extends Swalayan {
    
    @Override
    void tampil(){
        System.out.println("Indomaret");
        if(harga%25==0){
            System.out.println("Harga   : "+harga);
            System.out.println("Bayar   : "+harga);
        
    }else{
        sisa=(int) (25-(harga%25));
        bayar=(int) (harga+sisa);
            System.out.println("Harga   : "+harga);
            System.out.println("Bayar   : "+bayar);       
}
    
}
}
