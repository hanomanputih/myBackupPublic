/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes7;

/**
 *
 * @author praktikan
 */
public class coba {
    Swalayan swl;
        Indomaret ind=new Indomaret();
        TokoAgung tgn=new TokoAgung();
        
        swl=ind;
        swl.tampil();
        
        System.out.println("======================");
        swl=tgn;
        swl.tampil();
    }
}
