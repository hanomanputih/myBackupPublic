/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Postest7;

/**
 *
 * @author Praktikan
 */
public class Swalayan {
float Harga ;
int Bayar;
int Sisa;

void tampil (){

}

    }
