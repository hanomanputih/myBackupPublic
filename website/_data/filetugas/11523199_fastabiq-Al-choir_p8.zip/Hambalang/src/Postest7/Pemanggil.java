/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Postest7;

/**
 *
 * @author Praktikan
 */
public class Pemanggil {

     public static void main(String[] args) {

            Swalayan s = new Swalayan();
        Indomaret i = new Indomaret();
        TokoAgung t = new TokoAgung();

        i.Harga =  19212;
        t.Harga =  19212;
        s=i;
        s=t;

        i.tampil();
        t.tampil();
    }


}
