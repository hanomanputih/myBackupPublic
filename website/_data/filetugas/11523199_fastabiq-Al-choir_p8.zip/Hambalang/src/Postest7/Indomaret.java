/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Postest7;

/**
 *
 * @author Praktikan
 */
public class Indomaret extends Swalayan {


    @Override
    void tampil (){
    if (Harga % 25 == 0) {
        System.out.println("Harga :" + Harga);}
        else{
            Sisa = (int) (25 - (Harga % 25));
            Bayar = (int) (Harga + Sisa) ;
            System.out.println("Harga :" + Bayar);
        }
    }
}


