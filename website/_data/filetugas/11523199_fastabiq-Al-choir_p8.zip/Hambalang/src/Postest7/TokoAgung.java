/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Postest7;

/**
 *
 * @author Praktikan
 */
public class TokoAgung extends Swalayan {

    @Override
void tampil(){
    Sisa = (int) (Harga % 25);
    Bayar = (int) (Harga - Sisa) ;
            System.out.println("Bayar :" + Bayar);
            System.out.println("Harga   :" + Harga);

      
    }

}
