/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hambalang;

/**
 *
 * @author Praktikan
 */
public class Karyawan extends Manusia {
    String kantor;


    @Override
void tampil (){

    System.out.println("Nama   : "+ nama);
    System.out.println("Alamat  :"+ Alamat);
    System.out.println("Kantor  :"+ kantor);
}
}
