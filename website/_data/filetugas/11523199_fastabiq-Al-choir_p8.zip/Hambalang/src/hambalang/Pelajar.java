/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hambalang;

/**
 *
 * @author Praktikan
 */
public class Pelajar extends Manusia {
    String sekolah;

    @Override
    void tampil(){
        System.out.println("nama    : "+nama);
        System.out.println("Alamat  :"+Alamat);
        System.out.println("Sekolah :"+sekolah);
    }
}
