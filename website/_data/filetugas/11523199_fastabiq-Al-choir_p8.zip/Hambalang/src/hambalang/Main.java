/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hambalang;

/**
 *
 * @author Praktikan
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

       // Manusia m;
        //Pelajar p = new Pelajar ();
        //p.sekolah = "SMA 7 YK";
       // p.tampil();

       // Karyawan k = new Karyawan();
       // k.kantor = "PT. wakakaka";
        //k.tampil();
   double d = 5.99999;
        int i = (int)d;
     


        System.out.println("d   :"+ i);




    }

}
