package terserah;

public class Komputer {
    private String komputer;
    private int Harga;
    private Ram r;
    private Prosessor p;
    
    public Komputer(String komputer) {
        this.komputer = komputer;
        if (komputer.equals("tower")) {
            r = new Ram(1);
            p = new Prosessor("Pentium 4", 2.80);
        }
    }
    public void tampil(){
        System.out.println("Nama Komputer : " +komputer);
        System.out.println("Ram :"+r.Besar);
        System.out.println("Prosessor clock: "+p.Clock);
        System.out.println("Prosessor kelas: "+p.kelas);
  
    }
    public static void main(String[] args) {
        Komputer k = new Komputer("tower");
        k.tampil();
        
    }
}
