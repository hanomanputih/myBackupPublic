/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package terserah;
public class Ram {
     int Besar;
    
    public Ram (int Besar){
        this.Besar=Besar;
    }
    public void tampilRam(){
        System.out.println("Besar Ram: "+Besar);
    }
}
