/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package terserah;

public class Prosessor {
   String kelas;
   double Clock;
        
    public Prosessor(String kelas, double Clock){
        this.kelas=kelas;
        this.Clock=Clock;
    }
 public void tampil(){
     System.out.println("Kelas prosessor: "+kelas);
     System.out.println("Clock prosessor: "+Clock);
 }
}
