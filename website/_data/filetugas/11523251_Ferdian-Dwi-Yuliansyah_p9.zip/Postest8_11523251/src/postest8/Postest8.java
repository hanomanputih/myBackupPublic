/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest8;
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Praktikan
 */
public class Postest8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Map<String,String> mhs = new HashMap <String,String>();
  
        mhs.put("Cilacap","Ferdian");
        mhs.put("Sleman","Angga");
        mhs.put("Bantul","Pandu");
        mhs.put("Kudus","Reza");
        mhs.put("Cirebon","Miftah");
        
        System.out.println(mhs);
        System.out.println("");
        System.out.println(mhs.get("Cilacap"));
        
        System.out.println("=======================");
        
        for (Map.Entry<String,String> e : mhs.entrySet()){
            System.out.println(e.getKey()+" , "+e.getValue());
        }
        System.out.println("=======================");
        
        List mhsa = new ArrayList();
        mhsa.add("Ferdian");
        mhsa.add("Angga");
        mhsa.add("Pandu");
        mhsa.add("Reza");
        mhsa.add("Miftah");
        
        Iterator it = mhsa.iterator();
        while(it.hasNext()){
            System.out.println(it.next());
    }
        System.out.println("Menampilkan indeks 2 :");
        System.out.println(mhsa.get(2));
}
}
