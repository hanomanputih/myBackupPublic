/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author praktikan
 */
public abstract class Karyawan {
    int gajipokok= 3000000;
    int bonus=5000000;
    
  protected void view(){
      System.out.println("Gaji pokok :"+gajipokok);
      System.out.println("Bonus     :"+bonus);
  }
}
