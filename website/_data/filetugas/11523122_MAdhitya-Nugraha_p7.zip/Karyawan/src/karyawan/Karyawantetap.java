/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author praktikan
 */
public abstract class Karyawantetap extends Karyawan {
    int gaji;
    int tunjangan = 60000;
            
    @Override
    public void view(){
        gaji=gajipokok + bonus + tunjangan;
        System.out.println("Gaji Karyawan tetap        :"+ gaji);
}
}
