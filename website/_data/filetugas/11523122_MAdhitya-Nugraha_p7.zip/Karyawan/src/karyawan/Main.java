/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author praktikan
 */
public class Main {
   public static void main(String[] args){
       Karyawantetap kt = new Karyawantetap() {};
       kt.view();
       Karyawankontrak kk = new Karyawankontrak();
       kk.view();
   } 
}
