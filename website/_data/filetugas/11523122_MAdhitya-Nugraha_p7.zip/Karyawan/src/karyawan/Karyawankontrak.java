/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author praktikan
 */
public class Karyawankontrak extends Karyawantetap {
    //int gajipokok;
    //int tunjangan1 = 60000;
    int gaji;
    
    @Override
    public void view(){
       gaji=gajipokok + bonus;
        System.out.println("Gaji Karyawan kontak        :"+ gaji);
}
}