/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postestkomposisi;

/**
 *
 * @author PRAKTIKAN
 */
public class Komputer {
    String kategori;
    Ram ukuran;
    Prosesor nama;
    
    public Komputer(String kategori, Ram ukuran,Prosesor nama){
        this.kategori=kategori;
        this.ukuran=ukuran;
        this.nama=nama;
    }
    
    
    public void tampil(Ram ram1, Prosesor prosi1){
        System.out.println("kategori komputer : "+kategori);
        System.out.println("ramnya : "+ukuran.giga);
        System.out.println("prosesornya: "+nama.merk);
    }
    
}
