/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postestkomposisi;

/**
 *
 * @author PRAKTIKAN
 */
public class Ram {
    String giga;
    
    public Ram(String giga){
        this.giga=giga;
            }
    
}
