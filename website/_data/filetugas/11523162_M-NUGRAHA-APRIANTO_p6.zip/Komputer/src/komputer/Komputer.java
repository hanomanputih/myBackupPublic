/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class Komputer {
     String merk ;
     RAM R ;
     Prosessor P ;
    
    public Komputer (String merk, RAM R, Prosessor P) {
        this.merk = merk ;
        this.R = R ;
        this.P = P ;
   }

    Komputer(RAM r, Prosessor p) {
        throw new UnsupportedOperationException("Not yet implemented");
    }

    public Prosessor getP() {
        return P;
    }

    public void setP(Prosessor P) {
        this.P = P;
    }

    public RAM getR() {
        return R;
    }

    public void setR(RAM R) {
        this.R = R;
    }

    public String getMerk() {
        return merk;
    }

    public void setMerk(String merk) {
        this.merk = merk;
    }
    
}