/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class Main {
    public static void main(String[] args) {
        
        Prosessor p = new Prosessor () ;
        RAM r = new RAM () ;
        
        p.setHarga(1000000);
        p.setMerk("hitachi");
        
        r.setMerk("toshiba");
        r.setUkuran(100);
        Komputer komp = new Komputer ("merk",r, p) ;
        
        System.out.println("Merk RAM = "+komp.getR().merk);
        System.out.println("Ukuran RAM = "+komp.getR().ukuran);
        System.out.println("Merk Prosessor = "+komp.getP().getMerk());
        System.out.println("Harga Prosessor = "+komp.getP().getHarga());
        
        
        
    }
}
