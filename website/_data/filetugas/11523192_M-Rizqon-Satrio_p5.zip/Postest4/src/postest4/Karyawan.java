/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest4;

/**
 *
 * @author Praktikan
 */
public class Karyawan {
   public String nip;
   public String nama;
   public int gaji;
   String getNip;
   

   
   public void setNip(String nipKamu) {
       if (nipKamu.length()==8){
           nip=nipKamu;
       }else{
           System.out.println("Error");
           
       }
   }
   
   public String getNip(){
       return nip;
   }
   
   public void setNama(String namaKamu) {
       if (namaKamu.length()>10){
           nama=namaKamu;
       }else{
           System.out.println("Error");
           
       }
   }
   
   public String getNama(){
       return nama;
   }
 
   public void setgaji(int gajiKamu){
       gaji = gajiKamu;
   }
   
 
   
   public int getGaji(){
       return gaji;
      
   }
}




  
