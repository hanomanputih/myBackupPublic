/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest4;

/**
 *
 * @author Praktikan
 */
public class Pemanggil {
    public static void main(String[] args) {
        Karyawan kar = new Karyawan();
        
        kar.setNip("11523192");
        kar.setNama("Rizqon");
        kar.setgaji(10000000);
        
        System.out.println("NIP :"+kar.getNip);
        System.out.println("Nama :"+kar.getNama());
        System.out.println("Gaji :"+kar.getGaji());
    }
}
