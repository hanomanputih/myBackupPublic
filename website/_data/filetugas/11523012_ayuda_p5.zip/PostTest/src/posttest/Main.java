/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author Praktikan
 */
public class Main {

    
    public static void main(String[] args) {
        Karyawan ka = new Karyawan();
        ka.setNip("12356710");
        ka.setNama("Ayuda");
        ka.setGaji(50000000);
        System.out.println("NIP = "+ka.getNip());
        System.out.println("NAMA = "+ka.getNama());
        System.out.println("GAJI = "+ka.getGaji());
    }
}
