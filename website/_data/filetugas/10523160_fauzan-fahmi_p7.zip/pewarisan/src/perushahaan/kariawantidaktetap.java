/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perushahaan;

/**
 *
 * @author PRAKTIKAN
 */
public class kariawantidaktetap extends kariawan{
    int bonus=(15/100)*gajipokok;
    int totalgaji;
    public void gajikariawantidaktetap(){
        totalgaji=bonus*gajipokok;
        System.out.println("total gaji="+totalgaji);
    }

   
}
