/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pewarisan;

/**
 *
 * @author PRAKTIKAN
 */
public class dekan extends dosen {
    String fakultas;
    
    @Override
    public void view(){
        fakultas="fti";
        System.out.println("nama :"+nama);
        System.out.println("jurusan:"+jurusan);
        System.out.println("fakultas :"+fakultas);
    }
}
