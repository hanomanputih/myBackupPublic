/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pewarisan;

/**
 *
 * @author PRAKTIKAN
 */
public class dosen {
    String nama= "fauzan";
    String jurusan= "informatika";
    
    //dosen(int no_p){
        //System.out.println("no p"+no_p);
    //}
    
    public void view(){
        System.out.println("nama dosen :"+ nama);
        System.out.println("jurusan :"+jurusan);
        
    }
    
}
