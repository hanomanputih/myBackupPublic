package posttes3;

import java.util.Scanner;

public class Mahasiswa {
    String nama, nim, fakultas, jurusan, angkatan;
    
     void cetak(){
     System.out.println("Nama: " +nama+ " "+"Panjang Karakter Nama :"+ nama.length());
     System.out.println("NIM: " +nim+ " "+ "Panjang Karakter Nim : "+ nim.length());
     System.out.println("Fakultas: " +fakultas+ " "+ "Panjang Karakter Fakultas :  "  +fakultas.length());
     System.out.println("Jurusan: " +jurusan+ " " +"Panjang Karakter Jurusan :" + jurusan.length());
     System.out.println("Angkatan: " +angkatan+ " "+"Panjang Karakter Angkatan : "+ angkatan.length());
     }
     
     public static void main(String[] args){
         Mahasiswa m = new Mahasiswa();
         Scanner sc = new Scanner(System.in);
         System.out.println("Masukkan Nama Anda : ");
         m.nama = sc.nextLine();
         System.out.println("Masukkan NIM Anda : ");
         m.nim = sc.next();
         System.out.println("Masukkan Fakultas Anda :");
         m.fakultas = sc.next();
         System.out.println("Masukkan Jurusan Anda :");
         m.jurusan = sc.next();
         System.out.println("Masukkan Angkatan Anda :");
         m.angkatan = sc.next();
         m.cetak();
     }
}
