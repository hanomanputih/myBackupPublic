/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

/**
 *
 * @author PRAKTIKAN
 */
public class Main {
    public static void main(String[] args) {
        Karyawan ka = new Karyawan ();
        ka.setNIP("12345678");
        System.out.println("NIP = "+ka.getNIP());
        ka.setNAMA("Ayu");
        System.out.println("NAMA = "+ka.getNAMA());
        ka.setGAJI(15000000);
        System.out.println("GAJI Setahun = "+ka.getGAJI());
        
    }
}
