/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

/**
 *
 * @author PRAKTIKAN
 */
public class Karyawan {
    private String nip;
    private String nama;
    private int gaji;
    
    public void setNIP (String nip) {
        System.out.println("nip ="+nip);
    }
    String getNIP() {
return nip;
}
    public void setNAMA (String nama) {
        System.out.println("nama ="+nama);
    }
    String getNAMA() {
      return nama;  
    }
    public void setGAJI (int gaji) {
        this.gaji = gaji * 12;
        
    }
int getGAJI () {
    return gaji;
}
}
