/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package multiclass;

/**
 *
 * @author Praktikan
 */
public class Cpu {
    String produksi;
    Prosesor prosesor;
    Ram ram;
    
    public Cpu (String produk){
        produksi = produk;
        if (produk.equals("1")){
            ram = new Ram ();
            prosesor = new Prosesor();
         
            
        }
    } 
    
    public static void main(String[] args) {
        Cpu cp = new Cpu("1");
        System.out.println(cp.ram.nama+cp.ram.kapasitas);
        System.out.println(cp.prosesor.nama+cp.prosesor.besar);
    }
}
