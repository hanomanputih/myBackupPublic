/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Praktikan
 */
public class kapsul {
    public static void main(String[] args) {
        
        karyawan m = new karyawan();
        m.setgaji();
        m.setnama("samuraimy");
      m.setnip("11523266");
        System.out.println("nip  : "+ m.getnip());
        System.out.println("nama : "+ m.getnama());
        System.out.println("gsji : "+ m.getgaji());
    }
}
