/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Praktikan
 */
//THIS IS SAMURAIMY
//NIM 11523266
 class karyawan {
   private String nama, nip;
   private int gaji;
    
       public void setnip(String fnip){
    nip=fnip;
   }
       public void setnama(String myname){
       nama=myname;
   }
         public void setgaji(){
       gaji=234567;
   }
    public String getnama(){
   return(nama);
   }
   public String getnip(){   
   return(nip);
   } 
     public int getgaji(){
   return(gaji);
   }
   
}
