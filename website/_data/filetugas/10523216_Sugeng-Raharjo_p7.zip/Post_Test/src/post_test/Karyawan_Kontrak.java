/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package post_test;

/**
 *
 * @author praktikan
 */
public class Karyawan_Kontrak extends Karyawan {
    int gajiKontrak = (+gajiPokok + +bonus);

    @Override
    public void totalGaji() {
        super.viewGaji();
        System.out.println("Status : Karyawan Kontrak");
        System.out.println("==========================");
        System.out.println("Total Gaji : "+gajiKontrak);
        
    }
    
    
}
