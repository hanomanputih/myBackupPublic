/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package post_test;

/**
 *
 * @author praktikan
 */
public abstract class Karyawan {
    protected int gajiPokok = 3000000;
    protected double tunjangan = gajiPokok * 0.2;
    protected int bonus = 500000;
    
   
    public abstract void totalGaji();
    
    public void viewGaji(){
        System.out.println("Gaji Pokok : "+gajiPokok);
        System.out.println("Bonus : "+bonus);
}
}
