/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package post_test;

/**
 *
 * @author praktikan
 */
public class Karyawan_Tetap extends Karyawan{
    double gajiTetap = +gajiPokok + +tunjangan + +bonus;

    @Override
    public void totalGaji() {
        super.viewGaji();
        System.out.println("Status : Pegawai Tetap");
        System.out.println("Tunjangan : "+tunjangan);
        System.out.println("=======================");
        System.out.println("Total Gaji : "+gajiTetap);
        System.out.println("\n");
        
    }
    
    
    
}
