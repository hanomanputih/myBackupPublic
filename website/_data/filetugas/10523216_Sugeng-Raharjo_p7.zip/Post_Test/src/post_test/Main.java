/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package post_test;

/**
 *
 * @author praktikan
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Karyawan_Tetap kt = new Karyawan_Tetap();
        kt.totalGaji();
        
        Karyawan_Kontrak kk = new Karyawan_Kontrak();
        kk.totalGaji();
        
    }
}
