/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package postest;

/**
 *
 * @author Praktikan
 */
public class processor {
    String jenis;




public processor (String jenis) {
    this.jenis = jenis;
  

}
public void tampil(){
    System.out.println("Jenis Processor : "+jenis);

}
}
