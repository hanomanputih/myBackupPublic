/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package postest;

/**
 *
 * @author Praktikan
 */
public class komputer {
Ram rm;
processor porcie;
    public static void main (String [] args){
        Ram kapasitas = new Ram ("Kingstone 1800 DDR3");
        processor jenis = new processor ("AMD Athlon X2 255");
        komputer pc = new komputer();
        jenis.tampil();
        kapasitas.tampilan();
    }
}
