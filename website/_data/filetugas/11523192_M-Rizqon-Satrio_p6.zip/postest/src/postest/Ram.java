/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package postest;

/**
 *
 * @author Praktikan
 */
public class Ram {
String kapasitas;

public Ram (String Kapasitas1){
    kapasitas = Kapasitas1;
    }
    public void tampilan(){
        System.out.println("RAM :"+kapasitas);
}
}
