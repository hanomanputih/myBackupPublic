/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class Prosesor {
    String NoPro,kapasitas;
    Prosesor(String NoPro,String kapasitas){
        this.NoPro=NoPro;
        this.kapasitas=kapasitas;
    }
}
