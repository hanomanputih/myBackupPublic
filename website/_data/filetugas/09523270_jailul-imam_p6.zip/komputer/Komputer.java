/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class Komputer {
Prosesor pro;
    public void komputer(){
        pro=new Prosesor("1","4g");
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Komputer k = new Komputer();
        k.komputer();
        System.out.println("nama prosesor "+k.pro.NoPro);
    }
}
