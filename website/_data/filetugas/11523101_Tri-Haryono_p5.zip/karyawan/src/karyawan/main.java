/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author PRAKTIKAN
 */
public class main {

    public static void main (String [] args){
        Karyawan kry = new Karyawan();
        
        kry.setNip("54652145865");
        kry.setNama("tri Haryono");
        kry.setGaji(9000000);
        
        System.out.println("nip anda adalah: "+kry.getNip());
        System.out.println("nama anda adalah :"+kry.getNama());
        System.out.println("gaji anda setahun adalah: "+kry.getGaji());
    }
}

