/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

/**
 *
 * @author Praktikan
 */
public class Postest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        karyawan kry = new karyawan ();
        
        kry.setNIP("11523016");
        System.out.println("Nomor induk anda adalah " +kry.getNIP());
        
        kry.setNAMA("Tiwii");
        System.out.println("Nama anda adalah "+kry.getNAMA());
        
        kry.setGAJI(10000000);
        System.out.println("Gaji anda adalah "+kry.getGAJI());
        
        // TODO code application logic here
    }
}
