/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

/**
 *
 * @author Praktikan
 */
public class karyawan {
    private String nip;
    private String nama;
    private int gaji;
    
    void setNIP(String nip){
        if(nip.length() == 8){
            this.nip = nip;
        }else {
            System.out.println("Eror");
        }
    }
    String getNIP(){
        return nip;
    
    }
    void setNAMA(String nama){
        if (nama.length()==5){
            this.nama = nama;
    }else {
            System.out.println("Bukan nama anda");
        }
    }
    String getNAMA(){
        return nama;
        
    }
    void setGAJI(int gaji){
        if (gaji == 10000000){
            this.gaji = gaji;
        }else {
            System.out.println("Eror");
        }
    }
    int getGAJI(){
        return gaji;
    }
}

