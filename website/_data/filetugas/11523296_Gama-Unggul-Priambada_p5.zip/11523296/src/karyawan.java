 class karyawan {
   private String nama, nip;
   private int gaji;
    
   public void setnip(String nnip){
   nip=nnip;
   }
   public void setnama(String jeneng){
   nama=jeneng;
   }
   public void setgaji(){
   gaji=100000000;
   }
   public String getnama(){
   return(nama);
   }
   public String getnip(){   
   return(nip);
   } 
   public int getgaji(){
   return(gaji);
   }
   
}
