/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Praktikan
 */
public class pegawai {
    public static void main(String[] args) {
        
        karyawan m = new karyawan();
        m.setgaji();
        m.setnama("gama");
        m.setnip("11523296");
        System.out.println("NIP  : "+ m.getnip());
        System.out.println("Nama : "+ m.getnama());
        System.out.println("Gaji : "+ m.getgaji());
    }
}
