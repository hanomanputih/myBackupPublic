//post test pertemuan 5 
//Buatlah code program yang mengimplementasikan KOMPOSISI dari hubungan CPU,
//prosesor, dan RAM. dengan atribut bebas.cetaklah atribut tsb.


//Nama :wahyu purnomo
//NIM  : 10523002


package multiclass1;


public class CPU {
    private int np;
    private Processor p;
    private RAM ram;
    
    public CPU (int np) {
        this.np=np;
        if(np == 1){
            p = new Processor (5);
            ram = new RAM (3);
            
                    
        }
    }
    void tampil(){
        System.out.println("Nomor Produksi  : "+ np);
        System.out.println("Nomor Processor : "+ p.no);
        System.out.println("Nomor RAM       : "+ ram.no);
    }
            
}
 