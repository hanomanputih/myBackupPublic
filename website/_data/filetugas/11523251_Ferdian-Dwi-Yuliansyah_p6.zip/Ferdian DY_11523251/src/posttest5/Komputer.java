/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest5;

/**
 *
 * @author PRAKTIKAN
 */
public class Komputer {
    Prosesor P;
    Ram R;
    int hargaKomputer;
    
    public Komputer(int hargaKomputer){
        this.hargaKomputer = hargaKomputer;
        R = new Ram ("Kingstone");
        P = new Prosesor ("Intel",2500000);
    }
    public void Display(){
        System.out.println("Harga Komputer  : "+hargaKomputer);
        System.out.println("Merk Prosesor   : "+P.merk);
        System.out.println("Harga Prosesor  : "+P.harga);
        System.out.println("Nama RAM        : "+R.merkRam);
    }
    public static void main(String[]args){
    Komputer k = new Komputer (15000000);
    k.Display();
    }
}
