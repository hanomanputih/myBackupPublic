/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest7;

/**
 *
 * @author PRAKTIKAN
 */
public class Swalayan {
    //Scanner s = new Scanner(System.in);
    float harga = 19212;
    int bayar;
    int sisa;

    void carapembayaran() {
    }
}