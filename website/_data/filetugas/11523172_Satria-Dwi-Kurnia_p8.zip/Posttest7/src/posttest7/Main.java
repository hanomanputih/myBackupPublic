/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest7;

/**
 *
 * @author PRAKTIKAN
 */
public class Main {
    
    public static void main(String[] args) {
        Swalayan swa;
        System.out.println("INDOMART");
        swa = new Indomart();
        swa.carapembayaran();
        
        System.out.println("Toko Agung");
        swa = new TokoAgung();
        swa.carapembayaran();
    }
}
