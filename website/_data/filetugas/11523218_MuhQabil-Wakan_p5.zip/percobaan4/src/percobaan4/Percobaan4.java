/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package percobaan4;

/**
 *
 * @author Praktikan
 */
public class Percobaan4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       karyawan i = new karyawan();
       i.setNip("11523218");
       i.setNama("andrysys");
       i.getGaji();

       
        System.out.println("Nim : "+i.getNip());
        System.out.println("Nama : "+i.getNama());
        System.out.println("Gaji anda :"+i.getGaji());
        
    }
}
