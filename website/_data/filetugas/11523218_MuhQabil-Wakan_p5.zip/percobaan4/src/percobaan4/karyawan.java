/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package percobaan4;

/**
 *
 * @author Praktikan
 */
public class karyawan {
    private String nama;
    private String nip;
    private int gaji;
    
    
    void setNama(String n){
        nama = n;
    }
    
    String getNama(){
        return nama;
    }
    
        void setNip(String nm){
            nip = nm;
            if(nm.length()==10){
                nip = nm;
            }else {
                System.out.println("nip anda keluar");
            }
    }
        String getNip(){
            return nip;
        }
        
        void setGaji(int i){
            gaji =i;
            if(gaji== 6){
                gaji=i;
        }else {
                System.out.println("200.000");
            }
        }            
        int getGaji(){
            return gaji;
        }
}
