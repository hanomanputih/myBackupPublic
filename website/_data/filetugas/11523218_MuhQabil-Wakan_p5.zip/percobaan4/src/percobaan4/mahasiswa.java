/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package percobaan4;

/**
 *
 * @author Praktikan
 */
public class mahasiswa {
    private String nama;
    public String nip;
    
    void setNama(String n){
        nama = n;
    }
    
    String getNama(){
        return nama;
    }
        void setNip(String nm){
            nip = nm;
            if(nm.length()==8){
                nip = nm;
            }else {
                System.out.println("nim tidak sesuai");
            }
    }
        String getNim(){
            return nip;
        }
}
