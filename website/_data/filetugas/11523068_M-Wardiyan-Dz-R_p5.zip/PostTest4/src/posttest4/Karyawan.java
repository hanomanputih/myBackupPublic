/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest4;

/**
 *
 * @author praktikan
 */
public class Karyawan {

    private String nip;
    private String nama;
    private int gaji;

    void setNIP(String nip) {
        this.nip = nip;
    }

    String getNIP() {
        return nip;
    }

    void setNAMA(String nama) {
        this.nama = nama;
    }

    String getNAMA() {
        return nama;
    }

    void setGAJI(int gaji) {
        this.gaji = gaji;
    }

    int getGAJI() {
        return gaji;
    }
}
