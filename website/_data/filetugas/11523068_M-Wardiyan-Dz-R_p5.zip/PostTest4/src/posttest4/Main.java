/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest4;

/**
 *
 * @author praktikan
 */
public class Main {

    public static void main(String[] args) {
        Karyawan kr = new Karyawan() ;

            kr.setNIP ("11523068");
           kr.setNAMA ("ryan");
           kr.setGAJI(1000000*12);
        System.out.println("niP ku = "+kr.getNIP());
        System.out.println("nama ku = "+kr.getNAMA());
        System.out.println("gaji = "+kr.getGAJI());
    }
    
}
