/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {

    String nama, nim, fak, jur, angk;

    void cetak() {
     
        System.out.println();
        System.out.println("Nama:" + nama);
        System.out.println("NIM:" + nim);
        System.out.println("Fakultas:" + fak);
        System.out.println("Jurusan:" + jur);
        System.out.println("Angkatan:" + angk);


    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Mahasiswa cetak = new Mahasiswa();
        Scanner ct = new Scanner(System.in);
        System.out.println("Siapa namamu: ");
        cetak.nama = ct.next();
        System.out.println("Berapa NIMmu: ");
        cetak.nim = ct.next();
        System.out.println("Fakultasmu: ");
        cetak.fak = ct.next();
        System.out.println("Jurusanmu: ");
        cetak.jur = ct.next();
        System.out.println("Angkatanmu: ");
        cetak.angk = ct.next();
        cetak.cetak();
        // TODO code application logic here
    }
}
