/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;


/**
 *
 * @author Praktikan
 */
public class Karyawan {
    private String nip,nama;
    private int gaji;

public void setNip(String n){
    nip =n;
        
}
public String getNip(){
   return nip;
    }
public void setNama(String n){
    nama = n;
}
public String getNama (){
    return nama;
}
public void setGaji(int n){
    gaji = n *12;
}
public int getGaji(){
    return gaji;
}
}
