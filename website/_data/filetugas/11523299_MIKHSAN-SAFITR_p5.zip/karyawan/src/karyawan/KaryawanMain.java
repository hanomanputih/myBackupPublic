/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class KaryawanMain {
    public static void main(String[] args) {
         Karyawan Krwn = new Karyawan();
         Krwn.setNip("11523299");
         Krwn.setNama("M.IKHSAN SAFITR");
         Krwn.setGaji(100000000);
         
         System.out.println("nip "+Krwn.getNip());
         System.out.println("nama "+Krwn.getNama());
         System.out.println("gaji setahun "+Krwn.getGaji());
    }
   
 
     
    
    
    
    
}
