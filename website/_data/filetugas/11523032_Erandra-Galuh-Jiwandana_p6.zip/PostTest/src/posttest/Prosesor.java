/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author Praktikan
 */
public class Prosesor {
    public String tipe;
     public Prosesor (String tp){
            tipe=tp;
    }
    
    public void tampil (){
        System.out.println("tipenya " +tipe);
    }
    
}
