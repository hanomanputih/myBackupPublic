/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author Praktikan
 */
public class Komputer {
    public  Prosesor p;
    RAM r;
    
    public String nama;
    public String jeneng;
    public Komputer(String ini){
           nama=ini;
           jeneng=ini;
           if(nama.equals("1")){
               p=new Prosesor ("intel  pentium 4");
               
         
               r=new RAM ("NVDIA");
               
           }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Komputer f=new Komputer ("1");
        System.out.println("prosesornya itu " +f.p.tipe);
        System.out.println("sedangkan ramnya menggunakan " +f.r.merek);
    }
}
