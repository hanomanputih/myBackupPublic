/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author Praktikan
 */
public class RAM {
    public String merek;
    public RAM (String mrk){
            merek=mrk;
    }
    
    public void tampil (){
        System.out.println("mereknya adalah " +merek);
    }
    
}
