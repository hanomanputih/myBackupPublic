/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritancee;

/**
 *
 * @author PRAKTIKAN
 */
public class main {
    public static void main(String[] args) {
        karyawanTetap kT = new karyawanTetap();
        kT.gaji();
        KaryawanKontrak kK= new KaryawanKontrak() {};
        kK.gaji();
    }
    
}
