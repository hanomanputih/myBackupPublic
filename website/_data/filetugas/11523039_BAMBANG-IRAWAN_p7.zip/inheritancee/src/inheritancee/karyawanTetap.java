/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritancee;

/**
 *
 * @author PRAKTIKAN
 */
public  class karyawanTetap extends Karyawan{

double tunjangan=0.2*gajiPokok;


    @Override
public void gaji (){
        double gaji = tunjangan+gajiPokok+bonus;
        System.out.println("gaji karyawan tetap " +gaji);
    }
}
