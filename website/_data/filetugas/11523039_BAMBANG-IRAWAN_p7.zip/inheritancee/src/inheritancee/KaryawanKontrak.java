/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritancee;

/**
 *
 * @author PRAKTIKAN
 */
public abstract class KaryawanKontrak extends Karyawan {
    private int gaji;
    

    @Override
    public void gaji (){
        int gaji = gajiPokok+bonus;
        System.out.println("gaji karyawan kontrak " +gaji);
    }
}
