/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest8;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Praktikan
 */
public class PostTest8 {


    public static void main(String[] args) {
         List list1 = new ArrayList();
         List list2 = new ArrayList();
     
     list1.add("Ayuda");
     list1.add("Hafni");
     list1.add("nying");
     list2.add(11523012);
     list2.add(11523018);
     list2.add(11523036);
     
     for(int i=0; i< list1.size(); i++){
         System.out.println("index "+i+" : "+list1.get(i));
         System.out.println("index "+i+" : "+list2.get(i));
     }
     
     
        System.out.println("**************************");
        Iterator<String> ite1 =list1.iterator();
        Iterator ite2 =list2.iterator();
        while(ite1.hasNext()){
            String s = ite1.next();
            System.out.println(s);
            Object m = ite2.next();
            System.out.println(m);
        }
        
        System.out.println("**************************");
        System.out.println(list1);
        System.out.println(list2);
    
     Map<Integer,String> map = new HashMap<Integer, String>();{
        
        map.put(11523012, "Ayuda");
        map.put(11523018, "Hafni");
        map.put(11523036, "Nying");
        
        System.out.println("**********************");
        System.out.println(map.get(11523018));
        System.out.println("**********************");
        
        for (Integer i : map.keySet()){
            System.out.println("key "+i+" : "+map.get(i));
}
}
}

}