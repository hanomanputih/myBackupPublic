/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest.pkg4;

/**
 *
 * @author Praktikan
 */
public class Karyawan {
    
    private String nip;
    private String nama;
    private int gaji;
    
    public void setNip(String nip){
    
        if (nip.length()==7){
        this.nip=nip;
        }
        else{
        System.out.println("Error!");
        }
    }
        public String getNip(){
        return nip;
        }
        public void setNama(String nama){
        
            if (nama.length()>=7){
            this.nama=nama;
            }
            else
            {
                System.out.println("Error!");
        }
        }
        public String getNama(){
        return nama;
        }
        
        public void setGaji(int gaji){
        
        if (gaji >= 0){
        this.gaji=gaji;
        }
        else
        {
        System.out.println("Error!");
        }
        }
        
        public int getGaji(){
        return gaji;
        }
    }