/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest.pkg4;

/**
 *
 * @author Praktikan
 */
public class Pemanggil {
    
    public static void main(String[] args){
    Karyawan kyn = new Karyawan();
    kyn.setNip("7654321");
    kyn.setNama("vwxyzqw");
    kyn.setGaji(1750000);
    
    System.out.println("NIP : "+kyn.getNip());
    System.out.println("Nama : "+kyn.getNama());
    System.out.println("Gaji : "+kyn.getGaji());
    System.out.println("Gaji setahu : "+kyn.getGaji()*12);
    
    }
    
}
