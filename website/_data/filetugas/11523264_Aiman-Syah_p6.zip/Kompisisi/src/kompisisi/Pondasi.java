/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package kompisisi;

/**
 *
 * @author PRAKTIKAN
 */
public class Pondasi {
    public String Jenis;
    public Pondasi (String Jns){
    Jenis=Jns;
}
}
