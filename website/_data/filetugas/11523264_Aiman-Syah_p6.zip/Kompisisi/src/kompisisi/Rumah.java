/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package kompisisi;

/**
 *
 * @author PRAKTIKAN
 */
public class Rumah {
    Pondasi P;
    public String Nama;
    public Rumah (String ini){
        Nama=ini;
        if(Nama.equals("1")){
            P=new Pondasi ("kuat");
        }
        
    }
    
    public static void main(String[] args) {
        Rumah R=new Rumah ("1");
        System.out.println("Jadi Rumah ini" +R.P.Jenis);
    }
   
}
