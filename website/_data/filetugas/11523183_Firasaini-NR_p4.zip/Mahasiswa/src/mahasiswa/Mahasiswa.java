/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;
import java.util.Scanner;
/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
String nama;
    String nim;
    String fakultas;
    String jurusan;
    String angkatan;
    int jumlah;
    
    
    void isi(){
        Scanner read=new Scanner(System.in);
        System.out.println("masukan Nama anda = ");
        nama = read.next();
        System.out.println("Masukan NIM anda = ");
        nim=read.next();
        System.out.println("Masukan Fakultas anda = ");
        fakultas=read.next();
        System.out.println("Masukan Jurusan anda= ");
        jurusan=read.next();
        System.out.println("Angkatan tahun berapa = ");
        angkatan=read.next();
        jumlah = nama.length()+ fakultas.length();
    }
    void cetak(){
        System.out.println("Nama Anda = "+nama);
        System.out.println("Nim anda = "+nim);
        System.out.println("Fakultas anda = "+fakultas);
        System.out.println("Jurusan anda = "+ jurusan);
        System.out.println("Anda angkatan tahun = "+angkatan);
        System.out.println("Jumlah huruf  anda : " +jumlah);
    }
    public static void main(String[] args) {
        Mahasiswa mhs=new Mahasiswa();
        
        mhs.isi();
        mhs.cetak();
    }
}
