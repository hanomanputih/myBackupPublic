/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class Ram {
    String merkRam;
    
    public Ram(String namaR){
        this.merkRam = namaR;
    }
    
}
