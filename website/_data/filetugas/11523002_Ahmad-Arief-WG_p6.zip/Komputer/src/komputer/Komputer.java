/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class Komputer {
    
    String merkKom;
    private Prosesor p;
    private Ram r;
    
   public Komputer(String nama,String namaP,String namaR){
       this.merkKom=nama;
       
       if (merkKom.equals(nama))
           
                p=new Prosesor(namaP);
                r=new Ram(namaR);
           
           }
   public void tampil(){
       System.out.println("Prosesornya = "+p.merkProsesor);
           System.out.println("Ramnya = "+r.merkRam);
           
   }



    public static void main(String[] args) {
       Komputer kmp = new Komputer("Toshiba","Pentium 2,7","RAMM");

       kmp.tampil();

    }
}

