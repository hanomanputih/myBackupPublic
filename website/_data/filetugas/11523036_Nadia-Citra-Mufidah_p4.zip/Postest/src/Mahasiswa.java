/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.Scanner;
/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
  String nama, nim, jurusan, angkatan;
    public static void main(String[] args) {
       Mahasiswa Mhs1 =new Mahasiswa();
       Mhs1.Cetak();
    }
  void Cetak(){
      Scanner baca=new Scanner(System.in);
      System.out.println("Nama mahasiswa = ");
      nama= baca.next();
      System.out.println("NIM = ");
      nim= baca.next();
      System.out.println("Jurusan = ");
      jurusan=baca.next();
      System.out.println("Angkatan = ");
      angkatan=baca.next();
      System.out.print("Nama mahasiswa"+nama);
              System.out.print(" dengan NIM"+nim);
              System.out.print(" jurusan "+jurusan);
              System.out.print(" angkatan tahun "+angkatan);
                      
             
  }
}


