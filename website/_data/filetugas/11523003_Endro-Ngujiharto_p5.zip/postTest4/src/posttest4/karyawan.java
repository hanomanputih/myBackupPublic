/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest4;

/**
 *
 * @author Praktikan
 */
public class karyawan {
    private String nip,nama;
    private int gaji;
    
    public void setnip(String nip){
        this.nip = nip;
    }
    public void setnama(String nama){
        this.nama=nama;
    }
    public void setgaji(int gaji){
        gaji=12*gaji;
        this.gaji=gaji;
    }
    public String getnip(){
        return nip;
    }
    public String getnama(){
        return nama;
    }
    public int getgaji(){
        return gaji;
    }    
    
}
