/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest4;

/**
 *
 * @author Praktikan
 */
public class PostTest4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       karyawan kar = new karyawan();
       kar.setnip("11523003");
       kar.setnama("Endro Ngujiharto");
       kar.setgaji(50000000);
       System.out.println("NIP " + kar.getnip());
        System.out.println("Nama "+ kar.getnama());
        System.out.println("Gaji " + kar.getgaji());
    }
}
