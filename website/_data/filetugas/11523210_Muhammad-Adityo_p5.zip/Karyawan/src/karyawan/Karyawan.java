/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
class Karyawan {
    private String nip;
    private String nama;
    private int gaji;

    public void setNip(String nipKaryawan){
    nip=nipKaryawan;
    }
    
    public void setNama(String namaKaryawan){
    nama=namaKaryawan;
    }
    
    public void setGaji(int gajiKaryawan){
    gaji=gajiKaryawan;
    }
    
    public String getNip(){
    return nip;
    }
    
    public String getNama(){
    return nama;
    }
    
    public int getGaji(){
    return gaji;
    }
    public static void main(String[] args) {
        // TODO code application logic here
        
    }
}
