/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class Test {
    public static void main(String[] args) {
        Karyawan krywn = new Karyawan();
        
        krywn.setNip("11523210");
        krywn.setNama("Muhammad Adityo");
        krywn.setGaji(100000000);
        
        System.out.println("NIP: " +krywn.getNip());
        System.out.println("Nama: " +krywn.getNama());
        System.out.println("Gaji: " +krywn.getGaji());
    }
}
