/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan1;

/**
 *
 * @author Praktikan
 */
public class karyawan1 {

    private String Nip;
    private String Nama;
    private int Gaji;

    void setNip(String ni) {
        if (ni.length() == 8) {
            Nip = ni;
        } else {
            System.out.println("error..");
        }
    }

    String getNip() {
        return Nip;
    }

    void setNama(String na) {
        if (na.length() > 3) {
            Nama = na;
        } else {
            System.out.println("error...");
        }
    }

    String getNama() {
        return Nama;
    }

    void setGaji(int ga) {
        if (ga >= 50000) {
            Gaji = ga;
        } else {
            System.out.println("error...");
        }
    }

    int getGaji() {
        return Gaji;
    }
}

