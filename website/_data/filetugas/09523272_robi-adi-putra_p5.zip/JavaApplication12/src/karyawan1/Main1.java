/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan1;

/**
 *
 * @author Praktikan
 */
public class Main1{
    
    public static void main(String[] args) {
        karyawan1 ka = new karyawan1();
        ka.setNip("12356710");
        ka.setNama("pintar");
        ka.setGaji(50000000);
        System.out.println("NIP = "+ka.getNip());
        System.out.println("NAMA = "+ka.getNama());
        System.out.println("GAJI = "+ka.getGaji());
    }
}
