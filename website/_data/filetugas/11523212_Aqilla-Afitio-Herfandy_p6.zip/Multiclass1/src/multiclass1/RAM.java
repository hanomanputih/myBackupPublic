/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package multiclass1;

public class RAM {
    int no;
    
    public RAM (int no){
        this.no=no;
    }
}
