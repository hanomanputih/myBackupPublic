
package multiclass1;


public class CPU {
    private int np;
    private Processor p;
    private RAM ram;
    
    public CPU (int np) {
        this.np=np;
        if(np == 1){
            p = new Processor (5);
            ram = new RAM (5);
            
                    
        }
    }
    void tampil(){
        System.out.println("Nomor Produksi  : "+ np);
        System.out.println("Nomor Processor : "+ p.no);
        System.out.println("Nomor RAM       : "+ ram.no);
    }
            
}
 