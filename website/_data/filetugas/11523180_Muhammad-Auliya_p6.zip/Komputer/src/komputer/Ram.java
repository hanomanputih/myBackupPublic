/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class Ram {
    private String ramrek;
    public Ram(String ramrek){
        this.ramrek=ramrek;
    }
    public void tampilRam(){
        System.out.println("Nama RAM : " +ramrek);
    }
}
