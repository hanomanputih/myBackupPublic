/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class Komputer {

    String komrek;
    private Prosessor p;
    public Komputer(String komrek){
        this.komrek=komrek;
        if (komrek.equals("Samijo")){
            p = new Prosessor("Intel");
        }
    }
    public void tampilKomp(){
        System.out.println("Nama Komputer : " +komrek);
        p.tampilPros();
    }
    public static void main(String[] args) {
        Komputer kk = new Komputer("Samijo");
        kk.tampilKomp();
    }
}
