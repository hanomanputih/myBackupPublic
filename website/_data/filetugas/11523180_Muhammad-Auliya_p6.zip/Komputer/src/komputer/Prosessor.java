/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class Prosessor {
    private String psmerk;
    private Ram r;
    public Prosessor(String psmerk){
        this.psmerk=psmerk;
        if (psmerk.equals("Intel")){
            r = new Ram("Vengeance");
        }
    }
    public void tampilPros(){
        System.out.println("Nama Prosessor :" +psmerk);
        r.tampilRam();
    }
    
}
