/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

/**
 *
 * @author praktikan
 */
public class Prosesor {
    String merk;
    int harga;
    
    
    public Prosesor(String M, int H){
        this.merk = M;
        this.harga = H;
}
}
