/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

/**
 *
 * @author praktikan
 */
public class Komputer {
    RAM R;
    Prosesor P;
    int hargaKomputer;
    
    public Komputer (int hargaKomputer){
    this.hargaKomputer = hargaKomputer;
    R = new RAM ("Corsair");
    P = new Prosesor ("AMD", 1500000);
    }
    
    public void Display(){
        System.out.println("Nama Prosesor : "+P.merk);
        System.out.println("Harga Prosesor : "+P.harga);
        System.out.println("Merk RAM : "+R.merkRAM);
        System.out.println("Harga Komputer : "+hargaKomputer);
    }
    
        public static void main(String[]args) {
        Komputer k = new Komputer(10000000);
        //R.merkRAM = "Corsair";
        k.Display();
    }
}
