/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

/**
 *
 * @author praktikan
 */
public class RAM {
    String merkRAM;
    
    public RAM(String nama){
    this.merkRAM = nama;
    }
    
}
