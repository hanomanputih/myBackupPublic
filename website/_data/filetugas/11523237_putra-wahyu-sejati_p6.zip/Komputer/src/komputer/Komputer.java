/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;


public class Komputer {
      String NamaKomputer;
      Ram r;
      Prosesor p;
       
    public Komputer(String NamaKomp){
        this.NamaKomputer = NamaKomp;
        if (NamaKomputer.equals("1")){
            r = new Ram("RAM DDR 3");
            p = new Prosesor ("Prosesor Intel i7");
        }
    }
     
     public static void main(String [] args){
          Komputer  komp = new Komputer ("1");
          System.out.println ("komputer : " +komp.NamaKomputer);
          System.out.println("Jenis Ram : " + komp.r.JenisRam);
          System.out.println("Jenis Prosesor : " + komp.p.JenisPros);
        }
    }


