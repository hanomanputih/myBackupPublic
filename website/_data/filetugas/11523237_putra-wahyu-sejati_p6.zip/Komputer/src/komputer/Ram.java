/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;



public class Ram {
    String JenisRam;
    
    public Ram(String JnsRam){
        JenisRam = JnsRam;
    }
    
    public void tampilRam(){
        System.out.println("Jenis RAM : "+JenisRam);
    }
}
