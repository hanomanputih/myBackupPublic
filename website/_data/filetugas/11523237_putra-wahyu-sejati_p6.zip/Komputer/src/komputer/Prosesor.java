/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;


public class Prosesor {
      String JenisPros;
    
    public Prosesor(String JnsPros){
        JenisPros = JnsPros;
    }
    
    public void tampilPros(){
        System.out.println("Jenis Prosesor : "+JenisPros);
    }
}
