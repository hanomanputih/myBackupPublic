/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pertm8;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author praktikan
 */
public class mapbelajar {
    public static void main(String[] args) {
        Map<Integer,String> lalala = new HashMap<Integer,String> ();
        
        lalala.put(1,"P");
        lalala.put(2,"A");
        lalala.put(3,"R");
        lalala.put(4,"K");
        

           for(Map.Entry<Integer,String> ee: lalala.entrySet()){
               System.out.println(ee.getKey()+" - "+ee.getValue());
           }
        
        
        
        
    }
    
}
