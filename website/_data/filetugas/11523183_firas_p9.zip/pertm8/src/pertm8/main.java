/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pertm8;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author praktikan
 */
public class main {

    public static void main(String[] args) {
        List mhs = new ArrayList();
        Map<Integer, String> mahasiswa = new HashMap<Integer, String>();
        Scanner sc = new Scanner(System.in);

        String nama = sc.nextLine();
        String nim = sc.nextLine();
        mhs.add(nim);
        mhs.add(nama);
        mahasiswa.put(1, nim);
        mahasiswa.put(2, nama);


        System.out.println(mhs.size());
        System.out.println("__________________");

        for (Iterator<String> iter = mhs.iterator(); iter.hasNext();) {
            String ii = iter.next();
            System.out.println(ii);
        }
        System.out.println("indeks ke 2 dari list "+mhs.get(1));

        for (Map.Entry<Integer, String> ee : mahasiswa.entrySet()) {
            System.out.println(ee.getKey() + " - " + ee.getValue());
        }
        System.out.println("indeks ke 2 dari map "+mahasiswa.get(2));
    }
}

