/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komposisi_11523013;

/**
 *
 * @author Praktikan
 */
public class ram {
    String kapasitas;
    public ram (String kapasitas){
        this.kapasitas = kapasitas;
}
}