/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komposisi_11523013;

/**
 *
 * @author Praktikan
 */
public class MainKomposisi {
    ram rm;
    prosesor pr;
    
    public MainKomposisi(ram rm , prosesor pr) {
        this.rm = rm;
        this.pr = pr;
}
    
    
    public static void main(String[] args) {
        prosesor pr = new prosesor  ("Thosiba");
        ram rm = new ram ("16");
        MainKomposisi mk = new MainKomposisi(rm , pr);
          
        System.out.println("komputer");
        System.out.println("Merk prosesor : "+pr.merk);
        System.out.println("Kapasitas ram : "+rm.kapasitas +"GB");
        
    }
}
