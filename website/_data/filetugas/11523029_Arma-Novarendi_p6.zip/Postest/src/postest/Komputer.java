/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

/**
 *
 * @author Praktikan
 */
public class Komputer {
    String no_seri;
    
    // Ngambil dari class lain
    Ram r;
    Prosesor p;
    
    public Komputer(String _noseri){
        no_seri = _noseri;
        if (no_seri.equals("1")){
            r = new Ram("Visipro", 4096);
            p = new Prosesor(4, 3000);
        }
    }
    
    public static void main(String[] args) {
        Komputer pc1 = new Komputer("1");
        System.out.println("Spesifikasi Komputer Anda:");
        System.out.println("Prosesor: "+pc1.p.jumlah_core+" core,"+pc1.p.clockspeed+" Mhz");
        System.out.println("RAM: "+pc1.r.vendor+(" ")+pc1.r.kapasitasMemori+" MB");
        
    }
}
