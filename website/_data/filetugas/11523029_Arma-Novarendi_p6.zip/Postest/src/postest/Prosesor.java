/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

/**
 *
 * @author Praktikan
 */
public class Prosesor {
    int jumlah_core;
    int clockspeed;
    public Prosesor(int jcore, int csp){
        jumlah_core = jcore;
        clockspeed = csp;
    }
}
