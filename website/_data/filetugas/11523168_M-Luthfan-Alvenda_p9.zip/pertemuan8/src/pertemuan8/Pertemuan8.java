/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan8;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 *
 * @author PRAKTIKAN
 */
public class Pertemuan8 {
    public static void main(String[] args) {
        List Mahasiswa = new ArrayList();
        
        Mahasiswa.add("M. Luthfan Alvenda");
        Mahasiswa.add("11523168");
                
        System.out.println(Mahasiswa);
        System.out.println("_______________________________________");
        
        for(Object ls : Mahasiswa){
            System.out.println(ls);
        }
        System.out.println("_______________________________________");
        
        Iterator itt = Mahasiswa.iterator();
        while(itt.hasNext()){
            System.out.println(itt.next());
        }
        System.out.println("_______________________________________");
        
        for(int i = 0; i<Mahasiswa.size(); i++){
            System.out.println(Mahasiswa.get(i));
        }
        
    }
}
