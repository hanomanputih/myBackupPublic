/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan3;

import java.util.Scanner;

/**
 *
 * @author PRAKTIKAN
 */
public class Mahasiswa {
    
    String nama;
    String nim;
    
    void cetak(){
    
    
        System.out.println("Nama = "+nama);
        System.out.println("NIM = "+nim);
        
    }
    
    void masukan(){
    
    Scanner sc = new Scanner(System.in);
    System.out.println("Nama anda :");
    nama = sc.next();
    System.out.println("NIM  anda :");
    nim = sc.next();
    
    
        
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
   Mahasiswa mhs = new Mahasiswa();
   mhs.masukan();
   mhs.cetak();
    }
}
