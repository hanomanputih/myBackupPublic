/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perusahaan1;

/**
 *
 * @author PRAKTIKAN
 */
public class KaryawanTetap extends Karyawan {
    int tunjangan = 600000;
    int gaji;

   public void view(){
        gaji = tunjangan + gajipokok + bonus ;
        System.out.println(" gaji : = "+gaji);
        
    }
    
    

}
