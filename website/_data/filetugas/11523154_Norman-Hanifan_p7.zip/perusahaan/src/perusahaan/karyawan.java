/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perusahaan;

/**
 *
 * @author PRAKTIKAN
 */
public abstract class karyawan {
    public int gajiPokok = 3000000;
    public double tunjangan;
    public double bonus;
    
    public void gaji (){
        tunjangan = 0.2 * gajiPokok;
        bonus = gajiPokok + bonus;
        
    }
}
