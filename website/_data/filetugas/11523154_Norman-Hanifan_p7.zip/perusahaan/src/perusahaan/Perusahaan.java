/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perusahaan;

/**
 *
 * @author PRAKTIKAN
 */
public class Perusahaan {
    private static String gaji;
    public static void main(String[] args) {
        karyawantetap kt = new karyawantetap();
        karyawankontrak kk = new karyawankontrak();
        
        System.out.println(" gaji karyawan tetap : "+gaji);
        System.out.println(" gaji karyawankontrak : "+gaji);
    }
}
