/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perusahaan;

/**
 *
 * @author PRAKTIKAN
 */
public class karyawantetap extends karyawan {
    public double gaji;
    public void karyawantetap (){
        gaji = gajiPokok + tunjangan + bonus;
        System.out.println("gaji karyawan tetap : "+gaji);
    }
    
}
