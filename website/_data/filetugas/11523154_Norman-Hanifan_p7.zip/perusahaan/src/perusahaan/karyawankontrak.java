/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perusahaan;

/**
 *
 * @author PRAKTIKAN
 */
public class karyawankontrak extends karyawan {
    public double gaji;
    public void karyawankontrak() {
        gaji = gajiPokok + bonus;
        System.out.println("gaji karyawan kontrak : "+gaji);
    }
    
}
