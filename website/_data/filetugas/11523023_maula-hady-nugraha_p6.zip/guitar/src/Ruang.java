/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author praktikan
 */
public class Ruang {
    String ukuran;
    String isi;
    Kursi K;
    
    public Ruang (String U, String I, String k){
        this.ukuran = U;
        this.isi = I;
        K = new Kursi (k);
    }
    
    public void Display (){
        System.out.println("Ukuran ruangan : "+ukuran);
        System.out.println("Isi ruangan 1 : "+isi);
        System.out.println("Isi ruangan 2 : "+K.jenisKursi);
     
    }
    public static void main (String[]args){
        Ruang r = new Ruang ("3 x 4","Lemari", "kursi uncal");
        r.Display();
    }
}
