/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author praktikan
 */
public class Kursi {
     String jenisKursi;
    
    public Kursi(String nama) {
        this.jenisKursi=nama;
}
}
