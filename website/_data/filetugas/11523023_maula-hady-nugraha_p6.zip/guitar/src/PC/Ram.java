/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package PC;

/**
 *
 * @author praktikan
 */
public class Ram {
    String merkRam;
    
     public Ram (String R){
        this.merkRam=R;
     }
}
     
     
