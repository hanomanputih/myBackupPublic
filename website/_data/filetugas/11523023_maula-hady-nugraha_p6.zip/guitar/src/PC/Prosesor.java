/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package PC;

/**
 *
 * @author praktikan
 */
public class Prosesor {
    String merkPross;
    
    public Prosesor (String P){
        this.merkPross=P;
    }
}
