/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package PC;

/**
 *
 * @author praktikan
 */
public class Komputer {
    
    String merkKom;
    private Prosesor p;
    private Ram r;
    
    public Komputer(String nama, String P, String R){
        this.merkKom=nama;
        if (merkKom.equals(nama));
        p=new Prosesor(P);
        r=new Ram(R);
        
                  
    }
    
    public void tampil(){
        System.out.println("merk Laptop = "+merkKom);
        System.out.println("merk Prosesor = "+p.merkPross);
        System.out.println("merk Ram = "+r.merkRam);
        
    }
    
    
    public static void main(String[] args) {
       Komputer kmp = new Komputer("Acer","Intel Core","WD" );
       kmp.tampil();
        // TODO code application logic here
    }
}
