/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Karyawan;

/**
 *
 * @author Praktikan
 */
public class KaryawanTetap extends Karyawan {
    private int tunjangan;
    
     @Override
    public void view(){
         
        tunjangan =(tunjangan*20)/100;
        super.view();
        System.out.println("tunjangan Karyawan      : "+tunjangan);
        System.out.println("Gaji Karyawan Tetap     : "+(tunjangan+gajipokok+bonus));
    }

    public int getTunjangan() {
        return tunjangan;
    }

    public void setTunjangan(int tunjangan) {
        this.tunjangan = tunjangan;
    }

    

  

    
}
