/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Karyawan;

/**
 *
 * @author Praktikan
 */
public class KaryawanKontrak extends Karyawan {

    
@Override
    public void view(){
    super.view();
        System.out.println("Gaji Karyawan Kontrak     : "+(gajipokok+bonus));
    }

}
