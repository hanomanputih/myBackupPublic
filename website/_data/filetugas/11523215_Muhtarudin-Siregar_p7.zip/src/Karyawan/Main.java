/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Karyawan;

/**
 *
 * @author Praktikan
 */
public class Main {
    
    public static void main(String[] args) {
        Karyawan kr = new Karyawan();
        KaryawanTetap kt = new KaryawanTetap();
        KaryawanKontrak kk = new KaryawanKontrak();
       
        kr.setGajipokok(3000000);
        
        kr.view();
        System.out.println("");
        
        kt.setGajipokok(3000000);
        kt.setBonus(600000);
        kt.setTunjangan(50000);
        
        
        kt.view();
        System.out.println("");
        
        kk.setGajipokok(3000000);
        kk.setBonus(600000);
        kk.view();
    }
}
