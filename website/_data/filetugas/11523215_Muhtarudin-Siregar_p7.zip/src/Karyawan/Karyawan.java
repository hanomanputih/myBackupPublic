/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Karyawan;

/**
 *
 * @author Praktikan
 */
public class Karyawan {

  String nama="samuel";
  int nip=11523215;
  int gajipokok;
  int bonus;
  
  
  public void view(){
      System.out.println("Nama Karyawan         :   "+nama);
      System.out.println("Nip Karyawan          :   "+nip);
      System.out.println("Gaji pokok Karyawan   :   "+gajipokok);
      System.out.println("Bonus Karyawan        :   "+bonus);
  }

    public int getBonus() {
        return bonus;
    }

    public void setBonus(int bonus) {
        this.bonus = bonus;
    }

    public int getGajipokok() {
        return gajipokok;
    }

    public void setGajipokok(int gajipokok) {
        this.gajipokok = gajipokok;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public int getNip() {
        return nip;
    }

    public void setNip(int nip) {
        this.nip = nip;
    }
}
