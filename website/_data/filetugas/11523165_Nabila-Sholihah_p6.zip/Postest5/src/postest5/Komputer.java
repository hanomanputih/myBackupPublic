/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest5;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Komputer {
    String komputer;
    Prosesor p;
    Ram r;
    
   public Komputer (String komputer) {
      this.komputer= komputer;
      if (komputer.equals("asus")){
          p=new Prosesor("i5");
          r=new Ram ("kapasitas : 3 Gb");
      }
   }
   
    public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);
        
        System.out.println("Identitas PC");
        Komputer k = new Komputer (sc.next());
        
        System.out.println("prosesor: " +k.p.merk);
        System.out.println("kapasitas RAM: "+k.r.kapasitas);
    }
}
