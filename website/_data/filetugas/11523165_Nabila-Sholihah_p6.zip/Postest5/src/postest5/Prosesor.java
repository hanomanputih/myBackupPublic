/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest5;

/**
 *
}
 * @author Praktikan
 */
//String id_fak;

public class Prosesor {
    String merk;
    Prosesor p;
    Ram r;
    public Prosesor (String pro) {
        this.merk=pro;
        
    }
    
}
