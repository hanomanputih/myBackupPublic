/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class pemanggilan {
    public static void main(String[] args) {
        Karyawan krw = new Karyawan();
        
        krw.setNip("11512001");
        krw.setNama("Ariefka");
        krw.setGaji(500000);
        
        System.out.println("nip     : " +krw.getNip());
        System.out.println("nama    : "+krw.getNama());
        System.out.println("gaji    : "+krw.getGaji());
    }
    
}
        
        
    
    

