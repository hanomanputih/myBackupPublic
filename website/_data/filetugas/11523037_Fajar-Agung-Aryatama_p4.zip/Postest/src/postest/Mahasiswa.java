/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {

    /**
     * @param args the command line arguments
     */
    int nim,angkatan;
    String nama,jurusan,fakultas;
    
    
    public static void main(String[] args) {
        // TODO code application logic here
        Mahasiswa m= new Mahasiswa();
        Scanner baca= new Scanner (System.in);
        
        
    }
}
