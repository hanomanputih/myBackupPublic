/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest8yandi;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Posttest8Yandi {

    String nama, nim;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Posttest8Yandi p = new Posttest8Yandi();
        System.out.println("Masukkan nama : ");
        p.nama = sc.nextLine();
        System.out.println("Masukkan NIM  : ");
        p.nim = sc.nextLine();

        ArrayList list = new ArrayList();
        list.add(p.nama);
        list.add(p.nim);
        System.out.println("Ukuran : "+list.size());

        for (Iterator iterator = list.iterator(); iterator.hasNext();) {
            String i = (String) iterator.next();
            System.out.println("Isi : " + i);
        }
        
        HashMap map = new HashMap();
        map.put(1, p.nama);
        map.put(2, p.nim);
        System.out.println(map.get(2));
    }
}
