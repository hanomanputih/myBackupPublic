/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komposisi;

/**
 *
 * @author Praktikan
 */
public class Prosessor {
    String jenisProsessor;

    public String getJenisProsessor() {
        return jenisProsessor;
    }
    
    public Prosessor(String nama){
        this.jenisProsessor = nama;
    
    }
    
}
