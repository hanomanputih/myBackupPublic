/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komposisi;

/**
 *
 * @author Praktikan
 */
public class Komputer {
    String jenisKomputer;
    Prosessor P;
    RAM R;
    
    public Komputer(String j,String p, String r){
        this.jenisKomputer = j;
        P = new Prosessor(p);
        R = new RAM(r);
        
    }
    
    public static void main(String[] args){
        Komputer k = new Komputer("Game", "AMD", "8 Gb");
        System.out.println("Jenis Prosessor : "+k.P.getJenisProsessor());
        System.out.println("Kapasitas RAM : "+k.R.getKapasitasRAM());
        k.Display();
    
    }
    
    public void Display(){
        System.out.println("Jenis Komputer : "+jenisKomputer);
    
    }
}
