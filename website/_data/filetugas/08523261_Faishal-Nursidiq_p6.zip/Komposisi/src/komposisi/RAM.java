/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komposisi;

/**
 *
 * @author Praktikan
 */
public class RAM {
    String kapasitasRAM;

    public String getKapasitasRAM() {
        return kapasitasRAM;
    }
    
    public RAM (String nama){
        this.kapasitasRAM = nama;
    }
    
}
