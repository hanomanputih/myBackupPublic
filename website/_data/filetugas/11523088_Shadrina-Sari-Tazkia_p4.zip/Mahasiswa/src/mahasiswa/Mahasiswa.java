/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

import java.util.Scanner;

public class Mahasiswa {

    /**
     * @param args the command line arguments
     */
    String nama;
    String nim;
    String fakultas;
    String jurusan;
    String angkatan;
    void cetak(){
       Mahasiswa mhs = new Mahasiswa();
        Scanner siswa = new Scanner (System.in);
            System.out.println("Masukkan nama Anda");
        mhs.nama = siswa.nextLine();
            System.out.println("Masukkan NIM Anda");
        mhs.nim = siswa.next();
            System.out.println("Masukkan fakultas ");
        mhs.fakultas =  siswa.next();
            System.out.println("Masukkan jurusan Anda");
        mhs.jurusan =  siswa.next();
            System.out.println("Masukkan angkatan Anda");
        mhs.angkatan = siswa.next();
       
        System.out.println(" Panjang karakter nama Anda :"+mhs.nama.length());
    
      
    } 
    public static void main(String[] args) {
        // TODO code application logic here
     Mahasiswa mhs = new Mahasiswa();
     mhs.cetak();
    }
}
