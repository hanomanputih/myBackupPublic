/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes8;

/**
 *
 * @author praktikan
 */
public class Postes8 {

    /**
     * @param args the command line arguments
     */
    
        // TODO code application logic here
        
    }
