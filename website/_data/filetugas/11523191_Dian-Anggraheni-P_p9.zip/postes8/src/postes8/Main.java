/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes8;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author praktikan
 */
public class Main {
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        String nim = sc.nextLine();
        String nama = sc.nextLine();
        
         List<String> list1 = new ArrayList<String>();
        
        list1.add(nim);
        list1.add(nama);
        for (int i = 0; i < list1.size(); i++) {
            System.out.println("index" + i + " : " + list1.get(i));                       
                                            
                      
    }
        
        System.out.println("===============================");
        for (String s: list1){
            System.out.println(s);
        }
        
        System.out.println("===============================");
        Iterator<String> ite = list1.iterator();
        while(ite.hasNext()){
            String s = ite.next();
            System.out.println(s);
        }
        
        System.out.println("===============================");
        System.out.println(list1);
        
    

    
    Map<Integer, String> map = new HashMap<Integer, String>();
    
    map.put(1, nim);
    map.put(2, nama);
    
        System.out.println(map.get(1));        
        System.out.println("===============================");
        for (Integer i : map.keySet()) {
            System.out.println("key" + i + " : " +map.get(i));
        }
              
    
        for (Map.Entry<Integer, String>entry  : map.entrySet()) {
            System.out.println(entry.getKey() + " . " +entry.getValue());
        }
    } 
}
    

