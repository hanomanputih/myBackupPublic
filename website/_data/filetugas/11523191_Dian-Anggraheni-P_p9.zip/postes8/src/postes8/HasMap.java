/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes8;

/**
 *
 * @author praktikan
 */
class HasMap<T0, T1> {

    public HasMap() {
    }
    
}
