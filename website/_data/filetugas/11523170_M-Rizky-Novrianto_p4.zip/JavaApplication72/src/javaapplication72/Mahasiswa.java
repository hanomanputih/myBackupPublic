/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication72;

import java.util.Scanner;

/**
 *
 * @author PRAKTIKAN
 */
public class Mahasiswa {
    String nama, nim, fakultas, jurusan, angkatan;
    
    public void cikcik(){
        Scanner s = new Scanner(System.in);
        System.out.println("Isikan nama     : ");
        nama = s.nextLine();
        System.out.println("Isikan nim     : ");
        nim = s.nextLine();
        System.out.println("fakultas anda   :");
        fakultas = s.nextLine();
        System.out.println("jurusan anda   :");
        jurusan = s.nextLine();
        System.out.println("angkatan anda   :");
        angkatan = s.nextLine();
    }
    public void cetak(){
        System.out.println("Isikan nama :"+nama+", Isikan nim :"+nim+", fakultas anda :"+fakultas+", jurusan anda :"+jurusan+", angkatan anda :"+angkatan+")");
    }
    public static void main(String[] args) {
        Mahasiswa m = new Mahasiswa();
        m.cikcik();
        m.cetak();
    }
}
