/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication72;

/**
 *
 * @author PRAKTIKAN
 */
public class KelasObjek {

    String nama = "Rizky Novrianto";
    public static void main(String[] args) {
        KelasObjek cetak = new KelasObjek();
        System.out.println("Kata depan saya "+cetak.nama.startsWith("Rizky"));
        System.out.println("Kata terakhir saya "+cetak.nama.endsWith("Novrianto"));
        System.out.println("Panjang karakter nama saya "+cetak.nama.length());
    }
            
}
