/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author Praktikan
 */
public class Komputer {
    String jenisKomputer;
    Prosesor P;
    Ram R;
    
    public Komputer (String K, String p, String r){
        this.jenisKomputer = K;
        P = new Prosesor (p);
        R = new Ram (r);
    }
    public void Display(){
        System.out.println("Jenis Komputer : "+jenisKomputer);
        System.out.println("Jumlah Core : "+P.jumlahCore);
        System.out.println("Jumlah Memori : "+R.jumlahMemori);
    }
public static void main(String [] args) {
    Komputer r = new Komputer ("PC", "4", "2");
    r.P.jumlahCore = "4";
    r.R.jumlahMemori = "2";
    r.Display();

}
}
