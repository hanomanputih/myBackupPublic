/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main1;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Iterator;
import java.util.List;
import java.util.Map;



/**
 *
 * @author Praktikan
 */
public class Main1 {
   int nim;
         String nama;
  
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     
        List list = new ArrayList ();
        list.add("nama");
        list.add ("nim");
        for(Iterator<String> iterator = list.iterator(); 
iterator.hasNext();){//untuk melihat isi List
        String isi = iterator.next();
System.out.println(isi);
    }
        Scanner s = new Scanner (System.in);
        Map map = new HashMap ();
        System.out.println("Masukkan nama =");
        map.put(list.get(0),s.next());
        System.out.println("Masukkan nim =");
        map.put (list.get(1),s.next());
        
        System.out.println("nama = " + map.get("nama"));
        System.out.println("nim = " + map.get("nim"));
        
        
        // TODO code application logic here
    }
}
