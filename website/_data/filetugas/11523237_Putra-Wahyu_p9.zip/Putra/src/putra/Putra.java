/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package putra;

import java.util.Collections;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.HashMap;

public class Putra {

    public static void main(String[] args) {
        ArrayList list = new ArrayList();
        HashMap map = new HashMap();
        list.add ("nama :  wahyu");
        list.add ("nim  :  11523230");
        map.put("nama ", " putra");
        map.put("nim", new Integer (11523237));
        
        //System.out.println("map");
        System.out.println("ukuran map : " + map.size());
        boolean containKey = map.containsKey("nim");
        System.out.println("Has key (nim) : " + containKey);
        System.out.println(map);
    
        
        System.out.println("ukuran list " + list.size());

        for (Iterator iterator = list.iterator(); iterator.hasNext();) {
            String ii = (String) iterator.next();
            System.out.println("isi : " + ii);
        }
    }
}
