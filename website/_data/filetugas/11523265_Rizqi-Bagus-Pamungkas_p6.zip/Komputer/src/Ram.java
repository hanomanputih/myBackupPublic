public class Ram {
    int ukuranRam;
    public Ram(int n){
        ukuranRam = n;
    }
}
