public class Cpu {
    int nomerProduksi;
    Prosesor namaProsesor;
    Ram ukuran;
    
    public Cpu (int nP) {
        nomerProduksi=nP ;
        if(nP == 2) {
        namaProsesor = new Prosesor ("oke");
        ukuran = new Ram(1000);
        }
    }
    
    public void muncul(){
        System.out.println(namaProsesor.namaProsesor);
        System.out.println(ukuran.ukuranRam);
    }
}
