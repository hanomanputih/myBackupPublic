public class Prosesor {
 String namaProsesor;

    public Prosesor(String namaProsesor) {
        this.namaProsesor = namaProsesor;
    }
 
}
