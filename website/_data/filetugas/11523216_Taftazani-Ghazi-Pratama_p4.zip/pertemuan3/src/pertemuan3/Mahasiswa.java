/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan3;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
    String nama;
    String nim;
    String fakultas;
    String jurusan;
    String angkatan;
        
     void cetak(){
            System.out.println("Nama = " + nama);
            System.out.println("NIM = "  + nim);
            System.out.println("Fakultas = " + fakultas);
            System.out.println("Jurusan = " + jurusan);
            System.out.println("Angkatan = " + angkatan);
            
     }
     public static void main(String[] args) {
        Mahasiswa mhs1 = new Mahasiswa();
        mhs1.nama="Joko Jatmiko";
        mhs1.nim="10523200";
        mhs1.fakultas="Teknologi Industri";
        mhs1.jurusan="Teknik Informatika";
        mhs1.angkatan="2010";
        mhs1.cetak();
    }
       
     
}
