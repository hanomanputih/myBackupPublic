/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest3;
import java.util.Scanner;
/**
 *
 * @author Praktikan
 */
public class Mahasiswa {

    String nama,nim;

    void cetak (){
           Scanner baca = new Scanner(System.in);
           System.out.println("nama = ");
          nama = baca.next();
          System.out.println("nim = ");
          nim = baca.next();
           System.out.println("jadi nama anda = "+nama);
        System.out.println("jadi nim anda = "+nim);
    }
    public static void main(String[] args) {
          Mahasiswa nama = new Mahasiswa();
          nama.cetak();
            
           
    }
    
    
}
