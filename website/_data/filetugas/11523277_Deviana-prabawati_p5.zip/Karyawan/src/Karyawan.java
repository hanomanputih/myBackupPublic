/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;
/**
 *
 * @author PRAKTIKAN
 */
public class Karyawan {

    private String nip;
    private String nama;
    private int gaji;

    void setNip(String n) {
        if (n.length() == 10) {
            nip = n;
        } else {
            System.out.println("nip tidak sesuai");
        }
    }

    String getNip() {

        return nip;
    }

    void setNama(String nm) {
        if (nm.length() > 8) {
            nama = nm;
        }
    }

    String getNama() {
        return nama;
    }

    void setGaji(int g) {
        if (g>= 100000 && g<=500000) {
        gaji = g;
         
        }
    }

    }

