/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author PRAKTIKAN
 */
public class Main {
    public static void main(String[] args) {
        Karyawan k = new Karyawan();
        k.setNip("1234567899");
        k.setNama("deviana prabawati");
        k.setGaji(100000);
        
        System.out.println("Nip: "+k.getNip());
        System.out.println("Nama: "+k.getNama());
        System.out.println("Gaji: "+k.getGaji());
        
       
    }
    
}
