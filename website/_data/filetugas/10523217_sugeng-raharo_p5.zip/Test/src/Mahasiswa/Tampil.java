/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Mahasiswa;

/**
 *
 * @author Praktikan
 */
public class Tampil {
    public static void main(String[] args) {
        Karyawan krywn = new Karyawan();
        
        krywn.setNip("66666666");
        krywn.setNama("Miapaaah");
        krywn.setGaji(12312313);
        
        System.out.println("NIP  : "+krywn.getNip ());
        System.out.println("Nama : "+krywn.getNama ());
        System.out.println("Gaji Setahun : "+krywn.getGaji ());
        
    }
}
