/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Mahasiswa;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
    private String nim;
    public String nama;
    
    
        
    public void setNim(String nimKamu){
        if (nimKamu.length()==8){
            nim = nimKamu;
        }else{
            System.out.println("Error");
        }
    }
    public String getNim(){
        return nim;
    }
    
    }

