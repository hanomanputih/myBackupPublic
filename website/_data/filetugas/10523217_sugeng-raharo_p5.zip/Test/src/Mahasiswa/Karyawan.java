/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Mahasiswa;

/**
 *
 * @author Praktikan
 */
public class Karyawan {
    private String nip;
    private String nama;
    private int gaji;
    
    public void setNip(String nipKamu){
        if (nipKamu.length()==8){
            nip = nipKamu;
        }else{
            System.out.println("Error");
        }
    }
    public String getNip(){
        return nip;
    }
    
    public void setNama(String namaKamu){
        if (namaKamu.length()==8){
            nama = namaKamu;
        }else{
            System.out.println("Error");
        }
    }
    public String getNama(){
        return nama;
    }
    
    public void setGaji(int gajiKamu){
       gaji = gajiKamu;
       gaji *= 12;
    }
    
    public int getGaji(){
       return gaji;
    }

       
}
