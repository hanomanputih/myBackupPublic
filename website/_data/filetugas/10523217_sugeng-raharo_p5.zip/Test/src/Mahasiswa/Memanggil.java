/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Mahasiswa;

/**
 *
 * @author Praktikan
 */
public class Memanggil {
    public static void main(String[] args) {
        Mahasiswa mhs = new Mahasiswa();
        
        //mhs.nim =  10523217;
        //mhs.nama = "Haleluya";
        
        mhs.setNim("10523217");
        
        System.out.println("NIM  : "+mhs.getNim ());
        System.out.println("Nama : "+mhs.nama);
    }
}
