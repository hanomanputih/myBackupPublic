/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package coba;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class mahasiswa {

    String nama;
    String nim;
    String fakultas;
    String jurusan;
    String angkatan;
    
    void input(){
        Scanner sc = new Scanner(System.in);
        System.out.println("nama :");
        nama = sc.next();
        System.out.println("nim :");
        nim = sc.next();
        System.out.println("fakultas :");
        fakultas = sc.next();
        System.out.println("jurusan :");
        jurusan = sc.next();
        System.out.println("angkatan :");
        angkatan = sc.next();
        
    }
    void cetak(){
        System.out.println("nama anda :" +nama);
       
        System.out.println("nim anda :" +nim);
        
        System.out.println("fakultas anda :" +fakultas);
       
        System.out.println("jurusan anda :" +jurusan);
        
        System.out.println("angkatan anda :" +angkatan);
       
    }
    public static void main(String[] args) {
        
     mahasiswa mhs = new mahasiswa();
     
     mhs.input();
     
     mhs.cetak();
    }
}
