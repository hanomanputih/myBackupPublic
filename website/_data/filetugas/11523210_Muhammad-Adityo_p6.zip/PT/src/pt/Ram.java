/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pt;

/**
 *
 * @author Praktikan
 */
public class Ram {
    String Ram;

    public Ram(String Ram){
        this.Ram=Ram;
        
    }
    
    public void Display(){
        System.out.println("nama prosesor   :"+Ram);
        
    }
}
