/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pt;

/**
 *
 * @author Praktikan
 */
public class Prosesor {
    String namaProsesor;

    public Prosesor(String namaProsesor){
        this.namaProsesor=namaProsesor;
    }
    
    public void Display(){
        System.out.println("nama prosesor   :"+namaProsesor);
        
    }
}
