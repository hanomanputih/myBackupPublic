/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pt;

/**
 *
 * @author Praktikan
 */
public class Komputer {
    String merk;
    private Prosesor p;
    private Ram r;
    public Komputer(String nama){
        this.merk=nama;
        if(merk.equals("ASUS"));
        p=new Prosesor("Intel");
        r=new Ram("V-Gen");
        
    }
    
    public void Display(){
        System.out.println("Merk Komputer   : "+merk);
        System.out.println("Nama Prosesor   : "+p.namaProsesor);
        System.out.println("Nama RAM        : "+r.Ram);
        }
    
    public static void main(String[] args) {
        Komputer k= new Komputer("ASUS");
        k.Display();
        
        
    }
}
