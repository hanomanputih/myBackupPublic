/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class Main {
    public static void main(String[] args) {
        Karyawan kar=new Karyawan();
        kar.setNip("1234567890");
        kar.setNama("Ghina amanda");
        kar.setGaji(5000000);
        System.out.println("DATA KARYAWAN");
        System.out.println("NIP : " + kar.getNip());
        System.out.println("Nama : " + kar.getNama());
        System.out.println("Gaji per tahun : " + kar.getGaji());
        
        
    }
}
