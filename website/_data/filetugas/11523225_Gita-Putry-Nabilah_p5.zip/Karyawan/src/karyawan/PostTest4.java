/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class PostTest4 {
 public static void main(String[] args){   
     Karyawan kar = new Karyawan();
     kar.setNIP("011");
     System.out.println("NIP anda adalah:"+kar.getNIP());
     kar.setNAMA("Gita Putry");
     System.out.println("Nama Anda adalah:"+kar.getNAMA());
     kar.setGAJI(1000000);
     System.out.println("Gaji anda adalah:"+kar.getGAJI());
     
 }
}




