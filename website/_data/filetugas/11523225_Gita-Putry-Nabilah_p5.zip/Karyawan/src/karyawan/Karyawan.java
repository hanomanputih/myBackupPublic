/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class Karyawan {
private String nip;
private String nama;
private int gaji;

void setNIP(String nip){
    if(nip.length()== 3){
        this.nip = nip;
    }else{
        System.out.println("NIP yang anda masukkan salah!!");
    }
}

void setNAMA(String nama){
    
      this.nama = nama;
         
}

void setGAJI(int gaji){
    
        this.gaji = gaji*12;
       
}

String getNIP(){
    return nip;
}

String getNAMA(){
    return nama;
}

int getGAJI(){
    return gaji;
}
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
    }
}
