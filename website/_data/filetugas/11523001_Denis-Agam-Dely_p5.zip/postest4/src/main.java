/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Praktikan
 */
public class main {
 
    public static void main(String[] args) {
        karyawan kr = new karyawan();
        kr.setNIP ("11523001");
        kr.setNAMA("denis");
        kr.setGAJI(1000000);
        
        System.out.println("nama saya "+kr.getNAMA());
        System.out.println("nip saya "+kr.getNIP());
        System.out.println("gaji saya "+kr.getGAJI());
        
        
                
       
    }
}
