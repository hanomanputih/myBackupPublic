/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg08523447_arif;

/**
 *
 * @author Praktikan
 */
public class Komputer {
    String a1;
    String a2;
    Prosesor pros;
    RAM r;
    private final Object ehem;
    
    public Komputer (Prosesor proses, RAM ra){
        pros=proses;
        r=ra;
        if(a2.equals("ehem")){
            pros=new Prosesor("www","wyw");
            
        }else{
            pros=new Prosesor("salah","pilih");
          
            
            
        }
    }
    public static void main(String[]args){
        Prosesor proses=new Prosesor("www","wyw");
        
    }
    
}
