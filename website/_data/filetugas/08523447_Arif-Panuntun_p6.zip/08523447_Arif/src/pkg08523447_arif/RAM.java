/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg08523447_arif;

/**
 *
 * @author Praktikan
 */
public class RAM {
    String a;
    String b;
    
    public RAM(String a2, String b2);
    this.a=a2;
    this.b=b2;

    RAM(String string, String string0) {
        throw new UnsupportedOperationException("Not yet implemented");
    }
    