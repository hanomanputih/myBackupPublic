/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg08523447_arif;

/**
 *
 * @author Praktikan
 */
public class Prosesor {
    RAM r;
    
    String al;
    String bl;
    
    public Prosesor (String al, String bl){
        this.al=al;
        this.bl=bl;
        if(al.equals("www")){
            r=new RAM("suzuki","kawasaki");
        }else if(al.equals("wyw")){
            r=new RAM("itu","ini");
        }else{
            r=new RAM ("salah","pilih");
            
        }
    }
    public void tampil(){
        System.out.println("Prosesor:"+al);
        System.out.println("RAM:"+r.a+"");
    }
}
