/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package post.test;

/**
 *
 * @author PRAKTIKAN
 */
import java.util.Scanner;

class Mahasiswa {

    /**
     * @param args the command line arguments
     */
   String nama, nim, fakultas, jurusan, angkatan;
    
    void masukan() {
    Scanner read = new Scanner(System.in);
     System.out.print("Nama: ");
      nama=read.next();
     System.out.print("NIM: ");
      nim=read.next();
     System.out.print("Fakultas: ");
      fakultas=read.next();
     System.out.print("Jurusan: ");
       jurusan=read.next();
     System.out.print("Angkatan: ");
       angkatan=read.next();
    }
    
    void cetak() {
        System.out.println();
        System.out.println("Nama: "+nama); 
        System.out.println("NIM: "+nim);
        System.out.println("Fakultas: "+fakultas);
        System.out.println("Jurusan: "+jurusan);
        System.out.println("Angkatan: "+angkatan);
    }

 public static void main (String[] args) {
        // TODO code application logic here
        Mahasiswa m = new Mahasiswa();
        m.masukan();
        m.cetak();
    }
}