/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author PRAKTIKAN
 */
public class KaryawanKontrak extends Karyawan {


    @Override
    public void lihat() {
        int gaji=gajipokok+bonus;
        System.out.println("Gaji karyawan Kontrak : "+gaji);
    }
}
