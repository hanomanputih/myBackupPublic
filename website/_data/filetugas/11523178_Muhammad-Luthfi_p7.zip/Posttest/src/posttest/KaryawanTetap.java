/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author PRAKTIKAN
 */
public class KaryawanTetap extends Karyawan {
   double tunjangan=gajipokok*20/100;
    
    @Override
    public void lihat(){
    double gaji=gajipokok+tunjangan+bonus;
    System.out.println("gaji karyawan tetap : "+gaji);  
    }

}
