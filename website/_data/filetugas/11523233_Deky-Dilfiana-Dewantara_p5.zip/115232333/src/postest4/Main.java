/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package postest4;

/**
 *
 * @author Praktikan
 */
public class Main {

    /**
     * @param args the command line arguments
     */

        public static void main(String[] args) {
        Karyawan pegawai1 = new Karyawan();


        pegawai1.setNip("2011523233");
        pegawai1.setNama("Deky .D.Dewa");
        pegawai1.setGaji(10000000);

        System.out.println("nip : "+pegawai1.getNip());
        System.out.println("nama : "+pegawai1.getNama());
        System.out.println("Gaji Setahun : "+pegawai1.getGaji()*12);
    }
    }


