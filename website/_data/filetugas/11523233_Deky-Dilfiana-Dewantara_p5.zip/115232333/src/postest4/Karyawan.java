/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package postest4;

/**
 *
 * @author Praktikan
 */
public class Karyawan {
    private String nip;
    private String nama;
    private int gaji;
   

     public void setNip(String nipMasuk){
              if(nipMasuk.length()==10){
            nip=nipMasuk;
        }
        else{
            System.out.println("Error");
        }

    }
    public String getNip(){
        return nip;
    }

    public void setNama(String namaMasuk){
            nama=namaMasuk;

    }
    public String getNama(){
        return nama;
    }
    public void setGaji(int gajiMasuk){
                 if((gajiMasuk >(2000000))&&(gajiMasuk <(1000000000))){
            gaji=gajiMasuk;
        }
        else{
            System.out.println("Error");
        }

    }
    public int getGaji(){
        return gaji;
    }
}
