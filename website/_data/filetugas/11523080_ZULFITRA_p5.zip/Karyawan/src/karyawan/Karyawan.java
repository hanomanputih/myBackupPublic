/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class Karyawan {
    private String nip;
    private String nama;
    private int gaji;
    
    Karyawan (){
        nip= "11523080";
        nama= "Fitra";
        gaji= 10000000;
    }
    
    
    public void setNip (String newNip){
        nip=newNip;
    }
    public String getNip(){
        return nip;
    }
    
    
    public void setNama (String newNama){
        nama=newNama;
    }
    
    public String getNama(){
        return nama;
    }
    
    public void setGaji (int newGaji){
        gaji=newGaji;
    }
    public int getGaji(){
        return gaji;
    }
   
}
