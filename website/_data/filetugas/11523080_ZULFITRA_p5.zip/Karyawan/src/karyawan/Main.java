/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class Main {
    public static void main(String[] args) {
        Karyawan kryn = new Karyawan ();
        
        kryn.setNip("11523080");
        kryn.setNama("Fitra");
        kryn.setGaji(10000000);
        
        System.out.println("NIP :" +kryn.getNip());
        System.out.println("Nama :"+kryn.getNama());
        System.out.println("Gaji :"+kryn.getGaji());
    }
}
