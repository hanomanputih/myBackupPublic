/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest8;
//import java.util.Iterator;
import java.util.Map;
import java.util.HashMap;
/**
 *
 * @author Praktikan
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Map<String, String> mhs = new HashMap<String, String> ();
        
        mhs.put("Jakal KM 12", "Joko");
        mhs.put("Jakal KM 10", "Udin");
        mhs.put("Jakal KM 13", "Rahmat");

        System.out.println(mhs);
        
        for(Map.Entry<String,String> e : mhs.entrySet()){
           System.out.println(e.getKey()+", "+e.getValue());
        System.out.println(mhs.get("Jakal KM 10"));
        } 
    }
}
