/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package postest;

import java.util.HashMap;

import java.util.Map;



/**
 *
 * @author Praktikan
 */
public class Main {



    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    Map<Integer,String> data = new HashMap<Integer,String>();
        data.put(11523001,"Denis");
        data.put(11523002,"Arif");
        data.put(11523003,"Denok");
        for(Map.Entry<Integer,String> e : data.entrySet() ) {
            System.out.println(e.getKey() +": "+e.getValue());
        }
       

}}
