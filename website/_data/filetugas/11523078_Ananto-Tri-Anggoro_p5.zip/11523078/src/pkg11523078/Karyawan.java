/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg11523078;

/**
 *
 * @author PRAKTIKAN
 */
public class Karyawan {

    private String nip;
    private String nama;
    private int gaji;

    public int getGaji() {
        return gaji;
    }

    public void setGaji(int gaji) {
        this.gaji = gaji;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getNip() {
        return nip;
    }

    public void setNip(String nip) {
        this.nip = nip;
    }
}
