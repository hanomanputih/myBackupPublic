/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg11523078;

/**
 *
 * @author PRAKTIKAN
 */
public class Karyawan2 {

    public static void main(String[] args) {
        Karyawan kyn = new Karyawan();
        kyn.setGaji(10000000);
        kyn.setNama("ananto");
        kyn.setNip("11523078");
        System.out.println("Gaji per tahun anda = " + kyn.getGaji());
        System.out.println("Nama anda = " + kyn.getNama());
        System.out.println("NIP anda = " + kyn.getNip());

    }
}
