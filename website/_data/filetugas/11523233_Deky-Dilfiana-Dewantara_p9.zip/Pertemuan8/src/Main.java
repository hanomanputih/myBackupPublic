/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Praktikan
 */


import java.util.HashMap;

import java.util.Map;


public class Main {

    /**
     * @param args the command line arguments
     */


     public static void main(String[] args) {
        System.out.println("---------");
        Map<String, String> nama = new HashMap<String, String>();

        nama.put("Kaliurang", "Deky D Dewa");
        nama.put("JAKAL", "Kekew");
        nama.put("JOGJA", "titttt");

        for (Map.Entry<String, String> e : nama.entrySet()) {
            System.out.println(e.getKey() + " , " + e.getValue());
        }

        System.out.println(nama.get("JOGJA"));



    }

}
