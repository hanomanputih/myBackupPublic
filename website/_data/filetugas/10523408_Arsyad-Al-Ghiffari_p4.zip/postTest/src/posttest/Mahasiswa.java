/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {

    String nama, fakultas, jurusan, nim, angkatan;

    void isi() {
        Scanner baca = new Scanner(System.in);
        System.out.println("Siapa Nama Anda? ");
        nama = baca.nextLine();
        System.out.println("Berapa Nim Anda? ");
        nim = baca.nextLine();
        System.out.println("Angkatan berapakah anda? ");
        angkatan = baca.nextLine();
        System.out.println("Apa Jurusan Anda? ");
        jurusan = baca.nextLine();
        System.out.println("Apa Fakultas Anda? ");
        fakultas = baca.nextLine();
    }
    
    void cetak(){
        System.out.println(" ");
        System.out.println("-------------------");
        System.out.println("DATA DIRI MAHASISWA");
        System.out.println("-------------------");
        System.out.println(" ");
        System.out.println("Nama Anda : "+nama);
        System.out.println("Nim Anda : "+nim);
        System.out.println("Angkatan Anda : "+angkatan);
        System.out.println("Jurusan Anda : "+jurusan);
        System.out.println("Fakultas Anda : "+fakultas);   
    }
}
