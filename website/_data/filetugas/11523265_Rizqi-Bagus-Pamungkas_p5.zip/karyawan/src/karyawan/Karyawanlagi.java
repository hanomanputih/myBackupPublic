package karyawan;


public class Karyawanlagi {
   public static void main(String[] args) {
    Karyawan saya = new Karyawan();
    
   saya.setNip("11523265");
        System.out.println("NIP :  "+saya.getNip());
    saya.setNama("rizqi");
        System.out.println("NAMA anda :"+saya.getNama());
    saya.setGaji(20000000);
        System.out.println("Gaji :"+saya.getGaji()); 
                }
}
