package posttest4;

public class PostTest4 {

    public static void main(String[] args) {
        Karyawan heru = new Karyawan();
        heru.setNip("123456789");
        heru.setNama("Heru Hang Tryputra");
        heru.setGaji(40000);
        
        System.out.println("NIP : " + heru.getNip());
        System.out.println("Nama : " + heru.getNama());
        System.out.println("Gaji Setahun : Rp. " + heru.getGaji() * 12);
        
    }
}

class Karyawan {
    private String nip,nama;
    private int gaji;
    
    public void setNip(String nipP) {
        if (nipP.length() >= 10) {
            nip = nipP;
        }
        else {
            System.out.println("NIP kurang dari 10");
        }
    }
    
    public String getNip() {
        return nip;
    }
    
    public void setNama(String namaP) {
        nama = namaP;
    }
    
    public String getNama() {
        return nama;
    }
  
    public void setGaji(int gajiP) {
        if ((gajiP >= 100000) && (gajiP <= 500000)) {
            gaji = gajiP;
        }
        else {
            System.out.println("Gaji tidak diantara 100 ribu dan 500 ribu");
        }
    }
    
    public int getGaji() {
        return gaji;
    }
}
