/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

/**
 *
 * @author Praktikan
 */
import java.util.Scanner;

public class Mahasiswa {

    /**
     * @param args the command line arguments
     */
    String nama;
    String nim;
    String fakultas;
    String jurusan;
    String angkatan;

    public void cetak() {
        System.out.println("Nama anda adalah : " + nama);
        System.out.println("Panjang karakter nama adalah : " + nama.length());
        System.out.println("Nim anda adalah :" + nim);
        System.out.println("Panjang karakter nim adalah :" + nim.length());
        System.out.println("Fakultas anda adalah : " + fakultas);
        System.out.println("Panjang karakter fakultas anda adalah :" + fakultas.length());
        System.out.println("Jurusan anda adalah :" + jurusan);
        System.out.println("Panjang karakter jurusan anda adalah :" + jurusan.length());
        System.out.println("Angkatan anda adalah :" + angkatan);
        System.out.println("Panjang karakter angkatan anda adalah :" + angkatan.length());
    }

    public static void main(String[] args) {
        Mahasiswa mhs = new Mahasiswa();
        Scanner tulis = new Scanner(System.in);
        System.out.println("Masukkan Nama anda: ");
        mhs.nama = tulis.next();
        System.out.println("Masukkan Nim anda:");
        mhs.nim = tulis.next();
        System.out.println("Masukkan Fakultas anda: ");
        mhs.fakultas = tulis.next();
        System.out.println("Masukkan Jurusan anda:");
        mhs.jurusan = tulis.next();
        System.out.println("Masukkan Angkatan anda:");
        mhs.angkatan = tulis.next();
        mhs.cetak();
        // TODO code application logic here
    }
}
