/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;
import java.util.Scanner;
/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
    String nama , nim , fakultas , jurusan , angkatan ;
    
    void isi(){
        Scanner read = new Scanner(System.in);
        System.out.println("nama : ");
        nama = read.next();
        System.out.println("nim : ");
        nim = read.next();
        System.out.println("fakultas : ");
        fakultas = read.next();
        System.out.println("jurusan : ");
        jurusan = read.next();
        System.out.println("angkatan : ");
        angkatan = read.next();
    }
    
    void cetak(){
        System.out.println("nama anda adalah "+nama);
        System.out.println("nim anda adalah "+nim);
        System.out.println("fakultas anda adalah "+fakultas);
        System.out.println("jurusan anda adalah "+jurusan);
        System.out.println("angkatan anda adalah "+angkatan);
        
    }
    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Mahasiswa mh = new Mahasiswa();
        
        mh.isi();
        mh.cetak();
        // TODO code application logic here
    }
}
