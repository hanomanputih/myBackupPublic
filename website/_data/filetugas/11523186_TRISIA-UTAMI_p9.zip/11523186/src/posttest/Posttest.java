/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;

/**
 *
 * @author PRAKTIKAN
 */
public class Posttest {
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        ArrayList list = new ArrayList();
        LinkedList list2 = new LinkedList();
        list.add ("Nim :11523186");
        list.add ("Nama :amoy");
        list2.add("Nim");
        list2.add("Nama");
        System.out.println("ukuran list "+ list.size());
        
          for (Iterator iterator = list.iterator() ; iterator.hasNext();){
            String ii =(String) iterator.next();
            System.out.println(ii);
        
    }
           
        Map<Integer, String> map = new HashMap<Integer, String>();
        
        map.put(11, "11523186");
        map.put(22, "amoy");
        
    
        
        System.out.println(map.get(11));
        System.out.println("===================");
        for(Integer i : map.keySet ()) {
            System.out.println (i +" : " + map.get(i));
    }
        System.out.println("===================");
       
        for (Map.Entry<Integer, String> entry : map.entrySet ()){
            System.out.println (entry.getKey() + ","+ entry.getValue());
        }
}
    
}

