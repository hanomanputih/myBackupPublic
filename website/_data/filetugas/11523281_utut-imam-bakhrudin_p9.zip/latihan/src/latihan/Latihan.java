/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package latihan;
import java.util.Scanner;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

*
 *
 * @author Praktikan
 */
public class Latihan {
public static void main(String[] args) {
     List list = new ArrayList();
     list.add("Nama");
     list.add("NIM");
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
}
