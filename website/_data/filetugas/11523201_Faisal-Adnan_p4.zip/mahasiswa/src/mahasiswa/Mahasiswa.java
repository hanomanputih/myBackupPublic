/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
    String nama, nim, fakultas, angkatan;
    
    void cetak(){
        System.out.println("siapa nama anda: "+nama);
        System.out.println("berapa nim anda: "+nim);
        System.out.println("apa fakultas anda: "+fakultas);
        System.out.println("angkatan berapa anda:"+angkatan);
    }

    public static void main(String[] args) {
        Mahasiswa mhs=new Mahasiswa();
        mhs.nama="faisal adnan";
        mhs.nim="11523201";
        mhs.fakultas="teknik industri";
        mhs.angkatan="2011";
        mhs.cetak();
        
        
    }
}
