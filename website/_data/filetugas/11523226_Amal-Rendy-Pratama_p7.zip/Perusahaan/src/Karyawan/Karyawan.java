/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Karyawan;

/**
 *
 * @author Praktikan
 */
public class Karyawan {

  String nama="rendy";
  String nip="11523226";
  int gajipokok=3000000;
  int bonus=600000;
  
  
  public void view(){
      System.out.println("Nama Karyawan         :   "+nama);
      System.out.println("Nip Karyawan          :   "+nip);
      System.out.println("Gaji pokok Karyawan   :   "+gajipokok);
      System.out.println("Bonus Karyawan        :   "+bonus);
  }

    public int getBonus() {
        return bonus;
    }

    public void setBonus(int bonus) {
        this.bonus = bonus;
    }

    public int getGajipokok() {
        return gajipokok;
    }

    public void setGajipokok(int gajipokok) {
        this.gajipokok = gajipokok;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getNip() {
        return nip;
    }

    public void setNip(String nip) {
        this.nip = nip;
    }
}
