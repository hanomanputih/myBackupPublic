/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Karyawan;

/**
 *
 * @author Praktikan
 */
public class Main {
    
    public static void main(String[] args) {
        Karyawan kr = new Karyawan();
        KaryawanTetap kt = new KaryawanTetap();
        KaryawanKontrak kk = new KaryawanKontrak();
       
        kr.view();
        System.out.println("");
    
        kt.view();
        System.out.println("");
 
        kk.view();
    }
}
