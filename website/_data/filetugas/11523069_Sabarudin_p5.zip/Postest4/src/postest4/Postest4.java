/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest4;

/**
 *
 * @author Praktikan
 */
public class Postest4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         Karyawan kry = new Karyawan ();
        kry.setNip("11523069");
        kry.setNama("Sabarudin");
        kry.setGaji(500000000);
        System.out.println(kry.getNama());
        System.out.println(kry.getNip());
        System.out.println(kry.getGaji());
                
    }
}
