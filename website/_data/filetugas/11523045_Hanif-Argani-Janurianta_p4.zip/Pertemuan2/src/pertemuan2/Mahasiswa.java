/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package pertemuan2;
import java.util.Scanner;
/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
    String Nama;
    String NIM;
    String Jurusan;
    String Fakultas;
    String Universitas;

void cetak(){
    System.out.println("Nama"+Nama + "NIM"+NIM + "Jurusan"+Jurusan + "Fakultas"+Fakultas + "Universitas"+Universitas);
}

    public static void main(String[] args) {
        Scanner baca = new Scanner(System.in);
        Mahasiswa mhs1 = new Mahasiswa();
        System.out.print("Sebutkan nama = ");
        mhs1.Nama = baca.next();
        System.out.print("Sebutkan NIM = ");
        mhs1.NIM = baca.next();
        System.out.print("Jurusan apa = ");
        mhs1.Jurusan = baca.next();
        System.out.println("Fakultas apa = ");
        mhs1.Fakultas = baca.next();
        System.out.println("Universitas apa = ");
        mhs1.Universitas = baca.next();
    }
}
