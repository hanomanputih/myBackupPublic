/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package pertemuan2;
import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Hewan {
    int jumlahKaki;
    String nama;

    public static void main(String[] args) {
    Scanner baca = new Scanner(System.in);
    Hewan animal = new Hewan();
    System.out.print("sebutkan nama hewan = ");
    animal.nama = baca.next();
    System.out.print("berapa jumlah kaki nya = ");
    animal.jumlahKaki = baca.nextInt();
    System.out.print("jadi nama hewan terdapat "+animal.nama.length()+" huruf");
    }
}
