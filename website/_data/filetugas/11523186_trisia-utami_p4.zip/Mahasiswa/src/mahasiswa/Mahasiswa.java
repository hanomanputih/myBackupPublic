
package mahasiswa;
import java.util.Scanner;



/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
    String nama;
    String nim;
    
    public void cetak (){
        
     Scanner ct = new Scanner (System.in);
    
    System.out.println("masukkan nama anda :");
    nama=ct.next();
    System.out.println("masukkan nim anda:");
    nim=ct.next();
    
    System.out.println("nama saya "+nama );
    System.out.println("nim saya "+nim);
    }   
    public static void main(String[] args) {
     
      
     Mahasiswa aku= new Mahasiswa();
     aku.cetak();
     //ct.cetak();
      
      
    
     
    }
}
