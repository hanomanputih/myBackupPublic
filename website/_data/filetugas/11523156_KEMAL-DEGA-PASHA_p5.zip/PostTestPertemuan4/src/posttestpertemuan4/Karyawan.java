/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttestpertemuan4;

/**
 *
 * @author PRAKTIKAN
 */
public class Karyawan {
    private String nip;
    private String nama;
    private int gaji;
    
    void NIP(String ni){
        if(ni.length() <= 8) {
            nip=ni;
        }else {
            System.out.println("Error..");
        }
    }
    void NAMA (String nam) {
         if(nam.length() <= 20) {
            nama=nam;
        }else {
            System.out.println("Error..");
    }
}
    void GAJI (int gaj){
    gaji=gaj;
    }
    String NIP() {
        return nip;
    }
    String NAMA() {
        return nama;
    }
    int GAJI() {
        gaji=gaji*12;
        return gaji;
        
   }
    
}


    


