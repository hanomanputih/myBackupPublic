/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttestpertemuan4;

/**
 *
 * @author PRAKTIKAN
 */
public class Main {
    public static void main(String[] args) {
        Karyawan ma = new Karyawan() ;
        ma.NIP("11523");
        System.out.println("NIP = "+ma.NIP()) ;
        ma.NAMA ("KEMAL") ;
        System.out.println ("NAMA= "+ma.NAMA ()) ;
        ma.GAJI(100000);
        System.out.println ("GAJI= "+ma.GAJI()) ;
        
}
}   
