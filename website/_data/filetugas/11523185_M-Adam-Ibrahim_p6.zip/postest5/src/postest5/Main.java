/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest5;

/**
 *
 * @author Praktikan
 */
public class Main {
    
    public static void main(String[] args) {
        
       RAM r = new RAM();
       PROSESOR p = new PROSESOR();
       r.setUkuran("200");
       p.setType("intel");
        
       CPU cu = new CPU("1213",p,r);
       
      cu.tampil();
        
        
        
        
    }
    
}
