/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package belajar;

/**
 *
 * @author Praktikan
 */
public class coba {

    public static void main(String[] args) {
    String nama="Bahar Rizky Supriyadi";
    System.out.println("kata terakhir : "+nama.endsWith("yadi"));
    System.out.println("kata pertama : "+nama.startsWith("Mahar"));
    System.out.println("ini buat apa? "+nama.charAt(6));
    System.out.println("panjang karakter nama :"+nama.length());
}
}
