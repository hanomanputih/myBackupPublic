/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package belajar;
import java.util.Scanner;
/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
    String nama;
    String nim;
    String fakultas;
    String jurusan;
    String angkatan;

void isi(){
    Scanner read=new Scanner(System.in);
    System.out.println("inputkan nama anda : ");
    nama = read.next();
    System.out.println("inputkan nim anda ");
    nim=read.next();
    System.out.println("inputkan fakultas anda : ");
    fakultas = read.next();
    System.out.println("inputkan jurusan anda : ");
    jurusan = read.next();
    System.out.println("inputkan angkatan anda : ");
    angkatan = read.next();
}
void cetak(){
    System.out.println("nama anda ="+nama);
    System.out.println("nim ="+nim);
    System.out.println("fakultas anda ="+fakultas);
    System.out.println("jurusan anda ="+jurusan);
    System.out.println("angkatan anda ="+angkatan);
    System.out.println("jumlah karakter nama"+nama.length());
    System.out.println("jumlah karakter nim"+nim.length());
    System.out.println("jumlah karakter fakultas"+fakultas.length());
    System.out.println("jumlah karakter jurusan"+jurusan.length());
    System.out.println("jumlah karakter angkatan"+angkatan.length());
    System.out.println("jumlah seluruh karakter"+nama.length()+nim.length()+fakultas.length()+jurusan.length()+angkatan.length());
}
public static void main(String[] args) {
    Mahasiswa ms=new Mahasiswa();
    ms.isi();
    ms.cetak();
}
}
