/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Mahasiswa;

/**
 *
 * @author PRAKTIKAN
 */
public class Mahasiswa {

    String nama;
    String nim ;
    String fakultas ;
    String jurusan ;
    
      void cetakData (){
        System.out.println(" nama gua adalah : " + nama );
        System.out.println(" nim gua adalah : " + nim );
        System.out.println(" fakultas gua adalah : " + fakultas );
        System.out.println(" jurusan gua adalah : " + jurusan );
        
    }
    
    public static void main(String[] args) {
        Mahasiswa Mahasiswa007  = new Mahasiswa ();
        
        Mahasiswa007.nama = "Arif Ambiyanto" ;
        Mahasiswa007.nim = "10523329" ;
        Mahasiswa007.fakultas = " Teknik Industri ";
        Mahasiswa007.jurusan = "Teknik Informatika ";
        
        
       Mahasiswa007.cetakData();
    }
}
