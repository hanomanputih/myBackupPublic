/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author PRAKTIKAN
 */
public class PostTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    Karyawam_kontrak KT = new Karyawam_kontrak();
    KT.gaji();
    KT.makan();
    Karyawan_tetap KK = new Karyawan_tetap();
    KK.gaji();
    KK.makan();
    }
}
