/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author PRAKTIKAN
 */
public class Karyawan_tetap extends Karyawan implements Manusia{

    @Override
    public void gaji() {
        gaji = gajip + tunjangan + bonus;
        System.out.println("Gaji Karyawan Tetap : " +gaji);
    }

    @Override
    public void makan() {
        System.out.println("Karyawam tetap makan");
    }
    
    
}
