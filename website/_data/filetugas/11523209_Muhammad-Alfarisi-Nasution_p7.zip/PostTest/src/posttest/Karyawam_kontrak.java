/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author PRAKTIKAN
 */
public class Karyawam_kontrak extends Karyawan implements Manusia {
    
    @Override
    public void gaji() {
    gaji = gajip + bonus;
        System.out.println("GAJI Karyawan Kontrak : " +gaji);
    }

    @Override
    public void makan() {
        System.out.println("Karyawan kontrak tidak makan");
    }
    
}
