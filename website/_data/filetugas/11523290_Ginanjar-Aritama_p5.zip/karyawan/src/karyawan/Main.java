/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class Main {
    public static void main(String[] args) {
        Karyawan k = new Karyawan();
        k.setGaji(20000);
        System.out.println("Gaji Aku"+k.getGaji());
        k.setNama("aritama");
        System.out.println("Nama Aku"+k.getNama());
        k.setNip("11523290");
        System.out.println("NIP Aku"+k.getNip());
                
    }
}
