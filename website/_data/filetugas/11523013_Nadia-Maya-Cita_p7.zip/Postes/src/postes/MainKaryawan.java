/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes;

/**
 *
 * @author Praktikan
 */
public class MainKaryawan {

    public static void main (String []args){
        System.out.println("Karyawan Tetap");
        KaryawanTetap kt= new KaryawanTetap();
        kt.view();
        
        System.out.println("");
        
        System.out.println("Karyawan Kontrak");
        KaryawanKontrak kk = new KaryawanKontrak();
        kk.view();
    }
}