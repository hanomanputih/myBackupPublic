/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes;

/**
 *
 * @author Praktikan
 */
public abstract class Karyawan {
    protected int gajipokok = 3000000;
    protected int tunjangan=(int)(0.2*gajipokok);

   
    public void view (){
        System.out.println("gaji pokok : "+gajipokok);
        System.out.println("tunjangan : "+tunjangan);

    }
}
