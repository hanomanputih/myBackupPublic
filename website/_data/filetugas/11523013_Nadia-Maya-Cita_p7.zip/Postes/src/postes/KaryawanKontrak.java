/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes;

/**
 *
 * @author Praktikan
 */
public class KaryawanKontrak extends Karyawan implements Manusia {
    public int gaji;
    public int bonus = 650000;

    @Override
    public void  view(){
        super.view();
        gaji=gajipokok+bonus;
        System.out.println("Bonus : "+bonus);
        System.out.println("Gaji : "+gaji);
    }

    @Override
    public void menulis() {
        System.out.println("menulis");
    }
}
