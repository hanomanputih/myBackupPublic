/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package postest4;

import java.util.Scanner;

public class karyawan {
  private String nip,nama;
  private int gaji;

public void setnip() {
   
    Scanner masuk = new Scanner(System.in);
    System.out.println("nipku = ");
    nip = masuk.next();
    System.out.println("namaku = ");
    nama = masuk.next();
    System.out.println("gajiku = ");
    gaji=masuk.nextInt();
        }


    String getnip() {
        return nip;

    }
    String getna() {
        return nama;

    }
    int getga() {
        return gaji;

    }
}
