/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest4;

/**
 *
 * @author Praktikan
 */
public class tampil {

    public static void main(String[] args) {
        karyawan k = new  karyawan();
//        System.out.println(n.nip);
        //System.out.println();
        k.setnip();
        System.out.println("jadi nimnya "+k.getnip());
        System.out.println("nama saya "+k.getna());
        System.out.println("gaji saya "+k.getga());
        


    }
}
