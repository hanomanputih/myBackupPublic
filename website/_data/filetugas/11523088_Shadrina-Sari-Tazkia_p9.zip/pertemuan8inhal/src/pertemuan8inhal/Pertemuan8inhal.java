/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan8inhal;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 *
 * @author Praktikan
 */
public class Pertemuan8inhal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
       List<String> list1=new ArrayList<String>();
       
       list1.add("cici");
       list1.add("ajeng");
          
        System.out.println(list1);
        
        System.out.println("-------------");
        Iterator <String> ite= list1.iterator();
        while(ite.hasNext()){
            String s = ite.next();
            System.out.println(s);
        }
        
    }
}
