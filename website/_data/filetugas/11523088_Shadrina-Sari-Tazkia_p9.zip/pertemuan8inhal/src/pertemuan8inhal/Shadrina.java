/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan8inhal;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

/**
 *
 * @author Praktikan
 */
public class Shadrina {
    public static void main(String[] args) {
        Map<Integer, String> m=new HashMap<Integer, String> ();
        
        m.put(11523088,"adrin");
        m.put(11523066,"bangkrut");
        System.out.println(m );
        System.out.println(m.get(11523088));
        
        for(String i : m.values()){
            System.out.println(i);
        }
        
        for(Integer i : m.keySet()){
            System.out.println(m.get(i));
        }
        
        Iterator<Entry<Integer,String>> it=m.entrySet().iterator();
        while(it.hasNext()){
            System.out.println(it.next());
        }
    }
}
