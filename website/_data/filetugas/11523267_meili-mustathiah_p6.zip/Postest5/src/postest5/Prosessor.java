/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest5;

/**
 *
 * @author Praktikan
 */
public class Prosessor {

    String merk = "intel";

    public Prosessor(String merk) {
        this.merk = merk;
    }

    public void Tampil() {
        System.out.println("jadi merk prosessornya adalah: " + merk);


    }

    public void Percabangan() {
        if ("intel".equals(this.merk)) {
            System.out.println("wapik");

        } else {
            System.out.println("jelek");
        }

    }
}
