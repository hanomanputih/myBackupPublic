/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest5;

/**
 *
 * @author Praktikan
 */
public class Ram {

    int besar;

    public Ram(int besar) {
        this.besar = besar;

    }

    public void Tampil() {
        System.out.println("jadi merk RAM ini adalah: ");

    }

    public void Percabangan() {
        if (this.besar == 123) {
            System.out.println("benar");
        } else {
            System.out.println("salah");
        }
    }
}
