/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest5;

/**
 *
 * @author Praktikan
 */
public class Komputer {
//    String merk;
//    
//    
//    public void njebolKomputer(){
//        System.out.println("merknya: ");
//        
//    }
//    
//   public Komputer (String merk){
//       this.merk=merk;
//       
//   }

    public static void main(String[] args) {

        Prosessor komp1 = new Prosessor("intel");
        Ram ram1 = new Ram(12);

        komp1.Tampil();
        komp1.Percabangan();

        ram1.Tampil();
        ram1.Percabangan();



    }
}
