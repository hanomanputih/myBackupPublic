/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttestkomposisi;

/**
 *
 * @author PRAKTIKAN
 */
public class PosttestKomposisi {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Ram kp = new Ram ("100 giga");
        Prosesor mk =new Prosesor ("Intel");
        Komputer km= new Komputer(mk,kp);
        km.Tampil(mk,kp);
        
    }
}
