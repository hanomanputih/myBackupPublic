/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttestkomposisi;

/**
 *
 * @author PRAKTIKAN
 */
public class Komputer {
    String merk;
    String kapasitas;
    Prosesor mk;
    Ram kp;
    public Komputer (Prosesor mk,Ram kp ){
        
        this.mk=mk;
        this.kp=kp;
    }
    public void Tampil (Prosesor mk,Ram kp){
        System.out.println("merknya :"+mk.merk);
        System.out.println("kapasitas"+kp.kapasitas);
    }
}
