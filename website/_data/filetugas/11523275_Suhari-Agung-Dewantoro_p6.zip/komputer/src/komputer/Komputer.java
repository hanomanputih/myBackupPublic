/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;


 
public class Komputer {

String NamaKomputer;
prosesor p;
ram r;

public Komputer(String NamaKomputer) {
    this.NamaKomputer = NamaKomputer;
    if (NamaKomputer.equals("Apple")) {
        p = new prosesor("i7");
        r = new ram("DDR3");
    }
}
public static void main (String []args) {
    Komputer kom = new Komputer ("Apple");

    System.out.println ("Nama Komputer  : "+kom.NamaKomputer);
    System.out.println ("Jenis Prosesor : "+kom.p.JenisProsesor);
    System.out.println ("Jenis RAM      : "+kom.r.JenisRam);
 
    
}}


