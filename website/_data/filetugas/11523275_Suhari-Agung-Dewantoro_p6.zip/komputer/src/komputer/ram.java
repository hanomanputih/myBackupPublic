/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;


public class ram {

    String JenisRam;
    public ram (String JenisRam) {
        this.JenisRam = JenisRam;
    }
    public void tampilRam () {
        System.out.println("Jenis RAM : " + JenisRam);
    }
}
