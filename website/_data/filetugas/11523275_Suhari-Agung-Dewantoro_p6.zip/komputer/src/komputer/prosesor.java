/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;


public class prosesor {
    String JenisProsesor;
    public prosesor (String JenisProsesor) {
        this.JenisProsesor = JenisProsesor;
    }
    public void tampilRam () {
        System.out.println("Jenis Prosesor : " +JenisProsesor);
    }
}
