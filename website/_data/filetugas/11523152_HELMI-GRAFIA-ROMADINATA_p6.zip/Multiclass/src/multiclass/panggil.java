/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package multiclass;

/**
 *
 * @author praktikan
 */
public class panggil {
    public static void main(String[] args) {
        Komputer komp1 = new Komputer ("Asus");
        komp1.TampilKomp();
    }
}
