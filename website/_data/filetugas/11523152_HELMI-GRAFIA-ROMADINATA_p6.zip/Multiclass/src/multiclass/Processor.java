/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package multiclass;

/**
 *
 * @author praktikan
 */
public class Processor {
    String namaProc;
    public Processor(String namaProc){
        this.namaProc = namaProc;
        
    }
}
