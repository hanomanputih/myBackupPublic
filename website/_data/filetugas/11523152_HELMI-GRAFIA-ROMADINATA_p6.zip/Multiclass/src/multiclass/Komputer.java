/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package multiclass;

/**
 *
 * @author praktikan
 */
public class Komputer {
    String namaKomp;
    private Processor p;
    private ram r;
    public Komputer (String komp){
        this.namaKomp = komp;
        if (komp.equals ("Asus")){
       
        p = new Processor ("AMD");
        r = new ram ("Corsair");
        }
    }
    public void TampilKomp(){
        System.out.println("Nama Komputer :"+namaKomp);
        System.out.println("Nama Processor :"+p.namaProc);
        System.out.println("Nama Ram :"+r.namaRam);
    }
   
}
