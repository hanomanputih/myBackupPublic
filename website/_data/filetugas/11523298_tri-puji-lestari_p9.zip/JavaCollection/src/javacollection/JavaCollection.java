/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javacollection;
import java.util.*;


/**
 *
 * @author Praktikan
 */
public class JavaCollection {
    
  private static void loadData(List<String> list) {
list.add("data 1");
list.add("data 2");

}
  
  private static void tampilkanList(List<String> list) {
for (int i = 0; i < list.size(); i++)
System.out.print(list.get(i) + "  "); // menampilkan isi 
System.out.println();
}
  
  

     public static void main(String[] args) {
        HashMap map = new HashMap();
        HashSet set = new HashSet();
        
     List<String> list = new ArrayList<String>();
loadData(list);
tampilkanList(list);
                System.out.println("list di index ke 1 = "+list.get(0));   
        
for (int i = 1; i < 3; i ++) {
    set.add(i+"-"+"Pratikan");// menambahkan object ke koleksi
}
System.out.println("ukuran set : "+set.size());
for(Iterator iterator = set.iterator(); iterator.hasNext();){
String ii = (String) iterator.next();
System.out.println("isi : "+ii);
        
        Scanner pembaca = new Scanner(System.in); 
        int nim;
        String nama;
        System.out.print("nama: ");
        nama = pembaca.nextLine(); 
        System.out.print("nim: ");
        nim = pembaca.nextInt();
        
//        System.out.println("nama: "+nama);
//        System.out.println("nim"+nim);
         map.put("Nama", nama);
         map.put("NIM", new Integer(nim));
         System.out.println(map);
         System.out.println("Ukuran Map : " + map.size());
         boolean containKey = map.containsKey("NIM");
         System.out.println("Has key (NIM): " + containKey);

         Object removed = map.remove("NIM");
         System.out.println("Removed : " + removed);
         System.out.println(map);
         System.out.println("ukuran map baru baru : " + map.size());

     }
     }
}
