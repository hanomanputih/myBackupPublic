/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javacollection;
import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class coba {
    


public static void main(String[] args) {
   Scanner pembaca = new Scanner(System.in); 
        int nim;
        String nama;
        System.out.println("nama: ");
        nama = pembaca.nextLine(); 
        System.out.println("nim: ");
        nim = pembaca.nextInt();
        
        System.out.println("nama: "+nama);
        System.out.println("nim"+nim);
}
}