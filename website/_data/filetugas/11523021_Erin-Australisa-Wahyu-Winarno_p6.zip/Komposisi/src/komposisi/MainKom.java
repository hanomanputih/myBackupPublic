/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komposisi;

/**
 *
 * @author Praktikan
 */
public class MainKom {
    Ram rm;
    Prosesor pr;
    
    public MainKom(Ram rm, Prosesor pr){
        this.rm = rm;
        this.pr = pr;
        
    } 
    public static void main(String[] args) {
        Prosesor pr = new Prosesor ("hp");
        Ram rm = new Ram("32");
        MainKom mk = new MainKom(rm,pr);
        
        System.out.println("Merk Prosesor :"+pr.merk);
        System.out.println("Kapasitas RAM :"+rm.kapasitas +"GB");
        
        
    }
}
