/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuanakhir;

import java.util.HashMap;
import java.util.Scanner;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


public class main {
    
    public static void main(String[] args) {
    List list = new ArrayList();
    list.add("nama");
    list.add("nim");
    
for(Iterator<String> iterator = list.iterator(); 
iterator.hasNext();){//untuk melihat isi List
        String isi = iterator.next();
System.out.println(isi);}

    Scanner s = new Scanner(System.in);
    Map map = new HashMap();
    System.out.println("Masukan nama : ");
    map.put(list.get(0),s.next());
    System.out.println("Masukan nim : ");
    map.put(list.get(1),s.next());
    
    System.out.println("Nama : " +map.get("nim"));
    System.out.println("Nama : " +map.get("nama"));
    
   
    }
}
