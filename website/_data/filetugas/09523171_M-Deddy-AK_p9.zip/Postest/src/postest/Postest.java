/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;
import java.util.Collections;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class Postest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
 HashMap mp = new HasMap ();
 
 mp.put("nama", "deddy");
        Object put = mp.put("im",new Integer(09523171));
 
        System.out.println(map);
        System.out.println("Ukuran map :"+map.size());
        
        boolean countainKey = mp.containsKey("nim");
        System.out.println("rtury");
    }
}
