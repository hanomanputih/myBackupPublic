/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;


import javax.swing.JOptionPane;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
    String nama;
    String nim;
    
   
    
    public void masukann(){
        nama=JOptionPane.showInputDialog(null,"masukan nama anda");
        nim=JOptionPane.showInputDialog(null,"masukan NIM anda");
        
        
    }
    
    public void cetakn(){ 
        JOptionPane.showMessageDialog(null, " nama :"+nama+ "   NIM :"+ nim ,"dataku ",JOptionPane.INFORMATION_MESSAGE);
     
    }
    
    
    
    
    
    public static void main(String[] args) {
        Mahasiswa m=new Mahasiswa();
        m.masukann();
        m.cetakn();
                
    
    }
    
}
