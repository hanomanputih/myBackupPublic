/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author Praktikan
 */
public class Kontrak extends Karyawan implements Manusia{
    public int gaji;
    public int bonus=300000; 
    
    @Override
    public void view(){
        super.view();
        gaji=gajiPokok+bonus;
        System.out.println("Gaji :"+gaji);
    }

    @Override
    public void bekerja() {
        System.out.println("bekerja");
    }
}
    
    

