/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author Praktikan
 */
public abstract class Karyawan {
    protected int gajiPokok=3000000;
    protected int tunjangan=(int)(0.2*gajiPokok);
    
    
    public void view(){
        System.out.println("Gaji Pokok :"+gajiPokok);
        System.out.println("Tunjangan :"+tunjangan);
      
    }
    
    
    
}
