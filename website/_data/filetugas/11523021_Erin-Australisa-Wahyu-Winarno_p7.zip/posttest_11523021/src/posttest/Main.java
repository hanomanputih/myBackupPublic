/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author Praktikan
 */
public class Main {
    public static void main(String[] args) {
        
        System.out.println("Karyawan Tetap");
        Tetap tp = new Tetap();
        tp.view();
        
        System.out.println("");
        
        System.out.println("Karyawan KOntrak");
        Kontrak kt = new Kontrak();
        kt.view();
        
        
    }
    
}
