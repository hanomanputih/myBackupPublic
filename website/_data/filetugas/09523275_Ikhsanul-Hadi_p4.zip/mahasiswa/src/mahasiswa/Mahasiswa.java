/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;
import java.util.Scanner;


/**
 *
 * @author Praktikan
 */
public class Mahasiswa {

    /**
     * @param args the command line arguments
     */
    String namaMahasiswa;
    String NIM;
    String fakultas;
    String jurusan;
    String angkatan;
 
    public static void main(String[] args) {
Mahasiswa c = new Mahasiswa ();
Scanner cetak = new Scanner (System.in);
System.out.println("masukkan nama anda");
c.namaMahasiswa = cetak.next();
System.out.println("masukkan NIM anda");
c.NIM = cetak.next();
System.out.println("masukkan fakultas anda");
c.fakultas = cetak.next();
System.out.println("masukkan jurusan anda");
c.jurusan = cetak.next();
System.out.println("masukkan angkatan anda");
c.angkatan = cetak.next();
System.out.println("panjang karakter nama anda :" +c.namaMahasiswa);
System.out.println("panjang karakter NIM anda :" +c.NIM);
System.out.println("panjang karakter fakultas anda :" +c.fakultas);
System.out.println("panjang karakter jurusan anda :" +c.jurusan);
System.out.println("panjang karakter angkatan anda :" +c.angkatan);





    }
}
