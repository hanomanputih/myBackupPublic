/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javacollection;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 *
 * @author PRAKTIKAN
 */
public class JavaCollection {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        List<String> list1 = new ArrayList<String>();
        List list2 = new ArrayList();
        list1.add("Armaho");
        list1.add("Normani");
        list1.add("Kemal");

        list2.add("115231");
        list2.add("115232");
        list2.add("115233");



        for (int i = 0; i < list1.size(); i++) {
            System.out.println("Nama" + i + " :" + list1.get(i));
        
        System.out.println("NIM" + i + " :" + list2.get(i));
        }

        Map<Integer, String> map = new HashMap<Integer, String>() ;
        map.put (115231, "Armaho");
        map.put (115232, "Normani");
        map.put (115233, "Kemal");
        
        System.out.println("*******");
        System.out.println(map.get (115231));
        System.out.println("*******");
        
        Iterator <String> ite = list1.iterator();
        while (ite.hasNext()){
            String s = ite.next();
            System.out.println(s);
        }
                
    }
}
