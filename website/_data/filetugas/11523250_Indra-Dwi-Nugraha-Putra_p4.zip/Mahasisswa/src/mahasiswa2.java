/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Praktikan
 */
public class mahasiswa2 {

    String nim;
    String nama;
    String fakultas;
    String jurusan;
    int angkatan;
    float jumlah1, jumlah2, jumlah3;

    void cetak() {
        nim = "11523250";
        nama = "Indra Dwi Nugraha Putra";
        fakultas = "FTI";
        jurusan = "Informatika";
        angkatan = 2011;

        jumlah1 = nim.length();
        jumlah2 = nama.length();
        jumlah3 = jumlah1 + jumlah2;
        jumlah1 = nama.length();
        System.out.println("jumlah kata nim = " + jumlah1);
        jumlah2 = nim.length();
        System.out.println("jumlah kata nama = " + jumlah2);

        System.out.println("nama anda adalah" + nama);
        System.out.println("fakultas anda :"+fakultas);
        System.out.println("nim anda adalah" + nim);
        System.out.println("jumlah dari nim anda adalah : " + nim);
        System.out.println("jumlah dari nama anda adalah : " + nama);
        System.out.println("jumlah dari nim dan nama anda adalah");
        System.out.println("jumlah semuanya dari nim dan nama" + jumlah3);
    }

    public static void main(String[] args) {
        mahasiswa2 mhs = new mahasiswa2();
        mhs.cetak();
    }
}
