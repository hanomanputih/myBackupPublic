/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest3;

/**
 *
 * @author Praktikan
 */
import java.util.Scanner;

public class Mahasiswa {

    String nama, fakultas, jurusan, nim, angkatan;
    
    /**
     * @param args the command line arguments
     */
   void input(){
       Scanner cetak = new Scanner(System.in);
       
        
        System.out.print("masukan nama mahasiswa = ");
        nama = cetak.next();
        
        System.out.print("masukan nim mahasiswa  = ");
        nim = cetak.next();
        
        System.out.print("masukan fakultas       = ");
        fakultas = cetak.next();
        
        System.out.print("masukan jurusan        = ");
        jurusan = cetak.next();
        
        System.out.print("masukan angkatan       = ");
        angkatan = cetak.next();
   }
   void cetak(){
        System.out.println(" ");
        System.out.println("Data anda adalah sebagai berikut !");
        System.out.println(" ");
        System.out.println("Nama     = "+nama);
        System.out.println("NIM      = "+nim);
        System.out.println("Fakultas = "+fakultas);
        System.out.println("Jurusan  = "+jurusan);
        System.out.println("Angkatan = "+angkatan);
   }
   
    public static void main(String[] args) {
        // TODO code application logic here
        Mahasiswa m = new Mahasiswa();
            m.input();
            m.cetak();
    
    }
}
