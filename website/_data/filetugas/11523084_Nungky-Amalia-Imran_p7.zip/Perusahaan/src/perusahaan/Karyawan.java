/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perusahaan;

/**
 *
 * @author Praktikan
 */
public abstract class Karyawan {
    protected String nama;
    protected String NIP;
    protected float gajiPokok=3000000;
    protected float bonus=1000000;
    
    public abstract void hitungGaji();
    
    public void view(){
        System.out.println("Nama        : "+nama);
        System.out.println("Nomor IP    : "+NIP);
        System.out.println("gajiPokok   : "+gajiPokok);
        System.out.println("Bonus       : "+bonus);
    }
}
