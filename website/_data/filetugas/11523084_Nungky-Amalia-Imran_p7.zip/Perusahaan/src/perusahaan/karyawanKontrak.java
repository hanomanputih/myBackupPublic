/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perusahaan;

/**
 *
 * @author Praktikan
 */
public class karyawanKontrak extends Karyawan{
    private double gaji;

    @Override
    public void hitungGaji() {
       gaji=gajiPokok+bonus;
        System.out.println("Gaji Karyawan Kontrak   : "+gaji);
    }
    
    
    
}
