/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perusahaan;

/**
 *
 * @author Praktikan
 */
public class karyawanTetap extends Karyawan{
    private double gaji;
    private double tunjangan;
    
    @Override
    public void view(){
        super.view();
}

    @Override
    public void hitungGaji() {
       tunjangan=gajiPokok*0.2;
       gaji=gajiPokok+tunjangan+bonus;
        System.out.println("Gaji Karyawan Tetap   : "+gaji);
        
    }
    
}