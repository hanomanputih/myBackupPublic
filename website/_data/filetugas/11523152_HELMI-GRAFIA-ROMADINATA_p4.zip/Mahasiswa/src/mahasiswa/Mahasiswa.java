/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {

    String nama;
    String nim;
    
       void cetak ()
       {
     Scanner mahasiswa = new Scanner(System.in);
     System.out.println("Masukkan Nama Anda:");
     nama= mahasiswa.next();
     System.out.println("Masukkan Nim Anda:");
     nim= mahasiswa.next();
     System.out.println("Nama anda:"+nama);
     System.out.println("Nama anda:"+nim);
         
       }
       public static void main(String[] args) {
        Mahasiswa m = new Mahasiswa();
        m.cetak();
    }
}
