/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class RAM {
    String kapasitas;
    
    public RAM(String capacity) {
        kapasitas = capacity;
    }    
    public static void main (String[] args){
        RAM patriot = new RAM("6 GB");
        System.out.println("Kapasitas RAM : " + patriot.kapasitas);
    }
}
