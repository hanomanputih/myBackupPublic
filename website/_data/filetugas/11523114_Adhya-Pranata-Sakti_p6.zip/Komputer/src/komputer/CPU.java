/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class CPU {
   public int noProduksi;
   public Prosesor p;
   public RAM r;
   
   public CPU(int noProduksi){
       this.noProduksi = noProduksi;
       if(noProduksi == 1){
           p = new Prosesor("Intel Core i5 2500k");
           r = new RAM("6 GB");
       }
   }
   public void TampilCPU() {
       System.out.println("Nama Prosesor : " + p.nama);
       System.out.println("Kapasitas RAM : " + r.kapasitas);
   }

   
   public static void main(String[] args){
       CPU com = new CPU(1);
       com.TampilCPU();
   }
   
}
