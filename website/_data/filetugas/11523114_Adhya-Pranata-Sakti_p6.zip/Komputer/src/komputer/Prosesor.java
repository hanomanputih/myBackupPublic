/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class Prosesor {
    String nama;
    
    public Prosesor(String name) {
        nama = name;
    }    
    public static void main (String[] args){
        Prosesor intel = new Prosesor("Intel Core i5 2500k");
        System.out.println("Nama Prosesor : " + intel.nama);
    }
    }


