/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest4;

/**
 *
 * @author Praktikan
 */
public class Postest4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         Karyawan ka = new Karyawan();
         ka.NIP("1234567890");
        System.out.println("nip ku = "+ ka.NIP());
     
         ka.NAMA ("Roki");
        System.out.println("nama ku = "+ ka.NAMA()); 
       
         ka.GAJI (90000);
        System.out.println("gaji ku = "+ ka.GAJI());
    }
}
