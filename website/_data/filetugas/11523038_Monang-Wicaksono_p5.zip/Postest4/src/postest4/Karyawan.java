/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest4;

/**
 *
 * @author Praktikan
 */
public class Karyawan {
    
    private String nip, nama;
    private int gaji;
    
    public Karyawan (){
        
    }
    
    void NIP(String nip){
        if(nip.length()== 10){
            this.nip = nip;
        }else{
            System.out.println("Erooooooooooor......");
        }
    }
    
    String NIP(){
        return nip;

    }
    
    void NAMA(String nama){
        if(nama.length()<5){
            this.nama = nama;
        }else{
            System.out.println("Tidak Dikenal");
        }
    }
    String NAMA(){
        return nama;
    }
    
    void GAJI(int gaji){
        if(gaji<100000){
            this.gaji = gaji;
        }else
        {
            System.out.println("Sangat Memprihatinkan");
        }
}
    int GAJI(){
        return gaji;
    }
}


