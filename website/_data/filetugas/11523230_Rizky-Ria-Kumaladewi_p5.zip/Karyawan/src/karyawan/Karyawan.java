/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class Karyawan {
    private String nip;
    private String nama;
    private int gaji;
    
    public void setNip(String nip){
     this.nip = nip;
    }
    
    public void setNama(String nama){
     this.nama = nama;
    }
    
    public void setGaji(int gaji){
     this.gaji = gaji;
    }
   
    public String getNip(){
     return nip;
    }
    public String getNama(){
     return nama;
    }
    
    public int getGaji(){
     return gaji;
    }
    
    public static void main(String[] args) {
        Karyawan k = new Karyawan();
        k.setNip("11523230");
        k.setNama("rizkyria");
        k.setGaji(1000000);
        
        System.out.println("nip :" + k.getNip());
        System.out.println("nama :" + k.getNama());
        System.out.println("gaji setahun :" + k.getGaji() * 12);
    }
}
