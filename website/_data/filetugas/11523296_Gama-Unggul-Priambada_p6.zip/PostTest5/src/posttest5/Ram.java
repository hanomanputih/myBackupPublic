/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest5;

/**
 *
 * @author Praktikan
 */
public class Ram {
    String kapasitas;
    public Ram(String kapasitas){
    this.kapasitas = kapasitas;
    }
public void tampilRam(){
    System.out.println("Kapasitas RAM = "+kapasitas);
}
}
