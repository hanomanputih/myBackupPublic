/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest5;

/**
 *
 * @author Praktikan
 */
public class Prosesor {
    String merkProsesor;
    public Prosesor(String merkProsesor){
    this.merkProsesor = merkProsesor;
    }
public void tampilProsesor(){
    System.out.println("Merk Prosesor = "+merkProsesor);
}
    
}
