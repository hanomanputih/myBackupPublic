/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest5;

/**
 *
 * @author Praktikan
 */
public class Cpu {
    private int nomorProduksi;
    private Prosesor p;
    private Ram r;
    
public Cpu(int nomorProduksi) {
this.nomorProduksi = nomorProduksi;
if (nomorProduksi==1){
p = new Prosesor("Phenom");
r = new Ram("4 GB");
}
}

public void TampilCpu() {
    System.out.println("Kode Produksi : "+nomorProduksi);
    System.out.println("Merk Prosesor : "+p.merkProsesor);
    System.out.println("Kapasitas RAM : "+r.kapasitas);
}

    public static void main(String[] args) {
        Cpu cpu1 = new Cpu(1);
        cpu1.TampilCpu();
    }
}
