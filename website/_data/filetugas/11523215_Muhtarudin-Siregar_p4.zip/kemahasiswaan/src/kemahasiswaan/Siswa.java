
package kemahasiswaan;

import java.util.Scanner;

public class Siswa {
String nama,fakultas,jurusan;
int nim;

    void tampil(){
        System.out.println("Nama: " + nama);
        System.out.println("NIM : " + nim);
        System.out.println("Fakultas: " + fakultas);
        System.out.println("Jurusan : " + jurusan);
    }
    void masukan(){
        Scanner  inputan= new Scanner (System.in);        
      System.out.println(" masukkan nama anda: ");
      nama = inputan.next();
      System.out.println("NIM anda adalah: ");
      nim = inputan.nextInt();
        System.out.println("Fakultas anda : ");
      fakultas = inputan.next();
        System.out.println(" Jurusan anda :");
      jurusan = inputan.next();
    
    }
    
    public static void main(String[] args) {
       Siswa mhs1 = new Siswa();
       mhs1.masukan();
       mhs1.tampil();
    }
}
