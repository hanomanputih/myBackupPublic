/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author Praktikan
 */
public class KaryawanTetap extends Karyawan {

    @Override
    public void gaji() {
       
       int tunjangan = (int) (0.2*gajiPokok);
       int gajiTetap=tunjangan+gajiPokok+bonus;
        System.out.println("Gaji karyawan tetap adalah"+gajiTetap);
    }
    
}
