/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author Praktikan
 */
class Main{
public static void main(String[] args) {
    

   KaryawanTetap kt = new KaryawanTetap();
   KaryawanKontrak kk = new KaryawanKontrak();
   kt.gaji();
   kt.gaji();
    
    
}
}
