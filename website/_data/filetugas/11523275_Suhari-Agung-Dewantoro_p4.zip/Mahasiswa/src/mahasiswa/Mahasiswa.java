/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

/**
 *
 * @author Praktikan
 */
import java.util.Scanner;
public class Mahasiswa {

   String nama;
   String nim;
   String fakultas;
   String jurusan;
   String angkatan;


public void cetak (){
Scanner ct = new Scanner(System.in);
System.out.print("masukan nama anda : ");
nama = ct.next();
System.out.print("masukan nim anda : ");
nim = ct.next();
System.out.print("masukan fakultas anda : ");
fakultas = ct.next();
System.out.print("masukan jurusan anda : ");
jurusan = ct.next();
System.out.print("masukan angkatan anda : ");
angkatan = ct.next();


System.out.println("");
System.out.println("        BIODATA ANDA ADALAH :       ");
System.out.println("masukan nama anda : "+nama);
System.out.println("masukan nim anda : "+nim);
System.out.println("masukan fakultas anda : "+fakultas);
System.out.println("masukan jurusan anda : "+jurusan);
System.out.println("masukan angkatan anda : "+angkatan);
}
        

    public static void main(String[] args) {
        Mahasiswa ct = new Mahasiswa();
        
        ct.cetak();
        // TODO code application logic here
    
}}
