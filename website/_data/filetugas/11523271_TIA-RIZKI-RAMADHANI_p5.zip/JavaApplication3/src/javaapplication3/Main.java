/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

/**
 *
 * @author Praktikan
 */
public class Main {
    public static void main(String[] args) {
        karyawan k = new karyawan ();
        
        k.setNip("11523271");
        System.out.println("Nip anda : "+k.getNip());
        k.setNama("ririe");
        System.out.println("Nama anda : " +k.getNama());
        k.setGaji(10000);
        System.out.println("Gaji anda : " +k.getGaji());
        System.out.println("gaji setahun anda : "+k.getGaji()*12);
        
          
    }
}
    
