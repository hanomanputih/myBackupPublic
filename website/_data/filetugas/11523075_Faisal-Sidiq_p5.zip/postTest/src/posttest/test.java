/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author Praktikan
 */
public class test {
    public static void main(String[] args) {
        karyawan krwn = new karyawan();
        krwn.setNama("faisal");
        System.out.println("nama :" + krwn.getNama());
        krwn.setNip("999999");
        System.out.println("nip :" + krwn.getNip());
        krwn.setGaji(4000000);
        System.out.println("gaji :" + krwn.getGaji()*12);
    }
    
}
