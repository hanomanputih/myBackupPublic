
package komputer;


public class Komputer {
    String namakom;
    prosesor prs;
    ram r;
    
    public Komputer(String namakom) {
       this.namakom = namakom;
       if (namakom.equals("apple")) {
        prs = new prosesor("AMD","123");
        r = new ram ("apaaja","456");
       }
    }
    public static void main(String[] args) {
        Komputer kom = new Komputer("apple");
        System.out.println("komputer    : "+kom.namakom);
        System.out.println("prosesor    : "+kom.prs.namaprosesor +", "+kom.prs.nomerprosesor);
        System.out.println("ram         : "+kom.r.namaram +", "+kom.r.nomerram);
    }
}
