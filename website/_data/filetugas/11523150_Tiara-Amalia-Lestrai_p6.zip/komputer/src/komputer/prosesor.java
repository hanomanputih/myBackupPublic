
package komputer;


public class prosesor {
    String namaprosesor , nomerprosesor;
    
  

    prosesor(String namaprosesor, String nomerprosesor) {
        this.namaprosesor = namaprosesor;
        this.nomerprosesor = nomerprosesor;
        
    }
}
