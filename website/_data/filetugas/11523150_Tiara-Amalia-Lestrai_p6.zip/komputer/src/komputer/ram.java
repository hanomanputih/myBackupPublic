
package komputer;


public class ram {
   String namaram , nomerram;
  public ram (String namaram, String nomerram) {
      this.namaram=namaram;
      this.nomerram=nomerram;
  }
}

