/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;
import java.util.Scanner;
/**
 *
 * @author PRAKTIKAN
 */
public class Mahasiswa {
String nama,fakultas,jurusan,nim,angkatan;

void isi(){
    Scanner sc =new Scanner(System.in);
    System.out.println("Masukkan nim anda :");
    nim =sc.next();
    System.out.println("Masukkan nama Anda :");
    nama = sc.next();
    System.out.println("Masukkan fakultas Anda :");
    fakultas =sc.next();
    System.out.println("Masukkan Jurusan anda :");
    jurusan =sc.next();
    System.out.println("Masukkan angkatan anda :");
    angkatan =sc.next();
        
    System.out.println("Nim Anda adalah :" +nim);
     System.out.println("Nama Anda adalah :" +nama);
      System.out.println("Fakultas Anda adalah :" +fakultas);
       System.out.println("Jurusan Anda adalah :" +jurusan);
        System.out.println("Angkatan Anda adalah :" +angkatan);
}

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Mahasiswa mhs =new Mahasiswa();
        
       
        mhs.isi();
        
        int karakter =mhs.nama.length();
        System.out.println("panjang karakter nama anda adalah: "+karakter);
        
        // TODO code application logic here
    }
}
