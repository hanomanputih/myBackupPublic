
package postestpbo;
import java.util.Scanner;

public class Mahasiswa {

    String nama,nim,fakultas,jurusan,angkatan;
    int jumlah1;


    void isi(){
        Scanner read=new Scanner (System.in);
        System.out.print("Masukkan Nama: ");
        nama = read.nextLine();
        System.out.print("Masukkan NIM: ");
        nim = read.next();
        System.out.print("Masukkan Fakultas ");
        fakultas = read.next();
        System.out.print("Masukkan Jurusan: ");
        jurusan = read.next();
        System.out.print("Masukkan Angkatan: ");
        angkatan = read.next();
    }

    void cetak(){
        System.out.println("Nama Anda: "+nama);
        System.out.println("NIM Anda: "+nim);
        System.out.println("Fakultas Anda: "+fakultas);
        System.out.println("Jurusan Anda: "+jurusan);
        System.out.println("Angkatan Anda: "+angkatan);
    }

    void hitungKarakter(){
        jumlah1 = nama.length();
        System.out.println("Jumlah karakter Nama anda: "+jumlah1);
        jumlah1 = nim.length();
        System.out.println("Jumlah karakter NIM anda: "+jumlah1);
        jumlah1 = jurusan.length();
        System.out.println("Jumlah karakter Jurusan anda: "+jumlah1);
    }


    public static void main(String[] args) {
        Mahasiswa mh=new Mahasiswa();
        mh.isi();
        mh.cetak();
        mh.hitungKarakter();
    }

}
