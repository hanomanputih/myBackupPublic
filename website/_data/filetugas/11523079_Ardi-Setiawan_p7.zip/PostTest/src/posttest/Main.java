/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author PRAKTIKAN
 */
public class Main {
    public static void main(String[] args) {
        KaryawanTetap kt = new KaryawanTetap();
        System.out.println("KARYAWAN TETAP");
        kt.lihat();
        
        System.out.println("");
        
        KaryawanKontrak kk = new KaryawanKontrak();
        System.out.println("KARYAWAN KONTRAK");
        kk.lihat();
        
    }
    
}
