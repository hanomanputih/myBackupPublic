/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author PRAKTIKAN
 */
public class KaryawanTetap extends Karyawan {
   int tunjangan=gajipokok*20/100;
    
  

    @Override
    public void lihat() {
        int gaji=tunjangan+gajipokok+bonus;
        System.out.println("Gaji Karyawan Tetap : "+gaji);
    }

   
    
    
}
