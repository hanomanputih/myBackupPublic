/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author PRAKTIKAN
 */
public abstract class Karyawan {
     protected int gajipokok = 3000000;
     protected int bonus = 1000000;
    
    public abstract void lihat();
    
}
