/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package posttest8;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class posttest8 {

    
    public static void main(String[] args) {
       List<String> list1=new ArrayList<String>();

       list1.add("11523217");
       list1.add("anggun");

        System.out.println(list1);

        System.out.println("-------------");
        Iterator <String> ite= list1.iterator();
        while(ite.hasNext()){
            String s = ite.next();
            System.out.println(s);
        }

    }
}
  