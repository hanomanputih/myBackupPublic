/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Praktikan
 */
public class Cpu {
    private int nomorProduksi;
    private Prosesor p;
    private Ram r;
    public Cpu(int nomorProduksi){
    this.nomorProduksi= nomorProduksi;
    if(nomorProduksi == 1){
    p = new Prosesor("intel");
    r = new Ram("ddr3");
    }
   
    }
   public void tampilAll() {
       System.out.println("nomor produksi : "+ nomorProduksi);
        System.out.println("type ram : "+ r.type);
        System.out.println("nama prosesor : "+ p.namaProsesor);
        
    }
        
                public static void main(String[] args) {
       Cpu c = new Cpu(1);     
       c.tampilAll();
        
    }
    }
    

