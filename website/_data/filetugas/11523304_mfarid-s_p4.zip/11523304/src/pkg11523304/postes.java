/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg11523304;

/**
 *
 * @author Praktikan
 */
public class postes {
    
}
