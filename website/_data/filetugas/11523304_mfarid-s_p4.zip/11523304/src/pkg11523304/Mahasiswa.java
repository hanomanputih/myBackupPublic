/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg11523304;

/**
 *
 * @author Praktikan
 */

import java.util.Scanner;
class Mahasiswa {
    String nama = "farid";
    int nim =11523304;
    
    
    public void cetak(){
    System.out.println("nama saya="+ nama);
    System.out.println("nim saya="+ nim);
    }
    public static void main(String[] args) {
        
    }
}

