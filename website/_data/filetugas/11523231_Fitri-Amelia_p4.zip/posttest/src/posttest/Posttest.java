/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author praktikan
 */
import java.util.Scanner;

class Mahasiswa {
    String nama;
    String nim;
    String fakultas;
    String jurusan;
    int angkatan;
    
    void cetak(){
        System.out.println("DATA MAHASISWA");
        System.out.println("nim      :"+nim);
        System.out.println("nama     :"+nama);
        System.out.println("fakultas :"+fakultas);
        System.out.println("jurusan  :"+jurusan);
        System.out.println("angkatan :"+angkatan);
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Mahasiswa mhs=new Mahasiswa();
        Scanner b=new Scanner(System.in);
        
        System.out.println("Masukan NIM : ");
        mhs.nim=b.next();
        
        System.out.println("Masukan Nama : ");
        mhs.nama=b.next();
        
        System.out.println("Masukan Fakultas : ");
        mhs.fakultas=b.next();
        
        System.out.println("Masukan Jurusan : ");
        mhs.jurusan=b.next();
        
        System.out.println("Masukan Angkatan : ");
        mhs.angkatan=b.nextInt();
        
        mhs.cetak();
    
    }
}
