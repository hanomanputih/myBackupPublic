/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Karyawan;

/**
 *
 * @author Praktikan
 */
public class Main {
    public static void main(String[] args) {
        Karyawan k=new Karyawan();
        k.setNip("11523039");
        System.out.println("NIP anda : "+k.getNip());
        k.setNama("bambang");
        System.out.println("NAMA anda : "+k.getNama());
        k.setGaji(2000000);
        System.out.println("GAJI anda : "+k.getGaji());
    }
}
