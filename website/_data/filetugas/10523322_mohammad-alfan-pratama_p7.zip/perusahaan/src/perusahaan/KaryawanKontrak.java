/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perusahaan;

/**
 *
 * @author Praktikan
 */
public class KaryawanKontrak {
    String gajipokok;
    String bonus;
    
  ;
    int gajipokok2= 3000000;
    
    void karyawanTetap () {
    String tunjangan = null;
    System.out.println("gajipokok" +gajipokok);
    System.out.println("bonus" +bonus);
    }
}
