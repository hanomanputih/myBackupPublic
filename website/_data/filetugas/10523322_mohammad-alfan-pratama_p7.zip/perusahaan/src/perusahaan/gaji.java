/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perusahaan;

/**
 *
 * @author Praktikan
 */
public class gaji {
    String karyawanTetap;
    String karyawanKontrak;
    private String tunjangan;
    private String gajipokok;
    private String bonus;
    private String pokok;
    
    void gaji () {
        String gaji = null;
    System.out.println("karyawanTetap" +tunjangan+gajipokok+bonus);
    System.out.println("karyawanKontrak" +gajipokok+bonus);
    }
}


