/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perusahaan;

/**
 *
 * @author Praktikan
 */
public class karyawanTetap {
    String tunjangan;
    String gajipokok;
    String bonus;
    
    int tunjangan1= 60000;
    int gajipokok2= 3000000;
    
    void karyawanTetap () {
        System.out.println("tunjangan" +tunjangan);
        System.out.println("gajipokok" +gajipokok);
        System.out.println("bonus" +bonus);
    }
}
