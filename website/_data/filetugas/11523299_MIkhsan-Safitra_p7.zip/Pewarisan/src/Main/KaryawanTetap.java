/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

/**
 *
 * @author Praktikan
 */
public class KaryawanTetap extends Karyawan {
   int tunjangan=gajipokok*20/100;
   
 
    @Override
   public void gaji(){
    super.gaji =tunjangan+gajipokok+bonus;
    
       System.out.println("tampilgaji karyawan tetap "+super.gaji);
      
   }
   
    
}
