/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

/**
 *
 * @author Praktikan
 */
public class Karyawan {
    int gaji;
    int gajipokok=3000000;
    int bonus = 100000;

    public void gaji(){
    }
    
        
    }

