/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

/**
 *
 * @author Praktikan
 */
public class KaryawanKontrak extends Karyawan{
    
@Override
    public void gaji(){
        gaji =gajipokok+bonus;
        
        System.out.println("tampilgaji karyawan kontrak "+gaji);
    }
 
    
}
