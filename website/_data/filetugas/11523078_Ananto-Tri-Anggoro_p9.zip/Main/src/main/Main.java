/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Iterator;

/**
 *
 * @author PRAKTIKAN
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {


        Scanner pembaca = new Scanner(System.in);
        HashMap map = new HashMap();
        List list = new ArrayList();
        String nama = pembaca.next();
        String nim = pembaca.next();
        list.add(nama);
        list.add(nim);

        map.put("1", nama);
        map.put("2", nim);


        System.out.println(map);


        for (Iterator<String> i = list.iterator(); i.hasNext();) {
String isi = i.next();

            System.out.println(isi);
      
        }
        
        System.out.println(list.get(1));
        System.out.println(map.get(2));
        

    }
}
