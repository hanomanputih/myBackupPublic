/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;


public class Main {
     public static void main(String[] args) {
        Karyawan K=new Karyawan () ;
        K.setNip("11523143");
        System.out.println(K.getNip());
        
        
        K.setNama("Danar");
        System.out.println(K.getNama());
        
        
        K.setGaji(100000 * 12);
        System.out.println(K.getGaji ());
        
        
}
}
