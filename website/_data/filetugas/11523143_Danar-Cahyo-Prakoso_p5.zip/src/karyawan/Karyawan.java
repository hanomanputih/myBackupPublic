/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

public class Karyawan {
    private String  nip;
    private String nama;
    private int gaji;
   
    public void setNip(String n) {  
       this.nip = n;
   }
   
    public String getNip() {
    return nip;
}
    public void setNama(String nm) {
        this.nama = nm;
    }
    public String getNama() {
    return nama;
    }
    
    public void setGaji(int g){
            this.gaji = g;
}
    
    public int getGaji() {
    return gaji;
}

    public static void main(String[] args) {
        // TODO code application logic here
    }
}
