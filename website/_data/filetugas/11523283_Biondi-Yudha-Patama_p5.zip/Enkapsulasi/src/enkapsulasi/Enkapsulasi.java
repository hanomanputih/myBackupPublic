/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package enkapsulasi;

/**
 *
 * @author Praktikan
 */
public class Enkapsulasi {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Karyawan kry1 = new Karyawan();

        kry1.setter();
        kry1.getNama();

        System.out.println("Nama: " + kry1.getNama());
        System.out.println("NIP: " + kry1.getNip());
        System.out.println("Gaji Perbulan: " + kry1.getGaji());
        System.out.println("Gaji Setahun: " + kry1.getGaji() * 12);

    }
}
