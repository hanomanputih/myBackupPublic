/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package enkapsulasi;

/**
 *
 * @author Praktikan
 */
public class Karyawan {

    private String nama;
    private String nip;
    private int gaji;

    public void setter() {
        this.nama = nama;
        this.nip = nip;
        this.gaji = gaji;

        nama = "biondi yudha pratama";
        nip = "11523283";
        gaji = 5000000;
    }
    
    public String getNama() {
        return nama;
    }
    public String getNip() {
        return nip;
    }
    public int getGaji() {
        return gaji;
    }
}
