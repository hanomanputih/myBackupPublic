/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package list;
    
    import java.util.ArrayList ;
    import java.util.List ;
    
public class Main {
    public static void main(String[] args) {
        
        
        List<Integer> buku = new ArrayList<Integer> () ;
        
        buku.add(1) ;
        buku.add(2);
        buku.add(3);
        
       
       for (Integer i : buku) {
        System.out.println(1);
       }
        System.out.println("=====================================================");
       
       for (int = 0 ; i <buku.size();i++) ; {
        
    }
    }
}
