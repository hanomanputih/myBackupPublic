/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package PostTest;

import java.util.Collections;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        
        Map mp = new HashMap () ;
        
        mp.put("Nama", "Nugraha");
        mp.put("NIM", new Integer (11523162));
        
        System.out.println(mp);
        System.out.println("Ukuran Map : "+mp.size());
        
        boolean containKey = mp.containsKey("NIM");
        System.out.println("Has key (NIM): "+containKey);
        
        
    }
}
