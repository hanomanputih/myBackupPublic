/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package map;

import java.util.HashMap ;
import java.util.*;

public class main {
    public static void main(String[] args) {
        
        Map<Integer,String> nama = new HashMap <Integer,String> ();
        
        nama.put(1, "Joko");
        nama.put(2, "Wildan");
        nama.put(3, "Kun");
        
        System.out.println(nama.get(1));
        
        for (Map.Entry<Integer,String> entry : nama.entrySet()) {
            System.out.println(entry.getKey()+", "+entry.getValue());
        }
        
        for (String n : nama.values()){
            System.out.println(n);
        }
        
        
        
    }
    
}
