/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package posttest_3;
import java.util.Scanner;
/**
 *
 * @author praktikan
 */
public class Mahasiswa {
    String nama;
    String nim;


    void cetak(){
         Scanner baca = new Scanner(System.in);
        System.out.println("nama anda adalah ="+nama);
        System.out.println("nim anda adalah ="+nim);

    }
    public static void main(String[] args) {
    Mahasiswa mhs = new Mahasiswa();

    mhs.nama ="Devli setiawan";
    mhs.nim ="11523103";


mhs.cetak();



    }


}
