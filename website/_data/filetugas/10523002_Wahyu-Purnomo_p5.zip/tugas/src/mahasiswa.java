/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Praktikan
 */
public class mahasiswa {
    public int nim;
    public String nama;
    
}
public class Main{
    public static void main(String[] args) {
        Mahasiswa m= new Mahasiswa();
        m.nim=5;
        m.nama="Wahyu";
    }
}
