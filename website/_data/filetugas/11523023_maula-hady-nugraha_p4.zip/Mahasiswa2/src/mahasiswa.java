
import java.util.Scanner;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author praktikan
 */
public class mahasiswa {

   

   static String nama;
   static String nim;
   static String jurusan;
   static String angkatan;
   static String fakultas;

   void cetak (){
       Scanner sc = new Scanner (System.in);
       System.out.println ("NIM: ");
       nim = sc.next ();
       System.out.println ("NAMA: ");
       nama = sc.next ();
       System.out.println ("JURUSAN: ");
       jurusan = sc.next ();
       System.out.println ("FAKULTAS: ");
       fakultas = sc.next ();
       System.out.println ("ANGKATAN: ");
       angkatan = sc.next ();

    }

       public static void main (String[] args) {
      mahasiswa mhs = new mahasiswa();
      mhs.cetak();

        System.out.println(" ");
        System.out.println(" ");
        System.out.println("nama anda: " + nama);
        System.out.println("panjang karakter " +nama.length());
        System.out.println("nim anda: " + nim);
        System.out.println("panjang karakter " +nim.length());
        System.out.println("jurusan anda: " + jurusan);
        System.out.println("panjang karakter " +jurusan.length());
        System.out.println("fakultas anda: " + fakultas);
        System.out.println("panjang karakter " +fakultas.length());
        System.out.println("angkatan anda: " + angkatan);
        System.out.println("panjang karakter " +angkatan.length());


       }
   }


