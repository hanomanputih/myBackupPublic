/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Mahasiswa;
import java.util.Scanner;
/**
 *
 * @author PRAKTIKAN
 */


public class Mahasiswa {
    
   String nim;
   String nama;
   String fakultas;
   String jurusan;
   String alamat;

   void cetak() {
    
       Scanner sc = new Scanner (System.in);
   
       System.out.println("m.nama");
       nama = sc.next();
       System.out.println("m.nim");
       nim = sc.next();
       System.out.println("m.fakultas");
       fakultas = sc.next();
       System.out.println("m.jurusan");
       jurusan = sc.next();
       System.out.println("m.alamat");
       alamat = sc.next();
       
       System.out.println("Fakultas Anda adalah"+fakultas);
       System.out.println("Jurusan Anda Adalah"+jurusan);
       System.out.println("Alamat Anda Adalah"+alamat);
       System.out.println("Nama Anda Adalah"+nama);
       System.out.println("Nim Anda Adalah"+nim);
}
   
   public static void main(String[] args) {
      //nama mk = new nama ();
       Mahasiswa m = new Mahasiswa ();
       m.cetak();
        
                
    }
}
