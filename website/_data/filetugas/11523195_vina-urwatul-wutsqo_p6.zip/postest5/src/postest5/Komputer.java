/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest5;

import java.util.Scanner;

/**
 *
 * @author PRAKTIKAN
 */
public class Komputer {
    String id_komp;
    Processor p;
    Ram r;
    
    public Komputer (String komp) {
        this.id_komp=komp;
        if (id_komp.equals("1")){
            p= new Processor("punya vina");
            r= new Ram("coreduo");
            
        }
    }
        public static void main(String[] args) {
        Scanner sc= new Scanner (System.in);
        System.out.println("input komputer milik mu: ");
        Komputer komp = new Komputer (sc.next());
            
        System.out.println("jenis processor"+komp.p.nama);
        System.out.println("jumlah RAM"+komp.r.nama);
    }
    }

