/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest8;

import java.lang.String;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

/**
 *
 * @author Praktikan
 */
public class Prog_Sederhana {
    
    public static void main(String[] args) {
        
        Scanner X = new Scanner(System.in); 
            String Nama,NIM;
            System.out.print("Nama : ");
            Nama = X.next();
            System.out.print("NIM  : ");
            NIM = X.next();
            
        System.out.println("");
        System.out.println("====================================================");
        
            System.out.println("NAMA : "+Nama);
            System.out.println("NIM  : "+NIM);
            
        System.out.println("");
        System.out.println("====================================================");
                    
        List<String> list1 = new ArrayList <String> ();
        Map<Integer,String> map = new HashMap<Integer, String>();
        
        map.put(1,Nama);
        map.put(2,NIM);
        
        System.out.println(map.get(2));
        
        System.out.println("");
        System.out.println("====================================================");
        
        for(Map.Entry <Integer,String> entry : map.entrySet()){
            System.out.println(entry.getKey() + "." + entry.getValue());
        }
        
        System.out.println("");
        System.out.println("====================================================");
             
        list1.add (Nama);
        list1.add (NIM);
        
        for (int i = 0; i < list1.size(); i++) {
            System.out.println("index " + (i+1) + " : " + list1.get(i));            
        }
        System.out.println("");
        System.out.println("====================================================");
        
        for (String s : list1) {
            System.out.println(s);
        }
        System.out.println("");
        System.out.println("====================================================");
        
        Iterator <String> ite = list1.iterator();
        while (ite.hasNext()) {
              String s = ite.next();
              System.out.println(s);
        }
        
    }
}

