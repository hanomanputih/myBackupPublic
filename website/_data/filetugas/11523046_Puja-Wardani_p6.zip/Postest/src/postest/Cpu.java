/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

/**
 *
 * @author praktikan
 */
public class Cpu {
    int noproduk;
    String warna;
    Prosesor p1;
    Ram r1;
    
    public Cpu(int noproduk){
        if (noproduk == 2) {
            p1 = new Prosesor("Core I3");
            r1 = new Ram("3 GB");
        }
    }
    
    public void tampilCpu() {
        System.out.println("Nomor produk CPU =" + noproduk);
        System.out.println("Jenis prosesor = " + p1.jenis);
        System.out.println("Kapasistas RAM = " + r1.kapasitas);
    }
    
}
