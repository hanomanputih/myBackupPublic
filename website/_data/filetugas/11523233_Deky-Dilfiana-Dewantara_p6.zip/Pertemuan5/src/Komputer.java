/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Praktikan
 */
public class Komputer {
    int hargaBeli;
    Prosesor p1;
    RAM r1;
    
    public Komputer(int hb){
        this.hargaBeli = hb;
        if(hb > 5000000){
            this.p1 = new Prosesor("Core i9");
            this.r1 = new RAM("9 GB");
        }
        else{
            this.p1 = new Prosesor ("Core i1");
            this.r1 = new RAM("1 GB");
    }
    }
    
    public void tampil(){
        
        System.out.println("Harga : Rp."+hargaBeli);
        System.out.println("Prosesor : "+p1.merk);
        System.out.println("Ukuran RAM : "+r1.kapasitas);
    }
    
    
}
