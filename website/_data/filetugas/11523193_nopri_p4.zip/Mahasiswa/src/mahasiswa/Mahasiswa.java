/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

import java.util.Scanner;

public class Mahasiswa {
    String nim;
    String nama,fakultas,jurusan,angkatan ;
    
     
    void input () {
         Scanner pembaca = new Scanner (System.in);
        System.out.println("nim :");
        nim = pembaca.next ();
        System.out.println("nama saya " );
        nama = pembaca.next ();
        System.out.println("fakultas saya" );
        fakultas = pembaca.next ();
        System.out.println("jurusan saya " );
        jurusan= pembaca.next ();
         System.out.println("angkatan saya ");
         angkatan= pembaca.next ();
        
    }
    
    void cetak () {
    
          
        

       System.out.println("nim saya = " +nim);

       System.out.println("nama saya = " +nama);
       
      System.out.println("fakultas saya = " +fakultas);
       
       System.out.println("jurusan saya = " +jurusan);
    
       System.out.println("angkatan saya = " +angkatan);
        
    }
    public static void main(String[] args) {
        
   
      Mahasiswa mhs1 = new Mahasiswa ();
      mhs1.input ();
       mhs1.cetak ();
       
       
    }
}
