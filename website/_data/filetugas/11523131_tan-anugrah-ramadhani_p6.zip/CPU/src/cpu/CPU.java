/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cpu;

/**
 *
 * @author PRAKTIKAN
 */
public class CPU {

    private int noproduk;
    private ram Ram;
    private Prossesor prossesor;
    
    public CPU (){
        this.noproduk=noproduk;
        if (noproduk == 1 ){
            ram=new ram ("120000");
            prossesor =new prossesor ("intel)");
        }
        public void tampil (){
            System.out.println("ram" +ram.harga);
        }
    }


}

