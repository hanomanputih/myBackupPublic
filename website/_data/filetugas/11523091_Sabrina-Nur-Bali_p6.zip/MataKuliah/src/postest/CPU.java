/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

/**
 *
 * @author Praktikan
 */
public class CPU {
    private String merkCPU;
    private int jumlahCPU;

    public int getJumlahCPU() {
        return jumlahCPU;
    }

    public void setJumlahCPU(int jumlahCPU) {
        this.jumlahCPU = jumlahCPU;
    }

    public String getMerkCPU() {
        return merkCPU;
    }

    public void setMerkCPU(String merkCPU) {
        this.merkCPU = merkCPU;
    }

    
    
    
    
}
