/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

/**
 *
 * @author Praktikan
 */
public class NewClass {
    public static void main(String[] args) {
        RAM r = new RAM();
        r.setMerkRAM("ssd");
        
        Prosesor p = new Prosesor();
        p.setMerkProsesor("intel");
        
        CPU c = new CPU();
        c.setMerkCPU("core i5");
        
        Komputer kp = new Komputer ("lg", c, p, r);
        kp.tampil();  
    }
}

