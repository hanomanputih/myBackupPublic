/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

/**
 *
 * @author Praktikan
 */
public class Komputer {
    String merkKomputer;
    CPU merkCPU;
    Prosesor merkProsesor;
    RAM merkRAM;

    public Komputer(String merkKomputer, CPU merkCPU, Prosesor merkProsesor, RAM merkRAM) {
        this.merkKomputer = merkKomputer;
        this.merkCPU = merkCPU;
        this.merkProsesor = merkProsesor;
        this.merkRAM = merkRAM;
        
    }
    public void  tampil(){
        System.out.println(merkKomputer);
        System.out.println(merkCPU.getMerkCPU());
        System.out.println(merkProsesor.getMerkProsesor());
        System.out.println(merkRAM.getMerkRAM());
    }
        
}

    


