/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

/**
 *
 * @author Praktikan
 */
public class RAM {
    private String merkRAM;
    private int jumlahRAM;

    public int getJumlahRAM() {
        return jumlahRAM;
    }

    public void setJumlahRAM(int jumlahRAM) {
        this.jumlahRAM = jumlahRAM;
    }

    public String getMerkRAM() {
        return merkRAM;
    }

    public void setMerkRAM(String merkRAM) {
        this.merkRAM = merkRAM;
    }
    
    
}
