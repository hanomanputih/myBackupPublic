/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

/**
 *
 * @author Praktikan
 */
public class Prosesor {
    private String merkProsesor;
    private int jumlahProsesor;

    public int getJumlahProsesor() {
        return jumlahProsesor;
    }

    public void setJumlahProsesor(int jumlahProsesor) {
        this.jumlahProsesor = jumlahProsesor;
    }

    public String getMerkProsesor() {
        return merkProsesor;
    }

    public void setMerkProsesor(String merkProsesor) {
        this.merkProsesor = merkProsesor;
    }
    
    
}
