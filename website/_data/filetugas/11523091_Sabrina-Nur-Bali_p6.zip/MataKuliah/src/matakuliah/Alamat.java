/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package matakuliah;

/**
 *
 * @author Praktikan
 */
public class Alamat {
    String jalan;
    String kodepos;

    public void setJalan(String jalan) {
        this.jalan = jalan;
    }

    public void setKodepos(String kodepos) {
        this.kodepos = kodepos;
    }

    public String getJalan() {
        return jalan;
    }

    public String getKodepos() {
        return kodepos;
    }

    
    
    
        
        
    
}
