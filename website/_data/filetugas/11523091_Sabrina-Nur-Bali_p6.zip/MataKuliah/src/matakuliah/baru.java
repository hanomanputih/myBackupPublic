/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package matakuliah;

/**
 *
 * @author Praktikan
 */
public class baru {
    public static void main(String[] args) {
        Alamat jakal = new Alamat();
        jakal.setJalan("Jalan Kaliurang KM 14,5");
        jakal.setKodepos("51888");
        
        Manusia saby = new Manusia();
        Manusia fadhil = new Manusia();
        
        
        saby.setAlamat(jakal);
        saby.setNama("Sabrina");
        
        fadhil.setAlamat(jakal);
        
        
        System.out.println(saby.getNama()+""+saby.getAlamat().getJalan());
        
        
    }
}
