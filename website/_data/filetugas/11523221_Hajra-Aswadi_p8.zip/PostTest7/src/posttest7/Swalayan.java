/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest7;

/**
 *
 * @author Praktikan
 */
public class Swalayan {
    float harga = 19320;
    int bayar;
    int sisa;
    
    void tampil() {
        
        
    }
    
}
