/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest7;

public class PostTest7 {

    public static void main(String[] args) {

    }
}
