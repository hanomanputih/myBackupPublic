/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest7;

/**
 *
 * @author Praktikan
 */
public class Main {
    public static void main(String[] args) {
        Swalayan s;
        Indomart i = new Indomart ();
        s=i;
        s.tampil();
        TokoAgung ta= new TokoAgung();
        s=ta;
        s.tampil();
    }
    

}
