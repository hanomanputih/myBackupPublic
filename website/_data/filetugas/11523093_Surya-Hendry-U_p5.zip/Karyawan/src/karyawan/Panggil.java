/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class Panggil {
    public static void main(String[] args) {
        // TODO code application logic here
        Karyawan kar = new Karyawan();
        
        kar.setNip("123456");
        kar.setNama("Surya");
        kar.setGaji(-2000000);
        
        System.out.println("NIP :"+kar.getNip());
        System.out.println("Nama :"+kar.getNama());
        System.out.println("Gaji /tahun:"+kar.getGaji());
       
    }
    
}
