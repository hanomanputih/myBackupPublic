/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttestpewarisan;

/**
 *
 * @author praktikan
 */
public class Karyawan {
    protected double gajipokok;
    
    public void gajiPokok(){
        gajipokok   = 3000000;
    }
    
}
