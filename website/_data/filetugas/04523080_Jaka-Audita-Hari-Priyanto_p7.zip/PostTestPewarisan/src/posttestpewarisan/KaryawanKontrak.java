/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttestpewarisan;

/**
 *
 * @author praktikan
 */
public class KaryawanKontrak extends Karyawan {
    protected double bonus;
    protected double gaji;
    
    public double lihatGaji(){
        gajiPokok();
        bonus = 0.05 * gajipokok; 
        gaji = gajipokok + bonus;
        return gaji;
    }
    
    public void print(){
        System.out.println("Gaji Karyawan Kontrak "+gaji);
    }
}
