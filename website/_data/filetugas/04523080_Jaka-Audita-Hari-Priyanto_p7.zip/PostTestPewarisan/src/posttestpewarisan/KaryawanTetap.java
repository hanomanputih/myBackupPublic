/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttestpewarisan;

/**
 *
 * @author praktikan
 */
public class KaryawanTetap extends Karyawan {
    protected double gaji;
    protected double tunjangan;
    protected double bonus;
    
    
    public double lihatGaji(){
        super.gajiPokok();
        tunjangan   = 0.2 * gajipokok;
        bonus       = 0.05 * gajipokok;
        gaji        = tunjangan + gajipokok + bonus;
        return gaji;
    }
    
    public void print(){
        System.out.println("Gaji Karyawan Tetap "+gaji);
        
    }
}
