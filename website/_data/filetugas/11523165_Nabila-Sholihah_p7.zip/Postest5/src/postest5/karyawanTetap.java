/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest5;

/**
 *
 * @author Praktikan
 */
public class karyawanTetap extends Karyawan implements Human {

    @Override
    

   
    public void view() {
        super.view();
    }
    @Override
    public void gaji() {
        
        gaji=tunjangan + gajiP + bonus;
        System.out.println("gaji : "+gaji);
        System.out.println("=================================");
    }

    @Override
    public void eat() {
        
    }

    @Override
    public void drink() {
        
    }
    
}
