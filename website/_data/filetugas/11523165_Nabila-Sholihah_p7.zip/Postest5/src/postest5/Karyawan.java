/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest5;

/**
 *
 * @author Praktikan
 */
public abstract class Karyawan {
    protected int gajiP=3000000;
    protected double tunjangan=0.2*gajiP;
    protected double bonus=gajiP+150000;
    protected double gaji;
    
    public void view (){
        System.out.println("gaji pokok : "+gajiP);
        System.out.println("tunjangan : "+tunjangan);
        System.out.println("bonus :"+bonus);
     
    }
    
    public abstract void gaji();
    

}
