/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest5;

/**
 *
 * @author Praktikan
 */
public class Main {
    public static void main(String[] args) {
        karyawanTetap kt = new karyawanTetap();
        kt.view();
        kt.gaji();
        kt.eat();
        kt.drink();
        
        karyawanKontrak kk = new karyawanKontrak();
        kk.view();
        kk.gaji();
        kk.eat();
        kk.drink();
        
        
    }
  
}
