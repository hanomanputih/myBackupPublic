/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class ram {
    String jenis;
    public ram(String jenis){
        this.jenis=jenis;
    }
    
}
