/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class Komputer {

    /**
     * @param args the command line arguments
     */
    String nama;
    ram r;
    processor p;
    
    public Komputer(String nama){
        this.nama=nama;
        r = new ram("Zack");
        p = new processor("core i3");
        System.out.println("Nama Komputer " + nama);
        System.out.println("Jenis Processor " + p.jenis);
        System.out.println("Jenis RAM " + r.jenis);
    }
    
        public static void main(String[] args) {
        // TODO code application logic here
            Komputer kom = new Komputer("Apple");
    }
}
