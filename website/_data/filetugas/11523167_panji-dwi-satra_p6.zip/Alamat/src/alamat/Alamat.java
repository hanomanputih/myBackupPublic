/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package alamat;

/**
 *
 * @author Praktikan
 */
public class Alamat {

   private String jalan;
   private String kodepos;

    public String getJalan() {
        return jalan;
    }

    public void setJalan(String jalan) {
        this.jalan = jalan;
    }

    public String getKodepos() {
        return kodepos;
    }

    public void setKodepos(String kodepos) {
        this.kodepos = kodepos;
    }
    

    
}