package alamat;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Praktikan
 */
public class zzz {
    public static void main(String[] args) {
        Alamat jakal = new Alamat ();
        jakal.setJalan ("Jalan Kaliurang km 14");
        jakal.setKodepos("5188");
        
        Manusia budi = new Manusia();
        Manusia anto = new Manusia();
        
        anto.setAlamat(jakal);
        
        System.out.println("Nama :"+anto.getNama()+
                "alamat : "+ anto.getAlamat().getKodepos());
       
    }
}
