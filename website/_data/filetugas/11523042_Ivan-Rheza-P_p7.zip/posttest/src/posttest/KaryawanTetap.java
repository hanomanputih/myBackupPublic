/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author Praktikan
 */
public class KaryawanTetap extends Karyawan {
    
    @Override
    public void view() {
        System.out.println("Gaji karyawan tetap : "+gaji);
    }
    
    @Override
    public void gaji() {
        gaji=tunjangan+gajipokok+bonus;
       // System.out.println("");
    }
    
}
