/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author Praktikan
 */
public abstract class Karyawan {
    protected int gajipokok=3000000;
    protected int bonus=10000;
    protected double tunjangan=gajipokok*0.2;
    protected double gaji;
    
    public abstract void gaji();
    public abstract void view();
}
