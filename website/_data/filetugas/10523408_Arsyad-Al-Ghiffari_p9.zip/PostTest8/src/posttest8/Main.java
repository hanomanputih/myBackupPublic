package posttest8;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class Main {

    public static void main(String[] args) {
        List Nim = new ArrayList();

        Nim.add(10523408);
        Nim.add("Aar Al Ghiffari");
        Nim.add("Lamongan");

        System.out.println(Nim);
        System.out.println("Data Index ke 2 : " + Nim.get(2));
        System.out.println("\n");

// -----------------------------------------------------------------------------

        Map<Integer, String> uye = new HashMap<Integer, String>();

        uye.put(10523408, "Aar Al Ghiffie");
        uye.put(10523389, "Rachmat Suneo");

        for (Map.Entry<Integer, String> ab : uye.entrySet()) {
            System.out.println("Nim     : " + ab.getKey());
            System.out.println("Nama    : " + ab.getValue()+"\n");
        }


// -----------------------------------------------------------------------------

        Iterator it = Nim.iterator();
        System.out.println("\n");
        while (it.hasNext()) {
            System.out.println(it.next());
        }

    }
}
