/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class Komputer {
String merkKomputer;
String jenisKomputer;
String warna;
Prosesor P;
Ram R;

public Komputer(String m,String jK,String W,String p, String r ){
    this.merkKomputer = m;
    this.jenisKomputer = jK;
    this.warna = W;
    P = new Prosesor(p);
    R = new Ram(r);
    
}
    
public void Display (){
    System.out.println("Merk Komputer  : "+merkKomputer);
    System.out.println("Jenis Komputer : "+jenisKomputer);
    System.out.println("Warna Komputer : "+warna);

}

    public static void main(String[] args) {
        Komputer k = new Komputer("ASUS","Laptop","Hitam","Intel Core i-7","4 GB");
        k.Display();
        System.out.println("Jenis Prosesor : "+k.P.getJenisProsesor());
        System.out.println("Ukuran Ram     : "+k.R.getUkuranRam());
        
    }
}
