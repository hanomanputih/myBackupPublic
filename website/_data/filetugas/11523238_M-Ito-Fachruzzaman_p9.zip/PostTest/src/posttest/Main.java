package posttest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class Main {
    
    public static void isiData(List<String> list, String isi){
        list.add(isi);
    }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        List<String> list = new ArrayList<String>();
        HashMap map = new HashMap();
        
        System.out.print("Masukkan NIM: ");
        String NIM = sc.next();
        isiData(list, NIM);
        System.out.print("Masukkan nama: ");
        String nama = sc.next();
        isiData(list, nama);
        
        System.out.println("");
        System.out.print("Masukkan NIM: ");
        String NIM2 = sc.next();
        map.put("NIM", NIM2);
        System.out.print("Masukkan nama: ");
        String nama2 = sc.next();
        map.put("Nama ", nama2);
        
        System.out.println("");
        for(Iterator<String> iterator = list.iterator(); iterator.hasNext();){
            String isi = iterator.next();
            System.out.println(isi);
        }
        
        System.out.println("");
        System.out.println(list.get(1));
        System.out.println(map.get("Nama "));
    }
}
