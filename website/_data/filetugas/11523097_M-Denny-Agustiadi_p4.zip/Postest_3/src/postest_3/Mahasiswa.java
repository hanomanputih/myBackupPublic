/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest_3;
import java.util.Scanner;
/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
    
    String nama, nim, fakultas, jurusan,angkatan;
   
    void cetak() {
        Scanner baca = new Scanner(System.in);
        System.out.println("siapa nama anda ?");
        nama = baca.next();
        System.out.println("berapa nim anda ?");
        nim = baca.next();
        System.out.println("apa fakultas anda ?");
        fakultas = baca.next();
        System.out.println("apa jurusan anda ?");
        jurusan = baca.next();
        System.out.println("anda angkatan berapa ?");
        angkatan = baca.next();
       
        System.out.println("nama anda : " +nama);
        System.out.println("nim anda : " +nim);
        System.out.println("fakultas anda : " +fakultas);
        System.out.println("jurusan anda : " +jurusan);
        System.out.println("angkatan anda : " +angkatan);
        
    }
    
    public static void main(String[] args) {
        Mahasiswa mhs = new Mahasiswa();
        mhs.cetak();
    }
   
        
    }
   
