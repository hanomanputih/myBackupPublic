/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes6;

/**
 *
 * @author Praktikan
 */
public class KaryawanKontrak extends Karyawan {

    @Override
    public void gaji() {
        gaji = gajiP + bonus ;
        
        System.out.println(" Gaji Karyawan Kontrak Adalah -> "+gaji);
    }
    
}
