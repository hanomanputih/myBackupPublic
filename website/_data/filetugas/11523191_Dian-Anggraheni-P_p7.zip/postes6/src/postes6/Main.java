/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes6;

/**
 *
 * @author Praktikan
 */
public class Main {

    public static void main(String[] args) {
        KaryawanKontrak kk = new KaryawanKontrak();
        kk.gaji();
        KaryawanTetap kt = new KaryawanTetap();
        kt.gaji();
        
        
    }
}
