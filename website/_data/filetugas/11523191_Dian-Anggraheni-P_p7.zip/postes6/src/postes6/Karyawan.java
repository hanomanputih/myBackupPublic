/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes6;

/**
 *
 * @author Praktikan
 */
public abstract class Karyawan {
     int gajiP = 3000000;
     double tunjangan = 0.2 * gajiP ;
     double bonus = 0.5 * (tunjangan+gajiP);
     double gaji ;
    
    public void view(){
    System.out.println(" jumlah gaji -> "+gaji);
    System.out.println(" banyak tunjangan -> "+tunjangan);
    System.out.println(" banyak bonus -> "+bonus);
    
}
    public abstract void gaji();
    
    
}
