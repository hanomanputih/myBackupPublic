/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Post;

/**
 *
 * @author Praktikan
 */
public class Ramnya {
    String nameRam;
    
    
    public Ramnya (String name) {
        this.nameRam = name;
        
        if(nameRam.equals(name));
            
         
}
}