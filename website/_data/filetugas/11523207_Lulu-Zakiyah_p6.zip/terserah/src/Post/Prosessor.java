/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Post;

/**
 *
 * @author Praktikan
 */
public class Prosessor {
 String merkProsessor;
 
 public Prosessor(String merk) {
     this.merkProsessor=merk;
     if(merk.equals(merkProsessor));
         
         
     }
    

}
