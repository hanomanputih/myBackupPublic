/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Post;

/**
 *
 * @author Praktikan
 */
public class Komputer {
 String namaKomputer;
 private Prosessor pro; 
 private Ramnya Ram;
 public Komputer(String nama){
    this.namaKomputer = nama;
    if(nama.equals("Vaio")){
    pro=new Prosessor ("Intel");
    Ram=new Ramnya ("the ram");
    }
 }
    public void menampilkan(){
         System.out.println("nama Komputer  :"+namaKomputer);
         System.out.println("merk Prosessor :"+pro.merkProsessor);
         System.out.println("jenis Ramnya   :"+Ram.nameRam);
    }
    
      public static void main(String[] args) {
        Komputer komputer1=new Komputer("Vaio");
        komputer1.menampilkan();
        
    }
   
         
         
        
}

