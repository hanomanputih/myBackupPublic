/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

/**
 *
 * @author Praktikan
 */
public class Ram {
String jenisRam;
public Ram (String jenisRam){
this.jenisRam = jenisRam;
}
public void nampilRam() {
System.out.println("jenis ram :"+jenisRam);
}}
    

