package yesy;

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.HashMap;

public class Yesy
{
    
    public static void main(String[] args)
    {
    
        Map<String, String> mhs = new HashMap<String, String>();
        
        int n;
        
        mhs.put("heru", "sd");
        mhs.put("heruu", "sd");
        mhs.put("heruuu", "sd");
        
        
        for(Map.Entry<String, String> e : mhs.entrySet())
        {
            System.out.println(e.getKey() + " - "+ e.getValue());
        }
    
        
        System.out.println(mhs.get("heru"));
    
    }

}
