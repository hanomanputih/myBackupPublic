/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg3;

import java.util.Scanner;
public class Mahasiswa {
    String nama = "Deviana Prabawati";
    String nim = "11523277";
    String fakultas;
    String jurusan;
    String angkatan;
    
    void cetak(){
        Scanner baca = new Scanner(System.in);
        
        System.out.println("fakultas anda adalah ");
        fakultas = baca.next();
        System.out.println("jurusan anda adalah ");
        jurusan = baca.next();
        System.out.println("angkatan anda adalah ");
        angkatan = baca.next();
        
        System.out.println("fakultas " +fakultas);
        System.out.println("jurusan "+jurusan);
        System.out.println("angkatan "+angkatan);
        System.out.println("nama "+nama);
        System.out.println("nim "+nim);

    }      
    public static void main(String[] args) {
        Mahasiswa mhs = new Mahasiswa();
       
        mhs.cetak();
   
        
    }
    
    
}
