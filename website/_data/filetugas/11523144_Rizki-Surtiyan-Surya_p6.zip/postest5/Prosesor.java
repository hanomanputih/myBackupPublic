/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest5;

/**
 *
 * @author Praktikan
 */
public class Prosesor {
    public String namaProsesor;
  
    public Prosesor(String nama){
        namaProsesor=nama;
        
   
  
   // public Prosesor (String prosesor){
       // namaProsesor=prosesor;
    }
}

