/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest5;

/**
 *
 * @author Praktikan
 */
public class Ram {
 public String merk="usida";
  public String  ukuran="4GB";
  
  
 // public Ram (int ukrn){
     // ukuran=ukrn ;
  }
  

