/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest5;

/**
 *
 * @author Praktikan
 */
public class Komputer 
{
    Prosesor p;
    Ram R;
   
    
    public String nama;
    
    public Komputer(String kptr){
        nama=kptr;
        p=new Prosesor("isida");
        R=new Ram();
        
    }
    public static void main(String[] args) {
        
    
    
   Komputer K=new Komputer ("kptr");
    
        System.out.println("jadi prosesor Komputer ini :"+K.p.namaProsesor);
        
        
        System.out.println("jadi Ram nya "+K.R.merk+" "+"ukuran"+""+K.R.ukuran);
}
}


   

