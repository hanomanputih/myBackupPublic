/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
    
    
    String nama = "Muhammad Ridwan Dwiangga";
    String nim = "11523256";
    String fakultas = "FTI";
    String jurusan = "Teknik Informatika";
    String angkatan = "2011";
    void cetak()
    {

        System.out.println("Nama saya adalah = "+nama);
        System.out.println("NIM saya adalah = "+nim);
        System.out.println("Fakultas saya adalah = "+fakultas);
        System.out.println("Jurusan saya adalah = "+jurusan);
        System.out.println("Angkatan saya adalah = "+angkatan);
    }
    
    public static void main(String[] args)
    {
        Mahasiswa m = new Mahasiswa();
        m.cetak();
    }
}
