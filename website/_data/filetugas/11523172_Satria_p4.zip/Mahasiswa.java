/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package t;

/**
 *
 * @author PRAKTIKAN
 */
public class Mahasiswa {
    String nama;
    String nim;
    String fakultas;
    String jurusan;
    String angkatan;
    
    void cetak(){
    System.out.println("Nama = " + nama);
    System.out.println("NIM = " + nim);
    System.out.println("Fakultas = " + fakultas);
    System.out.println("Jurusan = " + jurusan);
    System.out.println("Angkatan = " + angkatan);
    }
    public static void main(String[] args) {
        Mahasiswa mhs1 = new Mahasiswa();
        mhs1.nama="Satria";
        mhs1.nim="11523172";
        mhs1.fakultas="Industri";
        mhs1.jurusan="Informatika";
        mhs1.angkatan="2011";
        mhs1.cetak();
    }
}
