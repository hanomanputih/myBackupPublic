/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author PRAKTIKAN
 */
public class PostTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        List AS = new ArrayList();
        
        System.out.print("NIM  : ");
        AS.add(sc.nextInt());
        System.out.print("NAMA : ");
        AS.add(sc.next());
        
        System.out.println(AS);
        System.out.println("Index ke-2 : "+AS.get(1));
        System.out.println("-------------------");
        Iterator it = AS.iterator();
        
        while(it.hasNext()){
            System.out.println(it.next());
        }
        
        System.out.println("-------------------");
        Map<Integer,String> data2 = new HashMap<Integer,String>();
        data2.put(sc.nextInt(), sc.next());
        
        for(Map.Entry<Integer,String> tampil : data2.entrySet()){
            System.out.println(tampil.getKey()+". "+tampil.getValue());
            System.out.println(tampil.getValue());
        }
    }
}
