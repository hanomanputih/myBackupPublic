/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package posttest;

/**
 *
 * @author praktikan
 */
public abstract class Karyawan {
    public int gajip = 3000000;
    public int tunjangan = gajip*20/100;
    public int bonus = 1000000;
     public int gaji;


    public abstract  void gaji();

}
