/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package posttest;

/**
 *
 * @author praktikan
 */
public class Karyawan_tetap extends Karyawan implements Manusia{
    
    public void gaji(){
        gaji=tunjangan+ gajip+ bonus;
        System.out.println("gaji Karyawan tetap "+gaji);
    }

     public void makan(){
         System.out.println("Karyawan tetap makan");

}
}
