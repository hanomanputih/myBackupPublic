/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package posttest;

/**
 *
 * @author praktikan
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Karyawan_tetap KT = new Karyawan_tetap();
        KT.gaji();
        KT.makan();

        Karyawan_kontrak KK = new Karyawan_kontrak();
        KK.gaji();
        KK.makan();
        // TODO code application logic here
    }

}
