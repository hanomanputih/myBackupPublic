/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttestpertemuan5;

/**
 *
 * @author Praktikan
 */
public class PostTestPertemuan5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Processor pr = new Processor("BLACK DARK","EXPERT","ex-9810","3.8Ghz");
        RAM r = new RAM("Extreme Dark","DDR-3",1024,14);
        Computer comp = new Computer("HIGH TOWER",pr,r);
        
        comp.tampilkan("HIGH TOWER", pr, r);
    }
}
