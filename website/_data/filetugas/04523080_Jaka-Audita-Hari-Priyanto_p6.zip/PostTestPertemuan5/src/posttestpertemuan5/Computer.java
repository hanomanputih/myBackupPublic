/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttestpertemuan5;

/**
 *
 * @author Praktikan
 */
public class Computer {
    String jenisCPU;
    Processor proc;
    RAM ram;
    
    public Computer(String jenisCPU,Processor proc,RAM ram){
        this.jenisCPU = jenisCPU;
        this.proc = proc;
        this.ram = ram;
    } 
    
    public void tampilkan(String jenisCPU,Processor proc,RAM ram){
        System.out.println("jenis CPU = " +jenisCPU);
        System.out.println("Processor = " + proc.brand + ", " + proc.projectName + ", " + proc.type + ", " + proc.voltage);
        System.out.println("RAM = " +ram.brand + ", " + ram.capacity + "Mb, CL" + ram.latency);
    }
}
