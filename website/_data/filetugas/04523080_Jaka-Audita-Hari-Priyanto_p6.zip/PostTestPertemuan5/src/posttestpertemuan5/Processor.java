/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttestpertemuan5;

/**
 *
 * @author Praktikan
 */
public class Processor {
    String projectName, brand, type, voltage;
        
    public Processor(String projectName, String brand, String type, String voltage){
        this.projectName = projectName;
        this.brand = brand;
        this.type = type;
        this.voltage = voltage;
    }
    
    public void ProcessorView(){
        System.out.println("PROCESSOR");
        System.out.println("Project Name    = " +projectName);
        System.out.println("Brand           = " +brand);
        System.out.println("Type            = " +type);
        System.out.println("Voltage         = " +voltage);
    }
}
