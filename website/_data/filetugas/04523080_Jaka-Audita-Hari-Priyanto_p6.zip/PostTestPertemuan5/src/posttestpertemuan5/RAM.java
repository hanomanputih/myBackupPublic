/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttestpertemuan5;

/**
 *
 * @author Praktikan
 */
public class RAM {
    String brand;
    String type;
    int capacity;
    float latency;
    
    public RAM(String brand,String type,int capacity,float latency){
        this.brand = brand;
        this.type = type;
        this.capacity = capacity;
        this.latency = latency;
    }
}
