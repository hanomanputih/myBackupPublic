
package postest11523192;

import java.util.Scanner;

public class Mahasiswa {
    String nama, nim, fakultas, jurusan, angkatan;
    int jumlah;

void cetak (){


    Scanner masuk = new Scanner (System.in);
    System.out.println("Masukkan Nama : ");
    nama = masuk.next();
    System.out.println("Masukkan NIM : ");
    nim = masuk.next();
    System.out.println("Fakultas Anda : ");
    fakultas = masuk.next();
    System.out.println("Jurusan Anda: ");
    jurusan = masuk.next();
    System.out.println("Masukkan Angkatan : ");
    angkatan = masuk.next();
    System.out.println("Nama Anda: "+ nama);
    System.out.println("Nim Anda: "+ nim);
    System.out.println("Fakultas Anda: "+ fakultas);
    System.out.println("Jurusan Anda :"+ jurusan);
    System.out.println("Angkatan: "+ angkatan);
}

void hitungKarakter() {
    jumlah = nama.length();
    System.out.println("Panjang karakter nama: " +jumlah);
    jumlah = nim.length();
    System.out.println("Panjang karakter nim: " +jumlah);
}

    public static void main(String[] args) {
    Mahasiswa mhs = new Mahasiswa ();
    mhs.cetak();
    mhs.hitungKarakter();
    }

}
