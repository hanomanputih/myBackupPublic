/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg11523229_pewarisan;

/**
 *
 * @author Praktikan
 */
public class KaryawanTetap extends Karyawan {
    private int tunjangan=gajiPokok*20/100;
    
    @Override
   public void gaji(){
       int gaji=tunjangan+gajiPokok+bonus;
       System.out.println("Gaji(karyawan tetap): "+ gaji);
   }
    
    
}
