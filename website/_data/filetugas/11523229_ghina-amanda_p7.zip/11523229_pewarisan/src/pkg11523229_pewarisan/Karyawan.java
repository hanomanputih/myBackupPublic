/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg11523229_pewarisan;

/**
 *
 * @author Praktikan
 */
public abstract class Karyawan {
    protected String nama;
    protected int gajiPokok=3500000;
    protected int bonus=500000;
    
    public void view() {
        System.out.println("nama karyawan : "+nama);
    }

    public abstract void gaji();
    }
    

