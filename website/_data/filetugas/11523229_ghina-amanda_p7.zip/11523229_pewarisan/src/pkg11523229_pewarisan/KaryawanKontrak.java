/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg11523229_pewarisan;

/**
 *
 * @author Praktikan
 */
public class KaryawanKontrak extends Karyawan {
    @Override
    public void gaji() {
        int gaji=gajiPokok+bonus;
        System.out.println("Gaji(karyawan kontrak): "+gaji);
    }
}
    
    
