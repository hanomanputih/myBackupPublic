/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg11523229_pewarisan;

/**
 *
 * @author Praktikan
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       KaryawanTetap kt = new KaryawanTetap();
       kt.nama="ghina";
       kt.view();
       kt.gaji();
       
       KaryawanKontrak kk = new KaryawanKontrak();
       kk.nama="amanda";
       kk.view();
       kk.gaji();
       
        
    }
}
