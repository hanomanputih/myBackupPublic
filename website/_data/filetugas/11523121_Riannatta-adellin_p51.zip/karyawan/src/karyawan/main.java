/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class main {
    public static void main(String[] args) {
        Karyawan b = new Karyawan ();
        
        b.setNip("11523121");
        System.out.println("NIP anda adalah = "+b.getNip());
        
        b.setNama("Riannatta adellin");
        System.out.println("nama anda adalah= "+b.getNama());
        
        b.setGaji(2000000);
        System.out.println("gaji anda adalah = "+b.getGaji());
        
    }
 
}
