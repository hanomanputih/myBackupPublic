/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest3;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {

String nim, nama, fakultas, jurusan, angkatan;

void cetak() { 
    
Mahasiswa m = new Mahasiswa ();
Scanner cetak = new Scanner (System.in);
System.out.println("Masukkan nama anda..");
nama = cetak.next();
System.out.println("Masukkan nim anda..");
nim = cetak.next();
System.out.println("Masukkan nama fakultas..");
fakultas = cetak.next();
System.out.println("Masukkan nama jurusan..");
jurusan = cetak.next();
System.out.println("Angkatan berapakah anda?");
angkatan = cetak.next();
}
public static void main (String []args) {
 Mahasiswa m = new Mahasiswa();
 m.cetak();
    System.out.println(m.nama);
    System.out.println(m.nim);
    System.out.println(m.fakultas);
    System.out.println(m.jurusan);
    System.out.println(m.angkatan);
}
}