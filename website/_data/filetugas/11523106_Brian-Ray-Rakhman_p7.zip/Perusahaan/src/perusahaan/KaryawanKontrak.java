/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perusahaan;

/**
 *
 * @author Praktikan
 */
public class KaryawanKontrak extends Karyawan {
    private double gaji;
    private int bonus;
 

    @Override
    public void hitungGaji() {
        gaji=GajiPokok+bonus;
        System.out.println("Gaji Karyawan Kontrak : "+gaji);
    }
    
}
