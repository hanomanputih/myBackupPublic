/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perusahaan;

/**
 *
 * @author Praktikan
 */
public abstract class Karyawan {
    protected String Nama;
    protected int GajiPokok=3000000;
    protected float Bonus=100000;
    
    public abstract void hitungGaji();
    
     public void view(){
        System.out.println("Nama        : "+Nama);
        System.out.println("GajiPokok   : "+GajiPokok);
        System.out.println("Bonus       : "+Bonus);
    }
    
}
