/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perusahaan;

/**
 *
 * @author Praktikan
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    KaryawanTetap kt = new KaryawanTetap();
    KaryawanKontrak kk = new KaryawanKontrak(); 
    
        System.out.println("");
        kt.hitungGaji();
        System.out.println("");
        kk.hitungGaji();
    }
    
}
