/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perusahaan;

/**
 *
 * @author Praktikan
 */
public class KaryawanTetap extends Karyawan {
    private double gaji;
    private double tunjangan;
    
    @Override
    public void view(){
        super.view();
    }

    @Override
    public void hitungGaji() {
        tunjangan=GajiPokok*0.2;
        gaji=GajiPokok+tunjangan+Bonus;
        System.out.println("Gaji Karyawan Tetap : "+gaji);
    }

   
}
