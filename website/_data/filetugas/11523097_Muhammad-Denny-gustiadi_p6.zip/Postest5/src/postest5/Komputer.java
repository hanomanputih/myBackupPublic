/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest5;

/**
 *
 * @author PRAKTIKAN
 */
public class Komputer {
    String Kom1;
    Prosesor p;
    Ram r;
    
    public Komputer (String kom){
        Kom1 = kom;
        if(Kom1.equals("1")){
            p = new Prosesor("core i7");
            r = new Ram("1GB");
        } 
            
        }
    public static void main (String[] args){
    Komputer kom = new Komputer("1");
    System.out.println(kom.p.Pro);
    System.out.println(kom.r.nRam);
    }
}
    
