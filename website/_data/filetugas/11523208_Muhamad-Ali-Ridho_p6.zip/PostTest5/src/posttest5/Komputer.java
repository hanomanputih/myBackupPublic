/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package posttest5;

/**
 *
 * @author praktikan
 */
public class Komputer {

    String namaKompi;
    Processor P;
    Ram r;
public Komputer(String jeneng, String R, String tipe){
    this.namaKompi = jeneng;
    this.r = new Ram(R);
    
    this.P = new Processor(tipe);

}
public void tampil(){
    System.out.println("Nama Komputer  : "+namaKompi);
    System.out.println("Dengan tipe RAM     : "+r.jenisRam);
    System.out.println("Dan Proceesor   : "+P.jenisProcessor);

}
    public static void main(String[] args) {
        Komputer kompi = new Komputer("Komputer Ku", "4GB DDR3","Intel Core i7");
        kompi.tampil();

    }
}
