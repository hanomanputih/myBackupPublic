/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Praktikan
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        List<String> buku = new ArrayList<String>();
        
        buku.add("Harry Potter");
        buku.add("Hari Jumat");
        buku.add("Mastering Java");
        
        
        for(String i : buku){
            System.out.println(i);
        }
    }
}
