/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan8;
import java.util.Map;
import java.util.HashMap;
/**
 *
 * @author Praktikan
 */
public class BelajarMap {
    
    public static void main(String[] args) {
        Map<Integer,String> mhs = new HashMap<Integer,String>();
        
       mhs.put(11523070,"Maulia");
       mhs.put(11523071, "Fajri");
       mhs.put(11523072, "Andriani");
       
        System.out.println(mhs);
        
        System.out.println(mhs.get(11523070));
        
        System.out.println("=================================================");
        for(Map.Entry<Integer,String> e : mhs.entrySet()){
            System.out.println(e.getKey()+" , "+e.getValue());
    }
}
}
