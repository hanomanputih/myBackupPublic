/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan8;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.HashMap;

/**
 *
 * @author Praktikan
 */
public class PostTest {
    private static void loadData(List<String>list){
        list.add("Maulia");
        list.add("Fajri");
        list.add("Andriani");
    }
    private static void tampilkanList(List<String>list){
        for (int i = 0; i<list.size(); i++){
            System.out.print(list.get(i)+" ");
        }
    }
    
    public static void main(String[] args) {
        
        List<String> list = new ArrayList<String>();
        loadData(list);
        System.out.print("Nama : ");
        tampilkanList(list);
        
        
        Map<String,String> almt = new HashMap<String,String>();
        almt.put("Maulia","jakal km.11");
        almt.put("Fajri", "jakal km.13");
        almt.put("Andriani", "jakal km.15");
        System.out.println(almt);
        System.out.println("================================================================");
        for(Map.Entry<String,String> e : almt.entrySet()){
            System.out.println(e.getKey()+" , "+e.getValue());
        }   
        System.out.println("================================================================");
        System.out.println(almt.get("Andriani"));
    }
}
