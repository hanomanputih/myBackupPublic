/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan8;
import java.util.List;
import java.util.ArrayList;

/**
 *
 * @author Praktikan
 */
public class Pertemuan8 {
    public static void main(String[] args) {
        
        List nama = new ArrayList();
        
        nama.add("Maulia");
        nama.add("Fajri");
        nama.add("Andriani");
        
        //System.out.println("nama");
        
        for(Object o : nama){
            System.out.println(o);
        }
        
        Iterator it = nama.iterator();
        while (it.)
        for(int i = 0;i<nama.size();i++){
            System.out.println(nama.get(i));
        }

    }
}
