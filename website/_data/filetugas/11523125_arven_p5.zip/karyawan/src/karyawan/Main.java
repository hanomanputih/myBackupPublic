/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package karyawan;

/**
 *
 * @author Praktikan
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        karyawan K=new karyawan();
        K.setNip("11523125");
        System.out.println(K.getNip());
        K.setGaji(2000000*12);
        System.out.println(K.getGaji());
        K.setNama("Arven");
        System.out.println(K.getNama());
    }

}
