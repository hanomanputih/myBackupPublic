/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

/**
 *
 * @author PRAKTIKAN
 */
public class Karyawan {
    private String nip;
    private String nama;
    private int gaji;
         
    public void setter(){
          this.nama=nama;
          this.nip=nip;
          this.gaji=gaji;
    
    nama="Surya Mudika";
    nip="10523188";
    gaji=10000000;
   
    }
   
    public String getter(){
        return nama;
    }
    public String getNip(){
        return nip;
    }
    public int getGaji(){
        return gaji;
    }
    
}