/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

/**
 *
 * @author PRAKTIKAN
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Karyawan m=new Karyawan();
        m.setter();
        System.out.println("nama "+ m.getter());
        System.out.println("nip "+ m.getNip());
        System.out.println("gaji perbulan "+ m.getGaji());
        System.out.println("gaji setahun "+ m.getGaji() * 12);
    }
   
}
