/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest5;

/**
 *
 * @author Praktikan
 */
public class Komputer {
    String kom1;
   Prosesor p;
   Ram r;
    
    public Komputer (String kom){
        kom1 = kom;
        if (kom1.equals("1")){
         p =new Prosesor("core 7");
         r =new Ram("64GB");
        } 
    }
    public static void main (String[] agrs){
        Komputer kom = new Komputer("1");
        System.out.println(kom.p.pro);
        System.out.println(kom.r.nRam);
    }
    
}

