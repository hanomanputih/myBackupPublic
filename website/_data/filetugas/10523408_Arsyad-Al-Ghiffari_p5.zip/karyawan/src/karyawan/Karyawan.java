/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Karyawan {
    Scanner sc = new Scanner(System.in);

    private String NIP, nama;
    private int gaji;

    void setNIP() {
        System.out.println("Masukkan NIP Anda : ");
         this.NIP=sc.nextLine();
    }
    
    String getNIP(){
        return NIP;
    }
    
    void setnama() {
        System.out.println("Masukkan Nama Anda : ");
         this.nama=sc.nextLine();
    }
    
    String getnama(){
        return nama;
    }
    
    void setgaji() {
        System.out.println("Masukkan Gaji Anda : ");
         this.gaji=sc.nextInt();
    }
    
    int getgaji(){
        return gaji;
    }

}
