/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class main {

    public static void main(String[] args) {

        Karyawan kr = new Karyawan();
        kr.setNIP();
        kr.setnama();
        kr.setgaji();

        System.out.println(" ");
        System.out.println("------------------------------");
        System.out.println("NIP = " + kr.getNIP());
        System.out.println("Nama = " + kr.getnama());
        System.out.println("Gaji Anda = " + kr.getgaji());
        System.out.println("------------------------------");
    }
}
