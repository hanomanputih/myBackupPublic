/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postestyati;

/**
 *
 * @author PRAKTIKAN
 */
public class KaryawanTetap extends Karyawan{
    int tunjangan = GajiPokok* 20/100;
    
    @Override
    public void Gaji() {
        Gaji = GajiPokok + tunjangan + bonus;
        System.out.println("Gaji KaryawanTetap :"+Gaji);
    }
    
}
