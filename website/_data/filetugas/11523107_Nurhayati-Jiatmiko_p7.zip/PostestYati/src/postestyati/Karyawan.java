/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postestyati;

/**
 *
 * @author PRAKTIKAN
 */
public abstract class Karyawan {
    protected int GajiPokok = 500000;
    protected int Gaji = 300000;
    protected int bonus = 200000;
    
    public abstract void Gaji();
    
    
            
} 


