/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postestyati;

/**
 *
 * @author PRAKTIKAN
 */
public class PostestYati {
   

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // KaryawanTODO code application logic here
        
        KaryawanTetap kt = new KaryawanTetap();
        KaryawanKontrak kk = new KaryawanKontrak();
        
        System.out.println("");
        kt.Gaji();
        
        System.out.println("");
        kk.Gaji();
    }
}
