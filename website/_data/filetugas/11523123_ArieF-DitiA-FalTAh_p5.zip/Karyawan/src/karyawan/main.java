/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class main {
    public static void main (String [] args){
        Karyawan kry = new Karyawan();
kry.setNip("c1nt4mu-74k-53murn1-b3n51nku");
kry.setNama("Sabarlahudin");
kry.setGaji(1000000);

        System.out.println("nip kamu itu : "+kry.getNip());
        System.out.println("nama kamu itu : "+kry.getNama());
        System.out.println("gaji kamu itu : "+kry.getGaji());       
    }
}
