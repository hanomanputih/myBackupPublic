/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class Karyawan {
private String nip;
private String nama;
private int gaji;

    public void setNip(String _nip){
        this.nip = _nip;
    }
    
    public void setNama(String _nama){
        this.nama = _nama;
    }
    
    public void setGaji(int _gaji){
        this.gaji = _gaji*12;
    }

    public String getNip(){
        return nip;
    }
       public String getNama(){
        return nama;
    }
       public int getGaji(){
        return gaji;
    }
   }

