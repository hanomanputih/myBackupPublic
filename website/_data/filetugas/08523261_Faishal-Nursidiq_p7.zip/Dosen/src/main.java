/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Praktikan
 */
public class main {
    
    public static void main(String[] args){
       Karyawan ky = new Karyawan();
       Tetap kt = new Tetap();
       Kontrak kk = new Kontrak();
       ky.nama="x";
       ky.nip="9";
       ky.gajipokok=3000000;
       ky.bonus=600000;
       
       ky.nama="x";
       ky.nip="9";
       ky.gajipokok=3000000;
       ky.bonus=600000;
       
       kk.nama="x";
       kk.nip="9";
       kk.gajipokok=3000000;
       kk.bonus=600000;
       ky.view();
       
       System.out.println("");
       kt.view();
       
       System.out.println("");
       kk.view();
    }
    
}
