/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Praktikan
 */
public class Kontrak extends Karyawan {
    private int gaji;
    
    @Override
    public void view(){
        super.view();
        System.out.println("Gaji : "+(gajipokok+bonus));
    }
}
