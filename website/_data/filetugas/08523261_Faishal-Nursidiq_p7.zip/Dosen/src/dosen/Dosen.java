/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dosen;

/**
 *
 * @author Praktikan
 */
public class Dosen {

    


   protected String nama="budi";
    protected String jurusan="informatika";

    public void view(){
       System.out.println("Nama Dosen   : "+nama);
       System.out.println("Jurusan      : "+jurusan);
    }
    
  public void bertugas(){
      System.out.println("Mengajar");
  } 

    public String getJurusan() {
        return jurusan;
    }

    public void setJurusan(String jurusan) {
        this.jurusan = jurusan;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }
    
}