/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dosen;

/**
 *
 * @author Praktikan
 */
public class Kalab extends Dosen implements MakhlukHidup {
    private String laboratorium;
    
    @Override
    public void view(){
        super.view();
        System.out.println("Laboratorium : "+laboratorium);
    }

    public String getLaboratorium() {
        return laboratorium;
    }

    public void setLaboratorium(String laboratorium) {
        this.laboratorium = laboratorium;
    }

    @Override
    public void makan() {
        System.out.println("Kalab Makan");
    }

    @Override
    public void minum() {
        System.out.println("Kalab Minum");
    }
    
}
