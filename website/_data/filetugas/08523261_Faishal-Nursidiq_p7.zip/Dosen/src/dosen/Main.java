/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dosen;

/**
 *
 * @author Praktikan
 */
public class Main {
    
    
 public static void main(String[] args) {
       Dosen ds = new Dosen();
       Dekan dk = new Dekan();
       Kalab kl = new Kalab();
       ds.view();
       System.out.println("");
       dk.setFakultas("FTI");
       dk.view();
       dk.makan();
       dk.minum();
       //dk.getFakultas();
       System.out.println("");
       kl.setLaboratorium("KSC");
       kl.view();
       System.out.println("");
       
    }
}
