/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dosen;

/**
 *
 * @author Praktikan
 */
public class Dekan extends Dosen implements MakhlukHidup {
    private String fakultas;
    
    @Override
    public void view(){
        super.view();
        System.out.println("Fakultas     : "+fakultas);
    }

    public String getFakultas() {
        return fakultas;
    }

    public void setFakultas(String fakultas) {
        this.fakultas = fakultas;
    }

    @Override
    public void makan() {
        System.out.println("Dekan Makan");
    }

    @Override
    public void minum() {
        System.out.println("Dekan Minum");
    }
}
