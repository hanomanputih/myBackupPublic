/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Praktikan
 */
public class Tetap extends Karyawan {
    private double tunjangan=0.2*gajipokok;
    private int gaji;
    
    @Override
    public void view(){
        super.view();
        System.out.println("Gaji : "+(gaji+tunjangan+bonus));
    }
    
}
