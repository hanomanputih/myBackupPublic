/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {

   String nama= "Rahardi";
   String nim="11523157";
   String fakultas="Teknik Industri";
   String jurusan="Teknik Informatika";
   String angkatan="2011";
   
   void cetak() {
       System.out.println(" ");
       System.out.println("Data Mahasiswa");
       System.out.println("nama : " + nama);
       System.out.println("nim : " + nim);
       System.out.println("fakultas : " + fakultas);
       System.out.println("jurusan : " + jurusan);
       System.out.println("angkatan : " + angkatan);
   }
   public static void main(String[] args) {
       Mahasiswa mhs1 = new Mahasiswa();
       Scanner baca = new Scanner(System.in);
       System.out.print("Nama Anda     : ");
        mhs1.nama = baca.nextLine();
        System.out.print("NIM Anda      : ");
        mhs1.nim = baca.nextLine();
        System.out.print("Fakultas Anda : ");
        mhs1.fakultas = baca.nextLine();
        System.out.print("Jurusan Anda  : ");
        mhs1.jurusan = baca.nextLine();
        System.out.print("Angkatan Anda : ");
        mhs1.angkatan = baca.nextLine();
        System.out.println("Jadi , nama Anda terdapat " + mhs1.nama.length() + " huruf");

        mhs1.cetak();
    }
}