/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class main {
    public static void main(String[] args) {
        Karyawan k = new Karyawan();
        k.setNip("123456789");
        k.setNama("Abdul");
        k.setGaji(10000000);
        
        System.out.println("Nomor Induk anda= "+k.getNip());
        System.out.println("Nama Anda= "+k.getNama());
        System.out.println("Gaji Anda= "+k.getGaji());
        
        
        
    }
}
