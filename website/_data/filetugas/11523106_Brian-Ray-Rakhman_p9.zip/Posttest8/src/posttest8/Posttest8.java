/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest8;

import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author PRAKTIKAN
 */
public class Posttest8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        List an = new ArrayList<String>();
        an.add("Alvin");
        an.add("Imam");
        an.add("Ivan");
        an.add("jakal");
        an.add("concat");
        an.add("babarsari");

        for (Object o : an) {
            System.out.println(o);
        }
        System.out.println("============================");

        Iterator it = an.iterator();
        while (it.hasNext()) {
            System.out.println(it.next());
        }
    }
}