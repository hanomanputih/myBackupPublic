/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest8;
import java.util.Map;
import java.util.HashMap;
/**
 *
 * @author PRAKTIKAN
 */
public class Alamat {
    public static void main (String [] args){
        Map<String,String> mhs = new HashMap<String,String>();
        
        mhs.put("Brian","jakal");
        mhs.put("Ray","concat");
        mhs.put("Rakhman", "babarsari");
        System.out.println(mhs);
        System.out.println(mhs.get("Rakhman"));
        
        System.out.println("====================================");
        for(Map.Entry<String,String>e :mhs.entrySet()){
            System.out.println(e.getKey()+" , "+e.getValue());
        }   
    }
}
