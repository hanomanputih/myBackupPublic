/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package postest;

/**
 *
 * @author praktikan
 */
public class output {
    public static void main(String[] args) {
        karyawan k = new karyawan();
        k.setNip("10523316");
        System.out.println("Nip anda: "+k.getNip());
        k.setNama("M.anton");
        System.out.println("Nama anda: "+k.getNama());
        k.setGaji(200000);
        System.out.println("Gaji anda: "+k.getGaji());
    }

}
