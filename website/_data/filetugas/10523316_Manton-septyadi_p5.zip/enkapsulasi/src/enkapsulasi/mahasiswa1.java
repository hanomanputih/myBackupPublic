/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package enkapsulasi;

/**
 *
 * @author praktikan
 */
public class mahasiswa1 {
    private   String nim;
    public String nama;

    public String getNim(){
    return nim;
    }

    public  void  setNim(String nim){
    this.nim = nim;
    }

//    public void isiNim(String n) {
//        if (n.length()==8){
//            nim = n;
//        }else{
//            System.out.println("error");
//            }
//        }
//       public void Info(){
//           System.out.println("nama");
//           isiNim(nim);
//
//    }

}
