/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package enkapsulasi;

/**
 *
 * @author praktikan
 */
public class Mahasiswa {
    

    public static void main(String[] args) {
        mahasiswa1 m = new mahasiswa1();

       m.setNim("10523316");
        System.out.println("nim anda : "+m.getNim());
    }
}
