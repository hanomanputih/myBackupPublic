/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes8;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Praktikan
 */
public class main {

    public static void main(String[] args) {
        List nad = new ArrayList();

        nad.add(nad);
        nad.add(11523013);
        nad.add("Nadia Maya");

        System.out.println(nad);
        System.out.println(nad.size());


        System.out.println("__________________________________________");
        System.out.println("");

        Iterator itt = nad.iterator();
        while (itt.hasNext()) {
            System.out.println(itt.next());
          
        }
        

        System.out.println("__________________________________________");
        System.out.println("");


        Map<Integer, String> nadia = new HashMap<Integer, String>();

        nadia.put(1, " NIM  : 11523013");
        nadia.put(2, " Nama : Nadia Maya Cita");


        for (Map.Entry<Integer, String> ee : nadia.entrySet()) {
            System.out.println(ee.getKey() + "-" + ee.getValue());
        }
        
        System.out.println("___________________________________________");
        System.out.println("");
        
    }
}
