/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postestpertemuan4;

/**
 *
 * @author Praktikan
 */
public class Main {
    public static void main(String[] args) {
        Karyawan kar = new Karyawan ();
        kar.NIP("11523154");
        System.out.println("NIP = "+kar.getNIP());
        kar.KARYAWAN("Norman");
        System.out.println("Karyawan = "+kar.getKARYAWAN());
        kar.setGAJI(1000000);
        System.out.println("Gaji = "+kar.getgaji());
               
}
    
}
