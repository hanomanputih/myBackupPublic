/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postestpertemuan4;

/**
 *
 * @author Praktikan
 */
public class Karyawan {
    private String nip,karyawan;
    private int gaji;
    
    void NIP(String ni){
        if(ni.length() == 8 ){
            nip = ni;
        }else  {
            System.out.println("Invalid Character length");
        }
    }
    String getNIP(){
        return nip;
    }
    
    
    void KARYAWAN(String ka){
        if(ka.length() <= 10 ) {
            karyawan = ka;
        }else {
            System.out.println("Salah jeneng");
        }
    }
    String getKARYAWAN(){
        return karyawan;
    }
    
    void setGAJI(int ga){
        if(ga > 1000 ){
            gaji = ga;
            
        }else {
            System.out.println("Kakean Ngutang");
        }
    }
    int getgaji (){
        gaji = gaji*12;
        return gaji;
    }
    
    
    
    
}
