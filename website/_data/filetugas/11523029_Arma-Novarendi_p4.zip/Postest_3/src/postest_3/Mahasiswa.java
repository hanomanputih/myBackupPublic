/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest_3;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
    String nama, nim, fakultas, jurusan, angkatan;    
    float hitung, jumlah1, jumlah2, jumlah3, jumlah4, jumlah5;
    void cetak(){
        Scanner masuk = new Scanner(System.in);
        System.out.println("Masukkan nama Anda: ");
        nama = masuk.next();
        System.out.println("Masukkan NIM Anda: ");
        nim = masuk.next();
        System.out.println("Masukkan fakultas Anda: ");
        fakultas = masuk.next();
        System.out.println("Masukkan jurusan Anda: ");
        jurusan = masuk.next();
        System.out.println("Masukkan angkatan Anda: ");
        angkatan = masuk.next();
        
        jumlah1 = nama.length();
        jumlah2 = nim.length();
        jumlah3 = fakultas.length();
        jumlah4 = jurusan.length();
        jumlah5 = angkatan.length();
        hitung = jumlah1+jumlah2+jumlah3+jumlah4+jumlah5;
        
        System.out.println("===DATA ANDA===");
        System.out.println("Nama Mahasiswa : "+nama);
        System.out.println("NIM : "+nim);
        System.out.println("Fakultas : "+fakultas);
        System.out.println("Jurusan : "+jurusan);
        System.out.println("Angkatan : "+angkatan);
        System.out.println("Jumlah semua karakter yang dimasukkan = "+hitung);
    } 
    public static void main(String[] args) {
        Mahasiswa nanana = new Mahasiswa();
        
        nanana.cetak();
    }
}
