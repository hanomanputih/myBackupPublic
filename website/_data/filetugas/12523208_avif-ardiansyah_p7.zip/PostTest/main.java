/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package PostTest;


/**
 *
 * @author PRAKTIKAN
 */
public class main {
    public static void main(String[] args)
    {
        
        System.out.println("Karyawan Kerja Kontrak");   
        Kontrak kk = new Kontrak();
        kk.nama = "Andilau";
        System.out.println("Gaji Karyawan Kontrak : "+kk.hitungGaji());
        kk.view();
        
        System.out.println("");
        
        System.out.println("Karyawan Kerja Tetap");
        Tetap kt = new Tetap();
        kt.nama = "Avif Ardiansyah";
        System.out.println("Gaji Karyawan Tetap : "+kt.hitungGaji());
        kt.view();
        
    }
    
    
    
}
