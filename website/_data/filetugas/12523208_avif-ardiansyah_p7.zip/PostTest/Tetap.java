/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package PostTest;

/**
 *
 * @author PRAKTIKAN
 */
public class Tetap extends Karyawan {
    private double tunjangan = 0.5 * 3000000;
    
    @Override
    public void view()
    {
        super.view();
    }
    @Override
    public double hitungGaji()
    {
        double gaji = gajipokok + tunjangan + bonus;
        return gaji;
    }  
            
}
