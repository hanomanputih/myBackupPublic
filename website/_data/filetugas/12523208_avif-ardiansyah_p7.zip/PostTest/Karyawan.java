/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package PostTest;

/**
 *
 * @author PRAKTIKAN
 */
public abstract class Karyawan 
{
    protected String nama;
    protected double gajipokok = 3000000;
    protected double bonus = 0.3 * 3000000 ;
    
    public void view()
    {
        System.out.println("Nama Karyawan : "+nama);
    }
    public double hitungGaji()
    {
        return 0;
    }

   
}
