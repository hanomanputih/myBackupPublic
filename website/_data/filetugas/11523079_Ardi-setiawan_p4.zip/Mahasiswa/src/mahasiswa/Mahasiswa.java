/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;
import java.util.Scanner;
/**
 *
 * @author Praktikan
 */
public class Mahasiswa {

    String nama;
    String nim,fakultas,jurusan,angkatan;
    
    void isi(){
        Scanner mhs=new Scanner(System.in);
        System.out.println("Masukan nama anda: ");
        nama = mhs.next();
        System.out.println("Masukan NIM anda: ");
        nim = mhs.next();
        System.out.println("Masukan fakultas anda: ");
        fakultas = mhs.next();
        System.out.println("Masukan jurusan anda: ");
        jurusan = mhs.next();
        System.out.println("Masukan angkatan anda: ");
        angkatan = mhs.next();
    }
    
    void cetak(){
    System.out.println("Nama anda adalah: "+nama);
    System.out.println("NIM anda adalah: "+nim);
    System.out.println("fakultas anda adalah: "+fakultas);
    System.out.println("jurusan anda adalah: "+jurusan);
    System.out.println("angkatan anda adalah: "+angkatan);
    }
    
   void hitung(){
       System.out.println("jumlah karakter nama anda adalah: "+nama.length());
       System.out.println("jumlah karakter nim anda adalah: "+nim.length());
       System.out.println("jumlah karakter fakultas anda adalah: "+fakultas.length());
       System.out.println("jumlah karakter jurusan anda adalah: "+jurusan.length());
       System.out.println("jumlah karakter angkatan anda adalah: "+angkatan.length());
   }
    public static void main(String[] args) {
        Mahasiswa baru=new Mahasiswa();
        baru.isi();
        baru.cetak();
        baru.hitung();      
        
    }
}
