/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

import java.util.Scanner;

/**
 *
 * @author PRAKTIKAN
 */
public class Mahasiswa {

   String nama;
   String nim;
   String fakultas;
   String jurusan;
   String angkatan;
  void cetak(){
      System.out.println("nama anda adalah "+nama);
      System.out.println("nim anda "+nim+"dengan jurusan "+jurusan);
      System.out.println("fakultas anda "+fakultas+"angkatan "+angkatan);
  }
    public static void main(String[] args) {
     Scanner dibaca = new Scanner(System.in);
        Mahasiswa mhs = new Mahasiswa();
        System.out.println("nama anda adalah ");
        mhs.nama = dibaca.next();
        System.out.println("nim anda adalah ");
        mhs.nim=dibaca.next();
        System.out.println("fakultas anda adalah ");
        mhs.fakultas=dibaca.next();
        System.out.println("jurusan anda ");
        mhs.jurusan=dibaca.next();
        System.out.println("anda angkatan ke? ");
        mhs.angkatan=dibaca.next();
        mhs.cetak();
       
    }
}
