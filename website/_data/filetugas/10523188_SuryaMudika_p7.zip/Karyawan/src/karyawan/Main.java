/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class Main {
    public static void main(String[] args) {
        KaryawanTetap A = new KaryawanTetap();
        A.Tampilan();
        KaryawanKontrak B = new KaryawanKontrak();
        B.View();
    }
}
