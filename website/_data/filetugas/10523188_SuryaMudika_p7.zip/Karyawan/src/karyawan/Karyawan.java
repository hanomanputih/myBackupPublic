/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public abstract class Karyawan {
    double GajiPokok= 3000000;
    
    public abstract void gaji();
}
