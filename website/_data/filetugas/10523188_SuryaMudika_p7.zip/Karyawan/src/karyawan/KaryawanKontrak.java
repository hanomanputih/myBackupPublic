/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class KaryawanKontrak extends Karyawan {
    double Bonus=0.10* GajiPokok;
    double Gaji2;
    
    @Override
    public void gaji(){
        Gaji2=Bonus + GajiPokok;
        
    }

    
    public void View() {
    System.out.println("Gaji Karyawan"+ Gaji2);
    }
   

}
