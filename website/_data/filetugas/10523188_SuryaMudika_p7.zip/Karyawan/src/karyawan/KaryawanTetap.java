/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class KaryawanTetap extends Karyawan{
    double Tunjangan=0.20* GajiPokok;
    double Bonus= 0.15* GajiPokok;
    double Gaji;
    
    
    @Override
    public void gaji(){
        Gaji=Tunjangan+ GajiPokok+ Bonus;
        
    }
    public void Tampilan(){
        System.out.println("Gaji Karyawan"+ Gaji);
    }
}
