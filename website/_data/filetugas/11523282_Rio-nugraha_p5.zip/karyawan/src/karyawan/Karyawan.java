/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;
private static void main(String[]args){
   int nip,nama,gaji
nip=11523282
nama=paijo
gaji=100

hasil=nip11523282;
System.out.println("Hasil Pembagian"+hasil)
}

/**
 *
 * @author PRAKTIKAN
 */
public class Karyawan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
}
