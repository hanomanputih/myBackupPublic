/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

/**
 *
 * @author Praktikan
 */
public class Prosesor {
String jenisProsesor;
public Prosesor (String jenisProsesor){
this.jenisProsesor = jenisProsesor;
}
public void nampilProsesor() {
System.out.println("jenis Prosesor :"+jenisProsesor);
}}
    
    

