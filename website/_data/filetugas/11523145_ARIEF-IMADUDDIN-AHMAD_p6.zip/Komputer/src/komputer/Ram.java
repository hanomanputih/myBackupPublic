/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class Ram {
    private String merkram;
    public Ram(String merkram){
        this.merkram=merkram;
        
    }
    public void tampilRam(){
        System.out.println("merk RAM adalah "+merkram);
    }
}
