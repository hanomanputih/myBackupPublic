/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class Prosessor {
      private String merpros;
      private Ram a;
      
    public Prosessor(String merpros){
        this.merpros=merpros;
        if (merpros.equals("VENGEANCE")) {
            a = new Ram("ALNECT");
        }
    }
    public void tampilPros(){
        System.out.println("merk PROSESSOR adalah "+merpros);
a.tampilRam();
    }
}
