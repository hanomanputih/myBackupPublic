/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class Komputer {

    private String namaKompi;
      private Prosessor a;
  
    
    public Komputer(String namaKompi){
        this.namaKompi=namaKompi;
        if (namaKompi.equals("BENJO")){
            a = new Prosessor("VENGEANCE");
        }
    }
    
public void TampilKompi(){
    System.out.println("nama Kompi :"+namaKompi);
    a.tampilPros();
    
}



    public static void main(String[] args) {
        Komputer b = new Komputer("BENJO");
        b.TampilKompi();
    }
}
