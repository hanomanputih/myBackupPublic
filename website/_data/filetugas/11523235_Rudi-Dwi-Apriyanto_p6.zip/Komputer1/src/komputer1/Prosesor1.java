/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer1;

/**
 *
 * @author Praktikan
 */
public class Prosesor1 {
   String JenisPros;
    
public Prosesor1 (String JnsRam) {
    this.JenisPros = JnsRam;

}

public void tampilRam(){
    System.out.println ("jenis Prosesor : +JenisPros");
}
    
}
