/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer1;



public class Ram1 {
    String JenisRam;
    
public Ram1 (String JnsRam) {
    this.JenisRam = JnsRam;

}

public void tampilRam(){
    System.out.println ("jenis RAM : "+JenisRam);
}
    
}
