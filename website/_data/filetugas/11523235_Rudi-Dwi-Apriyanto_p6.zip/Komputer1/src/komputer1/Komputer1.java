/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer1;

/**
 *
 * @author Praktikan
 */
public class Komputer1 {
    String  NamaKom;
    Ram1 r;
    Prosesor1 p;
    
    public Komputer1 (String NmKom){
        this.NamaKom = NmKom;
        if (NamaKom.equals ("SONY")) {
            r = new Ram1 ("DDR3");
            p = new Prosesor1 ("Prosesor intel i7");
        }
    }

    public static void main (String []args){
        Komputer1 kom = new Komputer1 ("SONY");
    
        System.out.println(" Nama Komputer        : " + kom.NamaKom);
        System.out.println(" Jenis Ram            : " + kom.r.JenisRam );
        System.out.println(" Jenis Prosesor       : " + kom.p.JenisPros);
        
    }
    
}