/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author 08
 */
public class Karyawan {
    private String nip;
    private String nama;
    private int gaji;
    
    public void setNip(String n){
        nip = n;
    }
    public void setNama(String x){
        nama = x;
    }
    public void setGaji(int g){
        gaji = g;
    }
    public String ambilNip(){
        return nip;
    }
    public String ambilNama(){
        return nama;
    }
    public int ambilGaji(){
        return gaji*12;
    }
    
}
