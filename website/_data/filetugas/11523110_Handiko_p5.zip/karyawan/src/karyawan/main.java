/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author 08
 */
public class main {
    public static void main(String[] args) {
        Karyawan m = new Karyawan();
        m.setNip("11523110");
        m.setNama("DIKO");
        m.setGaji(20000000);
        
        System.out.println("NIP : "+m.ambilNip());
        System.out.println("NAMA : "+m.ambilNama());
        System.out.println("Gaji : "+m.ambilGaji());
    }
    
}
