package perusahaan;

public abstract class Karyawan {

    int gajiPokok = 3000000 ;
    int bonus = 500000;

        
public abstract int gaji(); 
    
}
