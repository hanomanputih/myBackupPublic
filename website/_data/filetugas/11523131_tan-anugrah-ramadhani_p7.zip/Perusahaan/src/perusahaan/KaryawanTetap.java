package perusahaan;

public class KaryawanTetap extends Karyawan {
    int tunjangan = (int) (0.2 * 3000000);
    
    @Override
    public int gaji() {
        int gaji;
        gaji = tunjangan + bonus + gajiPokok;
        return gaji;
    }
 

}
