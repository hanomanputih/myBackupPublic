
package posttest;

public class Karyawan {
    public static void main(String[] args) {
       Main k = new Main();
       k.setNama("Reza");
       k.setNIP ("11523074");
       k.setGaji (500000);
       System.out.println("Nama anda : "+k.getNama());
       System.out.println("NIP anda: "+k.getNIP());
       System.out.println("Gaji anda : "+k.getGaji()*12);
    }
}
