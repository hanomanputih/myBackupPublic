/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest8;
import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
/**
 *
 * @author PRAKTIKAN
 */
public class Postest8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
//        Mahasiswa e = (Mahasiswa) organisasi.get(0);
        Map<String, String> mhs = new HashMap<String, String>();
        
        mhs.put("Jakarta", "Roy");
        mhs.put("Bali", "Gede");
        mhs.put("Jogja", "Slamet");
        
        System.out.println(mhs);
        System.out.println("");
        System.out.println("Mahasiswa Yang Tinggal di Jakarta Adalah :");
        System.out.println(mhs.get("Jakarta"));

         System.out.println("");
         for(Map.Entry<String, String> e : mhs.entrySet()){
            System.out.println(e.getKey()+", "+e.getValue());}
         System.out.println("====================");
         
         
         List mhsw = new ArrayList();
        
         mhsw.add("Jakarta");
        mhsw.add("Bali");
        mhsw.add("Jogja");

//         for (Object o : mhsw){
//            System.out.println();
         
    Iterator it = mhsw.iterator();
        while(it.hasNext()){
            System.out.println(it.next());
        }
        System.out.println("");
        System.out.println("Tampilan Indeks Kedua Adalah : ");
        System.out.println(mhsw.get(2));
}}
