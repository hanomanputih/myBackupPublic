/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komposisikomputer;

/**
 *
 * @author Praktikan
 */
public class MainKomputer {
    public static void main(String[] args){
    RAM ram = new RAM("2 Giga");
    Prosesor pro = new Prosesor("AMD Sempron 2.0 Ghz", ram);   
    pro.tampil(ram);
}}
