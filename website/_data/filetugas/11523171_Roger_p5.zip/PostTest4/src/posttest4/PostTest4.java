/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest4;

/**
 *
 * @author PRAKTIKAN
 */
public class PostTest4 {
    private String nip;
    private String nama;
    private int gaji;
    
    public void setNip(String _Nip){
        if(_Nip.length()==4){
            nip=_Nip;
        }
    }
    
    public void setNama(String _Nama){
        if(_Nama.length()>=0){
            nama=_Nama;
        }
    }public String getNama(){
        return nama;
    }
    public void setGaji(int _Gaji){
            if(_Gaji>=0){
                gaji=_Gaji*12;
            }else{
                System.out.println("gaji minus, jadi tidak mungkin");
            }
        }
    public int getGaji(){
        return gaji;
    }public String getNip(){
        return nip;
    }
    
}
    

    /**
     * @param args the command line arguments
     */
    //public static void main(String[] args) {
        // TODO code application logic here
    

