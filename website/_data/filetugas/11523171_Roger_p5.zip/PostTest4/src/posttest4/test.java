/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest4;

/**
 *
 * @author PRAKTIKAN
 */
public class test {
    public static void main(String args[]){
        PostTest4 cek= new PostTest4();
        cek.setGaji(-1200000);
        cek.setNama("ROGER");
        cek.setNip("1111");
        System.out.println(" Nama : "+cek.getNama());
        System.out.println("NIP : "+cek.getNip());
        System.out.println("Gaji : "+cek.getGaji());
        
    }
    
}
