/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Mahasiswa;

/**
 *
 * @author Praktikan
 */
public class mahasiswa {

    string nama = "demonology" ;
    int nim = "123456" ;
    int angkatan = "99";
    
    public static void main(String[] args) {
    
        mahasiswa cetak = new mahasiswa;
        
        System.out.println("nama= "+cetak.nama);
        System.out.println("nama= "+cetak.nim);
        System.out.println("nama= "+cetak.angkatan);
    }

}

