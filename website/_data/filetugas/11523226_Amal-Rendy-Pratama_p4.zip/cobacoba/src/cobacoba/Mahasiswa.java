/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cobacoba;


import java.util.Scanner;
 
public class Mahasiswa {

    String nama;
    String nim;
    String fakultas;
    String jurusan;
    String angkatan;
    
    void cetak(){
    System.out.println ("Nama : "+nama);
    System.out.println("Nim : "+nim);
    System.out.println("Fakultas : "+fakultas);
    System.out.println("Jurusan : "+jurusan);
    System.out.println("Angkatan : "+angkatan);
    }
    void input(){
    Scanner sc = new Scanner(System.in);
    System.out.println ("Masukkan Nama Anda : ");
    nama = sc.next();
    System.out.println("Masukkan Nim Anda : ");
    nim = sc.next();
    System.out.println("Masukkan Fakultas Anda: ");
    fakultas = sc.next();
    System.out.println("Masukkan Jurusan Anda : ");
    jurusan = sc.next();
    System.out.println("Masukkan Angkatan Anda : ");
    angkatan = sc.next();
    }
    
    public static void main(String[] args) {
    Mahasiswa mhs1 = new Mahasiswa();
    mhs1.input();
    mhs1.cetak();
   
     }
}
