/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
    String nama;
    String nim;
    String jurusan;

    
    public static void main(String[] args) {
        Mahasiswa mhs = new Mahasiswa();
        mhs.nama = "Sabrina";
        mhs.nim = "11523091";
        mhs.jurusan = "Informatika";
        
        
        
    }
}
