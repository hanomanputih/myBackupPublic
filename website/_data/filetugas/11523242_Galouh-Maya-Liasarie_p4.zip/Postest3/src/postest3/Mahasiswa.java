/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package postest3;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
//atribut
    String nama = "Maya";
    String nim = "11523242";
    String jurusan = "T.Informatika";
    String fakultas = "FTI";
    String angkatan = "2011";
//method
void cetak(){
    System.out.println("nama = "+nama);
    System.out.println("nim = "+nim);
    System.out.println("jurusan = "+jurusan);
    System.out.println("fakultas = "+fakultas);
    System.out.println("angkatan = "+angkatan);
}
    public static void main(String[] args) {
        Mahasiswa m = new Mahasiswa();
        m.cetak();
        

    }
}
