/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest7;

/**
 *
 * @author PRAKTIKAN
 */
public class Postest7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Swalayan swl = new Swalayan();
        swl.tampil();
        
        Indomart ind = new Indomart();
//        swl = ind;
        ind.tampil();
        
        
        System.out.println("-----------------");
    
        TokoAgung TA = new TokoAgung();
//        swl = TA;
        TA.tampil();
    
    
    }
}
