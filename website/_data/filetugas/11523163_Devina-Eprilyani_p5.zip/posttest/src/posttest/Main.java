/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package posttest;

/**
 *
 * @author Praktikan
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         karyawan k = new karyawan();
        k.setNip("11523163");
        k.setNama("Devinaaa");
        k.setGaji(100000*12);

        System.out.println("Nip : "+k.getNip());
        System.out.println("Nama :"+k.getNama());
        System.out.println("Gaji :"+k.getGaji());
    }

}
    


