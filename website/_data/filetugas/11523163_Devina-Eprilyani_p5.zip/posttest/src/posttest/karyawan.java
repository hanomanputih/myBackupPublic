/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package posttest;

/**
 *
 * @author Praktikan
 */
public class karyawan {
    private String nip;
    private String nama;
    private int gaji;

    void setNip(String n){
            nip = n;
        }

        String getNip() {
            return nip;
        }

        void setnip(String nm){

            if(nm.length() == 10) {
                nip = nm;
            }else{
                System.out.println("nip tidak sesuai");
            }
        }

//      void setNama(String m){
//            nama = m;
//      }

        String getNama() {
          return nama;}

      void setNama(String m){

          if(m.length() == 8) {
              nama  = m;
          }else{
              System.out.println("Devinaaaa");
          }
      }

      int getGaji() {
          return gaji;}

      void setGaji( int gj){
          gaji = gj;


          }
      }







