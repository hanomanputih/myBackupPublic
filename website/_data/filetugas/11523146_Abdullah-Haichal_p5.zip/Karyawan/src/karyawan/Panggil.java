/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class Panggil {
    public static void main(String[] args) {
        Karyawan kry = new Karyawan ();
        kry.setNip("12345");
        kry.setNama("Haichal");
        kry.setGaji(10000000);
        System.out.println(kry.getNama());
        System.out.println(kry.getNip());
        System.out.println(kry.getgaji());
                
    }
   
}
