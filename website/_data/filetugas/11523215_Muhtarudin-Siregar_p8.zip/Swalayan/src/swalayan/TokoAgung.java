/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package swalayan;

/**
 *
 * @author Praktikan
 */
public class TokoAgung extends Swalayan{
    
    
   void hitung(){
    if(harga  % 25 == 0){
        bayar = (int)harga;
        System.out.println("Yang harus anda bayar : "+bayar);
    }

    else{
   
       sisa = (int)(harga % 25);
       bayar = (int)(harga - sisa);
        System.out.println("yang harus dibayar ditoko agung: "+bayar);
       
   
   }
   
    
    
   }
   
   void tampil(){
   hitung();
   
   
   }
    
}
