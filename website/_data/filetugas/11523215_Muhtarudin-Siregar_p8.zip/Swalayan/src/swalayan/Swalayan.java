/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package swalayan;

/**
 *
 * @author Praktikan
 */
public class Swalayan {
    float harga;
    int sisa,bayar;
    
    
    void tampil(){
    
        
    }
    
    
    public static void main(String[] args) {
        
        
    }
}
