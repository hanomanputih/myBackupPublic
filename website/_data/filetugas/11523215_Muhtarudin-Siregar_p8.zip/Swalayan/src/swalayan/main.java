/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package swalayan;

/**
 *
 * @author Praktikan
 */
public class main {
    
    
    public static void main(String[] args) {
      Swalayan s;
      
      Indomaret i = new Indomaret();
      s = i;
      s.harga = 19212;
      s.tampil();
      
      TokoAgung t = new TokoAgung();
      s = t;
      s.harga =19212;
      s.tampil();
      
      
      
        
        
    }
    
    
    
}


