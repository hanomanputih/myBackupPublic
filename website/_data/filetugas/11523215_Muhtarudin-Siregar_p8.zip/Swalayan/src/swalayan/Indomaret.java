/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package swalayan;

/**
 *
 * @author Praktikan
 */
public class Indomaret extends Swalayan {
    void hitung(){
        if(harga % 25 == 0){
            bayar = (int)harga;
            System.out.println("Harga di Indomaret: "+bayar);
        
        
        }
        else{
         sisa = (int ) (25 -(harga % 25));
         bayar = (int) (harga + sisa);
            System.out.println("yang anda bayar di Indomaret: "+bayar);
    
        }
    
    
    }
    void tampil(){
    hitung();
    
    
    }
    
    
    
    
    
}



