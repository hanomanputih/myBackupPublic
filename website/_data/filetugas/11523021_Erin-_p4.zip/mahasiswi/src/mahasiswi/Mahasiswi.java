/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswi;
import java.util.Scanner;
/**
 *
 * @author Praktikan
 */
public class Mahasiswi {
String nama,nim,fakultas,jurusan,angkatan;

void isi(){
  Scanner read=new Scanner(System.in);
  System.out.println("inputan nama:");
  nama=read.next();
  System.out.println("inputan nim:");
  nim=read.next();
  System.out.println("inputan fakultas:");
  fakultas=read.next();
  System.out.println("jurusan:");
  jurusan=read.next();
  System.out.println("angkatan:");
  angkatan=read.next();
}

void cetak(){
    System.out.println("nama anda"+nama);
    System.out.println("nim anda"+nim);
    System.out.println("fakultas anda"+fakultas);
    System.out.println("jurusan anda"+jurusan);
    System.out.println("angkatan"+angkatan);
         
}


    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Mahasiswi mh = new Mahasiswi();
        
        mh.isi();
        mh.cetak();
    }
}
