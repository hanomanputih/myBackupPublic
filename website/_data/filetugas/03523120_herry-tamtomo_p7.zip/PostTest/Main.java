/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package PostTest;

/**
 *
 * @author PRAKTIKAN
 */
public class Main {
    public static void main(String[] args) {
        KaryawanTetap tetap = new KaryawanTetap();
        tetap.nama = "ali";
        System.out.println("Gaji Karyawan Tetap : "+tetap.itungGaji());
        tetap.view();
        
        System.out.println("");
        
        KaryawanKontrak kontrak = new KaryawanKontrak();
        kontrak.nama = "agus";
        System.out.println("Gaji Karyawan Kontrak : "+kontrak.itungGaji());
        kontrak.view();
    }
    
}
