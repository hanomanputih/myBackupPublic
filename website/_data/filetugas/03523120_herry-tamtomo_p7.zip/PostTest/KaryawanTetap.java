/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package PostTest;

/**
 *
 * @author PRAKTIKAN
 */
public class KaryawanTetap extends Karyawan {
    private double tunjangan = 0.2 * 3000000;
    
    @Override
    public void view()
    {
        super.view();
    }
    
    @Override
    public double itungGaji()
    {
        double gaji = tunjangan+gajipokok+bonus;
        return gaji;
    }
}
