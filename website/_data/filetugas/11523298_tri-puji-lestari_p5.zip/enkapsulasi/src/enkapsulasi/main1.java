/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package enkapsulasi;

/**
 *
 * @author Praktikan
 */
public class main1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        karyawan mhs1 = new karyawan();
        //mhs1.nim = 11523298;
//        mhs1.nama="puji";
//        mhs1.isiNim("11523298");
//        mhs1.info();
        mhs1.setter();
        mhs1.nip();
        mhs1.gaji();
        
        System.out.println("nama : "+mhs1.getter());
         System.out.println("nip: "+mhs1.nim());
          System.out.println("gaji perbulan : "+mhs1.upah());
          System.out.println("gaji pertahun: " + mhs1.upah()*12 );
        
    }
}
