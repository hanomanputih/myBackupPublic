/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package enkapsulasi;

/**
 *
 * @author Praktikan
 */
public class karyawan {
private String nip,nama;
private int gaji;
   
  
   public void setter(){
       this.nama= nama;
       
       nama= "puji";
}
   
      public void nip(){
       this.nip= nip;
       
       nip= "11523298";
}
       
         public void gaji(){
       this.gaji= gaji;
       
      gaji= 1000000;
}
   public String getter(){
       return nama;
   }
    public String nim(){
       return nip;
   }
    
     public int upah(){
       return gaji;
   }
   
   
//   public void getter(String n){
//       if (n.length() == 8 ){
//           nim = n;
//       }
//       else {
//           System.out.println("error!!");
//       }
//   }
//   public void info() {
//       System.out.println("nama " + nama);
//       isiNim (nim);
//   }
//}
}