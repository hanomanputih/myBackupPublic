/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postestempat;

/**
 *
 * @author PRAKTIKAN
 */
public class Keluaran {
    public static void main(String[] args) {
        Karyawan k = new Karyawan();
        k.setNip("11523180");
        System.out.println("Nip anda adalah = "+k.getNip());
        k.setNama("Gondes");
        System.out.println("Nama anda adalah = "+k.getNama());
        k.setGaji(10000);
        System.out.println("Gaji setahun anda adalah = "+k.getGaji());
    }
    
}
