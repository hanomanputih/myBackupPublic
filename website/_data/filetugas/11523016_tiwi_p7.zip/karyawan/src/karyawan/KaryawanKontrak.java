/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class KaryawanKontrak extends Karyawan {
    private String Karyawan;
    
    public void view(){
        System.out.println("Karyawan : "+karyawan);
        
    }

    