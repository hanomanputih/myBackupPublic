/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public abstract class Karyawan {
    protected String nama;
    protected String nip; 
    protected String gajipokok;
    protected String bonus;
    protected String tunjangan;
    
 public abstract void gaji();
  public void view(){
        System.out.println("Nama : "+nama);
        System.out.println("nip : "+nip);
        System.out.println("gajipokok : "+gajipokok);
        System.out.println("bonus : "+bonus);
        System.out.println("tunjangan: "+tunjangan);
        
  }
}

