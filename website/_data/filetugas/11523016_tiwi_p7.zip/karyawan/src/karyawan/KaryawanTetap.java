/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan ;


/**
 *
 * @author Praktikan
 */
public class KaryawanTetap extends Karyawan {
    private float gajitotal;
    private float gaji=3000000;
    
    public void view 
    
    public String getgaji(){
         return gaji;
     }
     
     public void setgaji(String gaji){
         this.gaji=gaji;}
         
         public void hitung(float gajitotal,float gaji){
             
         }

    @Override
    public void gaji() {
        System.out.println("gajipokok");
         System.out.println("bonus");
        
    }

    
    
}