/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class Main {
    public static main (String [] args){
       Karyawan kry = new Karyawan();
       kry.nama="Tiwi";
       kry.nip="11523016";
       kry.gajipokok="3000000"
    
}
