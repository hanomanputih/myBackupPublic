/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package posttest4;

/**
 *
 * @author Praktikan
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic he
        Karyawan kry =new Karyawan();
        kry.setNIP("1123182");
        System.out.println("NIP= "+kry.getNIP());

        kry.setnama("Esti");
        System.out.println("nama= "+kry.getnama());
        
        kry.setgaji(200000*12);
        System.out.println("gaji= "+kry.getgaji());
    }


}
