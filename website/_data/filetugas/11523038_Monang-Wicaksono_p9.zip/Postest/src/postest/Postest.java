/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Praktikan
 */
public class Postest {
    
   
   
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        List <String> Monang = new ArrayList<String> ();
        Monang.add("11523038");
        Monang.add("Monang Wicaksono");
        System.out.print("|||");
        Monang.add("11523037");
        Monang.add("Mamang Endut");
        System.out.print("|||");
        Monang.add("11523036");
        Monang.add("Gombloh Petruk");
        System.out.print("|||");
        
        System.out.println(Monang);
        
    }
}
