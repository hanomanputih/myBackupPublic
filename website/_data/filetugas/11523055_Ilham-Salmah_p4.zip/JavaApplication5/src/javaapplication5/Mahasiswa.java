/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication5;

import java.util.Scanner;


        // TODO code application logic here
/**
 *
 * @author Praktikan
 */
public class Mahasiswa {

    /**
     * @param args the command line arguments
     */

    String nim;
    String nama;
    String fakultas;
    String jurusan;
    int angkatan;
 
    
    void cetak(){ 
        Scanner baca = new Scanner(System.in);
        System.out.println("Masukkan nama: ");
        nama = baca.next();
        System.out.println("Masukkan nim: ");
        nim = baca.next();
        System.out.println("Masukkan fakultas: ");
        fakultas = baca.next();
        System.out.println("Masukkan jurusan: ");
        jurusan = baca.next();
        System.out.println("Masukkan angkatan: ");
        angkatan = baca.nextInt ();
        System.out.println("nama : "+nama);
        System.out.println("nim :"+nim);
        System.out.println("fakultas :"+fakultas);
        System.out.println("jurusan :"+jurusan);
        System.out.println("angkatan :"+angkatan);
    }
   
    public static void main(String[] args) {
        Mahasiswa mhs = new Mahasiswa();
        mhs.cetak();
    }
    
}
    
