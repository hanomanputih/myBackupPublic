/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

import java.util.Scanner;

/**
 *
 * @author PRAKTIKAN
 */
public class Mahasiswa {

        String nama;
        String nim;
        String jurusan;
        String angkatan;
        String fakultas;
        int coba;
        
        void Cetak(){
            System.out.println("Nama Anda :" + nama);
            System.out.println("Nim Anda :" + nim);
            System.out.println("Fakultas : " + fakultas);
            System.out.println("Jurusan :" + jurusan);
            System.out.println("Angkatan : " + angkatan);
           
            System.out.println("Jumlah karakter : " +nama.length());
            System.out.println("Jumlah karakter : " +nim.length());
            System.out.println("Jumlah karakter : " +fakultas.length());
            System.out.println("Jumlah karakter : " +jurusan.length());
            System.out.println("Jumlah karakter : " +angkatan.length());
            
        }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    Scanner baca = new Scanner(System.in);
    Mahasiswa mhs1 = new Mahasiswa();
        System.out.println("Nama anda : ");
    mhs1.nama = baca.next();
        System.out.println("Nim anda : ");
    mhs1.nim = baca.next();
        System.out.println("Fakultas Anda : ");
    mhs1.fakultas = baca.next();
        System.out.println("Jurusan Anda : ");
    mhs1.jurusan = baca.next();
        System.out.println("Angkatan : ");
    mhs1.angkatan = baca.next();
    
    
    mhs1.Cetak();
    
    }
}
