
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package post;

/**
 *
 * @author PRAKTIKAN
 */
public class komputer {
    prosesor pr;
    ram r;
    public komputer (String nama,int ram)
    {
        if(nama.equals("3"))
        {
            pr = new prosesor();
            pr.setNama("intel");
        }
        if (ram == 1)
        {
            r = new ram ();
            r.setNama(512);
        }
    }
    
    public static void main(String[] args) {
        komputer k = new komputer("3",1);
       
        k.pr.tampil();
        k.r.tampil();
    }
}
