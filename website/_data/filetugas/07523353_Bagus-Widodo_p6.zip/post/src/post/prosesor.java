/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package post;

/**
 *
 * @author PRAKTIKAN
 */
public class prosesor {
    String prosesor;
    
    public void setNama(String nama)
    {
        this.prosesor = nama;
    }
    public void tampil() {
        System.out.println("jenis prosesor : "+prosesor);
    }
    
}
