/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package post;

/**
 *
 * @author PRAKTIKAN
 */
public class ram {
    int ram = 512;
    public void setNama(int ram)
    {
        this.ram = ram;
    }
    public void tampil(){
        System.out.println("kapasitas ram : "+ram);
    }
}
