/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {

  String Nama;
  String nim;
  String fakultas;
  String jurusan;
  
  void cetakData (){
      System.out.println("nama saya adalah : " + Nama );
      System.out.println("nim saya adalah : " + nim );
      System.out.println("fakultas saya adalah : " + fakultas);
      System.out.println("jurusan saya adalah : " + jurusan);
      
      
  }
  
public static void main(String[] args) {
    Mahasiswa Mahasiswa27 = new Mahasiswa();
    
    Mahasiswa27.Nama = "Sozza Ayudha Razak" ;
    Mahasiswa27.nim = "10523366" ;
    Mahasiswa27.fakultas = "universitas islam indonesia" ;
    Mahasiswa27.jurusan = "teknik informatika" ;
    
    Mahasiswa27.cetakData();
    
    
    
   
}
}
