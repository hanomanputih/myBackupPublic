/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;


public class Mahasiswa {

   String  Nama, NIM, Fakultas, Jurusan, Angkatan;
   
   void cetak(){
       Nama="Krisna Wirawan";
       System.out.println(Nama);
       NIM="11523040";
       System.out.println(NIM);
       Fakultas="Teknik industri";
       System.out.println(Fakultas);
       Jurusan="Teknik Infromatika";
       System.out.println(Jurusan);
       Angkatan="Angkatan 2011";
       System.out.println(Angkatan);
   }
    public static void main(String[] args) {
        Mahasiswa mhs = new Mahasiswa();
        mhs.cetak();
                  
    }
    }
