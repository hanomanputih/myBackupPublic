/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest.pkg3;

import java.util.Scanner;

/**
 *
 * @author PRAKTIKAN
 */
public class Mahasiswa {
    String nim;
    String nama;
    String fakultas;
    String jurusan;
   
    void cetak(){
        System.out.println ("nama anda " + nama + "nim anda " + nim );
        System.out.println ("fakultas anda " + fakultas + "jurusan anda " + jurusan );
     
    }
        
       
        public static void main (String[] args){
            Scanner pembaca = new Scanner(System.in);
            Mahasiswa mhs = new Mahasiswa ();
            System.out.println("Siapa nama anda ?");
            mhs.nama = pembaca.next();
            System.out.println("Berapakah nim anda?");
            mhs.nim = pembaca.next();
            System.out.println("apakah fakultas anda?");
            mhs.fakultas=pembaca.next();
            System.out.println("apakah jurusan anda?");
            mhs.jurusan=pembaca.next();
            mhs.cetak();
            
           }
      }
                
              

    
  
    
            

