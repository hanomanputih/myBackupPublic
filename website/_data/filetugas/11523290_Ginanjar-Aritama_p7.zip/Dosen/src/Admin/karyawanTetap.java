/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Admin;

/**
 *
 * @author Praktikan
 */
public class karyawanTetap extends Karyawan {

    double Gaji;
    double Tunjangan;
    int Bonus;
    double Gaji_Pokok = 3000000;



    @Override
    public void Gaji() {
        Tunjangan = (0.2 * Gaji_Pokok);
        
        Gaji = Tunjangan + Gaji_Pokok + Bonus;
        
        System.out.println("Nama" +Nama);
        System.out.println("Gaji" +Gaji);
        System.out.println("Tunjangan" +Tunjangan);
        System.out.println("Bonus" +Bonus);
        
    }
}
