/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Admin;

/**
 *
 * @author Praktikan
 */
public abstract class Karyawan {
     public abstract void Gaji();

     
     String Nama;
    
    
    
}
