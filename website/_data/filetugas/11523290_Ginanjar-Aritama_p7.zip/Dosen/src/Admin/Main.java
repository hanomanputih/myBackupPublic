/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Admin;

/**
 *
 * @author Praktikan
 */
public class Main {
    public static void main(String[] args) {
        karyawanTetap Aan = new karyawanTetap();  
        Aan.Nama = "Aan";
        Aan.Bonus = 100000;
        Aan.Gaji();
        
        KaryawanKontrak Aming = new KaryawanKontrak ();
        Aming.Bonus = 100000;
        Aming.Nama = "Ateng";
        Aming.Gaji_pokok = 2000000;
        Aming.Gaji();
    }
}
