/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Admin;

/**
 *
 * @author Praktikan
 */
public class KaryawanKontrak extends Karyawan  {
   
    int Gaji;
    int Gaji_pokok;
    int Bonus;
    
    @Override
    public void Gaji() {
        Gaji = Gaji_pokok + Bonus;
        System.out.println("Nama" +Nama);
        System.out.println("Gaji" +Gaji);
        System.out.println("Bonus" +Bonus);
    }
    
}
