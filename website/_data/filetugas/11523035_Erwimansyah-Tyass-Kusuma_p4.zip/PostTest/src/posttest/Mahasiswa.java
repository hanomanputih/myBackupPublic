/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package posttest;

import java.util.Scanner;

/**
 *
 * @author praktikan
 */
public class Mahasiswa {

    /**
     * @param args the command line arguments
     */

    String nim,angkatan,nama,fakultas,jurusan;

    void cetak (){
        Scanner baca= new Scanner (System.in);
        System.out.println("Masukkan Nama Anda: ");
       nama=baca.next();
        System.out.println("Nama Anda=" +nama);
        System.out.println("Fakultas : ");
        fakultas=baca.next();
        System.out.println("Fakultas Anda=" +fakultas);
        System.out.println("Jurusan : ");
        jurusan=baca.next();
        System.out.println("Jurusan Anda=" +jurusan);
        System.out.println("Nim Anda : ");
       nim=baca.next();
       System.out.println("Nim Anda=" +nim);
        System.out.println("Angkatan : ");
        angkatan=baca.next();
        System.out.println("Angkatan=" +angkatan);
    }

    public static void main(String[] args) {
        Mahasiswa m=new Mahasiswa();
     m.cetak();

        // TODO code application logic here
    }

}
