/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritance;

/**
 *
 * @author PRAKTIKAN
 */
public  class KaryawanTetap extends Karyawan{
    double tunjangan=0.2*gajiPokok;

    @Override
    public void gaji() {
        double gaji=tunjangan+gajiPokok+bonus;
        System.out.println("gaji karyawan tetap "+gaji);
    }
    
    
}
