/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritance;

/**
 *
 * @author PRAKTIKAN
 */
public class KaryawanKontrak extends Karyawan {

    @Override
    public void gaji() {
        double gaji = gajiPokok+bonus;
        System.out.println("gaji karyawan kontrak "+gaji);
    }

    
}
       
