/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritance;

/**
 *
 * @author PRAKTIKAN
 */
public abstract class Karyawan {
    
    public int gajiPokok=3000000;
    public int bonus=500000;
   
    
    public abstract void gaji();
}
