/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication22;

/**
 *
 * @author Praktikan
 */
public class mahasiswa {
    
    private String nim;
    public String nama;
    
    public String getNim(){
        return nim;
    }
    
    public void setNim(String nim){
        if (nim.length() == 8){
        this.nim=nim;
        } else {
            System.out.println("Error...!!!");
        }
    }
    
    
//    public void isiNim(String n) {
//        if(n.length() == 8){
//            nim = n;
//        }else {
//            System.out.println("Error..!!! ");
//        }
//    }
//    public void info(){
//        System.out.println("Nama: "+nama);
//        isiNim(nim);
//    }

    
}


