/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication22;

/**
 *
 * @author Praktikan
 */
public class Karyawan {
    private String nip;
    private String nama;
    private int gaji;
    
    
     public String getNip(){
        return nip;
    }
     
     public void setNip(String nip){
        if (nip.length() == 8){
        this.nip=nip;
        } else {
            System.out.println("Error...!!!");
        }
    }
     
     public String getNama(){
        return nama;
    }
     
     public void setNama(String nama){
        if (nama.length() >= 0){
        this.nama=nama;
        } else {
            System.out.println("Error...!!!");
        }
    }
     public int getGaji(){
        return gaji;
    }
     
     public void setGaji(int gaji){
        if (gaji >= 0){
        this.gaji=gaji;
        } else {
            System.out.println("Error...!!!");
        }
    }
}
