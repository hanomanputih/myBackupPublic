/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication22;

/**
 *
 * @author Praktikan
 */
public class JavaApplication22 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
      
//        mahasiswa m=new mahasiswa();
//        m.setNim("11523262");
//        System.out.println("NIM anda: "+m.getNim());
//        m.nama="arif";
//        System.out.println("Nama Anda: "+m.nama);
        
        Karyawan k=new Karyawan();
        k.setNip("11523262");
        System.out.println("NIM anda: "+k.getNip());
        k.setNama("arif");
        System.out.println("Nama Anda: "+k.getNama());
        k.setGaji(1000000);
        System.out.println("Gaji Anda Sebulan: "+k.getGaji());
        System.out.println("Gaji Anda Setahun: "+k.getGaji()*12);
        
    }
}
