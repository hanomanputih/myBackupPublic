/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

import java.util.Scanner;

/**
 *
 * @author PRAKTIKAN
 */
public class Mahasiswa {

    String nama;
    String nim;
    String fakultas;
    String jurusan;
    String angkatan;
   
    
    void cetak (){
        System.out.println (" nama anda = "+nama);
        System.out.println (" nim anda = "+nim);
        System.out.println (" fakultas anda = "+fakultas);
        System.out.println (" jurusan anda = "+jurusan);
        System.out.println (" angkatan anda = "+angkatan);
        
        System.out.println (" jumlah karakter anda = " +nama.length());
        System.out.println (" jumlah karakter anda = " +nim.length());
        System.out.println (" jumlah karakter anda = " +fakultas.length());
        System.out.println (" jumlah karakter anda = " +jurusan.length());
        System.out.println (" jumlah karakter anda = " +angkatan.length());
    }
    public static void main(String[] args) {
        Scanner pembaca = new Scanner (System.in);
        Mahasiswa mhs1 = new Mahasiswa ();
        System.out.println (" nama anda = ");
        mhs1.nama = pembaca.next();
        System.out.println (" nim anda = ");
        mhs1.nim = pembaca.next();
        System.out.println (" fakultas anda = ");
        mhs1.fakultas = pembaca.next();
        System.out.println ("jurusan anda = ");
        mhs1.jurusan = pembaca.next();
        System.out.println (" angkatan anda = ");
        mhs1.angkatan = pembaca.next();
        mhs1.cetak();
        
        
    }
}
