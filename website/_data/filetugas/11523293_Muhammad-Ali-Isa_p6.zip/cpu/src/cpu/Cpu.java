/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cpu;

/**
 *
 * @author Praktikan
 */
public class Cpu {

    /**
     * @param args the command line arguments
     */
    private String Produksi;
    private Ram r;
    private Processor p;

    public Cpu(String Produksi){
        this.Produksi = Produksi;
        if (Produksi.equals("1")) {
            p = new Processor("hitam","Windows");
            r = new Ram("256");
        }

    }

    public void Tampil() {
        // TODO code application logic here
        
        System.out.println("Kode produksi   : " + Produksi);
        System.out.println("Warna processor :" + p.warna);
        System.out.println("Merk processor  :" + p.merk);
        System.out.println("Kapasitas RAM   :" + r.kapasitas + "MB");
    }
    public static void main(String[] args) {
        Cpu cpu1 = new Cpu("1");
        cpu1.Tampil();
    }
}
