/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cpu;

/**
 *
 * @author Praktikan
 */
public class Processor {

    private static class merk {

        public merk() {
        }
    }
    String warna, merk;
    Ram ram;

    public Processor(String warna, String merk) {
        this.warna = warna;
        this.merk = merk;
    }
}
