
package postes3;
 import java.util.Scanner;
public class mahasiswa {
    String nama;
    String nim;
   
    void    cetak(){
        
        System.out.println("nama anda adalah = "+nama);
        System.out.println("nim anda adalah = "+nim);

    }
    
    public static void main(String[] args) {
        
    mahasiswa mhs = new mahasiswa();
    mhs.nama ="Prasetyo sieskayadi";
    mhs.nim  ="10523134";
    mhs.cetak();
   
    
    
        
    }
    
}

