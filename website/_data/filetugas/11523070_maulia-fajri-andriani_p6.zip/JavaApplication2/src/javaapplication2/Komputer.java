/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author Praktikan
 */
public class Komputer {
    String jenisKomputer;
    Prosesor P;
    Ram R;
    
    public Komputer(String J, String mr, int sp, String jn, int hg){
        this.jenisKomputer = J;
        P = new Prosesor (mr, sp);
        R = new Ram (jn, hg);
      
    }

    public void tampil(){
        System.out.println("jenis komputer : "+jenisKomputer);
        System.out.println("merek prossor : "+P.merek);
        System.out.println("speed prosesor : "+P.speed);
        System.out.println("jenis RAM : "+R.jenisRam);
        System.out.println("harga RAM : "+R.hargaRam);
    }
    
    public static void main(String[] args) {
        Komputer k = new Komputer("server", "intel", 30, "abcd", 100000);
        k.tampil();
    }
    
    }
