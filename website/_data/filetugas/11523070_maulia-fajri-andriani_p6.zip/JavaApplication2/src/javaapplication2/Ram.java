/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author Praktikan
 */
public class Ram {
    String jenisRam;
    int hargaRam;
                      
    public Ram(String jn, int hg) {
       this.jenisRam = jn;
       this.hargaRam = hg;
    }
    
}
