/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author Praktikan
 */
public class Prosesor {
    String merek;
    int speed;

    public Prosesor(String mr, int sp) {
        this.merek = mr;
        this.speed = sp;
    }
    
    
}
