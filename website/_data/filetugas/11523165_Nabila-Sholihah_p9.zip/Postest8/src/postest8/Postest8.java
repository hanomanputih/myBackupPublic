/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest8;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Postest8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String nama = sc.nextLine();
        String nim = sc.nextLine();

        List list1 = new ArrayList();
        list1.add(nama);
        list1.add(nim);
        for (int i = 0; i < list1.size(); i++) {
            System.out.println("index" + i + " : " + list1.get(i));
        }

        System.out.println("==============================");
        for (Object s : list1) {
            System.out.println(s);
        }

        System.out.println("===============================");
        Iterator<String> ite = list1.iterator();
        while (ite.hasNext()) {
            String s = ite.next();
            System.out.println(s);
        }

        System.out.println("===============================");
        System.out.println(list1);

        Map<Integer, String> map = new HashMap<Integer, String>();
        map.put(1, nama);
        map.put(2, nim);

        System.out.println(map.get(11));
        System.out.println("=======================");
        for (Integer i : map.keySet()) {
            System.out.println("key" + i + " : " + map.get(i));
        }
            for (Map.Entry<Integer, String>entry : map.entrySet()) {
                System.out.println(entry.getKey() + ". "+entry.getValue());
            }
        
    }
}
