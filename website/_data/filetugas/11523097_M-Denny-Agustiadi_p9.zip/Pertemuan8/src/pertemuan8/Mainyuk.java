/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan8;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author PRAKTIKAN
 */
public class Mainyuk {
    public static void main (String[] args){
        Map<Integer, String> map = new HashMap<Integer, String>();
        
        map.put(1523097, "denny");
        map.put(22, "orang2");
        map.put(33, "orang3");
        
        System.out.println(map.get(11));
        System.out.println("===========");
        for (Integer i : map.keySet()){
            System.out.println("key"+i+":"+map.get(i));
            
        }
    }
}
