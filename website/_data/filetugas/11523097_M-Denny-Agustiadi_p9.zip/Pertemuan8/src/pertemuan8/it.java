/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan8;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author PRAKTIKAN
 */
public class it {
    public static void main(String[] args) {
        Map<Integer, String> m=new HashMap<Integer, String>();
        m.put(11,"gh" );
    }
    
}
