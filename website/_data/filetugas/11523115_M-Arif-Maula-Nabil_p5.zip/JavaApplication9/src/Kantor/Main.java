/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Kantor;

/**
 *
 * @author PRAKTIKAN
 */
public class Main {
    public static void main(String[] args) {
        Karyawan k = new Karyawan ();
        k.setNip("11523115");
        k.setNama ("MauL");
        k.setGaji(50000000);
                System.out.println("NIP Anda:"+k.getNip());
                System.out.println("Nama Anda:"+k.getNama());
                System.out.println("Gaji Anda : "+k.getGaji());
    }
}