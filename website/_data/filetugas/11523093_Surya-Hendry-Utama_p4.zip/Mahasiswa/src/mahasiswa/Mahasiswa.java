/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {

    String nama, nim, fakultas, jurusan, angkatan;
    /**
     * @param args the command line arguments
     */
    
    void cetak()
    {   System.out.println();
        System.out.println("====OUTPUT====");
        System.out.println("Nama : "+nama);
        System.out.println("NIM : "+nim);
        System.out.println("Fakultas : "+fakultas);
        System.out.println("Jurusan : "+jurusan);
        System.out.println("Angkatan : "+angkatan);
    }
    public static void main(String[] args) {
        // TODO code application logic here
        Mahasiswa mhs = new Mahasiswa();
        System.out.print("Masukkan Nama : ");
        Scanner sc = new Scanner(System.in);
        mhs.nama=sc.next();
        System.out.print("Masukkan NIM : ");
        mhs.nim=sc.next();
        System.out.print("Masukkan Nama Fakultas : ");
        mhs.fakultas=sc.next();
        System.out.print("Masukkan Nama Jurusan : ");
        mhs.jurusan=sc.next();
        System.out.print("Angkatan : ");
        mhs.angkatan=sc.next();
        
        
        mhs.cetak();
        
        
    }
}
