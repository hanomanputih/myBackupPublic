/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author Praktikan
 */
public class PostTest {

    public static void main(String[] args) {
        Map<String, String> mhs = new HashMap<String, String>();


        mhs.put("jakal no.8", "Yoni");
        mhs.put("jakal no.10", "Dani");
        mhs.put("jakal no.44", "Bogi");

        for (Map.Entry<String, String> e : mhs.entrySet()) {
            System.out.println(e.getKey() + "," + e.getValue());
        }
        System.out.println("+++++++++++++++++++++++++++++++++");
        System.out.println(mhs.get("jakal no.44"));

        }
    }
