/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttestterakhirhaha;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Praktikan
 */
public class PostTestTerakhirHAHA {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        List <String> list1 = new ArrayList <String>();
        List <Integer> list2 = new ArrayList <Integer>();
        
        list1.add ("Ayuda");
        list1.add ("Hafni");
        list1.add ("Nyingaut");
        
        list2.add (11523012);
        list2.add (11523018);
        list2.add (11523036);
        
        System.out.println(list1);
        
        for (int i =0; i < list1.size(); i++) {
            System.out.println(list1.get(i) + " " + list2.get(i));
        }
        
        System.out.println("*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*");
        
        Map <Integer, String> map = new HashMap <Integer, String> ();
        
        map.put (11523012, "Ayuda");
        map.put (11523018, "Hafni");
        map.put (11523036, "Nyingaut");
        
        for (Integer i : map.keySet()) {
        System.out.println("NIM " +i+ " : " + map.get(i));
        }
    }
}
