/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes8;

import java.util.Map;
import java.util.HashMap;

/**
 *
 * @author Praktikan
 */
public class Main {

    public static void main(String[] args) {

        Map<String, String> mhs = new HashMap<String, String>();

        mhs.put("Degolan", "Andi");
        mhs.put("Jalan Kaliurang Km 12", "Indra");
        mhs.put("Jalan Kaliurang Km 14,5", "Ivan");
    
    
       for(Map.Entry<String, String> e: mhs.entrySet ()){
        
        System.out.println(e.getKey() + " ," + e.getValue());
        //System.out.println("Jalan Kaliurang Km 14,5");

       }
           System.out.println(mhs.get("Jalan Kaliurang Km 14,5"));

    }

}
