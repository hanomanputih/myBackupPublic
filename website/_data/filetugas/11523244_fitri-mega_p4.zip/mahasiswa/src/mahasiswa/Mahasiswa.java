/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;
import java.util.Scanner;
/**
 *
 * @author praktikan
 */
public class Mahasiswa {
    String nama;
    String nim;
    String fakultas;
    String jurusan;
    String angkatan;
    
    void cetak(){
    Scanner diri=new Scanner(System.in);
        System.out.println("masukkan nama :");
        nama=diri.nextLine();
        System.out.println("masukkan nim:");
        nim=diri.nextLine();
        System.out.println("masukkan nama fakultas:");
        fakultas=diri.nextLine();
        System.out.println("masukkan nama jurusan:");
        jurusan=diri.nextLine();
        System.out.println("masukkan angkatan anda:");
        angkatan=diri.nextLine();
        
        System.out.println("nama anda adalah "+nama);
        System.out.println("nim anda adalah "+ nim);
        System.out.println("angkatan tahun "+angkatan);
        System.out.println("fakultas "+ fakultas);
        System.out.println("jurusan "+jurusan);
                
                
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Mahasiswa mhs=new Mahasiswa();
        mhs.cetak();
        int hasil=mhs.nama.length();
        int hasil1=mhs.nim.length();
        int hasil2=mhs.angkatan.length();
        int hasil3=mhs.fakultas.length();
        int hasil4=mhs.jurusan.length();
        int hasil5;
        
        hasil5=hasil+hasil1+hasil2+hasil3+hasil4;
        System.out.println("banyak karakter nama anda adalah:"+hasil);
        System.out.println("total jumlah karakter yang anda masukkan:"+hasil5);
    }
}
