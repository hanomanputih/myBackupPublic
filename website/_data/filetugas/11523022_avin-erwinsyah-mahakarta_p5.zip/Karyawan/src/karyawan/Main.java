/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class Main {
    public static void main(String[] args) {
        Karyawan k = new Karyawan ();
        k.setNip("11523022");
        System.out.println("nip anda :"+k.getNip());
        k.setNama("erwin");
        System.out.println("nama anda :"+k.getNip());
        k.setGaji(500000);
        System.out.println("gaji anda :"+k.getGaji()*12);
        
      
    }
    
}
