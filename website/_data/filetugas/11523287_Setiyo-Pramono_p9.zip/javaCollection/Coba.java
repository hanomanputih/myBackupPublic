package javaCollection;

import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Kuzoema
 */
public class Coba {
    private static void loadData(List<String> list){
        list.add("nool");
        list.add("siji");
    }
    private static void tampilkanList(List<String> list){
        for (int i =0 ; i<list.size();i++){
            System.out.print(list.get(i)+" ");
        }
        System.out.println();
    }
    public static void main(String[] args) {
        List<String> list = new ArrayList<>();
        loadData(list);
        tampilkanList(list);
        System.out.println("list index ke 1= "+ list.get(1));
    }
}
