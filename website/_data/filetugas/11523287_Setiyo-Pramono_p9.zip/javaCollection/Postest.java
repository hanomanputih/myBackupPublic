package javaCollection;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
/**
 *
 * @author Kuzoema
 */
public class Postest {
    String nama;
    int nim;
    
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        List list = new ArrayList();
        System.out.print("Nama : ");
        list.add(scan.next());
        System.out.print("Nim  : ");
        list.add(scan.nextInt());      
        
        for (Iterator <String> iterator = list.iterator(); iterator.hasNext();){
            String isi = iterator.next();
            System.out.println(isi);
            System.out.println("index ke -2 "+list.get(1));
            
            HashMap map = new HashMap();
            map.put("Nama", "Gue");
            map.put("NIM", new Integer(1234567));
            System.out.println("ukuran "+map.size());
            System.out.println(map.get("Nama"));
            System.out.println(map.get("NIM"));
            
            boolean containKey = map.containsKey("Nama");
            
            System.out.println("Has Key (NIM) : "+containKey);            
        }
    }
}
