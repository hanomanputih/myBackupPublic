package javaCollection;

import java.util.HashMap;
/**
 *
 * @author Kuzoema
 */
public class HasMap {
    public static void main(String[] args) {
        HashMap map = new HashMap();
        map.put("Nama ","Gue");
        map.put("NIM ", new Integer(123456));
        System.out.println(map);
        System.out.println(map.size());
        boolean containKey = map.containsKey("NIM");
        System.out.println(containKey);
    }
}
