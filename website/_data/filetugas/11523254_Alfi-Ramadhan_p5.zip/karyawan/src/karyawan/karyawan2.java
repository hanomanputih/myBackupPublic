/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package karyawan;

/**
 *
 * @author praktikan
 */
public class karyawan2 {
    public static void main(String[] args) {
        karyawan k = new karyawan ();
        k.setNama("alfi ramadhan");
        k.setNip("11523254");
        k.setGaji(400000);

        System.out.println("nama : "+k.getNama());
        System.out.println("nip :"+k.getNip());
        System.out.println("gaji : "+k.getGaji());
    }

}
