/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package karyawan;

/**
 *
 * @author praktikan
 */
public class karyawan {
    private String nip;
    private String nama;
    private int gaji;

    void setNama (String nm){
        nama = nm;
        if (nm.length() == 8){
            System.out.println(nama);
    }else{
            System.out.println("nama tidak sesuai");
    }

    }
    String getNama(){
        return nama;
    }
    void setNip (String np){
        nip = np;
        if (np.length() == 10){
            System.out.println(nip);
        }else{
            System.out.println("nim tidak sesuai");
        }
    }
    String getNip (){
        return nip;
    }
    void setGaji (int gj){
        gaji = gj;
        if (gj >= 100000 && gj <=500000){
            System.out.println(gaji);
        }else{
            System.out.println("gaji anda");
        }

    }
    int getGaji (){
        return gaji;
    }


    

}
