/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest4;

/**
 *
 * @author Praktikan
 */
public class Karyawan {

    private String nip;
    private String nama;
    private int gaji = 2000000;

    public void getNip(String nip) {
        this.nip = nip;

    }

    public String setNip() {
        this.nip= nip;
        return nip;
    }

    public void getNama(String nama) {

        this.nama = nama;
    }

    public String setNama() {

        this.nama = nama;
        return nama;
    }

    public void getGaji(int gaji) {
      this.gaji=gaji;
    }

    public int setGaji() {
          this.gaji = 12 * gaji;

        return gaji;
    }
}
