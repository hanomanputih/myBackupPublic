/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest4;

/**
 *
 * @author Praktikan
 */
public class Postest4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Karyawan k = new Karyawan();
        k.getNip("11523133");
        System.out.println("nip karyawan adalah : " +k.setNip());
        k.getNama("susofernandez");
        System.out.println("nama karyawan adalah " +k.setNama());
        k.getGaji(3000000);
        System.out.println("gaji karyawan adalah "  +k.setGaji());
        
    
    }
}
