
package karyawan;


public class Main {
    public static void main(String[] args) {
       Karyawan krywn = new Karyawan();
       
       krywn.setNip("11523114");
       krywn.setNama("Adhya Pranata ");
       krywn.setGaji(2500000);
       System.out.println("NIP Karyawan : "+krywn.getNip());
       System.out.println("Nama Karyawan : "+krywn.getNama());
       System.out.println("Gaji Karyawan : Rp "+krywn.getGaji());
    }
}
