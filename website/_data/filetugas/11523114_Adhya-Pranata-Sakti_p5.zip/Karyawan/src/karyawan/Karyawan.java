
package karyawan;


public class Karyawan {
    private String nip;
    private String nama;
    private int gaji;
    
    
    public void setNip(String newNip){
        nip = newNip;
    }
    
    public void setNama(String newNama){
        nama = newNama;
    }
    
    public void setGaji(int newGaji){
        gaji = newGaji;
    }
    
    public String getNip(){
        return nip;
    }
    
    public String getNama(){
        return nama;
    }
    
    public int getGaji(){
        return gaji;
    }
}
