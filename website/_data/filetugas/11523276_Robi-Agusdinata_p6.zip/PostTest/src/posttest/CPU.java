/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author Praktikan
 */
public class CPU {
    int nomerProduksi;
    Prosesor namapros;
    RAM ukuran;
    
    public CPU(int nom){
       nomerProduksi= nom;
        if(nom == 1){
            namapros = new Prosesor("AMD");
            ukuran = new RAM(512);
        }
    }
    public void muncul(){
        System.out.println(namapros.namaProsesor);
        System.out.println(ukuran.UkuranRam);
    }
    
}
