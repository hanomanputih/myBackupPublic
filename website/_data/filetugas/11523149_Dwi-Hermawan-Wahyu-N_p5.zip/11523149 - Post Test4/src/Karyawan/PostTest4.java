/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Karyawan;

/**
 *
 * @author PRAKTIKAN
 */
public class PostTest4 {
    private String nip,nama;
    private int gaji;
   
    
    void setNIP(String np) {
        if (np.length() <= 8){
        nip = np;
        } else {
            System.out.println("maaf Error");
        }}
    
    String getNIP (){
        return nip;
    }
    
    void setNama (String nm) {
        if (nm.length() == 11){
        nama = nm;
    } else {
            System.out.println("maaf Error");
        }}
    
    String getNama (){
        return nama;
        }
    
    void setGaji (int gj){
        gj = 1000000;
        gaji = gj;
            
}
    
    int getGaji (){
        return gaji;
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
}
