/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Karyawan;

/**
 *
 * @author PRAKTIKAN
 */
public class Pemanggil {
    public static void main (String[] args){
     
        PostTest4 pt = new PostTest4 ();
        
        pt.setNIP ("11523149");
        pt.setNama("DwiHermawan");
        pt.setGaji(1000000);
        
        System.out.println("Nip "+pt.getNIP());
        System.out.println("Nama "+pt.getNama());
        System.out.println("Gaji "+pt.getGaji());
        System.out.println("Gajisetahun "+pt.getGaji()*12);
    }
}
