/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author praktikan
 */
public class aksesKaryawan {
    public static void main (String [] args){
    Karyawan k = new Karyawan ();
    k.setGaji(200000000);
    k.setNama("Bachtiar");
    k.setNip("11523058");
    System.out.println("Gaji setahun anda = " + k.getGaji());
    System.out.println("Nama karyawan = " + k.getNama());
    System.out.println("NIP kayawan = " + k.getNip());    
    
}
}