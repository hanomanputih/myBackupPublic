
package posttest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public class Posttest {

    public static void loadData(List<String>list) {
           list.add("\nNama : Egne"+
                    "\nNIM : 11523108");
            list.add("\nNama : Adrin"+
                   "\nNIM : 11523088");
            list.add("\nNama : Metri"+
                   "\nNIM : 11523034");
    }
    private static void tampilkanList(List<String>list) {
       for (int i = 0; i < list.size(); i++) {
          System.out.println(list.get(i)+" ");
        }
      System.out.println();
    }
    public static void main (String[]args) {
        List<String> list = new ArrayList<String>();
        loadData(list);
        tampilkanList(list);
        System.out.println("list di index ke 2 = "+ list.get(1));
        
        for (Iterator<String>iterator = list.iterator();
        iterator.hasNext();) {
        String isi = iterator.next();
        System.out.println(isi);
    }
        
        System.out.println("=================================");
        HashMap map = new HashMap();
        map.put("Nama ", "Egne");
        map.put("NIM ", new Integer(11523108));
        map.put("Nama ", "Adrin");
        map.put("NIM ", new Integer(11523088));
        map.put("Nama ", "Metri");
        map.put("NIM ", new Integer(11523034));
        System.out.println("nim "+map.get("NIM "));
 
    }
    
    
}
