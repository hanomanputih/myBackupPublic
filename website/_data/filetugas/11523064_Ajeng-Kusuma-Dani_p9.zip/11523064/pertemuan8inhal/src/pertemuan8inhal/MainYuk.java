/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan8inhal;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

/**
 *
 * @author Praktikan
 */
public class MainYuk {
    public static void main(String[] args) {
        Map<Integer, String> m=new HashMap<Integer, String> ();
        
        m.put(11523063, "tioh");
        m.put(11523064, "ajenk");
        m.put(11523088, "adrin");
        System.out.println(m );
        System.out.println(m.get(3));
        
        for(String i : m.values()){
            System.out.println(i);
        }
        
        for(Integer i : m.keySet()){
            System.out.println(m.get(i));
        }
        
        Iterator<Entry<Integer,String>> it=m.entrySet().iterator();
        while(it.hasNext()){
            System.out.println(it.next());
        }
    }
}
