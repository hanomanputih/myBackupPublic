package enkapsulasi;

public class Main {
    public static void main(String[] args) {
        Karyawan k = new Karyawan();

        k.setNama("Ito");
        k.setNip("MGR0987512");
        k.setGaji(1000);

        System.out.println("Nama : "+k.getNama());
        System.out.println("Nip  : "+k.getNip());
        System.out.println("Gaji : "+k.getGaji()+"$");
    }
}
