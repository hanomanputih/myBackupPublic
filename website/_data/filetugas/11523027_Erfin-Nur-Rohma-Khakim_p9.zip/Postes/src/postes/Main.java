/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Main {
    public static void main(String[] args) {
        List<String> mhs = new ArrayList<String>();
        Map<Integer,String> mhsw = new HashMap<Integer,String>();
        Scanner sc = new Scanner(System.in);
        String nim,nama;
        System.out.print("NIM : ");
        nim=sc.nextLine();
        System.out.print("Nama : ");
        nama=sc.nextLine();
        
        mhs.add(nim);
        mhs.add(nama);
        
        mhsw.put(1, nim);
        mhsw.put(2, nama);
        
        System.out.println("");
        System.out.println("Menampilkan List dengan iterator");
        Iterator it = mhs.iterator();
        while (it.hasNext()) {
            System.out.println(it.next());
        }
        
        System.out.println("");
        System.out.println("Menampilkan Map");
        for(Map.Entry<Integer,String> ee : mhsw.entrySet()) {
            System.out.println(ee.getKey()+". "+ee.getValue());
        }
        
        System.out.println("");
        System.out.println("Indeks List dan Map");
        System.out.println("Indeks kedua List "+mhs.get(1));
        System.out.println("Indeks kedua Map "+mhsw.get(2));
        
        
    }
}
