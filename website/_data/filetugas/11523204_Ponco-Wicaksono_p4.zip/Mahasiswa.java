/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Scanner;

public class Mahasiswa {
    String nama, nim;
    int jumlah;
    public void cetak(){}
    
    public static void main(String[]args){
        Mahasiswa pewek = new Mahasiswa();
        Scanner baca = new Scanner (System.in);
        System.out.println("masukan nama anda: ");
        pewek.nama = baca.next();
        pewek.jumlah = pewek.nama.length();
        System.out.println("Panjang karakter nama anda: "+pewek.jumlah);
        System.out.println("masukan nim anda: ");
        pewek.nim = baca.next();
        pewek.jumlah = pewek.nim.length();
        System.out.println("Panjang karakter nim anda: "+pewek.jumlah);
        
        }  
    }

