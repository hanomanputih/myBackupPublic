
package javaapplication26;
import java.util.Collection;
import java.util.HashMap;
import java.util.Set;
public class Main {
     public static void main(String[] args) {
        HashMap map = new HashMap();
map.put("Nama","amat");
map.put("NIM",new Integer(01523165));
map.put("Alamat", "magelang");
System.out.println("Ukuran Map : "+map.size());
map.put("Email", "alibaba@yahoo.com");
Object email = map.get("Email");
System.out.println("Email nya : "+email);
boolean containKey = map.containsKey("NIM");
System.out.println("Has key (NIM): "+containKey);

        Object removed = map.remove("NIM");
System.out.println("Removed : "+removed);
System.out.println("Size baru : "+map.size());
Set set = map.keySet();
System.out.println("Key Set size: "+set.size());
boolean removedFromSet = set.remove("Alamat");
System.out.println("Alamat: "+removedFromSet);
System.out.println("Size: "+map.size());
Collection values = map.values();
System.out.println("Collection size: "+values.size());
     }
}