/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perusahaan;

/**
 *
 * @author Praktikan
 */
public abstract class Karyawan {
    protected int gajipokok = 2000000;
    protected int bonus;
    
    public abstract void view();
    
}
