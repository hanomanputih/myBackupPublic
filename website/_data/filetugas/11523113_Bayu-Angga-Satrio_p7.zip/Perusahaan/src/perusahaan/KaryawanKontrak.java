/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perusahaan;

/**
 *
 * @author Praktikan
 */
public class KaryawanKontrak extends Karyawan{

    @Override
    public void view(){
        double gaji = gajipokok+bonus;
        System.out.println("Gaji Karyawan Kontrak: "+gaji);        
    }
    
}
