/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perusahaan;

/**
 *
 * @author Praktikan
 */
public class KaryawanTetap extends Karyawan{
    double tunjangan=gajipokok*20/100;

    @Override
    public void view() {      
        double gaji = tunjangan+gajipokok+bonus;
        System.out.println("Gaji Karyawan Tetap: "+gaji);
    }
    
}
