/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest4;

/**
 *
 * @author PRAKTIKAN
 */
public class Utama {
    public static void main(String[] args) {
        Karyawan ka=new Karyawan();
        ka.setNIP("11523292");
        ka.setNama("rizky");
        ka.setGaji(300000);
        
        System.out.println("NIP:"+ka.getNIP());
        System.out.println("Nama:"+ka.getNama());
        System.out.println("Gaji:"+ka.getGaji());
        
    }
}
