/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest4;

/**
 *
 * @author PRAKTIKAN
 */
public class Karyawan {
private String nip;
private String nama;
private int gaji;

void setNIP(String nip){
    if(nip.length()==8){
        this.nip=nip;
    }else{
        System.out.println("error");
    }
}

void setNama(String nama){
    if(nama.length()==5){
        this.nama=nama;
    }else{
        System.out.println("eror");
    }
}

void setGaji(int gaji){
    if(gaji>=200000&&gaji<=10000000){
        this.gaji=gaji;
    }else{
        System.out.println("eror");
    }
}
String getNIP(){
    return nip;
}

String getNama(){
    return nama;
}

int getGaji(){
    return gaji;
}

}

    

