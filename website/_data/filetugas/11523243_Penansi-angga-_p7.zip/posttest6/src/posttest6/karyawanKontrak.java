/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package posttest6;

/**
 *
 * @author Praktikan
 */
public class karyawanKontrak extends karyawan {
    String nama = " Lek kemir ";
   

   
    public void gaji() {
        System.out.println ("Nama Karyawan Kontrak  " + nama);
        System.out.println("Gaji   "+(gajiPokok));
        System.out.println("Bonus "+bonus);
    }
     
}
