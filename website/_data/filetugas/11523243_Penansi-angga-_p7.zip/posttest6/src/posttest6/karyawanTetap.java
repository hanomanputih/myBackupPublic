/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package posttest6;

/**
 *
 * @author Praktikan
 */
public class karyawanTetap extends karyawan {
    String nama =" bang roni";
    double tunjangan = (0.2 * gajiPokok);
    
    public void gaji() {
        System.out.println ("Nama Karyawan Tetap  " + nama);
         System.out.println("Gaji "+gajiPokok);
         System.out.println("Tunjangan "+tunjangan);
         System.out.println("Bonus "+bonus);
    }
}

