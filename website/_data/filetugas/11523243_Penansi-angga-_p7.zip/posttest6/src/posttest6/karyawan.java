

package posttest6;

/**
 *
 * @author Praktikan
 */
public abstract class karyawan {
    int gajiPokok =  3000000;
    int bonus = 200000 ;
    
    public abstract void gaji();
}


   

