/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author Praktikan
 */
public class Posttest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        karyawan kry=new karyawan();
        
        kry.setNIP ("11523055");
        kry.setNAMA ("ilham");
        kry.setGAJI(5000000);
        System.out.println("NIP :"+kry.getNIP());
        System.out.println("Nama :"+kry.getNAMA());
        System.out.println("Gaji :"+kry.getGaji());
    }
}
