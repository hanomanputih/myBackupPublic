/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author Praktikan
 */
public class karyawan {
private String nip;
private String nama;
private int gaji;

    public void setNIP(String nip){
        this.nip = nip;
    }
    public void setNAMA(String nama){
        this.nama = nama;
}
    public void setGAJI(int gaji){
        this.gaji = gaji;
    }
    public String getNIP(){
    return nip;
    }
    public String getNAMA(){
    return nama;
}
    public int getGaji(){
return gaji;
    }
}