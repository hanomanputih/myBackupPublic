/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class MainKomputer {
    Ram ram;
    Processor pro;

    public MainKomputer(Ram ram,Processor pro) {
        this.ram=ram;
        this.pro=pro;
    }
    
    public static void main(String[] args) {
        Ram ra = new Ram("4GB");
        Processor pr = new Processor("Erfin"); 
        MainKomputer main=new MainKomputer(ra, pr);
        System.out.println("Ukuran : "+main.ram.size);
        System.out.println("Merk : "+main.pro.merk);
    }
}
