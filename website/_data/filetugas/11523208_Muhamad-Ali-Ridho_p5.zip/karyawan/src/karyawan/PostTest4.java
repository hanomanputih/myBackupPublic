/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package karyawan;

/**
 *
 * @author praktikan
 */
public class PostTest4 {

    private String nip;
    private String nama;
    private int gaji;

    void setNIP(String nipKamu){
    if (nipKamu.length()== 8){
        nip=nipKamu;
    }else{
        System.out.println("eror");
    }
    }
   String getNIP(){
    return nip;
}

   void setNAMA(String newnama){
    nama = newnama;
    }
   String getNAMA(){
    return nama;
}

   void setGAJI(int gajiKamu){
    gaji= gajiKamu*12;
    if (gaji>0){
        gaji= gajiKamu*12;
    }else {
        System.out.println("gaji tidak real");
        gaji=0;
    }
    }
   int getGAJI(){
    return gaji;
}
    public static void main(String[] args) {
       
    }

}
