/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package karyawan;

/**
 *
 * @author praktikan
 */

public class main {
    
    public static void main(String[] args) {
    PostTest4 karyawan = new PostTest4 ();
    karyawan.setNIP("11523208");
    System.out.println("NIP anda adalah "+karyawan.getNIP());
    karyawan.setNAMA("MUHAMAD ALI RIDHO");
    System.out.println("NAMA anda adalah "+karyawan.getNAMA());
    karyawan.setGAJI(-5000000);
    System.out.println("GAJI pertahun anda adalah "+karyawan.getGAJI());

    }
}