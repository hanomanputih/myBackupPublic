/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

public class main {
    public static void main(String[] args) {
    Karyawan saya = new Karyawan ();
    saya.setNip("11523295");
    System.out.println("NIP : "+saya.getNip());
    saya.setNama("Rizky");
    System.out.println("NANA    : "+saya.getNama());
    saya.setGaji(6000);
    System.out.println("GAJI    : "+saya.getGaji());
}
    
}
