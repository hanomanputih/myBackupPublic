/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa1;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa1 {
String nama, nim, jurusan, angkatan,fakultas;

void cetak(){
    Scanner tampil= new Scanner (System.in);
    Scanner tampil1= new Scanner (System.in);
    System.out.println("Nama:");
    nama=tampil.next();
    System.out.println("Nim:");
    nim=tampil.next();
    System.out.println("Jurusan:");
    jurusan=tampil1.nextLine();
    System.out.println("angkatan:");
    angkatan=tampil.next();
    System.out.println("Fakultas:");
    fakultas=tampil.next();
        
}
void tampil(){
    System.out.println("Nama:"+nama);
    System.out.println("Nim:"+nim);
    System.out.println("Jurusan:"+jurusan);
    System.out.println("Angkatan:"+angkatan);
    System.out.println("Fakultas:"+fakultas);
    
}

    public static void main(String[] args) {
        Mahasiswa1 mhs1= new Mahasiswa1();
        mhs1.cetak();
        mhs1.tampil();
    }
}
