/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author Praktikan
 */
public class PostTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        List nama = new ArrayList();
        List alamat = new ArrayList();
        
            nama.add("joko");
             nama.add("budi");
            
            
            alamat.add ("jlan raya");
            alamat.add ("jlan budo");
            
            
            Iterator it = nama.iterator();
            while(it.hasNext()){
            System.out.println(it.next());
            
            
            }
            
        Map<String,String> mhs = new HashMap<String,String>();
        mhs.put("joko","jalan raya");
        mhs.put("budi","jalan budo");
        
        for(Map.Entry<String,String> e : mhs.entrySet()){
            
            System.out.println(e.getKey()+"  , "+e.getValue());
        }
        
         System.out.println(mhs);
        
        System.out.println(mhs.get ("joko"));
        
        
    }
}

