/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class Komputer {
    String jenisKomputer;
    String warna;
    Prosesor P;
    Ram R;
    
    
    public Komputer(String J,String U,String p,String r,String s){
        this.jenisKomputer = J;
        this.warna = U ;
        P = new Prosesor(p);
        R = new Ram(r,s);

    }
    
    public void Display(){
    
        System.out.println("Jenis komputer: "+jenisKomputer);
        System.out.println("Warna Komputer : "+warna);
        System.out.println("Merek Prosesor: "+P.nama);
        System.out.println("Jenis Ram: "+R.jenis);
        System.out.println("Ukuran Ram : "+R.ukuran);
           
    }
    
    
    public static void main(String[] args) {
    Komputer kompi = new Komputer("IBM","Hitam","intel","ddr3","3gb");
    
    kompi.Display();
    
    }
}
