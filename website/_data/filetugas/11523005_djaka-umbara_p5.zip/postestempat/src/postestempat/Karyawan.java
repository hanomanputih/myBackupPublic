/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postestempat;

/**
 *
 * @author Praktikan
 */
public class Karyawan {
    private String nama,nip;
    private int gaji;
    
   public void setnip (String NIP){
       this.nip = NIP;
           
   }
   public void setnama (String Nama){
       this.nama = Nama ;
   }
   public void setgaji ( int Gaji){
       this.gaji = Gaji ;
   }
   
   public String getnip (){
       return nip;
   }
   public String getnama (){
       return nama;
   }
   public int getgaji (){
        int gajihsetahun;
        gajihsetahun = gaji * 12 ;
       return gajihsetahun ;
   }
   
   
    
}
