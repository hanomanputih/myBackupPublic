/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postestempat;

/**
 *
 * @author Praktikan
 */
public class Postestempat {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Karyawan wan = new Karyawan();
        wan.setnip("11523005");
        System.out.println("nip nya "+wan.getnip());
        wan.setnama("djakaaa");
        System.out.println("namanya "+wan.getnama());
        wan.setgaji(1000000);
        System.out.println("gajih setahun "+wan.getgaji());
    }
}
