/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;
import java.util.Scanner;
/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
int panjang;
    String nama, nim, fakultas, jurusan, angkatan,cetak; 
    public static void main(String[] args) {
        Mahasiswa m = new Mahasiswa();
        Scanner sc = new Scanner(System.in);
        System.out.println("masukkan nama anda : ");
       m.nama=sc.next();
          System.out.println("masukkan nim anda : ");
       m.nim=sc.next();
          System.out.println("masukkan fakultas anda : ");
       m.fakultas=sc.next();
          System.out.println("masukkan jurusan anda : ");
       m.jurusan=sc.next();
          System.out.println("masukkan tahun angkatan anda : ");
       m.angkatan=sc.next();
    m.cetak= m.nama + m.nim + m.fakultas +m.jurusan+ m.angkatan;
    m.panjang = m.cetak.length();
       System.out.println("panjang karakter: "+m.panjang); 
    }
}