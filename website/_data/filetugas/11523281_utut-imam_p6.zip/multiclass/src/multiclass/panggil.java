/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package multiclass;

/**
 *
 * @author Praktikan
 */
public class panggil {
 public static void main (String[] args){
    RAM panggil = new RAM();
    panggil.setKapasitas(89);
    PROSESOR LAJU = new PROSESOR();
    LAJU.setJenis("IYA");
    komputer thoshiba = new komputer (panggil,LAJU);
     System.out.println("thoshiba " + thoshiba.getRam1().getKapasitas());
    
 }   
}
