/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package multiclass;

/**
 *
 * @author Praktikan
 */
public class komputer {
  private String merk;
  private int idProduk;
  private RAM ram1;
  private PROSESOR P;
  
   public komputer(RAM ram1,PROSESOR P){
   this.ram1 = ram1;
   this.P = P;
   
}


    public PROSESOR getP() {
        return P;
    }

    public void setP(PROSESOR P) {
        this.P = P;
    }

    public int getIdProduk() {
        return idProduk;
    }

    public void setIdProduk(int idProduk) {
        this.idProduk = idProduk;
    }

    public String getMerk() {
        return merk;
    }

    public void setMerk(String merk) {
        this.merk = merk;
    }

    public RAM getRam1() {
        return ram1;
    }

    public void setRam1(RAM ram1) {
        this.ram1 = ram1;
    }

}
