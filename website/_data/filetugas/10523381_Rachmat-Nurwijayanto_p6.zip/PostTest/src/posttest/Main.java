/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author Praktikan
 */
public class Main {
    
 public static void main(String[] args) {
    Prosesor ps = new Prosesor ("Core i3");
    RAM rm = new RAM("2 gb");
    Komputer comp = new Komputer ("pc", ps, rm);
    comp.tampil (ps, rm);
    }
}
