/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author Praktikan
 */
public class Komputer {
    String comp;
    Prosesor ps;
    RAM rm;
    
    public Komputer(String KomputerTerdiri, Prosesor ps, RAM rm){
        this.comp = KomputerTerdiri;
        this.ps = ps;
        this.rm = rm;
    }
            
    public void tampil (Prosesor ps, RAM rm){
        System.out.println("bentuk komputer : "+comp);
        System.out.println("Dengan Jenis Prosesor : "+ps.macam);
        System.out.println("Dengan Ukuran RAM : "+rm.ukuran);
    }
}
