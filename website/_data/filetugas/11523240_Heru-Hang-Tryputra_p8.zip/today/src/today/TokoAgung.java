/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package today;

/**
 *
 * @author Praktikan
 */
public class TokoAgung extends Swalayan{
    
    int belanja;
    
    public TokoAgung(int belanja)
    {
        this.belanja = belanja;
    }
    
    public void totalBayar()
    {
        if (this.belanja % 25 == 0) super.bayar = this.belanja;
        else 
        {
            super.sisa = this.belanja % 25;
            super.bayar = belanja - super.sisa;
        }
      
        System.out.println("Anda belanja di TokoAgung dan membayar " + super.bayar);
    }
}
