/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package today;

/**
 *
 * @author Praktikan
 */
public class IndoMart extends Swalayan{
    
    int belanja;
    
    public IndoMart(int belanja)
    {
        this.belanja = belanja;
    }
    
    public void totalBayar()
    {
        if (this.belanja % 25 == 0) super.bayar = this.belanja;
        else 
        {
            super.sisa = 25 - (this.belanja % 25);
            super.bayar = belanja + super.sisa;
        }
      
        System.out.println("Anda belanja di IndoMart dan membayar " + super.bayar);
    }
}
