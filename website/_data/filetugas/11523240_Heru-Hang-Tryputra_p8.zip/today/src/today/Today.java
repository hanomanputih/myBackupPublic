package today;

public class Today
{
    public static void main(String[] args)
    {
        Swalayan s;
        
        IndoMart im = new IndoMart(19242);
        s = im;
        s.totalBayar();
        
        TokoAgung ta = new TokoAgung(167212);
        s = ta;
        s.totalBayar();
    }
}
