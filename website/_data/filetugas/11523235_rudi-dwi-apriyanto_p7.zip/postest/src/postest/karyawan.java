/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

public abstract class karyawan {
    protected String nama;
    protected String nik;
    protected int gaji;
    protected int gajipokok;
    protected int  tunjangan;
    protected int bonus;
    
    public void lihat()
    {
        
        System.out.println("nama pegawai : "+nama);
        System.out.println("nomor induk pegawai :"+nik);
        System.out.println("gaji anda segini: "+gaji);
    }
    
    public abstract void bekerja();
    public abstract void kehadiran();
    
}