/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;


public class Postest {

    
    public static void main(String[] args) {
        ktetap kt = new ktetap();
        kt.nama = "Rudi Dwi A";
        kt.nik = "11523235";
        kt.gajipokok = 3000000;
        kt.tunjangan=kt.gajipokok*20/100;
        kt.bonus=500000;
        kt.gaji=kt.gajipokok+kt.bonus+kt.tunjangan;
        kt.setGajiktetap("karyawan tetap");
        kt.lihat();
        
        System.out.println("");
        kt.nama = "bejo";
        kt.nik = "47364";
        kt.gajipokok = 3000000;
        kt.bonus=500000;
        kt.gaji=kt.gajipokok+kt.bonus;
        kt.setGajiktetap("karyawan kontrak");
        kt.lihat();
        
        kt.bekerja();
        kt.kehadiran();
    }
}