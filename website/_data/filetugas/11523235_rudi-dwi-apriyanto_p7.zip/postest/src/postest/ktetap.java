/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

public class ktetap extends karyawan {

    private String kerja;

    public void setGajiktetap(String gajiktetap) {
        this.kerja = gajiktetap;
    }
    
    public String getGajiktetap() {
        return kerja;
    }

    public void bekerja() {
        System.out.println("bekerja sepatuh waktu");
    }

    
    public void kehadiran() {
        System.out.println("kehasdiran penuh");
    }

  
    public void lihat() {
        super.lihat();
        System.out.println("status kerja  :" + kerja);
    }
}