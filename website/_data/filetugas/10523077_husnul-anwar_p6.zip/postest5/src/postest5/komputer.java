/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest5;

/**
 *
 * @author PRAKTIKAN
 */
public class komputer {
    public ram r;
    public prosesor p;
    
   
    public komputer(){
        r = new ram();
        p = new prosesor();
        
    }
    
    public static void main(String[] args) {
        komputer k = new komputer();
        k.p = new prosesor();
        k.r = new ram();
        k.p.jenis = "hjd";
        k.r.memori = "10gb";
        
        

        System.out.println("spesifikasi komuter anda adalah "+ k.p.jenis+" "+k.r.memori);
    }
        
        
       
        
    }
    

