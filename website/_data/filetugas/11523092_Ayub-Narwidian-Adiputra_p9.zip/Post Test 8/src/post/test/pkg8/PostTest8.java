/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package post.test.pkg8;
import java.util.Map;
import java.util.HashMap;

/**
 *
 * @author PRAKTIKAN
 */
public class PostTest8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Map<String, String> mhs = new HashMap<String, String>();
        
        mhs.put("Batang", "Jono");
        mhs.put("Semarang", "Rudi");
        mhs.put("Purbalingga", "Polo");
        
        for(Map.Entry<String, String> e : mhs.entrySet()) {
            System.out.println(e.getKey()+","+e.getValue());
        }
        System.out.println("===================");
        System.out.println(mhs.get("Semarang"));
        
        // TODO code application logic here
    }
}
