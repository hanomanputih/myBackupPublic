/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest4;

/**
 *
 * @author Praktikan
 */
public class Karyawan {
    private String nip,nama;
    private int gaji;
    
    
    public void setNIP(String nip){  
        this.nip=nip;
    
    }
    
    String getNIP(){
        return nip;
    }
    
    public void setnama(String nama){  
        this.nama=nama;
    }
    
    String getnama(){
        return nama;
    }
    public void setgaji(int gaji){  
        this.gaji=gaji;
   }
    
    int getgaji(){
        return gaji;
    }

   
    

    
}
