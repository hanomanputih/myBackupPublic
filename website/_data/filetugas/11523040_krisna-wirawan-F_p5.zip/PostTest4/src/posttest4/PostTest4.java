/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest4;

/**
 *
 * @author Praktikan
 */
public class PostTest4 {

   
    public static void main(String[] args) {
        Karyawan kyn = new Karyawan();
        kyn.setNIP("11523040");
        kyn.setnama("Krisna");
        kyn.setgaji(5000000);
        System.out.println("NIP saya "+kyn.getNIP());
        System.out.println("Nama saya "+kyn.getnama());
        System.out.println("Gaji saya "+kyn.getgaji());
        
        
    }
}
