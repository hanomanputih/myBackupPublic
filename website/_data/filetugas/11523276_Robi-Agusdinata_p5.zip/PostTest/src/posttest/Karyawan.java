package posttest;
public class Karyawan {
    private String nip;
    private String nama;
    private int gaji;
    public void setName(String nama){
        this.nama = nama;
    }
    public void setGaji(int gaji){
        this.gaji = (gaji*12);
    }
    public void setNip(String n){
    if(n.length()==12){
            nip = n;
        }else{
            System.out.println("MASUKAN SALAH!!!");
        }
    }
   
    public void tampil(){
        System.out.println("NIP : "+nip);
        System.out.println("Nama : "+nama);
        System.out.println("Gaji Setahun : "+gaji);
    }
}
