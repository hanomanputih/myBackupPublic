package posttest;
public class PostTest {

    public static void main(String[] args) {
        Karyawan kry = new Karyawan();
        kry.setName("Bejo");
        kry.setGaji(100000);
        kry.setNip("123456789112");
        kry.tampil();
    }
}
