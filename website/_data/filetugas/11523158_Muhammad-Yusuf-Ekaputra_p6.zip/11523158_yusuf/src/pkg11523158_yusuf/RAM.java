/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg11523158_yusuf;

/**
 *
 * @author Praktikan
 */
public class RAM {
    String a;
    String b;
    
    public RAM(String a2,String b2){
        this.a=a2;
        this.b=b2;
}
    
}
