/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg11523158_yusuf;

/**
 *
 * @author Praktikan
 */
public class Prosesor {
    RAM r;
    
    String a1;
    String b1;
    public Prosesor(String a1, String b1){
        this.a1= a1;
        this.b1=b1;
        if(a1.equals("yaya")){
            r=new RAM("honda","yamaha");
        }else if(b1.equals("yeye")){
            r=new RAM ("ini","itu");
        }else{
            r=new RAM ("salah","pilih") ;
        }
        
    }
    
    public void tampil(){
        System.out.println("Prosesor: "+a1);
        System.out.println("RAM: "+r.a+","+r.b);
        System.out.println("");
        System.out.println("Prosesor: "+b1);
        System.out.println("RAM :"+r.a+","+r.b);
    }
}
