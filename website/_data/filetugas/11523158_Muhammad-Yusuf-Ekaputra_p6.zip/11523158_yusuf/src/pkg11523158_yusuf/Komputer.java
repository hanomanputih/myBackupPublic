/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg11523158_yusuf;

/**
 *
 * @author Praktikan
 */
public class Komputer {
    String a2;
    String b2;
    Prosesor pros;
    RAM r;
    
    public Komputer ( String a2, String b2){
        this.a2=a2;
        this.b2=b2;
        if(a2.equals("ehem")){
            pros=new Prosesor("yaya","");
        }else if(b2.equals("ihim")){
            pros=new Prosesor("","yeye");
        
        }else{
            pros=new Prosesor("salah","pilih");
        }
    }
    
    public void muncul(){
        System.out.println("Komputer: "+a2);
        System.out.println("Prosesor: "+pros.a1);
        System.out.println("RAM: "+pros.r.a+pros.r.b);
        System.out.println("");
        System.out.println("Komputer: "+b2);
        System.out.println("Prosesor: "+pros.b1);
        System.out.println("RAM: "+pros.r.a+pros.r.b);
        
    }
    
    public static void main(String[] args) {
        Komputer komp=new Komputer("ehem","ihim");
        Prosesor proses=new Prosesor("yaya","yeye");
        proses.tampil();
        komp.muncul();
        
    }
    
}
