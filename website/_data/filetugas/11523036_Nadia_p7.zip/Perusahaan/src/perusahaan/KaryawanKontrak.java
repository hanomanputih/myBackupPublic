/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perusahaan;
import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class KaryawanKontrak extends Karyawan {
    public double gaji;
    public void  KaryawanKontrak(){
        
        System.out.println("Masukkan bonus karyawan kontrak: ");
        Scanner sn=new Scanner(System.in);
        bonus=sn.nextInt();
        gaji=gajiPokok+bonus;
        System.out.println("KARYAWAN KONTRAK");
        System.out.println("gajiPokok: "+gajiPokok);
        System.out.println("Bonus");
        System.out.println("Total :"+gaji);
    
}
}
