/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perusahaan;
/**
 *
 * @author Praktikan
 */
public abstract class Karyawan {
    public int gajiPokok=3000000;
    public double tunjangan;
    public int bonus;
     public void  gaji(){
         
    
     }
    
}
