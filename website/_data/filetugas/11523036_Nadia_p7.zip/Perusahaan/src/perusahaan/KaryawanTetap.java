/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perusahaan;
import java.util.Scanner;
/**
 *
 * @author Praktikan
 */
public class KaryawanTetap extends Karyawan {
    public double gaji;
    public void  KaryawanTetap(){
        tunjangan=0.2*gajiPokok;
        System.out.println("Masukkan bonus karyawan tetap: ");
        Scanner sn=new Scanner(System.in);
        bonus=sn.nextInt();
        gaji=gajiPokok+tunjangan+bonus;
        System.out.println("KARYAWAN TETAP");
        System.out.println("Gaji Pokok: "+gajiPokok);
        System.out.println("Tunjangan"+tunjangan);
        System.out.println("Bonus: "+bonus);
        System.out.println("Total :"+gaji);
        
        
        
        
    }
}
