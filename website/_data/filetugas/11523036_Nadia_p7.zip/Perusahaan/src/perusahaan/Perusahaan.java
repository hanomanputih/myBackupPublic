
package perusahaan;


public class Perusahaan {

    
    public static void main(String[] args) {
        KaryawanKontrak satu=new KaryawanKontrak();
        satu.KaryawanKontrak(); 
        KaryawanTetap dua=new KaryawanTetap();
        dua.KaryawanTetap();
    }
}
