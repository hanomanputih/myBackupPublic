/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javaapplication66;
    import java.util.ArrayList;
    import java.util.HashMap;
    import java.util.Iterator;
    import java.util.List;
    import java.util.Scanner;
public class Main {
    

    public static void main(String[] args) {
        HashMap map = new HashMap();
        List list = new ArrayList();
        Scanner sc = new Scanner(System.in);
        String nama = sc.nextLine();
        String nim = sc.nextLine();
        list.add(nama);
        list.add(nim);
        map.put("1",nama);
        map.put("2",nim);
        System.out.println(map);

       for (Iterator <String>iterator = list.iterator(); iterator.hasNext();){
           String ahh =(String) iterator.next();
           System.out.println(ahh);
       }
       System.out.println(list.get(1));
       System.out.println(map.get(2));




    }

}

