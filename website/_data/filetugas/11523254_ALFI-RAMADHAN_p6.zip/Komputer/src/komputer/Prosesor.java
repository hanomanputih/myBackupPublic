/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class Prosesor {
    String NamaProsesor;
    String KecepatanProsesor;
    public Prosesor (String nama, String kecepatan){
        this.NamaProsesor = nama;
        this.KecepatanProsesor = kecepatan;
        
    }
}
