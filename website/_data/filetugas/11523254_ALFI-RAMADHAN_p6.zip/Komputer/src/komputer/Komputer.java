/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class Komputer {
    String IdKomputer;
    Prosesor P;
    Ram R;
    
    public Komputer (String komp){
        IdKomputer = komp ;
        if (komp.equals("1")){
            P = new Prosesor ("intel","4000");
            R = new Ram ("mac ",4 );
            
        }
    }

 
    public static void main(String[] args) {
        Komputer PC = new Komputer ("1");
        System.out.println("Spesifikasi Komputer Anda:");
        System.out.println("Prosesor: " +PC.P.KecepatanProsesor +PC.P.NamaProsesor);
        System.out.println("RAM: "+PC.R.VendorPabrik +PC.R.BesarMemori );
        
    }
        
        // TODO code application logic here
    }

