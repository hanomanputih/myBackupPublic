/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest.pkg5;

/**
 *
 * @author Praktikan
 */
public class RAM {
     String nama,tipe,kapasitas;
    public RAM(String nama,String tipe,String kapasitas){
        this.nama=nama;
        this.tipe=tipe;
        this.kapasitas=kapasitas;
        
    }
}
