/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest.pkg5;

/**
 *
 * @author Praktikan
 */
public class KOMPUTER {

    String spek;
    PROSESOR p;
    RAM r;
    public KOMPUTER(String kom){
        spek=kom;
        if(spek.equals("1")){
            p =new PROSESOR("Intel","Core i5",1910000);
            r=new RAM("Corsair","DOMINATOR ","4GB");
            }
        }
    
 public static void main(String[] args) {
        // TODO code application logic here
        KOMPUTER kom = new KOMPUTER("1");
        System.out.println("Jenis processor: "+kom.p.nama);
        System.out.println("Tipe processor: "+kom.p.tipe);
        System.out.println("Harga processor: "+kom.p.harga);
        System.out.println("MERK RAM: "+kom.r.nama);
        System.out.println("Jenis RAM: "+kom.r.tipe);
        System.out.println("Kapasitas RAM: "+kom.r.kapasitas);
        
    }
}
