/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest.pkg5;

/**
 *
 * @author Praktikan
 */
public class PROSESOR {
    String nama,tipe;
    int harga;
    public PROSESOR(String nama, String tipe,int harga){
        this.nama=nama;
        this.tipe=tipe;
        this.harga=harga;
    }
}
