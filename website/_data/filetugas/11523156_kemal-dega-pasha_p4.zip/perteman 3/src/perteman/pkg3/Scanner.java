/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perteman.pkg3;

/**
 *
 * @author Praktikan
 */
class Scanner {
    
}
