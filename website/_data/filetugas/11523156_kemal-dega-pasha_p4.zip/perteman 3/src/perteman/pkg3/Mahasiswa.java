/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perteman.pkg3;
import java.util.Scanner;
/**
 *
 * @author Praktikan
 */
public class Mahasiswa {

    String nama, nim;
    float jumlah1, jumlah2;

    void cetak() {
        Scanner cetak = new Scanner (System.in);
        System.out.println("Nama mahasiswa =") ;
        System.out.println("NIM");
        System.out.println("Fakultas");
    }

    public static void main(String[] args) {
    Scanner baca = new Scanner (System.in);
    Mahasiswa siswa = new Mahasiswa ();
    siswa.nama = baca.next ();
    System.out.println("Nama anda =");
    siswa.nama = baca.next();
    System.out.println("NIM anda =");
    
        
    }
    
    
}
