/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perteman.pkg3;
import java.util.Scanner;
/**
 *
 * @author Praktikan
 */
public class Hewan {
    int jumlahKaki;
    String nama;
    public static void main(String[] args) {
        Scanner baca = new Scanner(System.in);
        System.out.println ("Sebutkan nama hewan= "); 
   Hewan animal = new Hewan();
   animal.nama = baca.next() ;
   System.out.print ("berapa jumlah kaki nya = ");
    animal.jumlahKaki = baca.nextInt () ;
    System.out.println ("jadi nama hewan terdapat "+animal.nama.length ()+" huruf");
   
    }
    
}
