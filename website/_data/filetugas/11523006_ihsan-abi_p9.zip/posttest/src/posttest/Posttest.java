/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class Posttest {

    /**
     * @param args the command line arguments
     */
    


public static void main(String[]args){
Set set = new HashSet();
set.add("nama : ");
set.add("nim : ");
System.out.println("ukuran set : "+set.size());
for(Iterator iterator = set.iterator(); iterator.hasNext();){
String ii = (String) iterator.next();
System.out.println(ii);
}}
}
