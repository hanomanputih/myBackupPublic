/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Praktikan
 */
public class karyawanKontrak extends Karyawan {
 int bonus = 200000;
int gaji =  bonus + gajiP;
    @Override
public void lihat(){
        System.out.println("gaji pokok : "+ gajiP);
        System.out.println("bonus : "+ bonus);
        System.out.println("gaji : "+ gaji);
}
    
    
}
