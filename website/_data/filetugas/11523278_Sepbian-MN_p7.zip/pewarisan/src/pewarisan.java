/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Praktikan
 */
public class pewarisan {
    public static void main(String[] args) {
        karyawanTetap kt = new karyawanTetap();
        karyawanKontrak kk = new karyawanKontrak();
        System.out.println("");
        System.out.println("karyawan tetap");
        kt.lihat();
        System.out.println("");
        System.out.println("karyawan kontrak");
        kk.lihat();
    }
    
}
