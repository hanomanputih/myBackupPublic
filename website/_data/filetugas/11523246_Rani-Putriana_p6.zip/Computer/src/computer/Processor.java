/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package computer;

/**
 *
 * @author Praktikan
 */
public class Processor {

    String merk;

    public Processor(String merk) {
        this.merk = merk;

    }

    public void tampilProcessor() {
        System.out.println("merk prosesornya adalah : " + " " + merk);

    }
    
    public void percabangan(){
        if ("intel".equals(this.merk)) {
            System.out.println("merk prosesor dari komputer ini intel");
        }
        else {
            System.out.println("merk prosesor tidak terdaftar");
        }
    }
}