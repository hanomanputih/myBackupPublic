/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package computer;

/**
 *
 * @author Praktikan
 */
public class Computer {

    /**
     * @param args the command line arguments
     */  
     
    public static void main(String[] args) {
        // TODO code application logic here
        Processor kom1=new Processor("intel");
        Ram komp2=new Ram(4);
        
        kom1.tampilProcessor();
        komp2.tampilRam();
        
        kom1.percabangan();
        komp2.percabangan2();
        
    }
}
