/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package computer;

/**
 *
 * @author Praktikan
 */
public class Ram {

    int ukuran;

    public Ram(int ukuran) {
        this.ukuran = ukuran;
    }

    public void tampilRam() {
        System.out.println("ram dari prosesornya berukuran: " + " " + ukuran);
    }
    
    public void percabangan2(){
        if (this.ukuran!=4){
            System.out.println("Ram ini tidak cocok dengan prosesor dan komputer");
        }
        else {
            System.out.println("ram compatible :)");
        }
    }
}
