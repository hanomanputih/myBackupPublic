/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest5;

/**
 *
 * @author Praktikan
 */
public class Komputer {
    String id_komp;
    Prosesor p;
    RAM r;
    public Komputer (String komp) {
        id_komp=komp;
        if(id_komp.equals("1")) {
            p=new Prosesor ("intel");
            r=new RAM ("kingston");
        }
    }
    public static void main(String[] args) {
        Komputer komp=new Komputer("1");
        System.out.println("merk prosesornya adalah "+komp.p.merk);
        System.out.println("merk RAMnya adalah "+komp.r.merk1);
    }
    
}
