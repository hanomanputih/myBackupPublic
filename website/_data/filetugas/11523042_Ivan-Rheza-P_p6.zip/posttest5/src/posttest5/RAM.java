/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest5;

/**
 *
 * @author Praktikan
 */
public class RAM {
    String merk1;
public RAM(String merk1) {
    this.merk1=merk1;
    }
}
