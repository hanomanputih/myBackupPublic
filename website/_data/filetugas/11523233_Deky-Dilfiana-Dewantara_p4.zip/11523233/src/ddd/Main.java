/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ddd;

import java.util.Scanner;


/**
 *
 * @author Praktikan
 */


class Mahasiswa {

  
        String nama,nim,fakultas,jurusan,angkatan;

        
        void cetak(){
        System.out.println("\nHASIL");
        System.out.println("Nama Anda:"+nama );
        System.out.println("NIM Anda: "+nim);
        System.out.println("Fakultas Anda: "+fakultas);
        System.out.println("Jurusan Anda: "+jurusan);
        System.out.println("Angkatan Anda: "+angkatan);
         
}
        int jumlah(){
            int total;
            total=nama.length()+nim.length()+fakultas.length()+jurusan.length()+angkatan.length();            
            System.out.println("Jumlah Semua Karakter: "+total);
            return total;
        }
}
public class Main{
   
     public static void main(String[] args){
        Mahasiswa mahasiswa1 =new Mahasiswa();  
        Scanner baca=new Scanner(System.in);
        System.out.println("Input Data");
        System.out.print("Masukkan Nama Anda :");
        mahasiswa1.nama = baca.next();
        System.out.print("Masukkan Nim Anda :");
        mahasiswa1.nim = baca.next();
        System.out.print("Masukkan Fakultas Anda :");
        mahasiswa1.fakultas = baca.next();
        System.out.print("Masukkan Jurusan Anda :");
        mahasiswa1.jurusan = baca.next();
        System.out.print("Masukkan Angkatan Anda :");
        mahasiswa1.angkatan = baca.next();
        
        mahasiswa1.cetak();       
        mahasiswa1.jumlah();

         
    }


}