/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg11523102;

/**
 *
 * @author Praktikan
 */
public class Main {
    public static void main(String[] args) {
        Karyawan m = new Karyawan();
        m.setNama("hardi");
        m.setNip("11523102");
        m.setGaji(5000000);
        
        System.out.println("NIP :"+m.getNip());
        System.out.println("NAMA :"+m.getNama());
        System.out.println("GAJI :"+m.getGaji());
    }
    
}
