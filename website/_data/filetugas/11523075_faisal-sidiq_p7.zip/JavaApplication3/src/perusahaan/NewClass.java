/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perusahaan;

/**
 *
 * @author Praktikan
 */
 public static void main(String[] args, int tunjangan) {
      karyawantetap kt = new karyawantetap(20/100 * 3000000, 500000);
      kt.gaji();
}
