/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perusahaan;

/**
 *
 * @author Praktikan
 */
public class karyawantetap extends karyawan {
    int tunjangan , bonus ,gaji;
  
    
    public  karyawantetap(int tunjangan , int bonus ){
        this.tunjangan = tunjangan;
        this.bonus = bonus;
        
    }

    karyawantetap() {
    
    }
    public void gaji (){
        gaji = tunjangan+gajiPokok+bonus;
        System.out.println("gaji pokok adalah " + gaji);
    }
    
}
