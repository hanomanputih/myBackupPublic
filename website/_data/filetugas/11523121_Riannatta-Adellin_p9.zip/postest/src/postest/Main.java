/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

import java.util.Collections;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;


/**
 *
 * @author Praktikan
 */
public class Main {
    public static void main(String[] args) {
        
        Map mp = new HashMap () ;
        
        mp.put("nama","ryan");
        mp.put("NIM",new Integer (11523121));
        
        System.out.println(mp);
        System.out.println("ukuran map : "+mp.size());
        
        boolean containKey = mp.containsKey("NIM");
        System.out.println("Has Key (NIM): "+containKey);
        
       
    }
    
}
