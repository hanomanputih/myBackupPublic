/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest5;

/**
 *
 * @author PRAKTIKAN
 */
public class komputer {
    String produk;
    prosesor p;
    Ram r;
    public komputer(String m){
        produk=m;
        if(produk.equals("9")){
            p=new prosesor("Intel Inside");
            
            r=new Ram("6GB");
        }
    }

 public static void main(String[] args) {
     komputer m = new komputer("9");
     System.out.println("nama prosesor : "+m.p.nama);
     System.out.println("nama RAM: "+m.r.Kapasitas);
     // TODO code application logic here
    }
}


