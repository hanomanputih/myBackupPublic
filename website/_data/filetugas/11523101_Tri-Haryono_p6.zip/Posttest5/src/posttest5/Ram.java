/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest5;

/**
 *
 * @author PRAKTIKAN
 */
public class Ram {
    String Kapasitas;
    public Ram (String Kapasitas){
        this.Kapasitas=Kapasitas;
    }
    
}
