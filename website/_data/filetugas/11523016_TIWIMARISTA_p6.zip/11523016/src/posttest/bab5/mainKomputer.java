/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest.bab5;

/**
 *
 * @author Praktikan
 */
public class mainKomputer {
     public static void main (String [] args) {
  
    Prosesor pr = new Prosesor("INTEL");
    RAM rm = new RAM ("1GB");
    Komputer km = new Komputer("LG","INTEL",rm);
    km.tampil(rm);
   
}
}
