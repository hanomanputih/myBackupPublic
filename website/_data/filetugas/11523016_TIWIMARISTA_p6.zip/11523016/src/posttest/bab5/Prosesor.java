/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest.bab5;

/**
 *
 * @author Praktikan
 */
public class Prosesor {
    String merkProsesor;
    public Prosesor(String merkProsesor) {
        this. merkProsesor = merkProsesor;
    }
}
    
   
