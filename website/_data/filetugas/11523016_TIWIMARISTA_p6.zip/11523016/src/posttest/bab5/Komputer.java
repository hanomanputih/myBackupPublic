/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest.bab5;

/**
 *
 * @author Praktikan
 */
public class Komputer {
    String namaKomputer;
    String merkProsesor;
    RAM rm;
   
    public Komputer(String namaKomputer, String merkProsesor,RAM rm){
        this.namaKomputer = namaKomputer;
        this.merkProsesor = merkProsesor;
        this. rm =rm;
    }
    
    public void tampil(RAM rm){
        System.out.println("namaKomputer; "+namaKomputer);
        System.out.println("merkProsesor: "+merkProsesor);
        System.out.println("ukuranRAM: "+rm.ukuranRAM);
    }
    }
   

