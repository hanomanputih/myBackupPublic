/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class Ram {
    int nomor;

    public int getNomor() {
        return nomor;
    }

    public void setNomor(int nomor) {
        this.nomor = nomor;
    }

    public Ram(int nomor) {
        this.nomor = nomor;
    }
    
}
