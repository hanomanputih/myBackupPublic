/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;
 
/**
 *
 * @author Praktikan
 */
public class cpu {
    private int np;
    private prosesor p;
    private Ram ram;

    public cpu(int np) {
        this.np = np;
      if (np == 1){
          p =new prosesor (20);
          ram =new Ram (20);
      }
    }
    void tampil (){
        System.out.println("Nomor Produksi :"+np);
        System.out.println("prosesor :"+p);
        System.out.println("ram :"+ram);
    }
}

   