/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class main {
    public static void main(String[] args) {
    cpu Cpu=new cpu (1);
    Cpu.tampil();
    }
}
