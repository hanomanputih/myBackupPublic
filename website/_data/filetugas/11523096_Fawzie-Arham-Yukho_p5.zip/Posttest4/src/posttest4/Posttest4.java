/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest4;

/**
 *
 * @author Praktikan
 */
public class Posttest4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Karyawan k=new Karyawan();
        k.setNip("11523096");
        System.out.println("NIM anda: "+k.getNip());
        k.setNama("FawzieArhamYukho");
        System.out.println("Nama Anda: "+k.getNama());
        k.setGaji(1000000);
        System.out.println("Gaji Anda Sebulan: "+k.getGaji()); 
    }
}
