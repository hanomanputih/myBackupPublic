/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

/**
 *
 * @author Praktikan
 */
public class KaryawanTetap extends Karyawan{
    int tunjangan = (int) (0.2*Gajipokok);



    @Override
    public int gaji() {
        int TotalGaji;
        TotalGaji = tunjangan + Bonus +Gajipokok;
        return TotalGaji;
    }
    public void view(){
        System.out.println("Gaji Karyawan Tetap : "+gaji());
    }
}
