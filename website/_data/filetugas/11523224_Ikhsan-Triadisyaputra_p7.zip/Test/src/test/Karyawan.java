/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

/**
 *
 * @author Praktikan
 */
public abstract class Karyawan {
    int Gajipokok = 3000000;
    int Bonus = 200000;
    
    public abstract int gaji();
    
    
}
