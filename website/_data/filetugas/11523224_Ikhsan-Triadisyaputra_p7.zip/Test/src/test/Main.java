/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

/**
 *
 * @author Praktikan
 */
public class Main {
    public static void main(String[] args) {
        KaryawanTetap kt = new KaryawanTetap ();
        KaryawanKontrak kk = new KaryawanKontrak ();
        
        kt.view();
        kk.view();
    }
}
