/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package posttest5;

/**
 *
 * @author Praktikan
 */
public class komputer {
    String NamaKomp;
    private prosesor p;
    private RAM r;

public komputer(String NamaKomp){
    this.NamaKomp = NamaKomp;
    if(NamaKomp.equals("asus")){
        p =new prosesor ("intel");
        r =new RAM ("Nvidia");

    }
    }
    public void tampil(){
        System.out.println("Nama Komputer :"+NamaKomp);
        System.out.println("Nama Prosesor :"+p.NamaPros);
        System.out.println("Nama RAM : "+r.NamaRAM);


}
    public static void main(String[] args) {
        komputer kom=new komputer("asus");
        kom.tampil();
    }
}
