/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author PRAKTIKAN
 */
public class Komputer {
    String nama;
    RAM r;
    Prossesor p;
    
    public Komputer(String nama, String namaRam, String tipeRam,String namaPro,String tipePro){
        this.nama=nama;
        this.p=new Prossesor(namaPro,tipePro);
        this.r= new RAM(namaRam,tipeRam);
        
    }
    
   

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Komputer k=new Komputer("asus","intel","core i 7","vgen","ddr3");
        System.out.println("nama komputer : "+k.nama);
        System.out.println("nama Prossessor :"+k.r.getNama()+" tipe "+k.r.getTipe());
        System.out.println("nama RAM :"+ k.p.getNama()+ " Tipe "+k.p.getTipe());
       
        
        // TODO code application logic here
    }
}
