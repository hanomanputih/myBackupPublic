/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author PRAKTIKAN
 */
public class Prossesor {
    String nama;
    String tipe;

    public String getNama() {
        return nama;
    }

    public String getTipe() {
        return tipe;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public void setTipe(String tipe) {
        this.tipe = tipe;
    }
    
    public Prossesor(String nama,String tipe){
        this.nama=nama;
        this.tipe=tipe;
    }
    
}
