/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class Ram {
    String jenis;
    String namaProsesor;
    String kecepatan;

    public Ram(String r) {
      this.jenis = "nama";
      this.kecepatan= "nama";  
    }
  
    
}
