/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class Komputer {
String jenis;
String spesifikasi;
Prosesor P;
Ram R;

 public Komputer(String J, String SPS, String p, String r){
     this.jenis = J;
     this.spesifikasi = SPS;
     P = new Prosesor(p);
     R = new Ram(r);
 }

    private Komputer(String string, String string0, String string1) {
        throw new UnsupportedOperationException("Not yet implemented");
    }
 
 public void Display(){
     System.out.println("jenis komputer : "+jenis);
     System.out.println("rincian spesifikasi : "+spesifikasi);
     System.out.println("nama prosesor : "+P.namaProsesor );
     System.out.println("kecepatan ram : "+R.kecepatan);
 }
 
 
    public static void main(String[] args) {
    Komputer k = new Komputer("acer","xxx","intel");
    k.spesifikasi="ram ,harddisk 1 T";
    k.P.namaProsesor ="amd";
    k.R.kecepatan = "1 Gb";
    k.Display();
    }
}
