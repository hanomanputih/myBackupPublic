/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Komposisi;

/**
 *
 * @author PRAKTIKAN
 */
public class Prosesor {
    String speed;
    String merk;
    
    public Prosesor(String s, String m){
    this.speed = s;
    this.merk = m;
}
}
