/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Komposisi;

/**
 *
 * @author PRAKTIKAN
 */
public class Ram {
    String kapasitas;
    
    public Ram(String k){
        this.kapasitas = k;
    }
}
