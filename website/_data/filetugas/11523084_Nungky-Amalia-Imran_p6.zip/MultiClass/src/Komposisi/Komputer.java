/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Komposisi;

/**
 *
 * @author PRAKTIKAN
 */
public class Komputer {
    String jenisKomputer;
    Prosesor R;
    Ram P;
    
    public Komputer(String J,String p, String s,String r){
        this.jenisKomputer = J;
        R = new Prosesor(r,s);
        P = new Ram(p);
        
    
    }
    public void Display(){
        System.out.println("Jenis Komputer    : "+jenisKomputer);
        System.out.println("Kapasitas RAM     : "+P.kapasitas);
        System.out.println("Merk Prosesor     : "+R.merk);
        System.out.println("Speed Prosesor    : "+R.speed);
    }
    public static void main(String[] args) {
        Komputer u = new Komputer("Router","500MB", "Thosiba","30ghz");
        
        u.Display();
    }
    
}
