/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest4;

/**
 *
 * @author Praktikan
 */
public class Karyawan {
    private String nip;
    private String nama;
    private int gaji;
    
    void setNip (String ni){
        nip = ni;
    }
    
    void setNama (String nm){
        nama = nm;
    }
    
    void setGaji (int gj){
        gaji = gj;
    }
    
    public String getNip(){
        return nip;
    }
    
    public String getNama(){
        return nama;
    }
    
    public int getGaji(){
        return gaji;
    }
}
