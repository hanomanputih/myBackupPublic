/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest4;

/**
 *
 * @author Praktikan
 */
public class main {
    public static void main(String[] args) {
    Karyawan kyw = new Karyawan();
    
    kyw.setNip("11523097");
    kyw.setNama("Denny");
    kyw.setGaji(1500000);
    
        System.out.println("Data karyawan");
        System.out.println("NIP : "+kyw.getNip());
        System.out.println("Nama : "+kyw.getNama());
        System.out.println("Gaji : "+kyw.getGaji());
    
}
}