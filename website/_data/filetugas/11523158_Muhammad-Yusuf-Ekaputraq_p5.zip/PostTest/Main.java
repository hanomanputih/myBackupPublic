/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package PostTest;

/**
 *
 * @author Praktikan
 */
public class Main {
    public static void main(String[] args) {
        Karyawan ys=new Karyawan();
        ys.setNip("12345");
        ys.setNama("ysusususu");
        ys.setGaji(400000);
        System.out.println("nip :"+ys.getNip());
        System.out.println("nama :"+ys.getNama());
        System.out.println("gaji perbulan :"+ys.getGaji());
        System.out.println("gaji pertahun :"+ys.getGaji()*12);
        
    }
}
