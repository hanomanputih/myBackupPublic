/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package PostTest;

/**
 *
 * @author Praktikan
 */
public class Karyawan {
    private String nip;
    private String nama;
    private int gaji;
    
    void setNip(String _nip){
        if(_nip.length()==10){
            nip=_nip;
        }else{
            System.out.println("nip harus 10 digit");
        }
    }
    String getNip(){
        return nip;
    }
    void setNama(String _nm){
        if(_nm.length()>=8){
            nama=_nm;
        }else{
            System.out.println("nama min 8 digit");
        }
    }
    String getNama(){
        return nama;
    }
    void setGaji(int _gj){
        if(_gj>=100000 && _gj<=500000){
           gaji=_gj;
        }else{
            System.out.println("gaji harus diantara 100rb - 500rb");
        }
    }
    int getGaji(){
        return gaji;
    }
}