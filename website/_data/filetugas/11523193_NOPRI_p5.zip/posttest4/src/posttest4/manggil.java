/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest4;

/**
 *
 * @author Praktikan
 */
public class manggil {
    public static void main(String[] args) {
      
    Karyawan kry = new Karyawan();
      
      kry.setNama ("andrian");
      kry.setNip ("11523193");
      kry.setGaji (-4444);
      
      
        System.out.println("nip :" +kry.getNip());
        System.out.println("nama:" +kry.getNama());
        System.out.println("gaji:" +kry.getGaji());
        
        
    }
}
    

