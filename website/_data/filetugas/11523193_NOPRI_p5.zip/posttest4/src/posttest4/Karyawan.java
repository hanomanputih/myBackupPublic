/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest4;

/**
 *
 * @author Praktikan
 */
public class Karyawan {
    
    private String nip;
    private String nama;
    private int gaji;
    

    public void setNip(String nipKamu) {
          if(nipKamu.length()==8){
          nip=nipKamu;
          
          }else{
              System.out.println("error");
          }
      }
      
  public String getNip(){
      return nip;
  }
  
  public void setNama (String namaKU) {
       nama = namaKU;
  }
  public String getNama(){
      return nama;
  
  }
  public void setGaji (int gajiKU) {
      if(gajiKU > 1){
          gaji=gajiKU;
          
          }else{
              System.out.println("error");
          }
      }
  
 
  
 
  public int getGaji(){
      return gaji* 12 ;
  }
}

        
    
    

