/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication4;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class JavaApplication4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        HashMap map = new HashMap();
        List list = new ArrayList();
        Scanner sc = new Scanner(System.in);
        String nama = sc.nextLine();
        String nim = sc.nextLine();
        list.add(nama);
        list.add(nim);
        map.put("1", nama);
        map.put("2", nim);
        System.out.println(map);



        for (Iterator <String> iterator = list.iterator(); iterator.hasNext();) {
            String wew = (String) iterator.next();
            System.out.println(wew);

        }
        System.out.println(list.get(1));
        System.out.println(map.get(2));
    }
}
