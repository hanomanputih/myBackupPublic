/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes4;

/**
 *
 * @author PRAKTIKAN
 */
public class Main {
    public static void main(String[] args) {
        Karyawan k = new Karyawan();
        k.setNip("1523100000");
        k.setNama("Islamiah");
        k.setGaji(300000);
        System.out.println("NIP : "+k.getNip());
        System.out.println("Nama : "+k.getNama());
        System.out.println("Gaji : "+k.getGaji());
    }
}
