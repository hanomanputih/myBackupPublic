/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes4;

/**
 *
 * @author PRAKTIKAN
 */
public class Karyawan {

    private String nip ;
    private String nama ;
    private int gaji;
    void setNip (String _nip){
        if (_nip.length() == 10){
            nip = _nip;
        }
        else{
            System.out.println("erooor");
        }
    }
    void setNama (String _nama){
        
        if (_nama.length() == 8){
            nama = _nama;
        }
        else{
            System.out.println("erooor");
        }
    }
    void setGaji (int _gaji){
        if (_gaji >= 300000 && _gaji <=500000){
            gaji = _gaji;
        }
        else{
            System.out.println("erooor");
        }
    }
    
    String getNip(){
        return nip;
    }
    String getNama(){
        return nama;
    }
    int getGaji(){
        return gaji;
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
}
