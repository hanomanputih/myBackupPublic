/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan3;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Hewan {

    int jumlahKaki;
    String nama;

    public static void main(String[] args) {
        Scanner baca = new Scanner(System.in);
        Hewan animal = new Hewan();
        System.out.println("sebutkan nama hewan = ");
        animal.nama = baca.next();
        System.out.println("berapa jumlah kakinya = ");
        animal.jumlahKaki = baca.nextInt();
        System.out.println("jadi nama hewan tersebut terdapat " + animal.nama.length() + " karakter");


    }
}
