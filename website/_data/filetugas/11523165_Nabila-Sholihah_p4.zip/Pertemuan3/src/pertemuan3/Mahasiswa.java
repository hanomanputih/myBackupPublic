/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan3;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {

    String nama;
    String nim;
    String fakultas;
    String jurusan;
    String angkatan;
    float jumlah1;
    float jumlah2;

    void Cetak() {
        Scanner cetak = new Scanner(System.in);
        System.out.println("Data Mahasiswa");
        System.out.println("Masukkan Nama Mahasiswa : ");
        nama = cetak.next();
        System.out.println("Masukkan Nim : ");
        nim = cetak.next();
        System.out.println("Masukkan Fakultas Mahasiswa : ");
        fakultas = cetak.next();
        System.out.println("Masukkan Jurusan Mahasiswa : ");
        jurusan = cetak.next();
        System.out.println("Masukkan Angkatan Anda: ");
        angkatan = cetak.next();
    }
    void Cetak2 () {
        System.out.println("Nama : " +nama);
        System.out.println("NIM : " +nim);
        System.out.println("Fakultas : " +fakultas);
        System.out.println("Jurusan : " +jurusan);
        System.out.println("Angkatan : " +angkatan);
    }
    public static void main(String[] args) {
        Mahasiswa m = new Mahasiswa();
        m.Cetak();
        m.Cetak2();   
    }
}
