/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;


public class main{
    
    public static void main(String[] args) {
        karyawan ka = new karyawan();
        ka.setNip("09523270");
        ka.setNama("good");
        ka.setGaji(50000000);
        System.out.println("NIP = "+ka.getNip());
        System.out.println("NAMA = "+ka.getNama());
        System.out.println("GAJI = "+ka.getGaji());
    }
}

/**
 *
 * @author Praktikan
 */
public class main {
    
}
