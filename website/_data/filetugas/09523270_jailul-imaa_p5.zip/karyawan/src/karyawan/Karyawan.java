/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class Karyawan {
 
public class karyawan {

    private String Nip;
    private String Nama;
    private int Gaji;

    void setNip(String ni) {
        if (ni.length() == 10) {
            Nip = ni;
        } else {
            System.out.println("error..");
        }
    }

    String getNip() {
        return Nip;
    }

    void setNama(String na) {
        if (na.length() > 8) {
            Nama = na;
        } else {
            System.out.println("error...");
        }
    }

    String getNama() {
        return Nama;
    }

    void setGaji(int ga) {
        if (ga >= 100000 && ga<= 500000) {
            Gaji = ga;
        } else {
            System.out.println("error...");
        }
    }

    int getGaji() {
        return Gaji;
    }
}


    public static void main(String[] args) {
        // TODO code application logic here
    }
}
