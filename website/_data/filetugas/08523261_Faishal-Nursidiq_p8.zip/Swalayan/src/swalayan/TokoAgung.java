/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package swalayan;

/**
 *
 * @author Praktikan
 */
public class TokoAgung extends Swalayan {
    
    void perhitungan(){
    sisa =(int) (harga % 25);
    bayar =(int) (harga - sisa);
        System.out.println(bayar);
    }
    
    @Override
    void tampil(){
        perhitungan();
    
    }
}
