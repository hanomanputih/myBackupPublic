/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package swalayan;

/**
 *
 * @author Praktikan
 */
public class Indomaret extends Swalayan{
    
    
    void perhitungan(){
        if (harga % 25 ==0){
            System.out.println(harga);
        }
        else
        {
            sisa = (int)(25-(harga % 25));
            bayar = (int)(harga+sisa);
            System.out.println(bayar);
        }
    }
    
    @Override
    void tampil(){
        perhitungan();
    }
}
