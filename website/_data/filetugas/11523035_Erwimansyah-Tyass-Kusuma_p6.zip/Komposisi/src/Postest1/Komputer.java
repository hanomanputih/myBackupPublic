/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Postest1;

/**
 *
 * @author PRAKTIKAN
 */
public class Komputer {
    String nama;
    
    Prosesor p;
    Ram rm;
    public Komputer(String nama){
       this.nama=nama;
    p=new Prosesor("Intel");
    rm=new Ram("16GB");
        System.out.println("Nama Komputer " +nama);
    System.out.println("So Komputer ini merknya " +p.merk_prosesor);
        System.out.println("So Komputer ini berkapasitas " +rm.kapasitas_memori);
    }
 public static void main(String[] args) {
 Komputer kp=new Komputer("Thosiba");
   
}
    
}

