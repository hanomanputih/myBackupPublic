/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Postest1;

/**
 *
 * @author PRAKTIKAN
 */
public class Ram {
    String kapasitas_memori;
   
     public Ram(String kapasitas_memori){
     this.kapasitas_memori=kapasitas_memori;
}
}
