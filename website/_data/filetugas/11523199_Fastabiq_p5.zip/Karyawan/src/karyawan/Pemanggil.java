/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class Pemanggil {
    
 public static void main(String[] args) {
        Karyawan kry = new Karyawan ();
        
        kry.setNama("haha");
        
        kry.setNip("11523199");

        kry.setGaji(2555);
        
        System.out.println("nip "+kry.getNip());
        System.out.println("nama "+kry.getNama());
        System.out.println("gaji "+kry.getgaji());
    }
}
