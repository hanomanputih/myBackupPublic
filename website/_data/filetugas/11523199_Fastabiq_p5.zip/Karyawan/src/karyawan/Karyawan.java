/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

public class Karyawan {
private String nip;
private String nama;
private int gaji;

public void setNip (String nipKamu){
    nip=nipKamu; 
    
    
}
public String getNip() {
        return nip;
}
public void setNama (String namaKamu) {
   nama=namaKamu;
    
    
}
public String getNama() {
        return nama;
}

public void setGaji (int gajiKamu){
   gaji=gajiKamu;
    
    
}
public int getgaji (){
    return gaji;
   
}
}
  