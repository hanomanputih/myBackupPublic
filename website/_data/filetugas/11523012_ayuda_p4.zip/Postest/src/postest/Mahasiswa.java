/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

import java.util.Scanner;

/**
 *
 * @author PRAKTIKAN
 */
public class Mahasiswa {

    String nama;
    String nim;
    String jurusan;
    String fakultas;
    String angkatan;

    public static void main(String[] args) {


        Mahasiswa m = new Mahasiswa();
        m.cetak();

    }

    void cetak() {
        Scanner b = new Scanner(System.in);
        System.out.println("Masukkan nama : ");
        nama = b.next();
        System.out.println("Masukkan nim : ");
        nim = b.next();
        System.out.println("Masukkan jurusan : ");
        jurusan = b.next();
        System.out.println("Masukkan fakultas : ");
        fakultas = b.next();
        System.out.println("Masukkan angkatan : ");
        angkatan = b.next();
        System.out.println("Nama anda " + nama + "dengan nim " + nim);
        System.out.println("jurusan yang dipilih " + jurusan+"di fakultas"+fakultas + "angkatan " + angkatan);
        System.out.println("Jumlah karakter dari nama "+nama.length()+"huruf");

    


    }
        
    }
