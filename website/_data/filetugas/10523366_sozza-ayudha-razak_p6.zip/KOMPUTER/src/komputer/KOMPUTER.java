/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class KOMPUTER {
    KOMPUTER komp;
    prosesor pros;
    ram r;
    
    public void tampil(){
        System.out.println("spesifikasi : " + komp );
    }
    
    public static void main(String[] args) {
        prosesor pros = new prosesor("amd");
        pros.tampil ();
    }
}
    

   
    public static void main(String[] args) {
        // TODO code application logic here
    }
}
