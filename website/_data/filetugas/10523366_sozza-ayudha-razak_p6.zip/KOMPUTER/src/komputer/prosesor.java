/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class prosesor {
    String pros;
    ram r;
    
    public prosesor(String pros) {
        this.pros = pros ;
        if(pros.equals ("amd")){
            r = new ram ("asrock");
            
} else {
            System.out.println("nama prosesor");
        }
    }
    
    public void tampil(){
          System.out.println("nama prosesor-e : " + pros);
            System.out.println("nama ram-e : " + r.ram);
    }
   
    
}
