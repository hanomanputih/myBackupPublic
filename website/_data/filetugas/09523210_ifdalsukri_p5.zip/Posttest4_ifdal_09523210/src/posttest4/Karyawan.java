/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest4;

/**
 *
 * @author Praktikan
 */
public class Karyawan {

    private String Nip;
    private String Nama;
    private int Gaji;

    void setNIP(String Nip) {
        if (Nip.length() == 8) {
            this.Nip = Nip;
        } else {
            System.out.println("erroor..");
        }
    }

    void setNama(String Nama) {
        if (Nama.length() == 8) {
            this.Nama = Nama;
        } else {
            System.out.println("erroor..");
        }
    }

    void setGaji(int Gaji) {
        if (Gaji == 89) {
            this.Gaji = Gaji;
        } else {
            System.out.println("erroor..");
        }
    }

    String getNip() {
        return Nip;
    }

    String getNama() {
        return Nama;
    }

    int getGaji() {
        return Gaji;
    }
}