/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest4;

/**
 *
 * @author Praktikan
 */
public class Main {
        public static void main(String[] args) {
        Karyawan ma = new Karyawan();
        ma.setNIP("462346923");
        ma.setNama("Bejo");
        ma.setGaji(1000000);
        
        
        System.out.println("nip = "+ma.getNip());
        System.out.println("nama = "+ma.getNama());
        System.out.println("gaji setahun = "+ma.getGaji());
}
}
