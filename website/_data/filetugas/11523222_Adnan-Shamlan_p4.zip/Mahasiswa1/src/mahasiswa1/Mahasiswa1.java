/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa1;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa1 {
String nama = "Adnan";
String nim = "11523222";
    
    void isi (){
        
    }
    
    void cetak (){
        System.out.println (" nama " + nama);
        System.out.println (" nim " + nim);
        
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Mahasiswa1 a = new Mahasiswa1();
        a.isi();
        a.cetak();
        
        
        
        
        
        // TODO code application logic here
    }
}
