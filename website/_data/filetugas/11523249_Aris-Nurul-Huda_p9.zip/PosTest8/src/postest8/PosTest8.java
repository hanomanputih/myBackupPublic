/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest8;

import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author praktikan
 */
public class PosTest8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Map<String, String> mhs = new HashMap<String, String>();

        mhs.put("Jepara", "Lulung");
        mhs.put("Jakarta", "Galih");
        mhs.put("Ferdian", "Cilacap");

        for (Map.Entry<String, String> e : mhs.entrySet()) {
            System.out.println(e.getKey() + " " + e.getValue());
        }

        System.out.println("-------------------------------");

        List mhh = new ArrayList();

        mhh.add("Lulung");
        mhh.add("Galih");
        mhh.add("Ferdian");

        Iterator it = mhh.iterator();
        while (it.hasNext()) {
            System.out.println(it.next());
        }
        
        System.out.println("-------------------------------");

        System.out.println(mhh.get(2));




    }
}
