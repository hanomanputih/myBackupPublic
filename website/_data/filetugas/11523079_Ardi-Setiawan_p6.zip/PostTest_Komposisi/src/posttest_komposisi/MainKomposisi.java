/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest_komposisi;

/**
 *
 * @author Praktikan
 */
public class MainKomposisi {
    public static void main(String[] args) {
    Prosesor ps = new Prosesor ("4.0 GBZ");
    RAM ram = new RAM ("2 GB");
    Komputer kp = new Komputer ("Leonovo", ps, ram);
    kp.tampil(ps, ram);
    }
}
