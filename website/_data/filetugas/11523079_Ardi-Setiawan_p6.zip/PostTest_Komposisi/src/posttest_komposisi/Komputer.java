/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest_komposisi;

/**
 *
 * @author Praktikan
 */
public class Komputer {
   String merkKomputer;
   Prosesor ps;
   RAM ram;
   public Komputer (String merkKomputer, Prosesor ps, RAM ram){
        this.merkKomputer = merkKomputer;
        this.ps = ps;
        this.ram = ram;        
    }
    public void tampil (Prosesor ps, RAM ram){
        System.out.println("Merk Komputer : "+merkKomputer);
        System.out.println("Kecepatan Prosesor : "+ps.kecepatan );
        System.out.println("Ukuran RAM :"+ram.ukuran);
    }
}
