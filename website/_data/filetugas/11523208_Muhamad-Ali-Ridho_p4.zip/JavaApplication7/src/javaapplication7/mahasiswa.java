/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication7;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */



public class mahasiswa {
    Scanner pembaca=new Scanner(System.in);
    String nama;
    String nim;  
    String fakultas;
    String jurusan;
    String angkatan;
     
        
    
    
    void masukan(){
        System.out.println("masukkan nama anda : ");
        nama=pembaca.next();
        System.out.println("masukkan nim anda : ");
        nim=pembaca.next();
        System.out.println("Fakultas ? ");
        fakultas=pembaca.next();
        System.out.println("jurusan ? ");
        jurusan=pembaca.next();
        System.out.println("angkatan ? ");
        angkatan=pembaca.next();
    }
    void cetak(){
           System.out.println("Nama anda adalah : " + nama);
           System.out.println("NIM anda adalah : "+nim);
           System.out.println("Fakultas " +fakultas);
           System.out.println("Jurusan " +jurusan);
           System.out.println("angkatan " +angkatan);
        }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        mahasiswa mhs1 = new mahasiswa();
        mhs1.masukan();
        mhs1.cetak();
    }
}
