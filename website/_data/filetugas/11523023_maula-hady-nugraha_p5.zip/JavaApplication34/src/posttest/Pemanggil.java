/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author Praktikan
 */
public class Pemanggil {
    
    public static void main(String[] args) {
    Karyawan krn = new Karyawan();
    krn.setNama ("Hady");
    krn.setNip ("11523023");
    krn.setGaji (1000);
    
    System.out.println ("Nama = "+krn.getNama());
    System.out.println ("NIP = "+krn.getNip());
    System.out.println ("GAJI = "+krn.getGaji());
    
    
    
    
    
}
