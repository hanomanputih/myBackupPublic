/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mobil;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
         String nama;
         String nim;
         float jumlah1, jumlah2;
        
   
    void cetak () {
     
        nama = "Alex";
        nim = "11523290";
        jumlah1 = nama.length();
        jumlah2 = nim.length();
    } 
    public static void main(String[] args) {
        Mahasiswa mhs = new Mahasiswa();
        mhs.cetak();
        System.out.println(" Nama anda adalah" + mhs.nama);
        System.out.println(" Nim anda adalah" + mhs.nim);
        System.out.println("jumlah dari Nama anda adalah"+ mhs.jumlah1);
        System.out.println("jumlah dari NIm anda adalah" + mhs.jumlah2);
        System.out.println("Jumlah dari Cetak yang berisi jumlah karakter nim dan nilai adalah" +(mhs.jumlah1 + mhs.jumlah2));
    }
}
