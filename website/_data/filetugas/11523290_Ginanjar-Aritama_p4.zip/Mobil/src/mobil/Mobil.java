/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mobil;

/**
 *
 * @author Praktikan
 */
public class Mobil {

    int ban;
    int spion;
    Coba Merk;
    Coba Plat;
    
    
      public static void main(Coba[] args) {
    Mobil mb = new Mobil();
    Mobil mb2 = newMobil();
    mb.Merk = "Honda";
    mb.ban = 4;
    mb.Plat = "K 123 E";
    mb.spion = 4;
    
          System.out.println("merk : "+mb.Merk);
          System.out.println("plat : "+mb.Plat);
          System.out.println("");
    }
    }

