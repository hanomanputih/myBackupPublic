
package posttest;


public class karyawan {
    private String nip;
    private String nama;
    private int gaji;
    
    public void setnip (String nip) {
     this.nip = nip;
    }
     public void setnama (String nama) {
     this.nama = nama;
    }
     public void setgaji (int gaji) {
     this.gaji = gaji;
    }
     
     public String getnip(){
         return nip;
     }
     public String getnama(){
         return nama;
     }
     public int getgaji(){
         int hasil = 12 * gaji;
         return hasil;
     }
}
