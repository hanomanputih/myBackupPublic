
package posttest;

public class PostTest {
    private String nip;
    private String nama;
    private int gaji;

    public static void main(String[] args) {
        karyawan kr = new karyawan();
        kr.setnip("11523111");
        kr.setnama("blabla");
        kr.setgaji(5000000);
        
        System.out.println("Masukkan NIP anda: "+kr.getnip());
        System.out.println("Masukkan nama anda: "+kr.getnama());
        System.out.println("Masukkan gaji satu tahun: "+kr.getgaji());

    }
}
