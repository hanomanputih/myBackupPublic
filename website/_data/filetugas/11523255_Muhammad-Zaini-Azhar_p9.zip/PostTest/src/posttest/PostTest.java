package posttest;
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import java.util.HashMap;

public class PostTest {
    private static void loadData(List<String>list){
        list.add("muhammad zaini azhar");
        list.add("11523255");        
    }
            
    private static void tampilkanList(List<String>list){
        for(Iterator<String>iterator=list.iterator();
                iterator.hasNext();) {
            String isi = iterator.next();
            System.out.println(isi);
        }
    }
    public static void main(String[] args) {
        List<String> list = new ArrayList<String>();
loadData(list);
tampilkanList(list);

HashMap map=new HashMap();
map.put("NIM", "11523255");
map.put("Nama", "Muhammad zaini azhar");

        System.out.println("nama " +map.get("Nama"));
        System.out.println("NIM " +map.get("NIM"));

}
}


