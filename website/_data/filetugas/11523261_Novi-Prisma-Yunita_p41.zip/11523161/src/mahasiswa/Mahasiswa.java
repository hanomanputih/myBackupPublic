/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
    String nama, nim, fakultas, jurusan, angkatan;
    
    void cetak(){
        Scanner isi = new Scanner (System.in);
        System.out.print("Nama      : ");
        nama=isi.nextLine();
        System.out.print("NIM       : ");
        nim=isi.nextLine();
        System.out.print("Fakultas  : ");
        fakultas=isi.nextLine();
        System.out.print("Jurusan   : ");
        jurusan=isi.nextLine();
        System.out.print("Angkatan  : ");
        angkatan=isi.nextLine();
        System.out.println(nama);
        System.out.println(nim);
        System.out.println(fakultas);
        System.out.println(jurusan);
        System.out.println(angkatan);
        
    }
    
    public static void main(String[] args) {
        Mahasiswa mhs = new Mahasiswa ();
        
        mhs.cetak();
    }
}
