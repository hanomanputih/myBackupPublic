/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Komputer;

/**
 *
 * @author PRAKTIKAN
 */
public class Komputer {
    String merekKomputer;
    int hargaKomputer;
    Prosesor p;
    RAM r;
    public Komputer(String[] args) {
        this.merekKomputer = merekKomputer;
        if(merekKomputer.equals("LG"));
            
    }
}
