/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {

    String nama;
    int nim;
    String alamat;
    
    public static void main(String[] args) {
    Mahasiswa ms = new Mahasiswa();
    ms.nama = "Rizky";
    ms.nim = 11523087;
    ms.alamat = "Yogyakarta";
    
    System.out.println ("nama "+ms.nama);
    System.out.println ("nim "+ms.nim);
    System.out.println ("alamat "+ms.alamat);
    
    
    
    }
}
