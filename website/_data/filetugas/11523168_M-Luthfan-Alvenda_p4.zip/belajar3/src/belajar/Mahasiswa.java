/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package belajar;
import java.util.Scanner;


public class Mahasiswa {
String nama;
String nim;
String fakultas;
String jurusan;
String angkatan;
int jumlah;

 
  void isi () {
         Scanner read = new Scanner(System.in);
         System.out.println("Masukkan Nama Anda : ");
         nama = read.next();
         System.out.println("Masukkan NIM Anda : ");
         nim = read.next();
         System.out.println("Masukkan Fakultas Anda : ");
         fakultas = read.next(); 
         System.out.println("Masukkan jurusan Anda : ");
         jurusan = read.next();
         System.out.println("Masukkan angkatan Anda : ");
         angkatan = read.next();
         jumlah = nama.length() + fakultas.length();
     }
     
     void cetak() {
         System.out.println("Nama Anda : "+nama);
         System.out.println("NIM Anda : "+nim);
         System.out.println("Fakultas Anda : "+fakultas);
         System.out.println("Jurusan Anda : "+jurusan);
         System.out.println("Angkatan Anda : "+angkatan);
         System.out.println("Jumlah : "+jumlah);
     }
     
     public static void main(String[] args) {
        Mahasiswa data = new Mahasiswa();
               
        data.isi();
        data.cetak();
        
    }
}
