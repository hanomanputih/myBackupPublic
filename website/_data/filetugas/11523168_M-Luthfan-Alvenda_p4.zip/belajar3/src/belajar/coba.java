/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package belajar;

/**
 *
 * @author Praktikan
 */
public class coba {
    
    public static void main (String[]args) {
        String nama = "Muhammad Luthfan Alvenda";
        System.out.println("last name : "+nama.endsWith("Alvenda"));
        System.out.println("first name : "+nama.startsWith("Muhammad"));
        System.out.println("ini buat apa ? "+nama.charAt(9));
        System.out.println("panjang karakter dalam nama anda adalah : "+nama.length());
    }
    
}
