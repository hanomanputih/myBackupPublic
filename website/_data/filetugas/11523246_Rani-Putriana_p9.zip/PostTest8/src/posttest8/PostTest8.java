/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package PostTest8;

/**
 *
 * @author Praktikan
 */
import java.util.Iterator;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class PostTest8 {

    public static void main(String[] args) {
        HashMap map = new HashMap();
        map.put("nama ", "rani");
        map.put("nim ", new Integer(11523246));
        System.out.println(map);
        List<String> list = new ArrayList<String>();
        list.add("rani");
        list.add("11523246");
        //System.out.println("array 1 " + list.get(0));
        //System.out.println("array 2 " + list.get(1));
        for (Iterator<String> iterator = list.iterator();
                iterator.hasNext();) {
            String isi = iterator.next();
            System.out.println(isi);


        }


    }
}
