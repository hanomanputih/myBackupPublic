/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

/**
 *
 * @author Praktikan
 */
import java.util.Scanner;
public class Mahasiswa {
     String nama;
String NIM;
int jumlah1;
int jumlah2;
int total;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Mahasiswa c = new Mahasiswa();      
        Scanner pembaca = new Scanner(System.in);
System.out.println("masukan nama anda = ");
c.nama = pembaca.next();
c.jumlah1 = c.nama.length();
System.out.println("masukan NIM anda = ");
c.NIM =pembaca.next();
c.jumlah2 = c.NIM.length();
c.total = c.jumlah1 + c.jumlah2;
System.out.println("jumlah panjang karakter adalah :" +c.total);
    }
}
               

        // TODO code application logic here
