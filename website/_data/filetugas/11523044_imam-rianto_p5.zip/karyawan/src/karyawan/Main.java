/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author PRAKTIKAN
 */
public class Main {
    public static void main(String[] args) {
        Karyawan k=new Karyawan();
        k.setNip("11523044");
        System.out.println("NIP :"+k.getNip());
        k.setNama ("imam rianto");
        System.out.println("Nama :"+k.getNama());
        k.setGaji (123456789);
        System.out.println("Gaji :"+k.getGaji());
    }
}
