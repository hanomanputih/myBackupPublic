
package postest;

public class Prosesor {
    private String type; // core i3 core i5

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
    
}
