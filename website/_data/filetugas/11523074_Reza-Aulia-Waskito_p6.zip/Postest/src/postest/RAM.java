
package postest;

public class RAM {
    private String ukuran; // 512 MB

    public String getUkuran() {
        return ukuran;
    }

    public void setUkuran(String ukuran) {
        this.ukuran = ukuran;
    }
    
}
