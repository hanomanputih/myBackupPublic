package postest;

public class CPU { // Terdiri dari Prosesor dan RAM
        private String merk; 
        private RAM ram; // CPU punya RAM
        private Prosesor prosesor; // CPU punya Prosesor

    public CPU(String merk, RAM ram, Prosesor prosesor) {
        this.merk = merk;
        this.ram = ram;
        this.prosesor = prosesor;
    }

   public void tampil()
   {
       System.out.println("Merk CPU : "+merk);
       System.out.println("Ukuran RAM : "+ram.getUkuran());
       System.out.println("Type Prosesor : "+prosesor.getType());
   }
    }
