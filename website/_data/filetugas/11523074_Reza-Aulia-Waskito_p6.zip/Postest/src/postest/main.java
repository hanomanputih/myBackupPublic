
package postest;

public class main {
    public static void main(String[] args) {
    Prosesor ps = new Prosesor ();
    ps.setType("Core I7");
            
    RAM rm = new RAM ();
    rm.setUkuran("512");
    
    CPU cpu = new CPU ("Simbadda",rm,ps);

    
    
   cpu.tampil();
    
}
}