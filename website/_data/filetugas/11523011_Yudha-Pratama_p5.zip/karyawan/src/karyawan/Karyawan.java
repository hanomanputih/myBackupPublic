/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class Karyawan {

    private String nip;
    private String nama;
    private int gaji;

    void setNama(String n) {
        nama = n;
        if (n.length() == 8) {
            System.out.println("nama");
        }
    }

    String getNama() {
        return nama;
    }

    void setNip(String np) {
        nip = np;
        if (np.length() == 10) {
            System.out.println("nip");
        } else {
            System.out.println("nip tidak sesuai");
        }
    }

    String getNip() {
        return nip;
    }

    void setGaji(int gj) {
        gaji = gj;
        if (gj >= 100000 && gj <= 500000) {
            System.out.println("gaji anda sebesar");
        }
        }
    int getGaji() {
        return gaji;
    }
}