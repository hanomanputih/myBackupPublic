/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class mainclass {

    public static void main(String[] args) {
        Karyawan k = new Karyawan();
        k.setGaji(250000);
        k.setNama("Muzakirs");
        k.setNip("1234567890");

        System.out.println("Gaji : " + k.getGaji());
        System.out.println("Nama : " + k.getNama());
        System.out.println("Nip : " + k.getNip());
    }
}
