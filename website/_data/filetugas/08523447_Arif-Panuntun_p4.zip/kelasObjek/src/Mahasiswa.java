
import java.util.Scanner;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
    String nama;
    String nim,fakultas, jurusan, angkatan;
   
    void cetak(){
        System.out.println("nama"+nama);
        System.out.println("nim"+nim);
        System.out.println("fakultas"+fakultas);
        System.out.println("jurusan"+jurusan);
        System.out.println("angkatan"+angkatan);
        
        
        
    }
     public static void main(String[] args) {
          Scanner zz=new Scanner(System.in);
          Mahasiswa cetak=new Mahasiswa();
          System.out.println("nama saya");
        cetak.nama = zz.nextLine();
        System.out.println("nim saya");
        cetak.nim = zz.nextLine();
        System.out.println("fakultas");
        cetak.fakultas = zz.nextLine();
        System.out.println("jurusan");
        cetak.jurusan = zz.nextLine();
        System.out.println("angkatan");
        cetak.angkatan = zz.nextLine();
        cetak.cetak();
         System.out.println("");
     }
}
