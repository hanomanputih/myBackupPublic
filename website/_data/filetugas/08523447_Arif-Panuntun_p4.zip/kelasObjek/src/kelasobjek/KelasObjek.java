/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package kelasobjek;

/**
 *
 * @author Praktikan
 */
public class KelasObjek {
String nama = "Arif Panuntun";
    public static void main(String[] args) {
     KelasObjek cetak = new KelasObjek();
        System.out.println("karakter ke 4 adalah "+cetak.nama.charAt(5));
        System.out.println("Kata depan saya"+cetak.nama.startsWith("arif"));
        System.out.println("Kata terakhir saya"+cetak.nama.endsWith("Panuntun"));
        System.out.println("Panjang karakter nama saya"+cetak.nama.length());
    }
}
