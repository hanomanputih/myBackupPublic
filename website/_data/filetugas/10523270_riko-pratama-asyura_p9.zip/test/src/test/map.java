/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author PRAKTIKAN
 */
public class map {
    public static void main(String[] args) {
        Map<Integer,String> mahasiswa = new HashMap<Integer,String>();
        
        mahasiswa.put(1, "10523270");
        mahasiswa.put(2, "riko pratama asyura");
        mahasiswa.put(3, "informatika");
        
        
        for(Map.Entry<Integer,String> ee : mahasiswa.entrySet()){
            System.out.println(ee.getKey()+ " "+ee.getValue());
        }
    }
    
}
