/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 *
 * @author PRAKTIKAN
 */
public class main {
    public static void main(String[] args){
        List mahasiswa = new ArrayList();
        
        mahasiswa.add("DATA MAHASISWA");
        mahasiswa.add(10523270);
        mahasiswa.add("riko pratama asyura");
        mahasiswa.add("informatika");
        
        
        System.out.println(mahasiswa);
        System.out.println("--------------");
        
        for(Object xx : mahasiswa){
            System.out.println(xx);
        }
        System.out.println("--------------");
        
        Iterator itt = mahasiswa.iterator();
        while(itt.hasNext()){
            System.out.println(itt.next());
            System.out.println("---------------");
        }
        for (int i = 0; i<mahasiswa.size();i++)
            System.out.println(mahasiswa.get(i));
        System.out.println("---------------");
    }
    
}
