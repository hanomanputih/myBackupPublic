/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;


import java.util.Scanner;
public class Mahasiswa {
    String nama;
    String nim ;
    String fakultas ;
    String jurusan ;
    String angkatan ;
    
    void cetak(){
        Scanner baca = new Scanner(System.in);
        System.out.println("Nama anda adalah");
        nama = baca.next();
        System.out.println("NIM anda");
        nim = baca.next();
        System.out.println("Fakultas anda adalah");
        fakultas = baca.next();
        System.out.println("Jurusan anda adalah");
        jurusan = baca.next();
        System.out.println("Angkatan anda adalah");
        angkatan = baca.next();
        
        System.out.println("nama anda : " +nama);
        System.out.println("nim anda : " +nim);
        System.out.println("fakultas anda : " +fakultas);
        System.out.println("jurusan anda : " +jurusan);
        System.out.println("angkatan anda : " +angkatan);
    }
    
        public static void main(String[] args) {
            Mahasiswa mhs = new Mahasiswa();
            mhs.cetak();
        
        
    
   
   
    }
}

