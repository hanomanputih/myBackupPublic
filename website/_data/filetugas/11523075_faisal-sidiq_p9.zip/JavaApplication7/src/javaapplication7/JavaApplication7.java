/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication7;
import java.util.Scanner;
import java.util.Collection;
import java.util.HashMap;
import java.util.Set;

public class JavaApplication7 {
 
  
    public static void main(String[] args) {
        String nm;
         Scanner sc = new Scanner(System.in);
                 System.out.println("Nama : ");
HashMap map = new HashMap();
map.put("1","nama");
map.put("NIM",new Integer(11523075));



     }
    
}
