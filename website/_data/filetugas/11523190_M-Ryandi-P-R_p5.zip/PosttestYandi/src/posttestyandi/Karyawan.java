/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttestyandi;

/**
 *
 * @author Praktikan
 */
public class Karyawan {
    private String nip, nama;
    private int gaji;
    
    void setNama(String nm){
        if(nm.length() >= 8){
            nama = nm;
        } else {
            System.out.println("kurang karakter nama");
        }
    }
    
    String getNama(){
        return nama;
    }
    
    void setNip(String np) {
        if(np.length() == 10){
            nip = np;
        } else {
            System.out.println("nip tidak sesuai");
        }
    }
    
    String getNip() {
        return nip;
    }
    
    void setGaji(int g){
        if(g >= 100000 && g <= 500000){
            gaji = g;
        } else {
            System.out.println("gaji tidak sesuai");
        }
    }
    
    int getGaji(){
        return gaji;
    }
    
}
