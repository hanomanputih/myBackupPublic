/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttestyandi;

/**
 *
 * @author Praktikan
 */
public class PosttestYandi {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Karyawan k = new Karyawan();
        k.setNip("1234567890");
        k.setNama("Ryandi Putra");
        k.setGaji(300000);
        System.out.println("NIP           = "+k.getNip());
        System.out.println("Nama          = "+k.getNama());
        System.out.println("Gaji perbulan = Rp."+k.getGaji());
        System.out.println("Gaji setahun  = Rp."+k.getGaji()*12);
    }
}
