/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package praktikan;

/**
 *
 * @author PRAKTIKAN
 */
public class Praktikan {

    String nama;
    String nim;
    static String variabel1;
    
    void tampil(){
        System.out.println("Nama = " + nama);
        System.out.println("NIM = " + nim);
    }
    
    public static void main(String[] args) {
        Praktikan prk1 = new Praktikan();
        prk1.nama="joko";
        prk1.nim="10523000";
        System.out.println("Diawali dengan kata =" + prk1.nama.startsWith("joko"));
        System.out.println("Jumlah huruf variabel =" + prk1.nama.length());
    prk1.tampil();
    
    //double coba = Math.abs(-10);
        //System.out.println(coba);
        //variabel1 = "aku";
        
    }
}
