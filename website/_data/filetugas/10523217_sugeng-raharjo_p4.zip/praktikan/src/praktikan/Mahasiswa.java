/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package praktikan;

import java.util.Scanner;



public class Mahasiswa {
    String nama;
    String nim;
    String fakultas;
    String jurusan;
    String angkatan;
    
    void cetak(){
        System.out.println("======HASILNYA ADALAH==========");
        System.out.println("Nama = " + nama);
        System.out.println("NIM = " + nim);
        System.out.println("Fakultas = " + fakultas);
        System.out.println("Jurusan = " + jurusan);
        System.out.println("Angkatan = " + angkatan);
    }

    
    
    public static void main(String[] args) {
        Mahasiswa mhs1 = new Mahasiswa();
        //int nama,nim,fakultas,jurusan,angkatan;
        Scanner sc = new Scanner(System.in);
        System.out.print("Nama = ");
        mhs1.nama=sc.nextLine();
        System.out.print("Nim = ");
        mhs1.nim=sc.nextLine();
        System.out.print("Fakultas = ");
        mhs1.fakultas=sc.nextLine();
        System.out.print("Jurusan = ");
        mhs1.jurusan=sc.nextLine();
        System.out.print("Angkatan = ");
        mhs1.angkatan=sc.nextLine();
        
        
       
        mhs1.cetak();
    }

}
