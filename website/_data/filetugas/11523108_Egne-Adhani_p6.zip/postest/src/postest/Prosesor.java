package postest;

public class Prosesor {
    int type;
    
    void cetak(){
        System.out.println("tipe prosesor: "+type);
    }
    public Prosesor (int tipe) {
        this.type=tipe;
    }
}
