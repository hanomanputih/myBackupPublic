package postest;

public class RAM {
int type;
    
    void cetak(){
        System.out.println("tipe prosesor: "+type);
    }
    public RAM (int tipe) {
        this.type=tipe;
    }
}
