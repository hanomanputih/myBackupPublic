package postest;

public class Komputer {
String nama;
private Prosesor p;
private RAM rm;

public Komputer(String nama) {
    this.nama=nama;
    if (nama.equals("asus")) {
        p=new Prosesor (3);
        rm=new RAM (1);
    }
}

void Tampil() {
    System.out.println("nama komputer: "+nama);
    System.out.println("nama prosesor: "+p.type);
    System.out.println("nama RAM: "+rm.type);
}

    public static void main(String[] args) {
        Komputer k = new Komputer("asus");
        k.Tampil();
    }
}
