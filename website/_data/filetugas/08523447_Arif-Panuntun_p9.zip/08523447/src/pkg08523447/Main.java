/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg08523447;

import java.util.Collections;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;


/**
 *
 * @author Praktikan
 */
public class Main {
    private static LinkedList LinkedLis;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList list=new ArrayList();
        LinkedList list2 =new LinkedList();
        
        list.add("ksc");
        list.add("PIT");
        list.add("sirkel");
        list.add("jarkom");
        list2.add("ini");
        list2.add("disini");
        System.out.println("ukuran list"+list.size());
        
        for (Iterator iterator = list.iterator(); iterator.hasNext();){
            String ii = (String) interator.next();
            System.out.println("isi : " +ii);
        }
    }
}
