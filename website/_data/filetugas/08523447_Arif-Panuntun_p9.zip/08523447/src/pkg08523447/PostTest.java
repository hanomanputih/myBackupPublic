/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg08523447;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;
import java.util.Scanner;
/**
 *
 * @author Praktikan
 */
public class PostTest {
    public static void main(String[] args) {
        int NIM;
        String nama;
        
        Scanner sc=new Scanner(System.in);
        HashMap hm=new HashMap();
        ArrayList ar=new ArrayList();
        
        ar.add("08523447");
        ar.add("Arif Panuntun");
        System.out.println("Ukuran List"+ar.size());
        for (Iterator it=ar.iterator();it.hasNext();){
        String ys=(String) it.next();
            System.out.println("nama dan NIM"+ys);
        }
         hm.put("NIM", "08523447");
         hm.put("Nama", "Arif");
         System.out.println("Ukuran Map:"+hm.size());
         System.out.println(hm);
        }
        
        
    }

