/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg08523447;
import java.util.HashMap;

/**
 *
 * @author Praktikan
 */
public class example {
     public static void main(String[] args) {
         HashMap map = new HashMap();
         map.put("Nama ", "Fadly");
         map.put("NIM ",new Integer(9523257));
     }
}
