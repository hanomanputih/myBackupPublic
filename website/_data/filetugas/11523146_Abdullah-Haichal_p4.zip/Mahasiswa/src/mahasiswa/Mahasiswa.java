/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
    String nama;
    String nim;
    String fakultas;
    String jurusan;
    String angkatan;
    
    void cetak ()
    { 
    Scanner mahasiswa = new Scanner (System.in);
        System.out.println("masukan nama anda : ");
        nama = mahasiswa.next ();
        System.out.println("masukan nim anda : ");
        nim = mahasiswa.next();
        System.out.println("masukan fakultas anda : ");
        fakultas = mahasiswa.next();
        System.out.println("masukan jurusan anda : ");
        jurusan = mahasiswa.next();
        System.out.println("masukan angkatan anda : ");
        angkatan = mahasiswa.next ();
        System.out.println("nama anda adalah : "+ nama);
        System.out.println("nim anda adalah : "+nim);
        System.out.println("fakultas anda : "+ fakultas);
        System.out.println("jurusan anda : "+ jurusan);
        System.out.println("angkatan anda : "+ angkatan);
        
        
    }
    public static void main(String[] args) {
        Mahasiswa mahasiswa1 = new Mahasiswa ();
        mahasiswa1.cetak();
        // TODO code application logic here
    }
}
