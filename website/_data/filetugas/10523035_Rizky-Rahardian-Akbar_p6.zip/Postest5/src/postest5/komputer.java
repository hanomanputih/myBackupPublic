/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest5;

/**
 *
 * @author Praktikan
 */
public class komputer {
     String Namakomp;
     private prosesor p;
     private ram r;
    public komputer(String Namakomp){
        this.Namakomp= Namakomp;
        if(Namakomp.equals("dell")){
            p = new prosesor("Quadcore");
            r = new ram("Nvidia Gforce 2TB");
        }
    }
    public void Tampil(){
        System.out.println("Nama Komputer "+Namakomp);
        if(Namakomp.equals("dell")){
        System.out.println("prosesor "+p.Namapros);
        System.out.println("Ram "+r.Namaram);
        }else{
            System.out.println("tidak terdaftar");
        }
    }
}
