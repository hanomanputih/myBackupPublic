/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest5;

import javax.swing.JOptionPane;

/**
 *
 * @author Praktikan
 */
public class Postest5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String komp=JOptionPane.showInputDialog("Masukkan Nama komputer(contoh : dell)");
         komputer comp = new komputer(komp);
     
        comp.Tampil();
    }
}
