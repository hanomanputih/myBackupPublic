/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest4;

/**
 *
 * @author PRAKTIKAN
 */
public class Karyawan {

    /**
     * @param args the command line arguments
     */
    private String nip, nama;
    private int gaji;
    
    
    public void setNip(String nipAnda){
        if(nipAnda.length()==3){
            nip=nipAnda;            
        }else{
            System.out.println("Error");
        }
    }
    public String getNip(){
        return nip;
    }
    
    
    public void setNama(String namaAnda){
        nama=namaAnda;
    }
        public String getNama(){
        return nama;
    }
    
    public void setGaji(int gajiAnda){
            if(gajiAnda<1000000){
            gaji=gajiAnda;            
        }else{
            System.out.println("Error");
        }
    }
        public int getGaji(){
        return gaji;
    }
    }
    
    
    
    
    
    
    
    
    
    
    
