/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest4;

/**
 *
 * @author PRAKTIKAN
 */
public class pemanggil4 {
        public static void main(String[] args) {
        Karyawan kry = new Karyawan();
        kry.setNip ("249");
        kry.setNama ("aris");
        kry.setGaji (100000);
                
                System.out.println("nip "+kry.getNip());
                System.out.println("nama "+kry.getNama());
                System.out.println("gaji "+kry.getGaji());
    
}
}