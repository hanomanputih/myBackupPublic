/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

/**
 *
 * @author Praktikan
 */
public abstract class karyawan {
      int gajipokok = 3000000;
      int tunjangan = (int) (0.2*gajipokok);
      int bonus = 300000;
      int gaji;
      
      public abstract void gaji();
      
  
      
}
