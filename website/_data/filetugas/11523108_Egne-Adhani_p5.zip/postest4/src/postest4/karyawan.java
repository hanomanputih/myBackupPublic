package postest4;


public class karyawan {
    private String nip;
    private String nama;
    private int gaji;
    
    public void setnip (String nip) {
        this.nip = nip;
    }
    
    public void setgaji (int gaji) {
        this.gaji = gaji;
    }
    
    public void setnama (String nama) {
        this.nama = nama;
    }
    
    public String getnip() {
        return nip;
    }
    
    public int getgaji () {
        return gaji;
    }
    
     public String getnama () {
        return nama;
    }
}
