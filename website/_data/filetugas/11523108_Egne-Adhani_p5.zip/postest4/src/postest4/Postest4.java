
package postest4;

public class Postest4 {

    
    public static void main(String[] args) {
       karyawan k = new karyawan ();
       
       k.setnama("hehehe");
       System.out.println("nama karyawan adalah "+k.getnama());
       
       k.setnip("12345");
       System.out.println("nip karyawan adalah "+k.getnip());
       
       k.setgaji(5000000); 
       System.out.println("gaji karyawan adalah "+k.getgaji());
        
    }
}
