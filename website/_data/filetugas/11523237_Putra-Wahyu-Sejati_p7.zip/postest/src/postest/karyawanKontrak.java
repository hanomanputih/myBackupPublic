
package postest;


public class karyawanKontrak extends Karyawan {

    private String kerja1;

    public String getKerja1() {
        return kerja1;
    }

    public void setKerja1(String kerja1) {
        this.kerja1 = kerja1;
    }

    public void bekerja() {
        System.out.println("bekerja sepatuh waktu");
    }

    
    public void kehadiran() {
        System.out.println("kehasdiran penuh");
    }

    public void lihat() {
        super.lihat();
        System.out.println("status kerja  :" + kerja1);
    }
}
