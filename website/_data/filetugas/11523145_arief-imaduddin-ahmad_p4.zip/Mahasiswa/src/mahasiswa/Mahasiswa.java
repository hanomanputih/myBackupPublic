/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

/**
 *
 * @author Praktikan
 */
import java.util.Scanner;

public class Mahasiswa {

    String nama;
    String nim;
    String fakultas;
    String jurusan;
    String angkatan;

    public void cetak() {
        System.out.println("Masukkan Nama : " + nama);
        System.out.println("Panjang karakter nama anda adalah : " + nama.length());
        System.out.println("Masukkan Nim anda :" + nim);
        System.out.println("Panjang karakter nim adalah :" + nim.length());
        System.out.println("Fakultas anda adalah : " + fakultas);
        System.out.println("Panjang karakter fakultas anda adalah :" + fakultas.length());
        System.out.println("Jurusan anda :" + jurusan);
        System.out.println("Panjang karakter jurusan anda adalah :" + jurusan.length());
        System.out.println("Angkatan anda :" + angkatan);
        System.out.println("Panjang karakter angkatan anda adalah :" + angkatan.length());
    }

    public static void main(String[] args) {
        Mahasiswa mhs = new Mahasiswa();
        Scanner coba = new Scanner(System.in);
        System.out.println("Masukkan Nama anda: ");
        mhs.nama = coba.next();
        System.out.println("Masukkan Nim anda:");
        mhs.nim = coba.next();
        System.out.println("Masukkan Fakultas anda: ");
        mhs.fakultas = coba.next();
        System.out.println("Masukkan Jurusan anda:");
        mhs.jurusan = coba.next();
        System.out.println("Masukkan Angkatan anda:");
        mhs.angkatan = coba.next();
        mhs.cetak();
    }
}
