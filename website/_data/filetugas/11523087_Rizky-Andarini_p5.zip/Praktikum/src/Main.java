/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author PRAKTIKAN
 */
public class Main {
    public static void main(String[] args) {
        Karyawan k = new Karyawan();
        
        k.setNip("11523087");
        k.setNama("Rizky Andarini");
        k.setGaji(1000000);
        
        System.out.println("NIM anda : "+k.getNip());
        System.out.println("Nama anda : "+k.getNama());
        System.out.println("Gaji anda : "+k.getGaji());
        
    }
}
