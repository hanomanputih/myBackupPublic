/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

import java.util.Scanner;

/**
 *
 * @author praktikan
 */
public class Mahasiswa {

    String nama;
    String nim;
    String fakultas;
    String jurusan;
    String angkatan;
    int tes;
    /**
     * @param args the command line arguments
     */
    void cetak(){
        System.out.println("Nama Anda : " +nama);
        System.out.println("NIM Anda : " +nim);
        System.out.println("Fakultas : " +fakultas);
        System.out.println("Jurusan : " +jurusan);
        System.out.println("Angkatan : " +angkatan);
        System.out.println("Jumlah karakter : " +nim.length());
        System.out.println("Jumlah karakter : " +nama.length());
        System.out.println("Jumlah karakter : " +fakultas.length());
        System.out.println("Jumlah karakter : " +jurusan.length());
        System.out.println("Jumlah karakter : " +angkatan.length());
    }
    
    public static void main(String[] args) {
    Scanner bc = new Scanner(System.in);
    Mahasiswa mhs1 = new Mahasiswa();
        System.out.println("Nama : ");
    mhs1.nama = bc.next();
        System.out.println("NIM : ");
    mhs1.nim = bc.next();
        System.out.println("Fakultas : ");
    mhs1.fakultas = bc.next();
        System.out.println("Jurusan : ");
    mhs1.jurusan = bc.next();
        System.out.println("Angkatan : ");
    mhs1.angkatan = bc.next();
        mhs1.cetak();
        
        
        // TODO code application logic here
    }
}
