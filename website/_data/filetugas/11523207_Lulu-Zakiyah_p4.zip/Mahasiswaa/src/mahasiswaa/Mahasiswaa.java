/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswaa;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Mahasiswaa {
String nama;
String nim;
String fakultas, jurusan, angkatan;

void cetak () {
    Scanner sc = new Scanner (System.in);
    System.out.print("masukkan nama :");
    nama = sc.next();
    System.out.print("masukkan nim :");
    nim = sc.next();
    System.out.print("masukkan fakultas :");
    fakultas = sc.next();
    System.out.print("masukkan jurusan :");
    jurusan = sc.next();
    System.out.print("masukkan angkatan :");
    angkatan = sc.next();
}
    public static void main(String[] args) {
        Mahasiswaa mhs1 = new Mahasiswaa ();
        
        mhs1.cetak();
        System.out.println("nama kamu adalah : " +mhs1.nama);
        System.out.println("panjang karakter nama : " +mhs1.nama.length());
        System.out.println("nim kamu adalah :" +mhs1.nim);
        System.out.println("panjang karakter nim : " +mhs1.nim.length());
        System.out.println("fakultas kamu adalah : " +mhs1.fakultas);
        System.out.println("panjang karakter fakultas : " +mhs1.fakultas.length());
        System.out.println("angkatan kamu adalah :" +mhs1.angkatan);
        System.out.println("panjang karakter angkatan : " +mhs1.angkatan.length());
    }
}
    /**
     * @param args the command line arguments
     */
   

