/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest4;

/**
 *
 * @author Praktikan
 */
public class Karyawan {
    private int gaji;
    private String nama, nip;
    
    void NIP(String nip){
    if(nip.length() == 8){
        this.nip = nip;
    } else {
        System.out.println("Erroooorrrrrr");
    }
}

String NIP (){
    return nip;
}

void NAMA(String nama){
    if(nama.length() == 6){
        this.nama = nama;
    } else {
        System.out.println("Erroooorrrrrr");
    }
}

String NAMA (){
    return nama;
}

void setGAJI(int gaji){
    if(gaji<1000000){
        this.gaji = gaji;
    } else {
        System.out.println("Lumayan");
    }
}

int GAJI (){
    int gajisetahun;
    gajisetahun= 12*gaji;
    return gajisetahun;
}

}
