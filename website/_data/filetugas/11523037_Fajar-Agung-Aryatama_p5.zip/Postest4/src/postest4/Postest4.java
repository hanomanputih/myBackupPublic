/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest4;

/**
 *
 * @author Praktikan
 */
public class Postest4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    Karyawan ka = new Karyawan();
    ka.NIP("12345678");
        System.out.println("NIP ku = "+ka.NIP());
    ka.NAMA("Mamang");
        System.out.println("Nama ku = "+ka.NAMA());
    ka.setGAJI(900000);
        System.out.println("Gaji ku = "+ka.GAJI());
    
    }
}
