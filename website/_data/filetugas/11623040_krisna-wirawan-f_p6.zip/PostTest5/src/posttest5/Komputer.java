/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest5;

/**
 *
 * @author Praktikan
 */
public class Komputer {
    String nama;
    Prosesor p;
    RAM r;
    
public Komputer(String nama){
    this.nama=nama;
    r= new RAM("2gb");
    p= new Prosesor("intel COre 13"); 
    System.out.println("nama komputer ini adalah "+ nama);
    System.out.println("Prosesornya adalah "+ p.Jenis);
    System.out.println("RAM komputer ini adalah " +r.Jenis);
}
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Komputer kom = new Komputer("Acer");
        

        
        
        
    }
}
