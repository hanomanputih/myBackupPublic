/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest5;

/**
 *
 * @author Praktikan
 */
public class Prosesor {
    String Jenis;
    public Prosesor(String Jenis){
    this.Jenis=Jenis;
}
}