/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest5;

/**
 *
 * @author Praktikan
 */
public class RAM {
    String Jenis;
    public RAM (String Jenis){
    this.Jenis=Jenis;
    }
}
    
