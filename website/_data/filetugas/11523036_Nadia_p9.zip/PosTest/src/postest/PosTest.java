
package postest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class PosTest {

    
    public static void main(String[] args) {
        List<String> list1=new ArrayList<String>();
        List<Integer> list2=new ArrayList<Integer>();
        
        list1.add("cia");
        list1.add("ambing");
        list1.add("onyet");
        
        list2.add(11523036);
        list2.add(11523018);
        list2.add(11523012);
        
        
        System.out.println("Pake list");
        System.out.println("================");
        
        for (int i=0;i<list1.size();i++){
            System.out.println(list1.get(i)+" "+ list2.get(i));
        
        }
        System.out.println("================");
        System.out.println("Pake Map");
        System.out.println("================");
        
       Map<Integer,String> map=new HashMap<Integer,String>();
       
       map.put(11523012, "onyet");
       map.put(11523018, "uni");
       map.put(11523036, "hapni ambing");
        
        for (Integer i : map.keySet()){
            System.out.println("key " +i+ " : "+ map.get(11523012));
        }
        
        
    }
}
