/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest4;

/**
 *
 * @author PRAKTIKAN
 */
public class Postest4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Karyawan ka = new Karyawan();
        ka.setNIP ("115230");
        System.out.println("nim ku ="+ka.getNIP());
        Karyawan ku = new Karyawan();
        ku.setNAMA ("eRWIM");
        System.out.println("nama ku ="+ku.getNAMA());
        Karyawan su = new Karyawan();
        su.setGAJI (800000);
        System.out.println("GAJI ku ="+su.getGAJI());
    }
}
