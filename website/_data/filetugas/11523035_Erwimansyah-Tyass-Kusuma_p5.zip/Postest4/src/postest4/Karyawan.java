/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest4;

/**
 *
 * @author PRAKTIKAN
 */



public class Karyawan {
private int gaji;
private String nip,nama;
 void setNIP(String nip){
     if(nip.length()==9){
         this.nip=nip;
         
     }else{
         System.out.println("Error");
     }
 }
String getNIP(){
return nip;
}

void setNAMA(String nama){
 this.nama=nama;
     }

String getNAMA(){
return nama;
 

} 
void setGAJI(int gaji){
     if(gaji > 500000){
         this.gaji=gaji;
         
     }else{
         System.out.println("Sangat rendah");
     }
 }
int getGAJI(){
return gaji;
}
}
