/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa1;

import java.util.Scanner;

/**
 *
 * @author PRAKTIKAN
 */
public class Mahasiswa1 {
String nama,nim,fakultas,jurusan,angkatan;
    

    /**
     * @param args the command line arguments
     */
void cetak()
{
    System.out.println("Nama: "+nama);
    System.out.println("Nim: "+nim);
    System.out.println("Nama fakultas:"+fakultas);
    System.out.println("Jurusan :"+jurusan);
    System.out.println("Angkatan :"+angkatan);
            
}
    public static void main(String[] args) {
        // TODO code application logic here
        Mahasiswa1 mhs = new Mahasiswa1();
        System.out.print("Masukkan Nama : ");
        Scanner sc = new Scanner(System.in);
        mhs.nama=sc.next();
        System.out.print("Masukkan NIM : ");
        mhs.nim=sc.next();
        System.out.print("Nama fakultas : ");
        mhs.fakultas=sc.next();
        System.out.print("Nama jurusan : ");
        mhs.jurusan=sc.next();
        System.out.print("Masukkan angkatan : ");
        mhs.angkatan=sc.next();
        
        mhs.cetak();
    }
}
