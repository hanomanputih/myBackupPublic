/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {

    /**
     * @param args the command line arguments
     */
    String nama, nim, fakultas, jurusan,angkatan;
    void cetak (){
        nama="mutiara";
        nim="11523292";
        fakultas="teknologi industri";
        jurusan="teknik informatika";
        angkatan="2011";
        System.out.println(nama);
        System.out.println(nim);
        System.out.println(fakultas);
        System.out.println(jurusan);
        System.out.println(angkatan);
                }
    public static void main(String[] args) {
        // TODO code application logic here
        Mahasiswa m = new Mahasiswa();
        m.cetak();
    }
}
