/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package CPU;

/**
 *
 * @author PRAKTIKAN
 */
public class CPU {

   int produk;
   String nonproduk;
   Procesor x1;
   RAM x2;
    public static void main(String[] args) {
        // TODO code application logic here
        Procesor x1 = new Procesor();
        RAM x2 = new RAM();
        x1 = new Procesor();
        x2 = new RAM();
        Procesor x1 = ("intel");
        RAM x2 = ("ddr3");
        
    }
    public void tampilCPU() {
    System.out.println("Procesor x1" + Procesor x1);
    System.out.println("RAM x2" + RAM x2);
    }
}
