/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa1;

/**
 *
 * @author Praktikan
 */
import java.util.Scanner;

public class Mahasiswa1 {

   String fakultas, nama, nim, jurusan, angkatan;
   
   void cetak (){
       Scanner cetak = new Scanner(System.in);
       System.out.println("Fakultas");
       System.out.print("Masukkan fakultas anda = ");
       fakultas = cetak.next();
          System.out.println("    ");
       System.out.println("Nama");
       System.out.print("Masukkan nama anda = ");
       nama = cetak.next();
          System.out.println("    ");
       System.out.println("NIM");
       System.out.print("Masukan Nim anda = ");
       nim = cetak.next();
          System.out.println("    ");
       System.out.println("Jurusan");
       System.out.print("masukan jurusan anda = ");
       jurusan = cetak.next();
          System.out.println("    ");
       System.out.println("Angkatan");
       System.out.print("Masukan tahun angkatan anda = ");
       angkatan = cetak.next();
   }
    public static void main(String[] args) {
        Mahasiswa1 m1 = new Mahasiswa1();
        m1.cetak();
        
        
    }
}
