/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes;

/**
 *
 * @author PRAKTIKAN
 */
public class Prosesor {
String nama, merk ;

    public Prosesor(String nama, String merk){
        this.nama = nama;
        this.merk = merk;
}
    
}