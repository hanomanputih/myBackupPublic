/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes;

/**
 *
 * @author PRAKTIKAN
 */
public class POSTES {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
}
