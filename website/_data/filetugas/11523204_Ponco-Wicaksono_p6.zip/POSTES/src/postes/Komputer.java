/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes;

/**
 *
 * @author PRAKTIKAN
 */
public class Komputer {
    String nama, merk;
    Prosesor p;
    RAM r;
    public Komputer(String m){
        merk=m;
        if(merk.equals("9")){
            p=new Prosesor("Pewek","Intel");
     
            r=new RAM(8);
        }
        
    }
    public static void main(String[] args) {
        Komputer m = new Komputer("9");
        System.out.println("Nama prosesor "+m.p.nama);
        System.out.println("Kapasitas ram "+m.r.kapasitas);
        System.out.println("Merk prosesor "+m.p.merk);
}
}
