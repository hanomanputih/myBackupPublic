/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes;

/**
 *
 * @author PRAKTIKAN
 */
public class RAM {
    int kapasitas;
    public RAM(int kapasitas){
        this.kapasitas=kapasitas;
    
}
}
