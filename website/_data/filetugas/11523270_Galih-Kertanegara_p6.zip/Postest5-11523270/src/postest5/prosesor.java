/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest5;

/**
 *
 * @author PRAKTIKAN
 */
public class prosesor {
    String merk;
    int harga;
    
    
    public prosesor(String M, int H){
        this.merk = M;
        this.harga = H;
        
}
    
    
}
