/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest5;

/**
 *
 * @author PRAKTIKAN
 */
public class Komputer {
    RAM R;
    prosesor p;
    int hargaKomputer;
    
    
    public Komputer (int hargaKomputer){
        this.hargaKomputer = hargaKomputer;
        R = new RAM ("Kingston");
        p = new prosesor ("Intel", 3000000);
    }
    
    public void Cetak(){
        System.out.println("Nama Prosesor :"+p.merk);
        System.out.println("harga Prosesor :"+p.harga);
        System.out.println("Nama RAM :"+R.merkRAM);
        System.out.println("Harga Komputer :"+hargaKomputer);
    }

    public static void main(String[] args) {
        // TODO code application logic here
        Komputer k = new Komputer (40000000);
    k.Cetak();

}
}
