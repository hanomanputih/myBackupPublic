/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest5;

/**
 *
 * @author Praktikan
 */
public class Prosesor {
    String jenisProsesor;
    public Prosesor (String jenisProsesor){
        this.jenisProsesor = jenisProsesor;
    }
    public void nampilProsesor() {
        System.out.println("jenis prosesor :"+jenisProsesor);
    }
    
}
