/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

/**
 *
 * @author Praktikan
 */
public class Karyawan {
    public static void main(String[] args) {
        Main M=new Main();
        
        M.setNip("11523185");
        M.setNama("Adam");
        M.setGaji(2000000);
        
        System.out.println("Nip anda adalah " +M.getNip());
        System.out.println("Nama anda adalah " +M.getNama());
        System.out.println("Gaji anda adalah " +M.getGaji()*12);
    }
}
