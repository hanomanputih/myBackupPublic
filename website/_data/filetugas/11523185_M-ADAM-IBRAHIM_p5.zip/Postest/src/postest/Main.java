/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

/**
 *
 * @author Praktikan
 */
public class Main {
    private String Nip;
    private String Nama;
    private int Gaji;
    
    public  String getNip() {
        return Nip;
    }
    public void setNip(String Nip)
    {
        this.Nip=Nip;
    }
    public  String getNama() {
        return Nama;
    }
    public void setNama(String Nama)
    {
        this.Nama=Nama;
    }
    public  int getGaji() {
        return Gaji;
    }
    public void setGaji(int Gaji)
    {
        this.Gaji=Gaji;
    }
}
