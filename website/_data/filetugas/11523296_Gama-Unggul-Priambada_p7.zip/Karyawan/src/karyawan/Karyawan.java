/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author lab-KSC
 */
public abstract class Karyawan {
public int gajiP = 3000000;
public void tampil(){
    System.out.println("Gaji Pokok : "+gajiP);
}
       

}
