/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author lab-KSC
 */
public class Pewarisan {
    public static void main(String[] args) {
        KaryawanTetap kartap = new KaryawanTetap();
        KaryawanKontrak karkon = new KaryawanKontrak();
        System.out.println("Karyawan Tetap :");
        kartap.tampil();
        System.out.println("");
        System.out.println("Karyawan Kontrak");
        karkon.tampil();
    }
}
