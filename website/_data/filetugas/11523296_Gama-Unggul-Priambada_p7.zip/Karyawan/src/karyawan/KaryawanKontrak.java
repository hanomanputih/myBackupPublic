/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author lab-KSC
 */
public class KaryawanKontrak extends Karyawan {
    int bonus = 2000000;
    double gaji = bonus + gajiP;
    
    @Override
    public void tampil(){
        System.out.println("Gaji pokok : "+gajiP);
        System.out.println("Bonus      : "+ bonus);
        System.out.println("Gaji Total : "+gaji);
    }
    
}
