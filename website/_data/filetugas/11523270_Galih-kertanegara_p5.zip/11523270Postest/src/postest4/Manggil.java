/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest4;

/**
 *
 * @author PRAKTIKAN
 */
public class Manggil {
    public static void main(String[] args) {
       Karyawan kry = new Karyawan();
        
        kry.setNip("11523270");
        kry.setNama ("galih");
        kry.setGaji  (300000);
        
        System.out.println("NIP Anda : " + kry.getNip());
        System.out.println("Nama anda : " + kry.getNama());
        System.out.println("Gaji perbulan : " + kry.getGaji());
        
}}
