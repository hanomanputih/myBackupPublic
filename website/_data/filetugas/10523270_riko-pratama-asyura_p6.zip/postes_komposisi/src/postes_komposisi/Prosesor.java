/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package postes_komposisi;

/**
 *
 * @author Praktikan
 */
public class Prosesor {
    String merk;
    public Prosesor(String mrk){
        merk = mrk;
    }
}
