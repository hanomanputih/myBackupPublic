/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package postes_komposisi;

/**
 *
 * @author Praktikan
 */
public class Komputer {
    String namaKomputer;
    Prosesor ps;
    Ram rm;

    public Komputer(String namaKomp, Prosesor pss, Ram rmm){
        namaKomputer = namaKomp;
        ps = pss;
        rm = rmm;
    }

    public void tampil(Prosesor ps, Ram rm){
        System.out.println("nama Komputer : "+namaKomputer);
        System.out.println("merk :"+ps.merk);
        System.out.println("kapasitas :"+rm.kapasitas);
    }
}
