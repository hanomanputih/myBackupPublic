/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package postes_komposisi;

/**
 *
 * @author Praktikan
 */
public class mainKomposisi {
    public static void main(String[] args){
        Prosesor pss = new Prosesor("apa aja");
        Ram rmm = new Ram("apa ya");
        Komputer kom = new Komputer("punya siapa ya", pss, rmm);
        kom.tampil(pss, rmm);
        //kom.tampil(rmm);
    }

}
