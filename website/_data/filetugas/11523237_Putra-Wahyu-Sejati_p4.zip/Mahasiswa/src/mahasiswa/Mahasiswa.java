/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package mahasiswa;
import java.util.Scanner;

public class Mahasiswa {
 String nama, nim, jurusan, fakultas;


public void cetak (){
Scanner ctk = new Scanner(System.in);
System.out.print("masukan nama anda      : ");
nama = ctk.next();

System.out.print("masukkan nim anda      : ");
nim = ctk.next();

System.out.print("masukkan jurusan anda  : ");
jurusan = ctk.next();

System.out.print("masukkan fakultas anda  : ");
fakultas = ctk.next();
System.out.println("");

System.out.println("BIODATA KAMU ADALAH SEBAGAI BERIKUT: ");

System.out.println("masukan nama anda       : "+nama);
System.out.println("masukan nim anda        : "+nim);
System.out.println("masukan jurusan anda    : "+jurusan);
System.out.println("masukan fakultas anda   : "+fakultas);
}

    public static void main(String[] args) {
        Mahasiswa ctk = new Mahasiswa();
        ctk.cetak();
        
        
    }
}
