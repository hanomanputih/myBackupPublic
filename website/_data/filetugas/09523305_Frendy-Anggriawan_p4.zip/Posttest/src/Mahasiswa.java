
import java.util.Scanner;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
   
    String nama = "Frendy Anggriawan";
    String nim = "09523305";
    
  String fakultas;
  String jurusan;
  String angkatan;
  
  void cetak(){
      Scanner s = new Scanner (System.in);
      
              
      System.out.println("nama anda adalah");
      nama = s.next();
      System.out.println("nim anda adalah");
      nim = s.next();
      System.out.println("fakultas anda adalah");
      fakultas = s.next();
      System.out.println("jurusan anda adalah");
      jurusan = s.next();
      System.out.println("angkatan anda adalah");
      angkatan= s.next();
      
      System.out.println("nama anda adalah"+nama);
      System.out.println("nim anda adalah"+nim);
      System.out.println("fakultas anda adalah"+fakultas);
      System.out.println("jurusan anda adalah"+jurusan);
      System.out.println("angkatan anda adalah"+angkatan);
      
      

/**
 *
 * @author Praktikan
 */

         
         
     }
}

    

  


    

