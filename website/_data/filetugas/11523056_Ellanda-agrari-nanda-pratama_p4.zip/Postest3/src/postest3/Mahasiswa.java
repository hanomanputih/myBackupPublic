/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package postest3;

import java.util.Scanner;


/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
    String nim;
    String nama;
    String jurusan;
    float jumlah1;
void cetak (){
    System.out.println("nama anda = "+nama);
    System.out.println("nim anda = "+nim);
    System.out.println("jurusan anda = "+jurusan);
}
    public static void main(String[] args) {
        Scanner baca = new Scanner (System.in);
            Mahasiswa mhs1 = new Mahasiswa();
            System.out.print("Nama = ");
            mhs1.nama = baca.next();
            System.out.print("Nim = ");
            mhs1.nim = baca.next();
            System.out.print("Jurusan = ");
            mhs1.jurusan = baca.next();
            System.out.println("jadi nama terdapat "+mhs1.nama.length()+"huruf");
            System.out.println("jadi nim terdapat "+mhs1.nim.length()+"huruf");
            System.out.println("jadi jurusan terdapat "+mhs1.jurusan.length()+"huruf");
            mhs1.cetak();

    }}






