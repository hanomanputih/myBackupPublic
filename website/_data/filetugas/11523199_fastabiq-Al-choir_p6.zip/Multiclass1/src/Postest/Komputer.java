/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Postest;

/**
 *
 * @author Praktikan
 */
public class Komputer {
Ram rm;
Prosesor Prosesor;

 public static void main(String[] args) {
        Ram kapasitas = new Ram ("Corsair 1800 DDR 3");
        Prosesor Merek = new Prosesor ("Amd APU K 5800 ");
        Komputer pc = new Komputer ();
        Merek.tampil ();
        kapasitas.tampil ();

}
}
