/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Postest;

/**
 *
 * @author Praktikan
 */
public class Ram {
    String kapasitas;

public Ram (String kapasitas2){
    kapasitas = kapasitas2;
}
   public void tampil(){
            System.out.println("Kapasitas Ram : "+kapasitas);
    }
}
