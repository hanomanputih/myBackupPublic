/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttestcollection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Praktikan
 */
public class Main {
    public static void main(String[] args) {
        List nama = new ArrayList();
        
        nama.add(4523080);
        nama.add("Jaka Audita Hari Priyanto");
        nama.add(4523081);
        nama.add("Jaka AHP");
        nama.add(4523082);
        nama.add("Jaka Audita HP");
        
        System.out.println(nama);
        System.out.println(nama.size());
        System.out.println("__________________________________________");
        
        for(Object zz : nama) {
            System.out.println(zz);
        }
        
        System.out.println("__________________________________________");
        
        Iterator itt = nama.iterator();
        while(itt.hasNext()){
            System.out.println(itt.next());
        }
        
        for(int i=0;i<nama.size();i++){
            if (i==2){
                System.out.println(nama.get(i));
            }
        }
        
        //----------------------------------------------------------------------
        System.out.println("__________________________________________");
        //----------------------------------------------------------------------
        
        System.out.println(nama.get(2));
        
        //----------------------------------------------------------------------
        System.out.println("__________________________________________");
        //----------------------------------------------------------------------
        
        Map<Integer,String> x = new HashMap<Integer,String>();
        
        x.put(4523080, "Jaka Audita Hari Priyanto");
        x.put(4523081, "Jaka AHP");
        x.put(4523082, "Jaka Audita HP");
        
        for(Map.Entry<Integer,String> y : x.entrySet()){
            System.out.println(y.getKey() + ". " + y.getValue());
        }
        
//        System.out.println("Ukuran List --> " + nama.size() );
//        Collections.sort(nama);
//        
//        for (Iterator<Integer> iterator = nama.iterator();  iterator.hasNext();) {
//                Integer isi = iterator.next();
//                System.out.println(isi);
//            }
    
}}
