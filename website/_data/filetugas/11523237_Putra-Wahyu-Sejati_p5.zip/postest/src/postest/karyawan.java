
package postest;


public class karyawan {
    private String nip;
    private String nama;
    private int gaji;
    
    void setNip(String nm){
        
        if (nm.length() >= 10){
            nip =nm;
        }else{
            System.out.println("nip ga sesuai");
            
        }
    }
    
    String getNip(){
        return nip;
    }
    
     void setNama(String n){
         if (n.length() > 8){
            nama = n;
        }else{
            System.out.println("nama ga sesuai");
        
          }
     }
     
    String getNama(){
        return nama;
    }
     
    void setGaji(int n){
         gaji = n;
        
    }
    int getGaji(){
        return gaji;
    }
        
    
    }

