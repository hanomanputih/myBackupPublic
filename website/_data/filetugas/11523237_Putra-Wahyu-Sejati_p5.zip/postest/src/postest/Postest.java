
package postest;


public class Postest {

    
    public static void main(String[] args) {
        karyawan n = new karyawan();
        n.setNip("1152323897");
        n.setNama("PutraWahyu");
        n.setGaji(500000*12);
        //n.getNama();
        
        System.out.println("nim  :" +n.getNip());
        System.out.println("nama :" +n.getNama());
        System.out.println("gaji :" +n.getGaji());
    }
}
