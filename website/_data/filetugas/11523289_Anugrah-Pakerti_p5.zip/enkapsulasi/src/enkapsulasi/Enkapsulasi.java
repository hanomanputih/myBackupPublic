/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package enkapsulasi;

/**
 *
 * @author Praktikan
 */
public class Enkapsulasi {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        karyawan mhs1=new karyawan();
//        mhs1.nip("1523289");
//        mhs1.Info();
        mhs1.setter();
        mhs1.getter();
        System.out.println("Nama :"+ mhs1.getter());
       mhs1.getNip();
        System.out.println("nip :" + mhs1.getNip());
        System.out.println("Gaji perbulan :"+ mhs1.getGaji());
        mhs1.getGaji();
        System.out.println("Gaji Setahun :"+ mhs1.getGaji()*12);
    }
}

    
