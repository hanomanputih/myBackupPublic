/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package enkapsulasi;

/**
 *
 * @author Praktikan
 */
public class karyawan {

    private String nip;
    private String nama;
    private int gaji;

    public void setter(){
        this.nama=nama;
        this.nip=nip;
        this.gaji=gaji;

    nama="anugrah pakerti";
    nip="11523289";
    gaji=1000000;
}
public String getter(){

    return nama;
    }

  public String getNip(){
      return nip;
  }

  public int getGaji(){
      return gaji;

    }
//    public karyawan (String nama){
//        this.nama= nama;
//    }
//private karyawan(int gaji){
//    this.gaji = gaji;
//}
//
//    private void nip(String n) {
//        this.nip= nip;
//
//        }
//    public void Info(){
//        System.out.println("Nama " + nama);
//        System.out.println("nip= " +nip);
//        System.out.println("gaji="+gaji);
//    }

}

