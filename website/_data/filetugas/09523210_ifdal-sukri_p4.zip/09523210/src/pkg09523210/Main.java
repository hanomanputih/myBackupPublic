/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg09523210;

/**
 *
 * @author Praktikan
 */
public class Main {
String nama= "ifdal sukri";
String nim ="09523210";

void cetak(){
    System.out.println("nama anda : "+nama);
    System.out.println("nim anda : "+nim);
    
    
}
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Main br= new Main();
        br.cetak();
        
        // TODO code application logic here
    }
}
