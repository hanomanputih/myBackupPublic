/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package computer;

/**
 *
 * @author Praktikan
 */
public class Prosesor {
    int jml_prosesor;

    public Prosesor (int jml_prosesor) {
        this.jml_prosesor = jml_prosesor;
    }
    
}
