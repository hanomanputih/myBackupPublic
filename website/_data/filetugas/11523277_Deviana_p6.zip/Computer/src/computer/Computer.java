/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package computer;




public class Computer {
    String id_com;
    Prosesor p ;
    Ram r;
    
    public Computer(String comp){
         id_com = comp;
         if(id_com.equals("1")){
          p = new Prosesor (1) ;
          r = new Ram ("8gb");
      }
    }
    public static void main(String[] args) {
      Computer PC = new Computer ("1");
      System.out.println("Spesifikasi komputer anda: ");
      System.out.println("Prosesor:"+PC.p.jml_prosesor);
      System.out.println("Ram:"+PC.r.jml_memori);
        
    }
    
        
}

