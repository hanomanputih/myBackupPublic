/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

/**
 *
 * @author PRAKTIKAN
 */
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.Scanner;
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Map <Integer,String> nama = new HashMap <Integer,String > ();
        
        nama.put(11523005,"Zuvia");
        nama.put(11523006,"Zack");
        nama.put(11522005,"Sssssst");
        
        
        
        for (Map.Entry<Integer,String> e : nama.entrySet()){
            System.out.println(e.getKey()+"'"+e.getValue());
        }
        
            System.out.println(nama.get(11523006+nama.get("Zack")));
        
    }
    }

