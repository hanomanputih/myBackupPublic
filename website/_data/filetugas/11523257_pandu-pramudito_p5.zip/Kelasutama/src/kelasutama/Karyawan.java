/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package kelasutama;

/**
 *
 * @author Praktikan
 */
public class Karyawan {
     private String Nip,Nama;
    private int Gaji;

    public int getGaji() {
        return Gaji;
    }

    public void setGaji(int Gj) {
        if ((Gj >= 100000) && (Gj <=500000)){
        this.Gaji = Gj;}
        else {
            System.out.println("Gaji gak sesuai");
        }
    }

    public String getNama() {
        return Nama;
    }

    public void setNama(String Nm) {
        if (Nm.length() >= 8){
        this.Nama = Nm;}
        else {
            System.out.println("Nama ra cocok");
        }
    }

    public String getNip() {
        return Nip;
    }

    public void setNip(String Np) {
        if (Np.length() == 10 ){
        this.Nip = Np;}
        else {
            System.out.println("Nip gak cocok");
        }
        
    }
}
