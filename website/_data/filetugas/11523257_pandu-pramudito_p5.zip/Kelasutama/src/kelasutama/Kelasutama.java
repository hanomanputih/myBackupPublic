/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package kelasutama;

/**
 *
 * @author Praktikan
 */
public class Kelasutama {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Karyawan K = new Karyawan ();
        K.setGaji(200000);
        K.setNama("Pandu pramudito");
        K.setNip("1234567899");
        
        System.out.println("Nama Karyawan :"+ K.getNama());
        System.out.println("Nip Karyawan:" + K.getNip());
        System.out.println("Gaji Karyawan :"+ K.getGaji()*12);
        
    }
}
