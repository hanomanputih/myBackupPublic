/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg11523078;

/**
 *
 * @author Praktikan
 */
public class Cpu {

private String kode;
private Ram r;
private Prosesor p;

public Cpu(String kode) {
    this.kode = kode;
    if (kode.equals("1")) 
    
            
            {
       r  =new Ram();
       p = new Prosesor();
    }
}
    public static void main(String[] args) {
       Cpu cpu = new Cpu("1");
      
        System.out.println(cpu.r.ram);
        System.out.println(cpu.p.p);
       
    }
}
