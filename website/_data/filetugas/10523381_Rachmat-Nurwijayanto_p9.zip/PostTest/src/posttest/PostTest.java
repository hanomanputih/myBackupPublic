/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 *
 * @author PRAKTIKAN
 */
public class PostTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
              List mhs = new ArrayList();
    
       
      mhs.add(mhs);
      mhs.add("painem");
      mhs.add(10523381);
      mhs.add("jakal");
      

        
        System.out.println(mhs);
        System.out.println("-------------index kedua--------------");
        System.out.println(mhs.get(2));
        
       
        System.out.println("--------------");
        
      
        System.out.println("_*_*Iterator*_*_");

        Iterator maha = mhs.iterator();
        while(maha.hasNext()){
            System.out.println(maha.next());
        }
        System.out.println("-----------index kedua---------");
              System.out.println(mhs.get(2));

      
        
        System.out.println("_*_*map*_*_");
        
       Map<Integer,String > dududu = new HashMap<Integer, String>();
        
        
      
       dududu.put(1, "painem");
       dududu.put(2,"10523381");
       dududu.put(3, "jakal");
       
       
      
        System.out.println(dududu);;
           System.out.println(dududu.get(2));
    }
}

