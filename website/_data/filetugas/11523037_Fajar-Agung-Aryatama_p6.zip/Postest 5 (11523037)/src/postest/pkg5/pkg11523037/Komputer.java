/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest.pkg5.pkg11523037;

/**
 *
 * @author Praktikan
 */
public class Komputer {
String nama;
    
Prosesor p;
RAM RM;
public Komputer(String nama){
    this.nama=nama;
p =new Prosesor("INTEL");
RM=new RAM("2GB");
    System.out.println("Merk komputer "+nama);
    System.out.println("mempunyai prosesor "+p.merk_Prosesor);
    System.out.println("mempunyai kapasitas RAM "+RM.kapasitas_RAM);
}
    

    public static void main(String[] args) {
       Komputer k = new Komputer("ACER");
    }
}
