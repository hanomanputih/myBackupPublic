/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest.pkg5.pkg11523037;

/**
 *
 * @author Praktikan
 */
public class RAM {
    String kapasitas_RAM;
  
  public RAM(String kapasitas_RAM){
      this.kapasitas_RAM=kapasitas_RAM;
  }
}
