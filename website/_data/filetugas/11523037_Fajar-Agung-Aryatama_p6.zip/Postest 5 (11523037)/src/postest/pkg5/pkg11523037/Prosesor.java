/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest.pkg5.pkg11523037;

/**
 *
 * @author Praktikan
 */
public class Prosesor {
  String merk_Prosesor;
  
  public Prosesor(String merk_Prosesor){
      this.merk_Prosesor=merk_Prosesor;
  }
  
}
