/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest6;

/**
 *
 * @author Praktikan
 */
public abstract class Karyawan {
    protected String nama;
    protected int gajipokok=3000000;
    protected int bonus=500000;
    
    
    
    
   public abstract void gaji(); 
    
            
    
}
