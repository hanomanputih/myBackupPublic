/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest6;

/**
 *
 * @author Praktikan
 */
public class KaryawanTetap extends Karyawan {
    int tunjangan=gajipokok*20/100;
    
    

    @Override
    public void gaji() {
      int gaji= tunjangan+gajipokok+bonus; 
        System.out.println("Gaji Karyawan tetap :"+gaji);
    }
}
