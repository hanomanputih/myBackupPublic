/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author PRAKTIKAN
 */
public abstract class Karyawan {

        int gajipokok =3000000;
        int bonus = 600000;
 
        protected void view (){
            System.out.println("Gaji pokok:"+gajipokok);
            System.out.println("Bonus:"+ bonus );
        }
}