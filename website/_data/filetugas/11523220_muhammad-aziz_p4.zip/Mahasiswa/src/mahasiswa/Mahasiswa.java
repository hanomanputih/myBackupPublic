/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {

   String nama;
   String nim;
   String fakultas;
   String jurusan;
   int angkatan;
   
   void input(){
       Scanner pembaca=new Scanner(System.in);
       System.out.print("masukkan nama anda : ");
       nama = pembaca.next();
       System.out.print("masukkan nim anda : ");
       nim = pembaca.next();
       System.out.print("masukkan fakultas anda : ");
       fakultas = pembaca.next();
       System.out.print("masukkan jurusan anda : ");
       jurusan = pembaca.next();
       System.out.print("masukkan angkatan anda : ");
       angkatan = pembaca.nextInt();
   }
   void cetak(){
    System.out.println ("nama :"+nama);
    System.out.println("nim : "+nim);
    System.out.println("fakultas : "+fakultas);
       System.out.println("jurusan : "+jurusan);
       System.out.println("angkatan : "+angkatan);
   }
       
    
    public static void main(String[] args) {
  
        Mahasiswa mhs1 = new Mahasiswa();
        mhs1.input();
        mhs1.cetak();
        
    }
}
