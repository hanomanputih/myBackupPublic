/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest11523201;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class main {
    public static void main(String[] args) {
        Scanner jh = new Scanner(System.in);
        List lol = new ArrayList();
        System.out.println("Nama :");
        lol.add(jh.nextInt());
        System.out.println("NIM :");
        lol.add(jh.nextInt());
        System.out.println(lol);
        System.out.println("index ke-2 :"+lol.get(1));
        System.out.println("_______________");
        Iterator it = lol.iterator();
        while (it.hasNext()){
            System.out.println(it.next());
        }
        System.out.println("_______________");
        Map<Integer,String> lol2 = new HashMap<Integer,String>();
        lol2.put(jh.nextInt(), jh.next());
        for (Map.Entry<Integer, String> tampil : lol2.entrySet()){
            System.out.println(tampil.getKey()+"."+tampil.getValue());
            System.out.println(tampil.getValue());
        }
        
        
        
        
        
                
    }

}