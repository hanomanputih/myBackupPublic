/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package postest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Main {   
    public static void main(String[] args) {
        String nama;
        int nim;
        Scanner sc = new Scanner(System.in);
        List lis   = new ArrayList();
        
        System.out.println("Nama    : "); nama =  sc.next();
        System.out.println("Nim     : "); nim  =  sc.nextInt();
        lis.add(nama);
        lis.add(nim);
        System.out.println(lis);
        System.out.println("Data ke 2 adalah "+lis.get(1));
        System.out.println("Jumlah sizenya adalah "+lis.size());
        

        Map<Integer,String> peye = new HashMap<Integer, String>();
        peye.put(11523261, "Novi Prisma Yunita");
        peye.put(11523019, "Tiwi Marista");
        peye.put(11523118, "Revangga Twin");
        for(Map.Entry<Integer,String> py : peye.entrySet()){
            System.out.println(py.getKey()+" - "+py.getValue());
        }}}

        
