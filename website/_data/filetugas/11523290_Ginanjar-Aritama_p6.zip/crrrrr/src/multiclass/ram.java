/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package multiclass;

/**
 *
 * @author Praktikan
 */
public class ram {
int kapasitas;
String Merk;

    public String getMerk() {
        return Merk;
    }

    public void setMerk(String Merk) {
        this.Merk = Merk;
    }

    public int getKapasitas() {
        return kapasitas;
    }

    public void setKapasitas(int kapasitas) {
        this.kapasitas = kapasitas;
    }



}
