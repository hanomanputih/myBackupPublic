package multiclass;

/**
 *
 * @author Praktikan
 */
public class Komputer {
   String Merk;
   int idProduk;
 ram ram;
 processor processor;

    public String getMerk() {
        return Merk;
    }

    public void setMerk(String Merk) {
        this.Merk = Merk;
    }

    public int getIdProduk() {
        return idProduk;
    }

    public void setIdProduk(int idProduk) {
        this.idProduk = idProduk;
    }

    public processor getProcessor() {
        return processor;
    }

    public void setProcessor(processor processor) {
        this.processor = processor;
    }

    public ram getRam() {
        return ram;
    }

    public void setRam(ram ram) {
        this.ram = ram;
    }
    public Komputer(ram ram, processor processor){
        this.ram=ram;
        this.processor=processor;
    }
    }




   