/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package multiclass;

/**
 *
 * @author Praktikan
 */
public class processor {
String merk;
String Kecepatan;

    public String getKecepatan() {
        return Kecepatan;
    }

    public void setKecepatan(String Kecepatan) {
        this.Kecepatan = Kecepatan;
    }

    public String getMerk() {
        return merk;
    }

    public void setMerk(String merk) {
        this.merk = merk;
    }

}
