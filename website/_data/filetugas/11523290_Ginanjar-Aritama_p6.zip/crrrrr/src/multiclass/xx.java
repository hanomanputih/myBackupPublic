/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package multiclass;

/**
 *
 * @author Praktikan
 */
public class xx {
public static void main(String[] args) {
        ram ati = new ram();
        ati.setKapasitas(2);
        processor intel = new processor();
        intel.setMerk("Toshiba");
        intel.setKecepatan("Cepat");
        Komputer Toshiba = new Komputer(ati,intel);
        System.out.println("Komputer"+Toshiba.getRam().getKapasitas());
        
}}
