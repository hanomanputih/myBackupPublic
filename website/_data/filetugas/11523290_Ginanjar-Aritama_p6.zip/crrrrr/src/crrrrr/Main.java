/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package crrrrr;

/**
 *
 * @author Praktikan
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Alamat jakal = new Alamat();
        jakal.setJalan("Jalan Kali urang km 14");
        jakal.setKodepos("51888");

        Manusia budi = new Manusia();
        Manusia anto = new Manusia();
        System.out.println(anto.getAlamat());

    }

}
