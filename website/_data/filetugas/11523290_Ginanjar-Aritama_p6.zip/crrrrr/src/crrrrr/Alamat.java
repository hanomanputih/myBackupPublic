/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package crrrrr;

/**
 *
 * @author Praktikan
 */
public class Alamat {
 String jalan;
 String Kodepos;

    public String getKodepos() {
        return Kodepos;
    }

    public void setKodepos(String Kodepos) {
        this.Kodepos = Kodepos;
    }

    public String getJalan() {
        return jalan;
    }

    public void setJalan(String jalan) {
        this.jalan = jalan;
    }


}

