/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package crrrrr;

/**
 *
 * @author Praktikan
 */
public class Manusia {

    private String nama;
    private Alamat alamat;

    public Alamat getAlamat() {
        return alamat;
    }

    public void setAlamat(Alamat alamat) {
        this.alamat = alamat;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }
    }

