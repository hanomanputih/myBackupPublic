/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttestyandi5;

/**
 *
 * @author PRAKTIKAN
 */
public class Komputer {
    
    String namaKom;
    Prosesor prs;
    Ram rm;
    
    public Komputer(String nKom){ 
        this.namaKom = nKom;
        if(nKom.equals("Apple")){
            prs = new Prosesor("AMD", "123");
            rm = new Ram("sakarep", "456");
        }
    }
    
    public static void main(String[] args) {
        Komputer kmp = new Komputer("Apple");
        System.out.println("Komputer    : "+kmp.namaKom);
        System.out.println("Prosesor    : "+kmp.prs.namaProsesor +", "+ kmp.prs.nomorProsesor);
        System.out.println("RAM         : "+kmp.rm.namaRam +", "+kmp.rm.nomorRam);
    }
}
