/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttestyandi5;

/**
 *
 * @author PRAKTIKAN
 */
public class Ram {
    
    String namaRam, nomorRam;
    
    public Ram(String nmRam, String noRam){
        this.namaRam = nmRam;
        this.nomorRam = noRam;
    }
    
}
