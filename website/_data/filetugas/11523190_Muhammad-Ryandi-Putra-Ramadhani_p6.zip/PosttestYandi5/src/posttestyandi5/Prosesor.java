/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttestyandi5;

/**
 *
 * @author PRAKTIKAN
 */
public class Prosesor {
    
    String namaProsesor, nomorProsesor;
    
    public Prosesor(String nmPros, String noPros){
        this.namaProsesor = nmPros;
        this.nomorProsesor = noPros;
    }
    
}
