/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package post_test5;

/**
 *
 * @author Praktikan
 */
public class CPU {
    String jenisCpu;
    Prosessor pros;
    RAM Ram;
    
    public CPU (String jenisCpu, Prosessor pros, RAM Ram){
        this.jenisCpu = jenisCpu;
        this.pros = pros;
        this.Ram = Ram;
    }
    public void tampil (Prosessor pros, RAM ram){
        System.out.println("nama CPU : "+jenisCpu);
        System.out.println("nama Prosessor : "+pros.namaProsessor);
        System.out.println("jenis ram : "+ram.jenisRam);
    }
    
}
