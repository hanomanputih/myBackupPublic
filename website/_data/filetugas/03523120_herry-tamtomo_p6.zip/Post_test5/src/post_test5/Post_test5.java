/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package post_test5;

/**
 *
 * @author Praktikan
 */
public class Post_test5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Prosessor pro = new Prosessor("intel");
        RAM rm = new RAM ("DDR5");
        CPU cpu = new CPU ("dell",pro,rm);
        
        cpu.tampil(pro, rm);
        // TODO code application logic here
    }
}
