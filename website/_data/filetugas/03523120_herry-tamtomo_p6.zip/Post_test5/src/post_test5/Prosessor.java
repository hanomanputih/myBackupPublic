/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package post_test5;

/**
 *
 * @author Praktikan
 */
public class Prosessor {
    String namaProsessor;
    public Prosessor (String namaProsessor){
        this.namaProsessor = namaProsessor;
    }
    public void tampil () {
        System.out.println("nama prosessor : "+namaProsessor);
    }
    
}
