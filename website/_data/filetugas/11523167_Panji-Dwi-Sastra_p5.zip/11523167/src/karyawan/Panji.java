/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author PRAKTIKAN
 */
public class Panji {
    public static void main(String[] args) {
   Karyawan kry = new Karyawan ();

   kry.setGaji (999999999);
kry.setNama ("Panji");
kry.setNip ("11523167");

System.out.println("Gaji per tahun anda = " + kry.getGaji());
        System.out.println("Nama anda = " + kry.getNama());
        System.out.println("NIP anda = " + kry.getNip());

}
}

