/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package postest;

/**
 *
 * @author Praktikan
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Swalayan s = new Swalayan();
        Indomaret i = new Indomaret();
        TokoAgung a = new TokoAgung();
     
        i.harga = 19212;
     
        a.harga = 19255;
        s = i;
        s = a;
        i.tampil();
        a.tampil();
    }

}
