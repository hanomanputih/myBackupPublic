/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package postest;

/**
 *
 * @author Praktikan
 */
public class TokoAgung extends Swalayan{
    @Override
    void tampil(){
    sisa = (int) (harga % 25);
    bayar = (int) (harga - sisa);
        System.out.println("Bayar : "+bayar);
        System.out.println("Harga : "+harga);
    }
}
