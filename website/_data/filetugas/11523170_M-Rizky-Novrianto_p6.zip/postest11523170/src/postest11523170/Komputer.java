/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest11523170;

/**
 *
 * @author praktikan
 */
public class Komputer {

    String namaKom;
    Prosesor prs;
    Ram rm;

    public Komputer(String nKom) {
        this.namaKom = nKom;
        if (nKom.equals("acer")) {
            prs = new Prosesor("AMD", "234");
            rm = new Ram("Gigabyte", "354");

        }
    }

    

    public static void main(String[] args) {
        Komputer komp = new Komputer("acer");
        System.out.println("Komputer    : " + komp.namaKom);
        System.out.println("Prosesor    : " + komp.prs.namaProsesor + ", " + komp.prs.idProsesor);
        System.out.println("RAM         : " + komp.rm.nmRam + ", " + komp.rm.idRam);
    }
}
