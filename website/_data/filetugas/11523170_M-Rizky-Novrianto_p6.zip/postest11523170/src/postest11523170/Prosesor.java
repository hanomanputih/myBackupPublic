/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest11523170;

/**
 *
 * @author praktikan
 */
public class Prosesor {

    String namaProsesor, idProsesor;

    public Prosesor(String nmPros, String idProsesor) {
        this.namaProsesor = nmPros;
        this.idProsesor = idProsesor;

    }
}
