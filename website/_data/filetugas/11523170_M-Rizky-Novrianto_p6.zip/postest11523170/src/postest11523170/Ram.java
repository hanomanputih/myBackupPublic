/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest11523170;

/**
 *
 * @author praktikan
 */
public class Ram {

    String nmRam, idRam;

    public Ram(String nmRam, String idRam) {

        this.nmRam = nmRam;

        this.idRam = idRam;
    }
}
