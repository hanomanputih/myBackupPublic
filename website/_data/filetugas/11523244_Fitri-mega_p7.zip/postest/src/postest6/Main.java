/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest6;

/**
 *
 * @author Praktikan
 */
public class Main {
    public static void main(String[] args) {
        karyawanTetap kt=new karyawanTetap();
        kt.Gaji();
        
        KaryawanKontrak kk=new KaryawanKontrak();
        kk.Gaji();
    }
    
}
