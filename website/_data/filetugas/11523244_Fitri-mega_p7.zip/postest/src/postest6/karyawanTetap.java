/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest6;

/**
 *
 * @author Praktikan
 */
public class karyawanTetap extends Karyawan {
    int tunjangan= gajiPokok*20/100;
    
    
  
    @Override
    public void Gaji() {
       
        int gaji=tunjangan+gajiPokok+bonus;
        System.out.println("Gaji karyawan tetap : "+gaji);
    }
}
