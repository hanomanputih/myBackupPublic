/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest6;

/**
 *
 * @author Praktikan
 */
public abstract class Karyawan {
    protected int gajiPokok=3000000;
    protected int bonus=10000;
    
    public abstract void Gaji();
}
