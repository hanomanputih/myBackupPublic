/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest6;

/**
 *
 * @author Praktikan
 */
public class KaryawanKontrak extends Karyawan {
    int gaji=gajiPokok+bonus;

    @Override
    public void Gaji() {
        System.out.println("gaji karyawan kontrak : "+gaji);
    }
    
}
