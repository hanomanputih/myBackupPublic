/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package posttest;

import java.util.HashMap;


public class map
{
    public static void main(String[] args)
    {
        HashMap map = new HashMap();
        map.put("nama ", " Indra");
        map.put("NIM ", new Integer(11523250));
        System.out.println(map);
        System.out.println("Ukuran map: " + map.size());
        boolean containKey = map.containsKey ("NIM ");
        System.out.println("Has Key (NIM): "+containKey);
        Object removed = map.remove("NIM ");
        System.out.println("Removed : "+removed);
        System.out.println(map);
        System.out.println("Ukuran map baru : "+map.size());
    }

}

