/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes5;

/**
 *
 * @author praktikan
 */
public class RAM {

    String nama ;
    public RAM(String nama){
        this.nama = nama ;
    }
}
