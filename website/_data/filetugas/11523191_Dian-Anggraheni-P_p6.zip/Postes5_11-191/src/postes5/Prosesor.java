/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes5;

/**
 *
 * @author praktikan
 */
public class Prosesor {
   String nama ;
    public Prosesor(String nama){
        this.nama = nama ;
    }
    
}
