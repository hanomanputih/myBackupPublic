/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes5;

import java.util.Scanner;

/**
 *
 * @author praktikan
 */
public class Komputer {
    String id_kom;
    Prosesor p ;
    RAM r ;
    public Komputer(String kom) {
        this.id_kom = kom ;
       
         if(id_kom.equals("1")){
         p = new Prosesor ("Core");
         r = new RAM("Dian");
         }
        
    }


public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.println("input komputer milik siapa =");
    Komputer kom = new Komputer (sc.next());
    
    System.out.println("Jenis Prosesor = "+kom.p.nama);
    System.out.println("Nama RAM = "+kom.r.nama);
  
    }
    
}
