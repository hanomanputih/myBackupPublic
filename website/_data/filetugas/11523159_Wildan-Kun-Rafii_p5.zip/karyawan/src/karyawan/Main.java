/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class Main {
    public static void main(String[] args) {
        Karyawan k = new Karyawan() ;
        
        k.setNip("11523159");
        System.out.println("NIP anda :" +k.getNip());
        
        k.setNama("Wildan Kun Rafi'i");
        System.out.println("Nama anda :" +k.getNama());
        
        k.setGaji(20000000);
        System.out.println("Gaji anda :" +k.getGaji());
        
    }
}
