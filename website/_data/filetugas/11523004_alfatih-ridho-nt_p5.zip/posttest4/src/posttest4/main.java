/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest4;

/**
 *
 * @author Praktikan
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        karyawan ka = new karyawan();
        ka.setNIP("90890890");
                System.out.println("nip ku"+ka.getNIP());
                
                ka.setNAMA("hdsjdk");
                System.out.println("namaku "+ka.getNAMA());
                
                ka.setGAJi(2356252);
                System.out.println("gajiku"+ka.getGAJI());
    }
}
