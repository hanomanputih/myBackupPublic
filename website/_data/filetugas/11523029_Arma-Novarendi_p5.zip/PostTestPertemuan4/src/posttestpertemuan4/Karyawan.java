/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttestpertemuan4;

/**
 *
 * @author PRAKTIKAN
 */
public class Karyawan {
    private String nip;
    private String nama;
    private int gaji;
    
    // SETTER
    public void setNIP(String _nip){
        if (_nip.length() == 5){
            nip = _nip;
        }
        else if (_nip.length() <= 5) {
            System.out.println("ERROR: NIP yang Anda masukkan KURANG dari 5 karakter");
        } else {
            System.out.println("ERROR: NIP yang Anda masukkan LEBIH dari 5 karakter");
        }
    }
    public void setNama(String _nama){
        nama = _nama;
    }
    public void setGaji(int _gaji){
        gaji = _gaji;
    }
    
    
    // GETTER
    String getNIP(){
        return nip;
    }
    String getNama(){
        return nama;
    }
    int getGajiSetahun(){
        gaji = gaji*12;
        return gaji;
    }
}
