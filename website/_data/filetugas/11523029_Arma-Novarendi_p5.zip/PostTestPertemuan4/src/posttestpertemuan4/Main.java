/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttestpertemuan4;

/**
 *
 * @author PRAKTIKAN
 */
public class Main {
        public static void main(String[] args) {
        Karyawan halah = new Karyawan();
        halah.setNIP("12324");
        halah.setNama("Arma");
        halah.setGaji(50000000);
        System.out.println("NIP : "+halah.getNIP());
        System.out.println("Nama : "+halah.getNama());
        System.out.println("Gaji Setahun : "+halah.getGajiSetahun());
    }
}
