/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;
import java.util.Scanner;
/**
 *
 * @author Praktikan
 */
public class karyawan {
     Scanner x = new Scanner (System.in);
private String nip, nama;
private int gaji;


void setNIP (){
    System.out.println("nip anda = ");
    nip = x.next();
}

String getNIP(){
    return nip;
    
    
}
void setNAMA (){
   System.out.println("nama anda = ");
    nama = x.next();
}

String getNAMA(){
    return nama;
    
    
}void setGAJI (){
    System.out.println("gaji anda = ");
    gaji = x.nextInt();
}

int getGAJI(){
    return gaji;
    
    
}

}

