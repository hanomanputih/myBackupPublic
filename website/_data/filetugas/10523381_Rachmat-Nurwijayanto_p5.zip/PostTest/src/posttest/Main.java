/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;



/**
 *
 * @author Praktikan
 */
public class Main {
    public static void main(String[] args) {

        karyawan m =new karyawan();
        m.setNIP();
        System.out.println("NIP anda= "+ m.getNIP());
    
        m.setNAMA ();
        System.out.println("Nama anda= "+ m.getNAMA());
    
        m.setGAJI();
        System.out.println("Gaji anda= "+ m.getGAJI());
    
    }
            
        
}
