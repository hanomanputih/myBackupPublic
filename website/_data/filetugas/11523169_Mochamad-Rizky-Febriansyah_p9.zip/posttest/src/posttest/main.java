/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

import java.util.HashSet;

/**
 *
 * @author Praktikan
 */
public class main {
    public static void main(String[] args) {
        HashSet<mahasiswa> set = new HashSet<mahasiswa>();
        mahasiswa a = new mahasiswa();
        a.setNama("rizky febriansyah");
        a.setNim(11523169);
        set.add(a);
        
        mahasiswa b = new mahasiswa();
        b.setNama("rizky febriansyah");
        b.setNim(11523169);
        
        
        }
        
    }
    

