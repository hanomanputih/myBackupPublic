/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
    String nama;
    String nim;
    String fakultas;
    String jurusan;
    String angkatan;
    
    void cetak(){
        System.out.println("nama : " + nama);
        System.out.println("nim : " + nim);
        System.out.println("fakultas "+ fakultas);
        System.out.println("jurusan " + jurusan);
        System.out.println("angkatan " +angkatan);
    }
    
    
    public static void main(String[] args) {
        Mahasiswa maulia = new Mahasiswa();
        Scanner sc = new Scanner(System.in);
  
        System.out.print("masukan nama : ");
        maulia.nama = sc.nextLine();
        System.out.print("masukan nim : ");
        maulia.nim = sc.nextLine();
        System.out.print("masukan fakultas : ");
        maulia.fakultas = sc.nextLine();
        System.out.print("masukan jurusan : ");
        maulia.jurusan = sc.nextLine();
        System.out.print("masukan angkatan : ");
        maulia.angkatan =sc.nextLine();
        System.out.println("================");
        maulia.cetak();

    }
}
