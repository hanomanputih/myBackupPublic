/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author Praktikan
 */
public class Komputer {
    Prosesor p;
    RAM r;
    public String nama;
    public Komputer (String nm){
        nama=nm;
        p=new Prosesor ("hantu");
        r=new RAM ("kuntilanak");
        
        
    }
        
    public static void main(String[] args) {
        Komputer komp=new Komputer ("apa aja");
        System.out.println("jadi komputer ini adalah "+komp.p.jenis);
        System.out.println("dan hantunya adalah "+komp.r.merk);
    }
}
