/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package post.test.pkg3;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
    static String nama, fakultas, jurusan, angkatan, nim;
    
    static void cetak () {
        System.out.print(nama); System.out.println(" ("+nama.length()+")");
        System.out.print(nim); System.out.println(" ("+nim.length()+")");
        System.out.print(fakultas); System.out.println(" ("+fakultas.length()+")");
        System.out.print(jurusan); System.out.println(" ("+jurusan.length()+")");
        System.out.print(angkatan); System.out.println(" ("+angkatan.length()+")");
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner cuetak = new Scanner(System.in);
        System.out.print("Masukkan Nama : ");
        nama = cuetak.next(); 
        System.out.print("Masukkan NIM  : ");
        nim = cuetak.next(); 
        System.out.print("Masukkan Fak  : ");
        fakultas = cuetak.next(); 
        System.out.print("Masukkan Jur  : ");
        jurusan = cuetak.next(); 
        System.out.print("Masukkan Angk : ");
        angkatan = cuetak.next(); 
        cetak();
        // TODO code application logic here
    }
}
