/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest8main;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

/**
 *
 * @author Praktikan
 */
public class collection {
     public static void main(String[] args) {
        Map<Integer, String> m = new HashMap<Integer, String>();
        
        m.put(11523150, "tiara");
        m.put(11523175, "arni");
        
        System.out.println(m);
        System.out.println("==================");
        
        for(String i : m.values()) {
            System.out.println(i);
        }
        System.out.println("===================");
        for(Integer i : m.keySet()){
            System.out.println(m.get(i));
        }
        System.out.println("===================");
        Iterator<Entry<Integer,String>> it = m.entrySet().iterator();
        while(it.hasNext()) {
            System.out.println(it.next());
        }
    }
 

}
