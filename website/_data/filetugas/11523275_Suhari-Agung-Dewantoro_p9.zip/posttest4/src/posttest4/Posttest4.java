/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest4;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 
 * 
 */


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;

/**
 *
 * @author Praktikan
 */
public class Posttest4 {

    
    public static void main(String[] args) {
      ArrayList list = new ArrayList();
      HashMap map = new HashMap ();
     
      list.add("11523275");
      list.add("11523276");
      list.add("11523277");
      list.add("Suhari Agung Dewantoro");
      list.add("Rudi");
      list.add("Putra");
      
        System.out.println("ukuran list : "+list.size());
        
        for(Iterator iterator = list.iterator(); iterator.hasNext();){
        String ii = (String) iterator.next();
            System.out.println("isi : "+ii);
        }
        map.put("Nama", "Hari");
          map.put("NIM", new Integer(11523275));
          System.out.println(map);
        
    }
}
