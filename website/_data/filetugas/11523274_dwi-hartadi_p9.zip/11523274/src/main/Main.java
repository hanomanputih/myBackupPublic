package main;
import java.util.HashMap;
import java.util.Scanner;
public class Main 
{
    public static void main(String[] args) 
    {
        int NIM;
        Scanner sc = new Scanner(System.in);
        for (int a=0; a<5; a++)
        {
            System.out.println("Masukkan NIM anda: ");
            NIM = sc.nextInt();
        }
        
        HashMap map = new HashMap();
        map.put("nama ", " Fadil");
        map.put("NIM ", new Integer(9523257));
        System.out.println(map);
        System.out.println("Ukuran map: " + map.size());
        boolean containKey = map.containsKey ("NIM ");
        System.out.println("Has Key (NIM): "+containKey);
        Object removed = map.remove("NIM ");
        System.out.println("Removed : "+removed);
        System.out.println(map);
        System.out.println("Ukuran map baru : "+map.size());
        
    }
}
