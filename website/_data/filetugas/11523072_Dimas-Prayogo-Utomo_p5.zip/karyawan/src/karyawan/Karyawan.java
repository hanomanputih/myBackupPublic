/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class Karyawan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        NIP krywn = new NIP();
        krywn.setNip("115242");
        System.out.println("nip "+krywn.getNip());
        krywn.setNama("pakuda");
        System.out.println("nama "+krywn.getNama());
        krywn.setGaji(1200000);
        System.out.println("gaji "+krywn.getGaji());
    }
}
