/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package PostTest5;

/**
 *
 * @author Praktikan
 */
public class Komputer {
    ram rm;
    Prosesor Prosesor;
 
public static void main (String[]args){
    ram kapasitas = new ram ("Corsair 1800 DDR 3");
    Prosesor Jenis = new Prosesor ("Amd CPU K 5800");
    Komputer pc = new Komputer ();
    Jenis.tampil();
    kapasitas.tampil();
}    
   
    }
