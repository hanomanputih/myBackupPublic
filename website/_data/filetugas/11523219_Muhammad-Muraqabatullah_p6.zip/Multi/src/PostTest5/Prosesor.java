/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package PostTest5;

/**
 *
 * @author Praktikan
 */
public class Prosesor {
      String Merek;
              
   
public Prosesor (String Merek){
    this.Merek = Merek;

}
public void tampil (){
    System.out.println("Merk Prosesor :"+Merek);

}
}