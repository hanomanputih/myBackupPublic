/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package p4;

/**
 *
 * @author PRAKTIKAN
 */
public class Main {
    Mahasiswa ma = new Mahasiswa();
    
}
