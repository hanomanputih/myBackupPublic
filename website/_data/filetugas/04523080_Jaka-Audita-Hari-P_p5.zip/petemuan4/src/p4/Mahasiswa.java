/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package p4;

/**
 *
 * @author PRAKTIKAN
 */
public class Mahasiswa {
    String nim;
}
