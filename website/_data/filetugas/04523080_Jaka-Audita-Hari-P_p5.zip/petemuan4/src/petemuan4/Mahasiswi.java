/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package petemuan4;

/**
 *
 * @author PRAKTIKAN
 */
public class Mahasiswi {
    
    private String nim;

    public String getNim() {
        return nim;
    }

    public void setNim(String nim) {
        this.nim = nim;
    }
    
    void setNIM(String nim){
        if (nim.length() == 8){
            this.nim = nim;
        } else {
            System.out.println("Error");
        }
    }
    
    String getNIM(){
        return nim;
    }
    
}
