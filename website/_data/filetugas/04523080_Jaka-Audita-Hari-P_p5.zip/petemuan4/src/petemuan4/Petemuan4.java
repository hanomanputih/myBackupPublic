/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package petemuan4;

/**
 *
 * @author PRAKTIKAN
 */
public class Petemuan4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Mahasiswi Mi = new Mahasiswi();
        Mi.setNIM("105233044");
        System.out.println("NIM Anda = " + Mi.getNIM());
    }
}
