/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author PRAKTIKAN
 */
public class Mahasiswa {

    private double ipk;
    private int length = 0;
    
    public int getLength(){
        return length;
    }

    public double getIpk() {
        return ipk;
    }

    public void setIpk(double ipk) {
        if (ipk < 0 || ipk > 4) {
            System.out.println("Error");
            this.ipk = 0;
        } else {
            this.ipk = ipk;
            length++;

        }
    }
}
