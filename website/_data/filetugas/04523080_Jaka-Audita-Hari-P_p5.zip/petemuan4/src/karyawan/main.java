/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author PRAKTIKAN
 */
public class main {
    public static void main(String[] args) {
        
        Karyawan kr = new Karyawan();
        
        kr.setGaji(1000000);
        kr.setNama("Jaka");
        kr.setNip("123456");
        
        System.out.println ("NIP = " + kr.getNip());
        System.out.println ("Nama = " + kr.getNama());
        System.out.println ("Gaji setahun = " + kr.getGaji());
        
        Mahasiswa m = new Mahasiswa();
        m.setIpk(4);
        System.out.println("IPK : "+m.getIpk());
        System.out.println("panjang : "+m.getLength());
        m.setIpk(2.5);
        System.out.println("panjang : "+m.getLength());
        m.setIpk(3);
        System.out.println("panjang : "+m.getLength());
    }
    
}
