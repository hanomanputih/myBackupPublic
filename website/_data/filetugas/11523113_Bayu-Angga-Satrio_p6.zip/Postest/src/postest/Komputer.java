/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

/**
 *
 * @author Praktikan
 */
public class Komputer {
    public static void main(String[] args) {
        Prosesor prs = new Prosesor("Inter Core i7");
        RAM tp = new RAM("sasaasas", prs);
        tp.tampil(prs);
}
