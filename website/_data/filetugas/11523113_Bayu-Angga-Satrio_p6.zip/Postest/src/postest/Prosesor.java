/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

/**
 *
 * @author Praktikan
 */
public class Prosesor {
    String merkProcie;
    RAM rm;
    
    public Prosesor(String merkProcie, RAM rm) {
        this.merkProcie = merkProcie;
        this.rm = rm;
    }
    
    public void tampil(RAM rm){
        System.out.println("Merk prosesor : "+merkProcie);
        System.out.println("RAM : "+rm.tipe);
    }
}
