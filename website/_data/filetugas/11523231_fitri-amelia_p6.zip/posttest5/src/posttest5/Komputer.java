/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest5;

/**
 *
 * @author Praktikan
 */
public class Komputer {

    Ram r;
    Prosesor p;
    String nama;
    
    public Komputer(String namaKompi){
        nama=namaKompi;
        p = new Prosesor("dual core");
        r = new Ram("4 giga");
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Komputer k=new Komputer("dell");
        System.out.println("nama kompi      : "+k.nama);
        System.out.println("ukuran ram      : "+k.r.ukuranMemori);
        System.out.println("jenis prosesor  : "+k.p.jenis);
    }

}