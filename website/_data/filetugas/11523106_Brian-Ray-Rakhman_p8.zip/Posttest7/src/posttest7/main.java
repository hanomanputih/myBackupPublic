/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest7;

/**
 *
 * @author Praktikan
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Swalayan s;
        Indomart i = new Indomart ();
        s=i;
        s.tampil();
        
        tokoAgung t = new tokoAgung ();
        s=t;
        s.tampil();
    }
}
