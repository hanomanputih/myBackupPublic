/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest7;

/**
 *
 * @author Praktikan
 */
public class tokoAgung extends Swalayan {
    
     @Override
    void tampil (){
         sisa = (int) (harga%25);
         bayar = (int) (harga-sisa);
         System.out.println("Harga Toko agung : "+bayar);
         
     }
             
        
}
