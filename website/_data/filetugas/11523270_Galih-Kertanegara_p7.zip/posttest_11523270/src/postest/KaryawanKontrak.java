/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

/**
 *
 * @author PRAKTIKAN
 */
public class KaryawanKontrak extends Karyawan implements Status{
    public String nama = "Sedunia";
   
    public int GajiKontrak;
    
    
    @Override
    public void Gaji(){
        
        
        System.out.println("Nama Anda :"+nama);
        GajiKontrak=GajiPokok+Bonus;
        System.out.println("Gaji Kontrak Anda :"+GajiKontrak);
        
    
    }

    @Override
    public void KaryawanTetap() {
        System.out.println("");
    }

    @Override
    public void KaryawanKontrak() {
        System.out.println("Karyawan Kontrak");
    }
    
}
