/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

/**
 *
 * @author PRAKTIKAN
 */
public class KaryawanTetap extends Karyawan implements Status{
    public String nama = "Udin";
    public int GajiTetap;
    public int Tunjangan = 100000;


    @Override
public void Gaji(){
        
        System.out.println("Nama Anda :"+nama);
      
    
        GajiTetap = Tunjangan+GajiPokok+Bonus;
        System.out.println("Gaji Tetap Anda :"+GajiTetap);
    }

 
    @Override
    public void KaryawanTetap() {
        System.out.println("Karyawan Tetap");
        
    }

    @Override
    public void KaryawanKontrak() {
        System.out.println("");
    }

    
}