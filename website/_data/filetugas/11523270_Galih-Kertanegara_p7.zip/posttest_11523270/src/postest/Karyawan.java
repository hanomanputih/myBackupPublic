/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

/**
 *
 * @author PRAKTIKAN
 */
public abstract class Karyawan {
    public int GajiTotal;
    public int GajiPokok = 2000000;
    public String Perusahaan = "PTSUKASUKA";
    public int Bonus = 50000;
    
    
    public abstract void Gaji();
    
    
}
