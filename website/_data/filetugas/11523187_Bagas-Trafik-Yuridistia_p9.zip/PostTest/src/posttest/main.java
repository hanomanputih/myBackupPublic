/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author Praktikan
 */
public class main {
    public static void main(String[] args) {
        Set<Mahasiswa> set = new HashSet<Mahasiswa>();
        Mahasiswa a = new Mahasiswa();
        a.setNama("Bagas Trafik");
        a.setNim(11523187);
        set.add(a);
        
        Mahasiswa b = new Mahasiswa();
        b.setNama("agoes Soedirmoan");
        b.setNim(112);
    for(Mahasiswa m : set){
            System.out.println("Nim     : "+m.getNim());
            System.out.println("Nama    : "+m.getNama());
        }
    }
    
}
