/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package postestpertemuan4;

/**
 *
 * @author praktikan
 */
public class karyawan {
    private String nip,nama ;
    private int gaji;

    void setNIP(String ni){
        if (ni.length() == 9){
           nip = ni ;
        }else {
            System.out.println("Error");
        }

        }
    String getNIP(){
    return nip ;
    }
    void setNAMA(String nam){
        nama = nam ;
    }
    String getNAMA (){
        return nama;
    }
    void setGAJI(int gaji){
        this.gaji = gaji;
    }
    int  getGAJI (){
        return gaji;
    }


    }


