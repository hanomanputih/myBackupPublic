/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package postestpertemuan4;

/**
 *
 * @author praktikan
 */
public class Main {
    public static void main (String [] args){
        karyawan ka = new karyawan();
        ka.setNIP("115230501");
        System.out.println("NIP = "+ka.getNIP());
        ka.setNAMA("Tirto INdra");
        System.out.println("NAMA = "+ka.getNAMA());
        ka.setGAJI(9999999);
        System.out.println("GAJI = "+ka.getGAJI());
    }

    /**
     * @param args the command line arguments
     */
 

}
