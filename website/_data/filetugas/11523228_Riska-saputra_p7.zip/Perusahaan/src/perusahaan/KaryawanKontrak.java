package perusahaan;

public class KaryawanKontrak extends Karyawan {

    @Override
    public int gaji() {
        int gaji;
        gaji = bonus + gajiPokok;
        return gaji;
        
    }
    
}
