/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package PostTest;

/**
 *
 * @author Praktikan
 */
public class karyawanKontrak extends Karyawan {
    
    @Override
    public void gaji(){
        gaji = gajiPokok + bonus ;
        System.out.println("gaji karyawan kontrak : "+gaji);
    }
    
}
