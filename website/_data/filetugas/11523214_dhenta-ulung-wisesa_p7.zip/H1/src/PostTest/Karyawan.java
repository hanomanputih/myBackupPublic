/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package PostTest;

/**
 *
 * @author Praktikan
 */
public abstract class Karyawan {
 public int gajiPokok = 30000000;
 public int gaji;
 public int bonus = 1000000;

public abstract void gaji();
    
}
