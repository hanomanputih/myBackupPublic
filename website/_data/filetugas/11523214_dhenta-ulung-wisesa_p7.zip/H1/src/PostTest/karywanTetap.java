/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package PostTest;

/**
 *
 * @author Praktikan
 */
public class karywanTetap extends Karyawan {
public int tunjangan;

@Override
public void gaji(){
    tunjangan = (20*gajiPokok)/100 ;
    gaji = tunjangan + gajiPokok + bonus ;
    System.out.println("gaji karyawan tetap : "+gaji);
    
  }
}
