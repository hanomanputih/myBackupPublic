/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package PostTest;

/**
 *
 * @author Praktikan
 */
public class main {
    
    public static void main(String[] args) {
        karywanTetap kt = new karywanTetap();
        karyawanKontrak kk = new karyawanKontrak();
        
        kt.gaji();
        kk.gaji();
    }
}
