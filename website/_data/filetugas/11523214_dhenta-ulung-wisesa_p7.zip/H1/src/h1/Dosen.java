/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package h1;

/**
 *
 * @author Praktikan
 */
public abstract class Dosen {
    String nama = "JOJON";
    String jurusan = "Sastra Mesin";

public abstract void view();
//    System.out.println("nama dosen : "+nama);
//    System.out.println("jurusan    : "+jurusan);
public void Bertugas(){
    System.out.println("ndlongop");
}
}
//}
