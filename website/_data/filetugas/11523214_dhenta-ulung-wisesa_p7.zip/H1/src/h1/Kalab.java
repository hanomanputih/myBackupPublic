/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package h1;

/**
 *
 * @author Praktikan
 */
public class Kalab extends Dosen {
    private String Laboratorium;
    
    @Override
    public void view(){
     //   super.view();
        System.out.println("laboratorium : "+Laboratorium);
    }
    public String getLaboratorium() {
        return Laboratorium;
    }

    public void setLaboratorium(String Laboratorium) {
        this.Laboratorium = Laboratorium;
    }

}
