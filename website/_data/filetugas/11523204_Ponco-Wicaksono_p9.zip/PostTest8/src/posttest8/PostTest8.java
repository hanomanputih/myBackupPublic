/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest8;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class PostTest8 {
    private static void nim(List<String> list) {
        list.add("1052369");
        list.add("pewek");
    }
//     private static void nama(List<String> list) {
//        list.add("pewek");
//     }
     
    public static void tampilkanList (List<String> list) {
        for (int i = 0; i < list.size(); i++){
            System.out.println(list.get(i) + " ");
        }
        System.out.println();
    }
    public static void main(String[] args) {
       List<String> list = new ArrayList<String>();
      nim(list);
       tampilkanList(list);
        System.out.println("list di index ke 2 = " + list.get(0));
    }
}
