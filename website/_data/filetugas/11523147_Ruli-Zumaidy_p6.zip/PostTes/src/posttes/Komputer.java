/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttes;

/**
 *
 * @author PRAKTIKAN
 */
public class Komputer {
    String NamaKomputer;
    private Ram R;
    private Prosesor P;
    
    public Komputer (String Komp){
        this.NamaKomputer = Komp;
        if (Komp.equals("Madamada")){
            R= new Ram ("Gskil");
            P= new Prosesor("Core I3");
            
        }
    }
    public void TampilKomp(){
        System.out.println("merk Ram" + R.NamaRam);
        System.out.println("merk Prosesor" + P.NamaPros);
        System.out.println("merk Komputer" + NamaKomputer);
    }
}

