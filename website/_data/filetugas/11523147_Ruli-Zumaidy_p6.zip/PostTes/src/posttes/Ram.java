/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttes;

/**
 *
 * @author PRAKTIKAN
 */
public class Ram {
    String NamaRam;
    
    public Ram (String NamaRam){
        this.NamaRam = NamaRam;
        
    }
          
}
