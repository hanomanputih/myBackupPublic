/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa1;

/**
 *
 * @author PRAKTIKAN
 */
public class Mahasiswa1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Mahasiswa2 mhs = new Mahasiswa2();
        mhs.setNam("adit");
        mhs.setNip("11523026");
        mhs.setGaji(10000);
        System.out.println("nim "+ mhs.getNip());
        System.out.println("nama "+ mhs.getNam()); 
        System.out.println("gaji setahun "+ mhs.getGaji());
        
    }
    
}
