/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa1;

/**
 *
 * @author PRAKTIKAN
 */
public class Mahasiswa2 {
    private String nip;
    private String nama;
    private int gaji;

    public void setNip(String nimKamu) {
        if (nimKamu.length()==8) {
            nip=nimKamu;
        } else {
            System.out.println("ERROR");
        }
    }
    
    public String getNip() {
        return nip;
    }
    public void setNam(String namKamu) {
        if (namKamu.length()<=100 ) {
            nama=namKamu;
        } else {
            System.out.println("ERROR");
        }
    }
    public String getNam() {
        return nama;
    }
    
    
    public void setGaji(int gajiKamu) {
        
        gaji=12*gajiKamu;
        }
    public int getGaji() {
        return gaji;
    }
    
    }
    
    
