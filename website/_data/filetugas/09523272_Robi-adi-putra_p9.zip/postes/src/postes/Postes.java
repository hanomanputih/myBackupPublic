/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author PRAKTIKAN
 */
public class Postes {
    String nama, nim;
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      Scanner sc = new Scanner (System.in);
        System.out.println("masuak an nama");
        String nama = sc.nextLine();
        System.out.println("masuak an Nama");
        String nim = sc.nextLine();
        ArrayList list = new ArrayList ();
        list.add (nama);
        list.add (nim);
        
for (Iterator<String> iterator = list.iterator(); iterator.hasNext (); ){
    String ii = (String) iterator.next();
}
Map<Integer,String> map = new HashMap();
map.put(1, nama);
map.put(2, nim);

for (Map.Entry<Integer,String> entry : map.entrySet()){
    System.out.println(entry.getKey() +","+entry.getValue());
    
}


}
        

    }

