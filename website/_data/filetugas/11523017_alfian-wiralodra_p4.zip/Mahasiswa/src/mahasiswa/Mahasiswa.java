/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
    String robby;
    String nama;
    String nim;
    String fakultas;
    String jurusan;
    String angkatan;
    float jumlah1;
    void cetak(){
        System.out.println("nama"+nama + "nim"+nim + "fakultas"+fakultas + "jurusan"+jurusan + "angkatan"+jurusan);
    }
    public static void main(String[] args) {
        Scanner baca = new Scanner(System.in);
        Mahasiswa mhs1 = new Mahasiswa();
        System.out.print("sebutkan nama mahasiswa");
        mhs1.nama = baca.next();
        System.out.print("nim anda");
        mhs1.nim = baca.next();
        System.out.print("fakultas apa");
        mhs1.fakultas = baca.next();
        System.out.print("jurusan apa");
        mhs1.jurusan = baca.next();
        System.out.print("angkatan apa");
        mhs1.angkatan = baca.next();
        mhs1.jumlah1 = mhs1.nama.length();
        
    }
}
