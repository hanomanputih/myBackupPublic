/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg11523004;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class mahasiswa {
String nama,nim,fakultas,jurusan,angkatan;
    void data(){
        Scanner baca = new Scanner(System.in);
        System.out.println("masukkan nama anda :");
        nama = baca.next();
        System.out.println("masukkan nim anda :");
        nim = baca.next();
        System.out.println("nama fakultas anda :");
        fakultas = baca.next();
        System.out.println("jurusan anda :");
        jurusan = baca.next();
        System.out.println("angkatan :");
        angkatan = baca.next();
               
    }
    public static void main(String[] args) {
        
        mahasiswa m = new mahasiswa();
       m.data();
        System.out.println("nama :" +m.nama);
        System.out.println("nim :"+m.nim);
        System.out.println("fakultas:"+m.fakultas);
        System.out.println("jurusan:"+m.jurusan);
        System.out.println("angkatan:"+m.angkatan);
        
        
    }
}
