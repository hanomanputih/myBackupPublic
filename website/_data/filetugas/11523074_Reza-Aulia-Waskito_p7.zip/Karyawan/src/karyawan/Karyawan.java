
package karyawan;

public abstract class Karyawan { //absttrack //umum
    int gajiPokok=3000000;
    int bonus= 500000;
   
   
    public abstract void gaji();
    
}
