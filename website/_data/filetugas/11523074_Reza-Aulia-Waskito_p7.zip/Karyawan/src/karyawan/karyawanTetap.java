/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class karyawanTetap extends Karyawan {
    double tunjangan=0.20*gajiPokok;
    

    @Override
    public void gaji() {
        double gaji=tunjangan+gajiPokok+bonus;
        System.out.println("Gaji Karyawan Tetap   : "+gaji);
    }
    
}
