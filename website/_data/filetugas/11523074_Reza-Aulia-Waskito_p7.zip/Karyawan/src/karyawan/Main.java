/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class Main {
    public static void main(String[] args) {
        karyawanTetap kt = new karyawanTetap();
        kt.gaji();
        KaryawanKontrak kk = new KaryawanKontrak();
        kk.gaji();
    }
}
