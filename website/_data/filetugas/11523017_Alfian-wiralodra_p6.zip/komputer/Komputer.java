/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class Komputer {
    String namaKomputer;
    procesor Komputer;
    int hargaKomputer;
    String ram;
    ram r;
    int Hargaram;
    procesor pi;
    
    public class komputer {
    String namaKomputer;
    public komputer(String nama){
        this.namaKomputer=namaKomputer;
        if(namaKomputer.equals("1"))
            r = new ram("igiga");
    }
    }
    
}