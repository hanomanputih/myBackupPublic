/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

public class AksesKaryawan {

    public static void main(String[] args) {
        
        Karyawan kyw=new Karyawan();
        
        
        kyw.setNip("11523246");
        kyw.setNama("Rani putriana");
        kyw.setGaji(5000000);
        
        System.out.println("nip anda adalah: "+kyw.getNip());
        System.out.println("nama anda adalah: "+kyw.getNama());
        System.out.println("gaji anda selama setahun adalah: "+kyw.getGaji());
        
    }
}
