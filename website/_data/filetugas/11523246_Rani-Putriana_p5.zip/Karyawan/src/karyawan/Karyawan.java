/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

public class Karyawan {

    private String nip;
    private String nama;
    private int gaji;
     
    public void setNip(String nip) {
        if (nip.length()==8){
        this.nip=nip;
        }
        else {
            System.out.println("nip anda salah");
        }
    }
    public String getNip(){
        return nip;
    }
    
    public void setNama(String nama) {
        this.nama=nama;
    }
    public String getNama(){
        return nama;
    }
    
    public void setGaji(int gaji) {
        if (gaji != 0){
        this.gaji=12*gaji;
        }
        else {
            System.out.println("gaji impossible");
        }
    }
    public int getGaji(){
        return gaji;
      
    }
    
}
