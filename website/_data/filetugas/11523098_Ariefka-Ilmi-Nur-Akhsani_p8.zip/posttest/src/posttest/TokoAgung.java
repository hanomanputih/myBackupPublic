/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author Praktikan
 */
public class TokoAgung extends Swalayan {
    @Override
    void pembayaran(){
        harga=19200;
        sisa = (int) (harga%25);
        bayar = (int) (harga - sisa);
            
    }
}
