/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author Praktikan
 */
public class Posttest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Swalayan s;
        Indomart i = new Indomart();
        s=i;
        s.pembayaran();
        System.out.println(s.bayar);
        
        
        TokoAgung t = new TokoAgung();
        
        s=t;
        s.pembayaran();
        System.out.println(s.bayar);
        
       
        // TODO code application logic here
    }
}
