/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;
import java.util.Scanner;


/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
    String nama;
    String nim;
    
    void Saya() {
        Scanner cetak = new Scanner (System.in);
        System.out.println("Masukkan Nama: " );
        nama = cetak.next();
        System.out.println("Masukkan NIM: ");
        nim = cetak.next();
        
        System.out.println("Nama"+nama );
        System.out.println("Nama"+nim );
        
        
    }   
            
    public static void main(String[] args) {
        
        Mahasiswa identitas=new Mahasiswa();
        identitas.Saya();
        
            }
}
