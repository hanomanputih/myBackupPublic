/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest_komposisi;

/**
 *
 * @author Praktikan
 */
public class Prosesor {
    
    String Merek;
    int core;
    
    public Prosesor(String Merek, int core){
        this.Merek = Merek;
        this.core = core;
    }
    
}
