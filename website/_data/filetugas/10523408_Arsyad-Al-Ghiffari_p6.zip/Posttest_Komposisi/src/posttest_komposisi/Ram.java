/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest_komposisi;

/**
 *
 * @author Praktikan
 */
public class Ram {
    String GB;
    
    public Ram(String GB){
        this.GB = GB;
    }
}
