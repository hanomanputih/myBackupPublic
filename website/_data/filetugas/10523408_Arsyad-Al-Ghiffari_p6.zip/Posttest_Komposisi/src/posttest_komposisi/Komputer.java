/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest_komposisi;

/**
 *
 * @author Praktikan
 */
public class Komputer {
    String namaKomputer;
    Prosesor ps;
    Ram rm;
    
    public Komputer (String namaKomputer, Prosesor ps, Ram rm){
        this.namaKomputer = namaKomputer;
        this.ps = ps;
        this.rm = rm; 
    }
    
    public void tampil(Ram rm){
        System.out.println("Nama Manusia : "+namaKomputer);
        System.out.println("Merek Prosesor : "+ps.Merek);
        System.out.println("Jumlah Core : "+ps.core);
        System.out.println("RAM Size : "+rm.GB);
    }
}
