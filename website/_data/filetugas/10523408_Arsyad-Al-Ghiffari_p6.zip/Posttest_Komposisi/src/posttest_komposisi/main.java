/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest_komposisi;

/**
 *
 * @author Praktikan
 */
public class main {
    public static void main(String[] args) {
      Prosesor pt = new Prosesor("AMD", 8);
      Ram r = new Ram("8 GB");
      Komputer kom = new Komputer("Lenovo", pt, r);
      
      kom.tampil(r);
}}
