/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author PRAKTIKAN
 */
public abstract class Karyawan {
    int gajiPokok = 3000000;
    int tunjangan = (2/10)*gajiPokok;
    int Bonus;
    int gaji;
    int totalGaji;
    
    abstract void gaji ();
}
