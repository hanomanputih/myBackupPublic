/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author PRAKTIKAN
 */
public class Main {
    public static void main(String[] args) {
        karyawanTetap kt = new karyawanTetap();
        kt.gaji();
        System.out.println("Gaji Pokok : "+kt.gajiPokok);
        System.out.println("Tunjangan : "+kt.tunjangan);
        System.out.println("Bonus : "+kt.Bonus);
        System.out.println("Gaji : "+kt.gaji);
        System.out.println("Total Gaji Karyawan Tetap : "+kt.totalGaji);
    }
}
