/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package posttest6;

/**
 *
 * @author Praktikan
 */
public class KaryawanTetap extends Karyawan{

    String nama = "Gery";
    int tunjangan = (int) (0.2 * gajipokok);

    @Override
    public void gaji(){
        System.out.println("Nama : "+nama);
        System.out.println("Gaji Tetap : "+(tunjangan+gajipokok+bonus));
    }
}
