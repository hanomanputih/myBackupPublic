/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package posttest6;

/**
 *
 * @author Praktikan
 */
public class KaryawanKontrak extends Karyawan{

    String nama = "Danu";

 
    @Override
    public void gaji(){
        System.out.println("Nama : "+nama);
        System.out.println("Gaji Kontrak : "+(gajipokok+bonus));
    }
}
