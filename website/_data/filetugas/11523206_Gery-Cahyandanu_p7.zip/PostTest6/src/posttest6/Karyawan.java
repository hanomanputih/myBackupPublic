/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package posttest6;

/**
 *
 * @author Praktikan
 */
public class Karyawan {
    
    int gajipokok = 3000000;
    int bonus = 500000;

    public void gaji(){
       
    }
}
