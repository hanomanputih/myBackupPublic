/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

/**
 *
 * @author PRAKTIKAN
 */
public class Mahasiswa {
    
    
    String angkatan;
    String fakultas;
    String nama;
    String nim;
    String jurusan;
    float jumlah1;
    float jumlah2;
    float hitung;
    void    cetak(){
        System.out.println("nama anda adalah = "+nama);
        System.out.println("nim anda adalah = "+nim);
        System.out.println("jurusan anda adalah = "+jurusan);
        System.out.println("fakultas anda adalah = "+fakultas);
        System.out.println("angkatan anda adalah = "+angkatan);
    }
    
    public static void main(String[] args) {
    Mahasiswa mhs = new Mahasiswa();
    mhs.nama ="Prasetyo sieskayadi";
    mhs.nim  ="11523121";
    mhs.jurusan="teknik informatika";
    mhs.fakultas="teknik industri";
    mhs.angkatan="2011";
    mhs.cetak();
    
        System.out.println("nama= "+mhs.nama);
        System.out.println("nim= "+mhs.nim);
        System.out.println("jurusan= "+mhs.jurusan);
        System.out.println("fakultas= "+mhs.fakultas);
        System.out.println("angkatan= "+mhs.angkatan);
          
     float jumlah1 = mhs.nama.length();
        System.out.println("jumlah string nama anda adalah : "+jumlah1);
     
     float jumlah2 = mhs.nim.length();
        System.out.println("jumlah string nim anda adalah : "+jumlah2);
     
     float hitung = jumlah1+jumlah2;
             System.out.println("jumlah total string anda adalah : "+hitung);
        
        
    }
    
}
