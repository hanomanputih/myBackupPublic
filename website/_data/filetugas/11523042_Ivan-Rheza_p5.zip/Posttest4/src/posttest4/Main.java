/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest4;

/**
 *
 * @author praktikan
 */
public class Main {
    public static void main(String[] args) {
        Karyawan kry = new Karyawan();
        kry.getTAMPILna();
        System.out.println(kry.getTAMPILna());
        System.out.println("Nama : "+kry.nama);
        System.out.println("nip : "+kry.gaji);
        
    }
}
