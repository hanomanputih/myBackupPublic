/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest4;

/**
 *
 * @author praktikan
 */
public class Karyawan {
    String nip,nama;
    int gaji;
    
    void setTAMPILni (){
        nip="12345";
    }
    String getTAMPILni(){
        return nip;
    }
    
    void setTAMPILna (){
        nama = "Ivan Rheza P.";
    }
    String getTAMPILna(){
        return nama;
    }
    
    void setTAMPILga (){
        gaji = 1500000;
    }
    int getTAMPILga(){
        return gaji;
    }

}
