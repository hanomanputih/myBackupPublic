/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest.pkg4;

/**
 *
 * @author Praktikan
 */
public class karyawan {
     private String nip ;
    private String nama ;
    private int gaji ;

void setNIP (String ni){

 nip=ni;
}

void setNAMA (String nm){

nama = nm;
}

void setGaji (int gj){
        gaji=gj;
}

public String GetNip (){
    
    return nip;
}
public String Getnama (){
    return nama;
}
public int GetGaji (){
    return gaji ;
}
       
}