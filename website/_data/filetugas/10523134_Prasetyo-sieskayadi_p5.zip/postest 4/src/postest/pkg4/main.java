/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest.pkg4;

/**
 *
 * @author Praktikan
 */
public class main {
    public static void main(String[] args) {
        karyawan ky = new karyawan ();
        ky.setNIP("10523134");
        ky.setNAMA("prasetyo sieskayadi");
        ky.setGaji(2000000);
        
        System.out.println("Data karyawan");
        System.out.println("NIP; "+ky.GetNip());
        System.out.println("NAMA"+ky.Getnama());
        System.out.println("Gaji"+ky.GetGaji());
    }
     
     
   
}
