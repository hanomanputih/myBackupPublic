/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;

/**
 *
 * @author PRAKTIKAN
 */
public class Postes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        ArrayList list = new ArrayList();
        LinkedList list2 = new LinkedList();
        list.add("NIM: 10523081");
        list.add("NAMA: saia dona");
        list2.add("NIM");
        list2.add("Nama");
        System.out.println("ukuran list "+list.size());
        
        for (Iterator iterator = list.iterator(); iterator.hasNext();) {
            String ii = (String) iterator.next();
            System.out.println(ii);
           
        }
        
        
        Map <Integer, String> map = new HashMap <Integer, String>();
        
        map.put (11, "dona");
        map.put (22, "1522383");
        
        
        System.out.println(map.get(1));
        
        System.out.println("-------------------------");
        for (Integer i : map.keySet())
        {
            System.out.println("key "+i+i+ ":" +map.get(i));
        }
        System.out.println("==================");
        for (Map.Entry<Integer, String> entry : map.entrySet()){
            System.out.println(entry.getValue());
        }
    }
}



