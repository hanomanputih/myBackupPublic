/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class Komputer {

   private String namaKom;
   private prosesor p; 
    
   public Komputer(String Kom){
   this.namaKom = Kom;
   if (namaKom.equals("SAMSUNG"))
            p = new prosesor("AMD");
    }
   
   
   public void TampilKom(){
       System.out.println("Nama Komputer :" +namaKom);
       //System.out.println("Nama Prosesor :" +p);
   }
 
    public static void main(String[] args) {
     
        Komputer  namaKom = new Komputer("SAMSUNG");
        namaKom.TampilKom();
  
        
    
    }
}
