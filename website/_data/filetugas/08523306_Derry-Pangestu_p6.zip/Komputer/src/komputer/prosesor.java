/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class prosesor {
    private String namaPro;
    private RAM r;
    
    public prosesor(String namaPro){
        this.namaPro = namaPro;
        if (namaPro.equals("AMD"))
            r = new RAM("SanDisk");
    }


/*public void TampilPro(){
System.out.println("Nama Prosesor :" +namaPro);
System.out.println("Nama RAM :" +r);
}*/
}