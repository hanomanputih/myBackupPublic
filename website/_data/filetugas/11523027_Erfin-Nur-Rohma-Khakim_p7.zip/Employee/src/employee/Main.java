/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package employee;

/**
 *
 * @author Praktikan
 */
public class Main {
    public static void main(String[] args) {
        Tetap ttp = new Tetap();
        ttp.gaji();
        ttp.bernafas();
        
        System.out.println("");
        
        Kontrak ktr = new Kontrak();
        ktr.gaji();
        ktr.bernafas();
    }
}
