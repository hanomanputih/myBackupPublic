/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package employee;

/**
 *
 * @author Praktikan
 */
public abstract class Karyawan {
    protected int gajiPokok=3000000;
    protected int gaji;
    
    public void view() {
        System.out.println("Gaji Pokok : "+gajiPokok);
    }
    public abstract void gaji();
}
