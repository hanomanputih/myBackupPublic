/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package employee;

/**
 *
 * @author Praktikan
 */
public class Kontrak extends Karyawan implements Manusia{
    public int bonus=200000;
    
    @Override
    public void gaji() {
        super.view();
        gaji=gajiPokok+bonus;
        System.out.println("Bonus : "+bonus);
        System.out.println("Gaji Total : "+gaji);
    }

    @Override
    public void bernafas() {
        System.out.println("Bernafas juga");
    }

}
