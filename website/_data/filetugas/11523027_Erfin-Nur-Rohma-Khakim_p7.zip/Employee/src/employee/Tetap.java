/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package employee;

/**
 *
 * @author Praktikan
 */
public class Tetap extends Karyawan implements Manusia{
    public int bonus=500000;
    protected int tunjangan=(int) (0.2*gajiPokok);
    
    @Override
    public void gaji() {
        super.view();
        gaji=tunjangan+gajiPokok+bonus;
        System.out.println("Tunjangan : "+tunjangan);
        System.out.println("Bonus : "+bonus);
        System.out.println("Gaji Total : "+gaji);
    }

    @Override
    public void bernafas() {
        System.out.println("Bernafas");
    }
    
}
