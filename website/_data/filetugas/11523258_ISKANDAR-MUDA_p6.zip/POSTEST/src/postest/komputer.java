/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

/**
 *
 * @author Praktikan
 */
public class komputer {
    ram r;
    prosesor p;
    public String kompi;
    
    public komputer(String ini){
        kompi=ini;
        
        r=new ram("4GB");  
        p=new prosesor("i7 intel core");
    
}
    public static void main(String[]args){
        komputer K=new komputer("mantap");
        System.out.println("Jadi komputer ini ram "+K.r.jenis);
        System.out.println("dengan prosesor "+K.p.tipe);
    }
    
    }