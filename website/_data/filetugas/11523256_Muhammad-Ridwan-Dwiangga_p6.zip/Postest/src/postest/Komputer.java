/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

/**
 *
 * @author Praktikan
 */
public class Komputer {
    Ram rm;
    Prosesor pr;
    
    public Komputer(String nmRam,String nmPr){
        if(nmRam.equals("2"))
        {
            rm = new Ram("2048 MB");
        }
        if (nmPr.equals("i5"))
        {
            pr = new Prosesor("Intel Prosesor Core i5");
        }
        else 
        {
            System.out.println("Salah masukkan om!!");
        }
       
    }
    
    public static void main(String[] args) {
        Komputer k =  new Komputer("2","i5");
        k.rm.tampilRam();
        k.pr.tampilPros();
    }
}
