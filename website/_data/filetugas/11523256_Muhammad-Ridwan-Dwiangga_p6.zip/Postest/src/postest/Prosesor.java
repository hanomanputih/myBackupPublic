/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

/**
 *
 * @author Praktikan
 */
public class Prosesor {
    String NamaPros;
    

 public Prosesor(String NamaPros){
     this.NamaPros = NamaPros;
 }

 public void tampilPros (){
     System.out.println("Jenis Prosesor = "+NamaPros);
 }
}