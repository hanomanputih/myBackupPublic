/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

/**
 *
 * @author Praktikan
 */
public class Ram {
    String NamaRam;
    

 public Ram(String NamaRam){
     this.NamaRam = NamaRam;
 }

 public void tampilRam (){
     System.out.println("besar ram = "+NamaRam);
 }
}