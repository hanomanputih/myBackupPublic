/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

/**
 *
 * @author PRAKTIKAN
 */
public class Mahasiswa {
    String Nama;
    String nim;
    String fakultas;
    String jurusan;
    String angkatan;
    
    
    void cetakData(){
        System.out.println("nama saya adalah: "+Nama);
        System.out.println("nim saya adalah: "+nim);
        System.out.println("fakultas saya adalah: "+fakultas);
        System.out.println("saya jurusan : "+jurusan);
        System.out.println("saya angkatan tahun: "+angkatan);
        
    }
    public static void main(String[] args) {
        Mahasiswa mhs = new Mahasiswa();
        mhs.Nama = "mei";
        mhs.nim = "11523267";
        mhs.fakultas = "fakultas teknologi industry";
        mhs.jurusan = "teknik informatika";
        mhs.angkatan = "angkatan 2011";
//        System.out.println("nama adalah: "+mhs.Nama);
//        System.out.println("nim saya adalah: "+mhs.nim);
//        System.out.println("fakutas: "+mhs.fakultas);
//        System.out.println("jurusan: "+mhs.jurusan);
//        System.out.println("angkatan: "+mhs.angkatan);
        
        mhs.cetakData();
        
    }
    

    
   
   
        
        
        
    }

