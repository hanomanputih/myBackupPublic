/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest8;

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.HashMap;

/**
 *
 * @author Praktikan
 */
public class PostTest8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        Map<String, String> mhs = new HashMap<String, String>();
        List<String> alamat = new ArrayList<String>();
        List<String> nama = new ArrayList<String>();

        alamat.add("Jakal");
        nama.add("Surya");
        alamat.add("CongCat");
        nama.add("Hendry");
        alamat.add("Wates");
        nama.add("NN");

        System.out.println("menggunakan Array List");
        System.out.println(alamat.get(2) + ", " + nama.get(2));

        System.out.println("");


        mhs.put("Jakal 14.5", "Surya");
        mhs.put("Congcat", "Hendry");
        mhs.put("Wates", "NN");
        System.out.println("");

        System.out.println("menggunakan Map, tampil dengan for");
        for (Map.Entry<String, String> e : mhs.entrySet()) {
            System.out.println(e.getKey() + ", " + e.getValue());
        }

        // System.out.println(e.getKey()+", "+e.getValue());
        System.out.println("");
        System.out.println("Menggunakan List dengan Iterator");
        Iterator nm = nama.iterator();
        Iterator al = alamat.iterator();
        while (al.hasNext()) {
            System.out.println(al.next() + ", " + nm.next());
        }

//        System.out.println("");
//        System.out.println("Menggunakan List dengan Iterator");
        
//        Iterator<Map.Entry<String, String>> m = mhs.entrySet().iterator();
//        while (m.hasNext()) {
//            System.out.println(m.next());
//        Map<String,String> s = (Map) m;
//            System.out.println(s.keySet());
//            System.out.println(s.values());
//        
//        }

    }
}
