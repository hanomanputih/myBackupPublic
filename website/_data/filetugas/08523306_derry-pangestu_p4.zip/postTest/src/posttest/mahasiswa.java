/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

import java .util.Scanner;

/**
 *
 * @author Praktikan
 */
public class mahasiswa {

    /**
     * @param args the command line arguments
     */
    String namaMahasiswa;
    String nim;
    String fakultas;
    String jurusan;
    String angkatan;
    
    public static void main(String[] args) {
       mahasiswa saya = new mahasiswa();
       Scanner cetak = new Scanner (System.in);
       System.out.println("Masukkan nama Anda");
       saya.namaMahasiswa = cetak.next();
       System.out.println("nama anda" + saya.namaMahasiswa);
       System.out.println("Masukkan nim Anda");
       saya.nim = cetak.next();
       System.out.println("nim anda" + saya.nim);
       System.out.println("Masukkan fakultas Anda");
       saya.fakultas = cetak.next();
       System.out.println("fakultas anda" + saya.fakultas);
       System.out.println("Masukkan jurusan Anda");
       saya.jurusan = cetak.next();
       System.out.println("jurusan anda" + saya.jurusan);
       System.out.println("Masukkan angkatan Anda");
       saya.angkatan = cetak.next();
       System.out.println("angkatan anda" + saya.angkatan);
    }
}
