/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest8;

import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Praktikan
 */
public class Posttest8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        List list1 = new ArrayList<String>();
        
        list1.add("Ivan");
        list1.add("Rheza");
        list1.add(11523042);
        for (int i = 2; i < list1.size(); i++) {
            System.out.println("indeks "+ i +" : "+ list1.get(i));
        }
        
        System.out.println("====================");
        Map<Integer, String> map = new HashMap<Integer, String>();
        
        map.put(11523042, "Ivan Rheza");
        
        for (Integer i : map.keySet()) {
            System.out.println("NIM anda: "+ i +" dan Nama anda: "+ map.get(i));
    }
    }
}
