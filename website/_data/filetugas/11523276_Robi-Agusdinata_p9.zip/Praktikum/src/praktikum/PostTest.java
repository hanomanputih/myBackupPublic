package praktikum;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class PostTest {

    private static void loadData(List<String> list){
        //class Scanner
        Scanner n = new Scanner(System.in);
        System.out.println("masukkan nama");
        list.add(n.next());
        System.out.println("masukkan nim");
        list.add(n.next());
    }
    private static void tampilkanList (List<String> list){
        //pake iterator
        for(Iterator<String> iterator = list.iterator(); 
        iterator.hasNext();){
        String isi = iterator.next();
        System.out.println(isi);}
    }
    //class main
    public static void main(String[] args) {
        List<String> list = new ArrayList<String>();
        loadData(list);
        tampilkanList(list);
        //bukti pake array list
        System.out.println("list di index ke 1 = "+list.get(0));
        //pake map
        HashMap map = new HashMap();
        Scanner n = new Scanner(System.in);
        map.put("Nama ", n.next());
        map.put("NIM ", n.next());
    }
}
