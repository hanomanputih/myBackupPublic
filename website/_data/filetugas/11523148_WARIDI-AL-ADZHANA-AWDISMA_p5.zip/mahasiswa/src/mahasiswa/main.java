/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

/**
 *
 * @author Praktikan
 */
public class main {
    public static void main(String[] args) {
        Mahasiswa m = new Mahasiswa ();
        
        m.setNim("11523148");
        System.out.println("nim anda :"+m.getNim());
    }
}
