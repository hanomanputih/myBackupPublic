/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

/**
 *
 * @author Praktikan
 */
public class main_karyawan {
    public static void main(String[] args) {
        karyawan k = new karyawan ();
        
        k.setNip("11523148");
        System.out.println("nip anda :"+k.getNip());
       
        k.setNama("waridi al adzhana");
        System.out.println("nama anda :"+k.getNama());
        
         k.setGaji("10000000000");
        System.out.println("gaji anda :"+k.getGaji());
    }
}
