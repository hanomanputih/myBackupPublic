/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
 private String nim;
 public String nama;

 public String getNim(){
     return nim;
 }
 public void setNim (String nim) {
     this.nim = nim;
 }
}
    
