/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;


public class Main {
    public static void main(String[] args) {
        Karyawan aku=new Karyawan();
        aku.setnip("1234567890");
        aku.setnama("Sharrawy");
        aku.setgaji(400000);
        System.out.println("NIP:"+aku.getnip());
        System.out.println("Nama:"+aku.getnama());
        System.out.println("Gaji:"+aku.getgaji());
    }
    
}
