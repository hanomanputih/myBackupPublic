/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg11523158;

/**
 *
 * @author Praktikan
 */
import java.util.*;

public class test {
public static void main(String[]args){ 
List<String> list = new LinkedList();//deklarasi pembuatan List 
    for(int i=1; i<=3; i++){ 
        if(i % 2 == 0){ 
            list.add("- Laboratorium KSC");//untuk memasukkan data ke 
            //dalam List jika i = genap 
        }else{ 
            list.add("- KSC laboratory");//untuk memasukkan data ke dalam 
            //List jika i = ganjil 
            } 
        } 
    System.out.println("Ukuran List --> "+list.size());//untuk melihat 
                                                       //jumlah data di dalam List 
    Collections.sort(list);// untuk men sortir data di dalam list 
    for(Iterator<String> iterator = list.iterator(); 
    iterator.hasNext();){//untuk melihat isi List 
        String isi = iterator.next(); 
        System.out.println(isi); 
    } 
  } 
}
   
