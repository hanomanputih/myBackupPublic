/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg11523158;
import java.util.HashMap;

public class bbbbb {
    public static void main(String[] args) {
        HashMap map = new HashMap ();
        map.put("Nama ", " YS");
        map.put("NIM "," 11523158");
        System.out.println(map);
        System.out.println("Ukuran Map: " + map.size());
        boolean containKey = map.containsKey("NIM");
        System.out.println("Has key (NIM): "+containKey);
        Object removed = map.remove("NIM");
        System.out.println("Removed: "+removed);
        System.out.println(map);
        System.out.println("Ukuran Map Baru: "+map.size());
    }
    
}
