/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg11523158;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;


/**
 *
 * @author Praktikan
 */
public class PostTest {
    public static void main(String[] args) {
        int NIM;
        String nama;
        
        Scanner sc=new Scanner(System.in);
        HashMap hm=new HashMap();
        ArrayList ar=new ArrayList();
        
        ar.add("11523158");
        ar.add("Muhammad Yusuf Ekaputra");
        ar.add("fasdfda");
        System.out.println("Ukuran List: "+ar.size());
        for (Iterator it= ar.iterator();it.hasNext();){
            String ys=(String) it.next();
            System.out.println("NIM :"+ys);
            System.out.println("Nama :"+it.next());
            System.out.println("sdsdfs:"+it.next());
        }
        hm.put("NIM "," 11523158");
        hm.put("Nama "," Yusuf");
        System.out.println("Ukuran Map: "+hm.size());
        System.out.println(hm);
        
        
        
        
    }
    
    
}
