/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg11523158;

import java.util.Collections;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

/**
 *
 * @author Praktikan
 */
public class aaaa {
    
    public static void main(String[] args) {
        
        ArrayList list=new ArrayList();
        LinkedList list2=new LinkedList();
        list.add("ksc");
        list.add("PIT");
        list.add("sirkel");
        list.add("jarkom");
        list2.add("ini");
        list2.add("itu");
        System.out.println("ukuran list: "+list2.size());
        System.out.println("");
        
        for (Iterator iterator=list2.iterator(); iterator.hasNext();){
            String ys = (String) iterator.next();
            System.out.println("isi: "+ys);
        }
    }
    
}
