/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package postest;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
/**
 *
 * @author Praktikan
 */
public class Main {

    
    public static void main(String[] args) {
         Map<Integer,String> data = new HashMap<Integer,String>();
         
        
        data.put(11523037,"mamang"); 
                
        data.put(11523038,"monang");
        
        data.put(11523035,"erwim");
        
        for(Map.Entry<Integer,String> e : data.entrySet()){
        System.out.println(e.getKey()+", "+e.getValue());

    }

}
}
