/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest8;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

/**
 *
 * @author PRAKTIKAN
 */
public class Posttest8 {

    /**
     * @param args the command line arguments
     */
   public static void main (String[]args){
        Map<Integer, String> m = new HashMap<Integer, String>();
        
        m.put (11523257,"Pandu pramudito");
        
        System.out.println(m);
        Iterator<Entry<Integer,String>> it = m.entrySet().iterator();
        while (it.hasNext()){
            System.out.println(it.next());
        }
        
    }
    
}
