/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package post.test.pkg5;

/**
 *
 * @author Praktikan
 */
public class Komputer {
String jenisKom;
    Prosesor p;
    RAM r;
    

public Komputer (String k, String P, String R) {
    this.jenisKom = k;
    p = new Prosesor (P);
    r = new RAM (R);
    
}

public void tampilkan() {
    System.out.println("jenis komputer :"+jenisKom);
    System.out.println("jenis prosesor:"+p.jenisPro);
    System.out.println("jenis ram:"+r.jenisRAM);
}
public static void main(String[] args) {
    Komputer r = new Komputer("MSI","AMD","2GB");
    r.tampilkan();
}
}