/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package post.test.pkg5;

/**
 *
 * @author Praktikan
 */
public class Prosesor {
String jenisPro;

public Prosesor (String nama) {
    this.jenisPro = nama;
}
   
}