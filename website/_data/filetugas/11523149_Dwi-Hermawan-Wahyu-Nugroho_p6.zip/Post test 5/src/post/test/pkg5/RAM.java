/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package post.test.pkg5;

/**
 *
 * @author Praktikan
 */
public class RAM {
String jenisRAM;

public RAM (String nama) {
    this.jenisRAM = nama;
}
   
}
