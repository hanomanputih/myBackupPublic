
import java.util.Scanner;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

public class Mahasiswa {
    String nama, nim, fakultas, jurusan, angkatan;

void cetak(){
System.out.println("nama anda adalah"+nama);
System.out.println("NIM anda adalah"+nim);
System.out.println("Fakultas anda adalah"+fakultas);
System.out.println("Jurusan anda adalah"+jurusan);
System.out.println("Anda adalah angkatan"+angkatan);
};   
    
/*
  void isidata(){
Scanner sc=new Scanner(System.in);
System.out.println("Masukan nama anda :" );nama=sc.nextLine();
System.out.println("Masukan NIM anda :" );nim=sc.next();
System.out.println("Masukan Fakultas anda :" );fakultas=sc.next();
System.out.println("Masukan Jurusan anda :" );jurusan=sc.next();
System.out.println("Angkatan berapa anda :" );angkatan=sc.next();
}
*/
 public static void main(String[] args) {
 Mahasiswa mahasiswa1 = new Mahasiswa();
 //mahasiswa1.isidata();
 Scanner sc=new Scanner(System.in);
System.out.println("Masukan nama anda :" );mahasiswa1.nama=sc.nextLine();
System.out.println("Masukan NIM anda :" );mahasiswa1.nim=sc.next();
System.out.println("Masukan Fakultas anda :" );mahasiswa1.fakultas=sc.next();
System.out.println("Masukan Jurusan anda :" );mahasiswa1.jurusan=sc.next();
System.out.println("Angkatan berapa anda :" );mahasiswa1.angkatan=sc.next();
 mahasiswa1.cetak();
 
 }
}
