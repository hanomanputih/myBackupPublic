/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perusahaan;

/**
 *
 * @author PRAKTIKAN
 */
public class KaryawanTetap extends Karyawan{
    int gaji1;
    int tunjangan = 600000;
    
    @Override
    public void view(){
       gaji1 = gajipokok + bonus + tunjangan;
       System.out.println("Gaji Karyawan Tetap : " + gaji1);
    }
}
