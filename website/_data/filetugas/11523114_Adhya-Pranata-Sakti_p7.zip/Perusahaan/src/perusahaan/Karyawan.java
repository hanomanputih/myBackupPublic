/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perusahaan;

/**
 *
 * @author PRAKTIKAN
 */
public abstract class Karyawan {
    int gajipokok = 3000000;
    int bonus = 500000;
    
    protected void view(){
        
        System.out.println("Gaji Pokok : " + gajipokok);
        System.out.println("Bonus : " + bonus);
    }
    
}
