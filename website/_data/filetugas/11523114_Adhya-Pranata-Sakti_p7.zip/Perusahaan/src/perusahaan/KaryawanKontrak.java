/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perusahaan;

/**
 *
 * @author PRAKTIKAN
 */
public class KaryawanKontrak extends Karyawan {
    int gaji2;
    
    @Override
    public void view(){
       gaji2 = gajipokok + bonus;
       System.out.println("Gaji Karyawan Kontrak : " + gaji2);
    }
}
