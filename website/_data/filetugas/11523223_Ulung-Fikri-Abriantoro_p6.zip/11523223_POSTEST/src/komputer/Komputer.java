/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author PRAKTIKAN
 */
public class Komputer {
    private int np;
    private Prosesor p;
    private RAM ram;
    
    public Komputer (int np) {
        this.np=np;
        if(np == 1){
            p = new Prosesor (5);
            ram = new RAM (5);
            
                    
        }
    }
    void tampil(){
        System.out.println("Nomor Produksi  : "+ np);
        System.out.println("Nomor Processor : "+ p.nomor);
        System.out.println("Nomor RAM       : "+ ram.nomor);
    }
            
}
 
