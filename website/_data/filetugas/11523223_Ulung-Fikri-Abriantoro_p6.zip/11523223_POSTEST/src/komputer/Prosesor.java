/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author PRAKTIKAN
 */
public class Prosesor {
    int nomor;

    public Prosesor(int nomor) {
        this.nomor = nomor;
    }
    

    public int getNomor() {
        return nomor;
    }

    public void setNomor(int nomor) {
        this.nomor = nomor;
    }
            
}

