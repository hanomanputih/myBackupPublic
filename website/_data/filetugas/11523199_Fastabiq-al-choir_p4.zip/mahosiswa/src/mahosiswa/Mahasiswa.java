/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package mahasiswa;

import java.util.Scanner;

public class Mahasiswa {

    private static class system {

        public system() {
        }
    }
String nama,nim,jurusan,angkatan,fakultas;
int jumlah;



void tampil(){

    Scanner tampil = new Scanner (System.in);
    System.out.println("Nama :" );
    nama = tampil.next();
    System.out.println("NIM :" );
    nim = tampil.next();
    System.out.println("Jurusan :");
    jurusan = tampil.next();
    System.out.println("Angkatan :");
    angkatan = tampil.next();
    System.out.println("Fakultas :");
    fakultas = tampil.next();
    System.out.println("Nama anda =" +nama);
    System.out.println("Nim anda =" +nim);
    System.out.println("Jurusan anda =" +jurusan);
    System.out.println("Angkatan anda =" +angkatan);
    System.out.println("Fakultas anda =" +fakultas);
}

void hitungKarakter(){
jumlah = nama.length();
    System.out.println("Panjangnya =" +jumlah);
jumlah = nim.length();
    System.out.println("Panjangnya nim =" +nim);


   }

    public static void main(String[] args) {
    Mahasiswa mhs1 = new Mahasiswa ();
    mhs1.tampil();
    mhs1.hitungKarakter();
    }


}
