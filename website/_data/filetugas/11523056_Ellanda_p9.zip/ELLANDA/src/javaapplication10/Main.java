/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication10;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author PRAKTIKAN
 */
public class Main {
     public static void main(String[] args) {
        Map<Integer, String> map = new HashMap<Integer, String>();
        
        map.put(11, "orang1");
        map.put(22, "orang2");
        map.put(33, "orang3");
        
        System.out.println(map.get(11));
        System.out.println("===================");
        for(Integer i : map.keySet ()) {
            System.out.println("key " + 1 + " : " + map.get(i));
    }
for(Map.Entry<Integer, String> entry : map.entrySet()) {
    System.out.println(entry.getKey() + ", " + entry.getValue());
        
    }
    
}

    
}
