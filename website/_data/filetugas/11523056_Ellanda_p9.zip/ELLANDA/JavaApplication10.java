/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication10;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 *
 * @author PRAKTIKAN
 */
public class JavaApplication10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        List list1 = new ArrayList();

        list1.add("Ellan");
        list1.add("11523056");
        list1.add("Ellan1");
        list1.add("115230561");
        list1.add("Ellan2");
        list1.add("115230562");

        for (int i = 0; i < list1.size(); i++) {
            if (i % 2 == 1) {
                System.out.println("nama " + i + " : " + list1.get(i));
                if (i % 2 == 0) {
                    System.out.println("nim " + list1.get(i));
                }
            }

        }
        System.out.println("======================");
        for (Object s : list1) {
            System.out.println(s);
        }

        System.out.println("======================");
        Iterator<String> ite = list1.iterator();
        while (ite.hasNext()) {
            String s = ite.next();
            System.out.println(s);
        }
        System.out.println("======================");
        System.out.println(list1);
    }
}
