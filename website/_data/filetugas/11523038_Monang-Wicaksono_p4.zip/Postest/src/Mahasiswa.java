/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author PRAKTIKAN
 */
  import java.util.Scanner;
public class Mahasiswa {
    
    
  
    public static void main(String[] args) {
        String nama ;
    String nim ;
    String fakultas;
    String jurusan;
    int angkatan;

        Scanner baca = new Scanner(System.in);
            System.out.println("Masukkan Nama : ");
            nama = baca.next();
            System.out.println("Masukkan NIM : ");
         nim = baca.next();
         System.out.println("Masukkan Fakultas : ");
        fakultas = baca.next();
        System.out.println("Masukkan Jurusan : ");
        jurusan = baca.next();
        System.out.println("Masukkan Angkatan : ");
        angkatan = baca.nextInt();
        System.out.println("Nama : "+nama);
        System.out.println("Nim : "+nim);
        System.out.println("Fakultas : "+fakultas);
        System.out.println("Jurusan : "+jurusan);
        System.out.println("Angkatan : "+angkatan);
        
    }
    
    
}