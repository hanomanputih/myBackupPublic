/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author Praktikan
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Swalayan s;
        Indomart i = new Indomart();
        s=i;
        s.tampil();
        TokoAgung t = new TokoAgung();
        s=t;
        s.tampil();
    }
}
