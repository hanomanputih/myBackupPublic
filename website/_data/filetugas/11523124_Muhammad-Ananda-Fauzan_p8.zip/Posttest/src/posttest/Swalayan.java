/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author Praktikan
 */
public class Swalayan {
    public float harga = 19212;
    public int bayar;
    public int sisa;
    
    void tampil(){
        
    }
}
