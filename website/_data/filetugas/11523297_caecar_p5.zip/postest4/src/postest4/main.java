/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest4;

/**
 *
 * @author Praktikan
 */
public class main {
    public static void main(String[] args) {
        karyawan kn = new karyawan();
       kn.setNIP ("11523297");
       kn.setNAMA ("caecar");
       kn.setGAJI (1000000);
        System.out.println("nama saya"+kn.getNAMA());
        System.out.println("nip saya"+kn.getNIP());
        System.out.println("gaji saya"+kn.getGAJI());
        
    }
}
