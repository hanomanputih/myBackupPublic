/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Praktikan
 */
public class karyawan { 
    private String NIP;
    private String nama;
    private int gaji;
    
    void getNIP (String ni){
        if(ni.length() == 10){
           NIP = ni;
        }
    }
    else {
            System.out.println("error...");
}
    
}

  void getNIP (String ni){
        if(ni.length() == 10){
            nama = ni;
        }
    
    else {
            System.out.println("error...");
}
void getgaji (String ni){
    if(ni.length() == 10){
            gaji = ni;
        }
    }
    else {
            System.out.println("error...");
}