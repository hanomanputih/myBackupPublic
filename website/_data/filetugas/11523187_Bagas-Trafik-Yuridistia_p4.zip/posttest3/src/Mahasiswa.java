
import java.util.Scanner;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author praktikan
 */
public class Mahasiswa {
    String nama;
    String nim;
    String fakultas;
    String jurusan;
    String angkatan;
    void cetak(){
        System.out.println("nama anda = "+ nama + " nim anda = " + nim + " fakultas = " + fakultas + " jurusan = " + jurusan + " angkatan = " + angkatan);
    }
    public static void main(String[] args) {
        Scanner baca = new Scanner (System.in);
        Mahasiswa mhs1 = new Mahasiswa();
        System.out.print("nama anda adalah = ");
        mhs1.nama = baca.next();
        System.out.print("nim anda adalah = ");
        mhs1.nim = baca.next();
        System.out.print("fakultas = ");
        mhs1.fakultas = baca.next();
        System.out.print("jurusan =");
        mhs1.jurusan = baca.next();
        System.out.print("angkatan =");
        mhs1.angkatan = baca.next();
        System.out.println("Mahasiswa UII");
        mhs1.cetak();
    }

}
