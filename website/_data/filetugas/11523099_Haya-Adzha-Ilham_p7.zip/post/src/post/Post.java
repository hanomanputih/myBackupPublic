/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package post;

/**
 *
 * @author Praktikan
 */
public class Post {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     karyawanTetap kt = new karyawanTetap();
     karyawanKontrak kk = new karyawanKontrak();
     
     kt.gaji();
        
        
     kk.gaji();
    }
}
