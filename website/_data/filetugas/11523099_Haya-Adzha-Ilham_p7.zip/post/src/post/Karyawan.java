/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package post;

/**
 *
 * @author Praktikan
 */
public abstract class Karyawan {
  public int gajiPokok = 3000000;
    
 
    public abstract void gaji();
    int gajiBonus = 400000;
    int tunjangan = 400000*20/100;
    }
