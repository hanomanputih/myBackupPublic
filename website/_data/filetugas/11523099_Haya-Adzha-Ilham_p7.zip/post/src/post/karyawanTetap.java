/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package post;

/**
 *
 * @author Praktikan
 */
public class karyawanTetap extends Karyawan {
    int gaji;
    
    

    @Override
    public void gaji() {
     gaji = tunjangan+gajiBonus+gajiPokok;
        System.out.println("gaji karyawan tetap adalah : "+gaji);
    }
}
