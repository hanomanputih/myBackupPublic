/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package mahasiswa;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
 Scanner pembaca = new Scanner (System.in);
String nama;
String nim;
String fakultas;
String jurusan;
String angkatan;


void masukan (){
    System.out.print("Masukan nama :");
    nama=pembaca.next();
    System.out.print("Masukan nim :");
    nim=pembaca.next();
    System.out.print("Masukan Fakultas anda :");
    fakultas=pembaca.next();
    System.out.print("Masukan Jurusan anda :");
    jurusan=pembaca.next();
    System.out.print("Masukan tahun angkatan anda :");
    angkatan=pembaca.next();
    }
void cetak (){
    System.out.println("Nama Anda :"+nama);
    System.out.println("NIm Anda"+nim);
    System.out.println("Fakultas Anda"+fakultas);
    System.out.println("Jurusan Anda"+jurusan);
    System.out.println("Tahun Angkatan anda"+angkatan);
}


    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
Mahasiswa mhs = new Mahasiswa ();
mhs.masukan();
mhs.cetak();
    }

}
