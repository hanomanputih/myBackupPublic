/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

/**
 *
 * @author LAB-KSC
 */
public class Mahasiswa {

    String Nama ;
    String NIM  ;
    String Fakultas  ;
    String Jurusan ;
    

        
        void cetak()
        {
        System.out.println("Nama anda : "+Nama);
        System.out.println("NIM anda : "+NIM);
        System.out.println("Fakultas anda : "+Fakultas);
        System.out.println("Jurusan anda : "+Jurusan);
        }
        
        
      public static void main(String[] args){
           Mahasiswa cetak = new Mahasiswa();
           cetak.Nama = "Ifazlur Rohman" ;
           cetak.NIM = "09523444";
           cetak.Fakultas = "Teknologi Industri";
           cetak.Jurusan = "Teknik Informatika" ;
           
           cetak.cetak();
    }


}

