/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author Praktikan
 */
public class CPU{
    private int nomorProduksi;
private Prosesor p; 
private Ram r;
public CPU(int nomorProduksi) {
this.nomorProduksi = nomorProduksi;
if (nomorProduksi ==1){
p = new Prosesor("amd");
r = new Ram ("ddr2");
}
}
public void nampilCpu(){
System.out.println("jenis prosesor :"+p.jenisProsesor);
System.out.println("jenis ram :"+r.jenisRam);
System.out.println("jenis kode produksi :"+nomorProduksi);
} 
public static void main(String[] args) {
CPU cpu1 = new CPU(1);
cpu1.nampilCpu();

}
}