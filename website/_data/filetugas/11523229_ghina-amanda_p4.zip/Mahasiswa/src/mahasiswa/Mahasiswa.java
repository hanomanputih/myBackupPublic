/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;
import java.util.Scanner;

/**
 *
 * @author PRAKTIKAN
 */
public class Mahasiswa {
String nama, fakultas, jurusan, nim, angkatan;
int jumlah1;
void isi() {
    Scanner sc=new Scanner(System.in);
    System.out.println("Masukkan nama= ");
    nama=sc.nextLine();
    System.out.println("Masukkan nim= ");
    nim=sc.next();
    System.out.println("Masukkan fakultas= ");
    fakultas=sc.next();
    System.out.println("Masukkan jurusan= ");
    jurusan=sc.next();
    System.out.println("Masukkan angkatan= ");
    angkatan=sc.next();
 
}
void cetak() {
    System.out.println("Nama anda adalah "+nama);
    System.out.println("NIM anda adalah "+nim);
    System.out.println("Anda dari fakultas "+fakultas);
    System.out.println("Anda dari jurusan "+jurusan);
    System.out.println("Angkatan anda "+angkatan);
 
        
}
void hitung() {
    jumlah1=nama.length();
    System.out.println("Jumlah karakter nama anda adalah "+jumlah1);
    
}

    public static void main(String[] args) {
       Mahasiswa mhs=new Mahasiswa();
       mhs.isi();
       mhs.cetak();
       mhs.hitung();
    }
}
