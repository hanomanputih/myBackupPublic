/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package posttest;

/**
 *
 * @author Praktikan
 */
public class Main {

    
    public static void main(String[] args) {
        karyawan k=new karyawan() ;
        k.setNip ("11523186");
        k.setNama ("TRISIA UTAMI");
        k.setGaji (100000*12);

        System.out.println("nip : "+k.getNip());
        System.out.println("nama : "+k.getNama());
        System.out.println("gaji : "+k.getGaji());

    }

}
