/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package posttest;

/**
 *
 * @author Praktikan
 */
public class karyawan {
 private String nama;
 private String nip;
 private int gaji;


 void setNama (String n){
     nama=n;

    }
 String getNama(){
    return nama;
    }
 void setNip (String np){
      nip = np;
    if (np.length() == 10){
        nip = np;
    }else{
        System.out.println ("");

 }}
 String getNip(){
     return nip;
 }

 void setGaji (int gj){
     gaji=gj;
 }
 int getGaji(){
     return gaji;
 }
}

