/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttestyandi6;

/**
 *
 * @author Praktikan
 */
public class KaryawanKontrak extends Karyawan implements Manusia{
    
    

    

    @Override
    public void gaji() {
        super.view();
        gaji=tunjangan+gajipokok;
        System.out.println("Gaji Karyawan Kontrak   = Rp."+gaji);
        System.out.println("=======================================\n");
    }

    @Override
    public void bernapas() {
        System.out.println("ngos2an/hooh2an......");
    }
    
}
