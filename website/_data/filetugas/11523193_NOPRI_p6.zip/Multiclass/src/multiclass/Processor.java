/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package multiclass;

/**
 *
 * @author PRAKTIKAN
 */
public class Processor {
    String merk;
    String kecepatan;
    
      public Processor(String nama) {
        this.merk = nama;
        this.kecepatan = nama;
        
    }
    
    
}
