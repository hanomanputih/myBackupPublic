/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package multiclass;

/**
 *
 * @author PRAKTIKAN
 */
public class Komputer {
    
    String jenis;
    String spesifikasi;
    Ram R;
    Processor P;
    
    public Komputer(String J,String SPS,String r,String p) {
        this.jenis = J ;    
        this.spesifikasi = SPS;
        R = new Ram(r);
        P = new Processor(p);
    }
    
    public void Display(){
        System.out.println("jenis komputer  : "+jenis);
        System.out.println("isi komputer : "+spesifikasi);
        System.out.println("isi ram : "+R.jenis);
        System.out.println("isi Processor : "+R.kapasitas);
        
       
       
    }
    
    public static void main (String [] args) {
        Komputer k = new Komputer ("ggd","fgsdfj","dfd","ggsds");
        k.R.jenis = "sdr";
        k.R.kapasitas = " 1 GB";
        k.P.merk = " athlon";
        k.P.kecepatan = " 512 GB";
        k.Display();
        
    }
    
}
