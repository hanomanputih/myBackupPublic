/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postestriefka;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.HashMap;
import java.util.List;

/**
 *
 * @author Praktikan
 */
public class PostestRiefka {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
         List alamat = new ArrayList();
        
        alamat.add("Magelang");
        alamat.add("Bengkulu");
        alamat.add("Palangkaraya");
        
        System.out.println(alamat);
        
        for(Object o : alamat){
                System.out.println(o);
        
        }
        
        System.out.println("===========================");
        
        Iterator it = alamat.iterator();
        while(it.hasNext ()){
            System.out.println(it.next());
        // TODO code application logic here
    }
    }
}
