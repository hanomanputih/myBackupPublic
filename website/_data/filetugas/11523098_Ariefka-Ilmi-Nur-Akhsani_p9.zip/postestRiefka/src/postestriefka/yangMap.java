/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postestriefka;
import java.util.Map;
import java.util.HashMap;
/**
 *
 * @author Praktikan
 */
public class yangMap {
     public static void main (String[] args){
    Map<String,String> nm = new HashMap<String, String>();
    
    nm.put("Riefka", "Magelang");
    nm.put("Yati", "Bengkulu");
    nm.put("Surya", "Palangkaraya");
    
    System.out.println (nm);
    System.out.println (nm.get("Yati"));
    
    for (Map.Entry<String, String> e : nm.entrySet ()){
            System.out.println(e.getKey()+" , "+e.getValue());
    }
    }   
}
