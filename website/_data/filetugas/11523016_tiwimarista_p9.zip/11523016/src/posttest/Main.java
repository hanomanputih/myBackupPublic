/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package posttest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Praktikan
 */
public class Main {
    public static void main(String[] args) {
//        String nama;
//        int nim;
        
        List ls = new ArrayList();

//     System.out.println("nama : ");
//     System.out.println("nim : ");

        ls.add("nama");
        ls.add("nim");
        ls.add("tiwi");
        System.out.println(ls);
        System.out.println(ls.get(2));
        System.out.println(ls.size());
        


      Map<Integer,String> tiwi = new HashMap<Integer, String>();

                tiwi.put(11523016, "tiwi marista");
                tiwi.put(11523261, "novi prisma");
                tiwi.put(11523116, "revangga");

                for(Map.Entry<Integer,String> tw : tiwi.entrySet()){
                    System.out.println(tw.getKey()+"--"+tw.getValue());
                }

         }
}


        // TODO code application logic here
   


