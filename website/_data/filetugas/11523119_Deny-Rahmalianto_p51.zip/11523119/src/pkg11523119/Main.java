/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg11523119;
import java.util.Scanner;

/**
 *
 * @author Praktikan
 */

public class Main {
    public static void main(String[] args){
        Scanner s = new Scanner(System.in);
        karyawan m = new karyawan();
        
      //  m.setNip("11523119");
      //  m.setNama("Deny");
       // m.setGaji(10000000);
        System.out.print("Masukkan nip anda : ");
        m.setNip(s.next());
        System.out.print("Masukkan nama anda : ");
        m.setNama(s.next());
        System.out.print("Masukkan gaji anda : ");
        m.setGaji(s.nextInt());
        System.out.println("NIp anda : " +m.getNip());
        System.out.println("Nama anda : " +m.getNama());
        System.out.println("Gaji anda sebulan : Rp. " +m.getGaji());
        System.out.println("Gaji anda Selama Setahun : Rp. " +m.getGaji()*12);
    }
}
