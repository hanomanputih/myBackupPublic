/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg11523119;

/**
 *
 * @author Praktikan
 */
public class karyawan {
    private String nip, nama;
    private int gaji;
    
    public String getNip(){
        return nip;
    }
    public void setNip(String Nip){
        nip=Nip;
    }
    
    public String getNama(){
        return nama;
    }
    public void setNama(String Nama){
        nama=Nama;
    }
    
    public int getGaji(){
        return gaji;
    }
    public void setGaji(int Gaji){
        gaji=Gaji;
    }
}
