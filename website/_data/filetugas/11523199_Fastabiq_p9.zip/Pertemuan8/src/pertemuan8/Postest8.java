/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan8;
import java.util.Map;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.HashMap;
/**
 *
 * @author Praktikan
 */
public class Postest8 {
    public static void main(String[] args) {
        
  Map<String,String> nama = new HashMap<String,String>();
  
        
        nama.put("jakal 20","Joko");
        nama.put("jakal 21","Koko");
        nama.put("jakal 22","Toto");
        
       
 
     System.out.println(nama.get ("jakal 20"));
        for(Map.Entry<String,String> e : nama.entrySet()){
           System.out.println(e.getKey()+" , "+e.getValue());
        }
        System.out.println("==================");
        
        List namar = new ArrayList();
        namar.add("Alvin");
        namar.add("Imam");
        namar.add("Ivan");
        System.out.println(namar.get (2));
    }
       
}
    
