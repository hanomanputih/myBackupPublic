/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan8;
import java.util.Map;
import java.util.HashMap;
/**
 *
 * @author Praktikan
 */
public class BelajarMap {
    
    public static void main(String[] args) {
        Map<Integer,String> mhs = new HashMap<Integer,String>();
        
        mhs.put(11523111,"Haha");
        mhs.put(11523112,"Haho");
        mhs.put(11523113,"Hahe");
        
      System.out.println(mhs);
        
        System.out.println(mhs.get (11523112));
        System.out.println("XXXXXXXXXXXXXXXXXXx");
        for(Map.Entry<Integer,String> e : mhs.entrySet()){
            System.out.println(e.getKey()+" , "+e.getValue());
        }
    }
    
}
