/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan8;

/**
 *
 * @author Praktikan
 */
class nama {
    
}
