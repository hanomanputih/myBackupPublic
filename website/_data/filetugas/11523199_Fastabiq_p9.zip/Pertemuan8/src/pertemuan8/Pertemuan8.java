/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan8;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

public class Pertemuan8 {

    public static void main(String[] args) {
        
        List nama = new ArrayList();
        
        nama.add("Alvin");
        nama.add("Imam");
        nama.add("Ivan");
        
    //    System.out.println(nama);
        
       for(Object o : nama){
           System.out.println(o);
        }
        System.out.println("==========");
        
        Iterator it = nama.iterator();
        while(it.hasNext()){
            System.out.println(it.next());
        }
        
        System.out.println("=============");
    }
}



