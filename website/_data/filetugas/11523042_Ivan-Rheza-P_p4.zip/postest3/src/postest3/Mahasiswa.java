/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest3;
import java.util.Scanner;
/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
    String nama;
    String nim;

    void cetak() {
        Scanner baca = new Scanner (System.in);
        System.out.print("isikan nama = ");
        nama = baca.next();
        System.out.print("isikan nim = ");
        nim = baca.next();
        System.out.println("nama anda adalah "+nama);
        System.out.println("nim anda adalah "+nim);
        
    }
    public static void main(String[] args) {
        Mahasiswa mhs = new Mahasiswa();
        mhs.cetak();
                

                
    }
}
