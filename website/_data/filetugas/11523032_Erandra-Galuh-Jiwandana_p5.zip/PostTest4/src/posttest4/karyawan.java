/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package posttest4;



/**
 *
 * @author Praktikan
 */
public class karyawan {
private String nip,nama;
private int gaji;

void setNIP (String ni){
    this.nip=ni;
    }
void setNAMA (String nam){
    this.nama=nam;
    }
void setGAJI (int gaj){
    this.gaji=gaj;
}


String getNIP() {
    return nip;
}
String getNAMA (){
    return nama;
}
int getGAJI (){
    return gaji;
}

}


