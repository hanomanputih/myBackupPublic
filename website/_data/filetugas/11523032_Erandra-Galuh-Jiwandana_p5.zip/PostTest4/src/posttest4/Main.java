/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package posttest4;

import java.util.Scanner;



/**
 *
 * @author Praktikan
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

    karyawan ka = new karyawan ();
    ka.setNIP("11523032");
    ka.setNAMA("Erandra Galuh Jiwandana");
    ka.setGAJI(10000000);
        System.out.println("namaku adalah "+ka.getNAMA());
        System.out.println("nipku adalah "+ka.getNIP());
        System.out.println("gajiku sebanyak "+ka.getGAJI());

    }

}
