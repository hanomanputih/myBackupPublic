/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest3;
import java.util.Scanner;
/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
Scanner cetak = new Scanner(System.in);   
String nama, nim, jurusan, fakultas;

void cetak (){
        System.out.println("masukkan nama mahasiswa= ");
        nama=cetak.next();
        
        System.out.println("masukkan nim mahasiswa= ");
        nim=cetak.next();

        System.out.println("masukkan jurusan mahsiswa= ");
        jurusan=cetak.next();
    
        System.out.println("masukkan fakultas mahasiswa= ");
        fakultas=cetak.next();    
}
public static void main (String [] args) {
  
        Mahasiswa m = new Mahasiswa();
        m.cetak();
        System.out.println(m.nama);
        System.out.println(m.nim);
        System.out.println(m.jurusan);
        System.out.println(m.fakultas);
}
}