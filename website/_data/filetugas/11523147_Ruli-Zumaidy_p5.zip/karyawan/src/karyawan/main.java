/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class main {
    public static void main(String[] args) {
        Karyawan key = new Karyawan ();
       key.setNIP("11523147");
       key.setNama("ruli");
       key.setGaji(50000000);
        System.out.println(key.getnip());
        System.out.println(key.getNama());
        System.out.println(key.getGaji ());  
    }
    
}
