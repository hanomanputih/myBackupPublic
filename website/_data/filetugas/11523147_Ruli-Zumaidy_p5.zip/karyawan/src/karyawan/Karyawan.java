/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class Karyawan {

  private String nip;
  private String nama;
  private int gaji;
  
 public void setNIP (String nomor)
  {
      nip=nomor;
      
  }
public String getnip ()
{
            return nip;}
     
public void setNama (String nama)
     {
        this.nama=nama;
     }
    public String getNama()
    {
 return nama;}
    
    
public void setGaji (int gaji)
{
this.gaji=gaji;}

public int getGaji()
{
return gaji;


}
}




