/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package terserah;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Main {

    /**
     * @param args the command line arguments
     */
       public static void main(String[] args) {
     List list = new ArrayList();
     list.add("Nama");
     list.add("NIM");

  for(Iterator<String> iterator = list.iterator();
iterator.hasNext();){//untuk melihat isi List
        String isi = iterator.next();
System.out.println(isi);
  }
    Scanner sc = new Scanner(System.in);

     Map map = new HashMap();
        System.out.print("Nama anda :");
        map.put(list.get(0), sc.next());
        System.out.print("NIM anda :");
        map.put(list.get(1), sc.next());

        System.out.println("Nama anda adalah " + map.get("Nama"));
        System.out.println("NIM anda adalah " + map.get("NIM"));
    }
}


