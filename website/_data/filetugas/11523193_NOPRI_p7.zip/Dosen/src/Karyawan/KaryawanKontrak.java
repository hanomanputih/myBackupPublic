/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Karyawan;

/**
 *
 * @author Praktikan
 */
public class KaryawanKontrak extends Karyawan {
    
    
@Override

public void gaji() {
    gaji = gajipokok + bonus;
    System.out.println("gaji karyawan kontrak :" +gaji);

}
}