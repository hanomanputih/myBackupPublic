/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Karyawan;

/**
 *
 * @author Praktikan
 */
public class KaryawanTetap extends Karyawan {
    
    public int tunjangan ;
    
    
    @Override
    public void gaji() {
        tunjangan =  (20*gajipokok)/100;
        gaji = tunjangan + gajipokok + bonus;
        System.out.println("gajikaryawan :" +gaji);
    
    
    
}
}