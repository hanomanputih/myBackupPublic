/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Karyawan;

/**
 *
 * @author Praktikan
 */
public abstract class Karyawan {
    
    public int gajipokok  = 12000;
    public int gaji   ;
    public int bonus  = 10000;
    
    public abstract void gaji();
}
