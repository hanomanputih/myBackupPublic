/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package KelasH;

/**
 *
 * @author Praktikan
 */
public class Dekan extends Dosen {
    private String Fakultas ;
    
    
    @Override
    
    public void view(){
        //super.view();
        System.out.println("Fakultas  :"+Fakultas);
    }
      @Override
    public void Bertugas (){
        System.out.println("jbjbjb");
    }

    public String getFakultas() {
        return Fakultas;
    }

    public void setFakultas(String Fakultas) {
        this.Fakultas = Fakultas;
    }
    
    
}
