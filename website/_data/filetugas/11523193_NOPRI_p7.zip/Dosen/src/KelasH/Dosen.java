/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package KelasH;

/**
 *
 * @author Praktikan
 */
public abstract class Dosen {
   
  protected String nama = "Budi" ;
   protected String jurusan = "INFORMATIKA" ;
  
    
    public abstract void view() ;
    
    public void Bertugas(){
        System.out.println("jghjfh");
      //  System.out.println("nama dosen : "+nama);
       // System.out.println("nama jurusan : "+jurusan);
        
      
        
    }
}
