/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package KelasH;

/**
 *
 * @author Praktikan
 */
public class main {
    
    
    public static void main (String[] args) {
 
       // Dosen ds = new Dosen ();
        Dekan dk = new Dekan ();
        Kalab kl = new Kalab ();
       // ds.view();
        System.out.println("");
        dk.setFakultas("FTI");
        dk.view();
        System.out.println("");
        kl.setLaboratorium("KSC");
        kl.view();
        
        
        
}
}