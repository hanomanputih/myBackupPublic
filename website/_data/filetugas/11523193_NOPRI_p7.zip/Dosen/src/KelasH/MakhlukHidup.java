/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package KelasH;

/**
 *
 * @author Praktikan
 */
public class MakhlukHidup {
    
}
