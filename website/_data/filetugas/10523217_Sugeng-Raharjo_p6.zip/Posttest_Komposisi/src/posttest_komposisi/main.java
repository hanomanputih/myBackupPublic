/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest_komposisi;

/**
 *
 * @author Praktikan
 */
public class main {
    public static void main(String[] args) {
      Prosesor pt = new Prosesor("Intel I7 3770K", 4);
      Ram r = new Ram("32 GB");
      MerkRam mr = new MerkRam("Corsair Dominator Platinum");
      Drive d = new Drive("SSD", 120);
      Komputer kom = new Komputer("Republic Of Gamers (R.O.G)", pt, r, d, mr);
      
      kom.tampil(r);
}}
