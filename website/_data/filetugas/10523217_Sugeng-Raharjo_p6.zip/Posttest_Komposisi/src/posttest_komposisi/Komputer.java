/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest_komposisi;

/**
 *
 * @author Praktikan
 */
public class Komputer {
    String namaKomputer;
    Prosesor ps;
    Ram rm;
    MerkRam mr; 
    Drive dr;
    
    
    public Komputer (String namaKomputer, Prosesor ps, Ram rm, Drive dr, MerkRam mr){
        this.namaKomputer = namaKomputer;
        this.ps = ps;
        this.rm = rm;
        this.mr = mr;
        this.dr = dr;
    }
    
    public void tampil(Ram rm){
        System.out.println("Nama Komputer : "+namaKomputer);
        System.out.println("Merek Prosesor : "+ps.Merek);
        System.out.println("Jumlah Core : "+ps.core);
        System.out.println("RAM Size : "+rm.GB);
        System.out.println("Merk RAM : "+mr.Merek1);
        System.out.println("Type Drive : "+dr.SSD);
        System.out.println("Drive Size : "+dr.size);
    }
}
