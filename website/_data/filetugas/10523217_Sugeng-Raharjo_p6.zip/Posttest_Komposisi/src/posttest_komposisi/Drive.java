/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest_komposisi;

/**
 *
 * @author Praktikan
 */
public class Drive {
    String SSD;
    int size;
    
    public Drive(String SSD, int size){
        this.SSD = SSD;
        this.size = size;
    }
}
