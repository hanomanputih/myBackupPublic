/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
  String nama;
 String nim;
 
     void cetak ()
     {
         Scanner Mahasiswa = new Scanner(System.in);
         System.out.println ("masukkan nama anda: ");
nama=Mahasiswa.next();
         System.out.println ("masukkan nim anda: ");
         nim=Mahasiswa.next();
         System.out.println("nama anda adalah"+nama);
         System.out.println("nim anda adalah"+ nim);
         
         
         
     }
    public static void main(String[] args) {
       Mahasiswa m = new Mahasiswa();
       m.cetak();
       
              
       
    }
}
