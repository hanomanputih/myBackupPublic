/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan_3;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
class Hewan_1 {
        int jumlahKaki;
    String nama;
    
    public static void main(String[] args) {
        Scanner baca = new Scanner (System.in);
        Hewan_1 animal = new Hewan_1();
        System.out.print("sebutkan nama hewan = ");
        animal.nama = baca.next();
        System.out.print ("berapa jumlah kaki nya = ");
        animal.jumlahKaki = baca.nextInt();
        System.out.println ("jadi nama hewan terdapat "+animal.nama.length()+" huruf");
    }
    

}
