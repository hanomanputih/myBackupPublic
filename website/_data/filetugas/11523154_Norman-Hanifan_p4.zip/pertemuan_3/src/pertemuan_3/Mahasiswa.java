/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan_3;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
    String nama,nim,fakultas,jurusan;
    float jumlah1,jumlah2;
    
    void cetak () {
        Scanner baca = new Scanner (System.in);
        System.out.print ("Nama anda = ");
        nama = baca.next();
        System.out.print ("NIM anda = ");
        nim = baca.next ();
        System.out.print ("Fakultas anda = ");
        fakultas = baca.next ();
        System.out.print("Jurusan anda = ");
        jurusan = baca.next ();   
        System.out.println("Nama Mahasiswa : "+nama);
        System.out.println("NIM : "+nim);
        System.out.println("Fakultas : "+fakultas);
        System.out.println ("Jurusan : "+jurusan);
    }  
    public static void main(String[] args) {
        Mahasiswa uii = new Mahasiswa();
        uii.cetak();
    }
}
