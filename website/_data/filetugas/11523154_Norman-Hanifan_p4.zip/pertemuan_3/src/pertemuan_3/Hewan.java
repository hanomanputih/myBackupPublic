/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan_3;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Hewan {


        public Hewan() {
        }
    }
    int jumlahKaki;
    String nama;
    
    public static void main(String[] args) {
        Scanner baca = new Scanner (System.in);
        Hewan animal = new Hewan();
        System.out.print("sebutkan nama hewan")
    }
    
}
