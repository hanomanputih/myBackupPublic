/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan_3;

/**
 *
 * @author Praktikan
 */
public class Ksc {
    String belajar = "akyu ingin bisa";
    public static void main (String[]args) {
        Ksc ksc = new Ksc();
        System.out.println("Kata pertama ="+ksc.belajar.startsWith("akyu"));
        System.out.println ("Kata kedua ="+ksc.belajar.endsWith("bisa"));
        System.out.println("Kata Panjang Karakter ="+ksc.belajar.length());
        
    }
    
}
