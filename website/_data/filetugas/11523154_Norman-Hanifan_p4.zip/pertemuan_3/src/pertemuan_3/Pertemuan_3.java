/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan_3;

/**
 *
 * @author Praktikan
 */
public class Pertemuan_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
}
