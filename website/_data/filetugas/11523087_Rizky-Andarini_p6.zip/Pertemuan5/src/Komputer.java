/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Praktikan
 */
public class Komputer {
    RAM merk;
    RAM kapasitas;
    Prosesor jenis;
    
    public Komputer (RAM merk, Prosesor jenis) {
    this.merk = merk;
    this.kapasitas = kapasitas;
    this.jenis = jenis;
   
}
    public void tampil()
    {
        System.out.println(merk.getMerk());
        System.out.println(jenis.getJenis());
    }
 
}
   
   
   
   
   

