/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Praktikan
 */
public class Jadi {
    public static void main(String[] args) {
        RAM r = new RAM();
        r.setMerk("abcde");
        Prosesor p = new Prosesor();
        p.setJenis("i5");
       
        Komputer k = new Komputer(r,p);
        k.tampil();
    }
}
