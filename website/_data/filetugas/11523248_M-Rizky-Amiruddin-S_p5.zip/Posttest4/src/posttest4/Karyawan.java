/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest4;

/**
 *
 * @author M Rizky AMiruddin S(11523248)
 */
public class Karyawan {
    
    private String nip;
    private String nama;
    private int gaji;
    
    void setNIP(String nip){
        this.nip = nip;
    }
    
    void setNAMA(String nama){
        this.nama = nama;
    }
    
    void setGAJI(int gaji){
        this.gaji = gaji;
    }
    
    String getNIP(){
            return nip;
    }
    
    String getNAMA(){
            return nama;
    }
    
    int getGAJI(){
        return gaji;
    }
}
