/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest4;

/**
 *
 * @author M Rizky AMiruddin(11523248)
 */
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Karyawan k = new Karyawan();
        k.setNIP("11523248");
        k.setNAMA("Bambung");
        k.setGAJI(5000000);
        
        System.out.println("nama : "+k.getNAMA());
        System.out.println("nip  : "+k.getNIP());
        System.out.println("gaji : "+k.getGAJI()*12);
    }
}
