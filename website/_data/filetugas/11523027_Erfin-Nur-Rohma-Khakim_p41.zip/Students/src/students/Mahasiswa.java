/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package students;
import java.util.Scanner;
/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
   String nama, nim, fakultas, jurusan, angkatan;


void isi() {
    Scanner sc = new Scanner(System.in);
    System.out.print("Nama : ");
    nama=sc.nextLine();
    System.out.print("NIM : ");
    nim=sc.nextLine();
    System.out.print("Fakultas : ");
    fakultas=sc.nextLine();
    System.out.print("Jurusan : ");
    jurusan=sc.nextLine();
    System.out.print("Angkatan : ");
    angkatan=sc.nextLine();
}

void cetak() {
    System.out.println("Nama anda "+nama);
    System.out.println("NIM anda "+nim);
    System.out.println("Fakultas anda "+fakultas);
    System.out.println("Jurusan anda "+jurusan);
    System.out.println("Angkatan anda "+angkatan);
}

void hitung() {
    int jumlah1,jumlah2,jumlah3,jumlah4,jumlah5,jumlahTotal;
    jumlah1=nama.length();
    jumlah2=nim.length();
    jumlah3=fakultas.length();
    jumlah4=jurusan.length();
    jumlah5=angkatan.length();
    jumlahTotal=jumlah1+jumlah2+jumlah3+jumlah4+jumlah5;
    System.out.println("Jumlah seluruh karakter yang diinputkan : "+jumlahTotal);
}

public static void main(String[] args) {
   Mahasiswa mhs =  new Mahasiswa();

   mhs.isi();
   mhs.cetak();
   mhs.hitung();
}
}