/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;
import java.util.Scanner;
/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
String nama,nim;
int hasil,a,b;
public void cetak (){
    System.out.println("jumlah hurufnya : " + hasil);
    
  
}
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
     Mahasiswa c = new Mahasiswa ();
     Scanner baca = new Scanner(System.in);
     System.out.print("masukkan nama anda : ");
     c.nama = baca.next();
     c.a = c.nama.length();
     System.out.print("masukkan nim anda : ");
     c.nim = baca.next();
     c.b = c.nim.length ();
     c.hasil = c.a + c.b ;
     c.cetak();
     
     
     
             // TODO code application logic here
    }
}
