/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest8;
import java.util.ArrayList;
import java.util.HashMap;
//import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Praktikan
 */
public class Posttest8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         List<String> list1 = new ArrayList();
        
        list1.add("devli");
        list1.add("11523103");
        for (int i = 0; i < list1.size(); i++) {
            System.out.println("index" + i + " : " + list1.get(i));
    }
        System.out.println("==============");
        Map<Integer, String> map = new HashMap<Integer, String>();
        
        map.put(11523103, "devli");
        for (Integer i : map.keySet()){
            System.out.println("NIM anda:"+ i + "dan nama anda "+map.get(i));
        }
    }
}
    
