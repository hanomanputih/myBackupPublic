/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest4;

/**
 *
 * @author Praktikan
 */
   class karyawan {
    private String nip;
    private String nama;
    private int gaji;
    
    
    public void setNip (String nipKrywn) {
       nip = nipKrywn ;
        
    }
    public String getNip () {
        return nip;
    }
    public void setNama (String namaKrywn) {
        nama = namaKrywn;
    } 
    public String getNama () {
        return nama;
    } 
    public void setGaji (int gajiKrywn) {
        gaji = 12 * gajiKrywn ;
       
    }
    public int getGaji () {
        return gaji;
    }
}
