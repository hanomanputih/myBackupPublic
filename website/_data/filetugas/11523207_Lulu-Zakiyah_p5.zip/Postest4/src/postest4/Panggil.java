/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest4;

/**
 *
 * @author Praktikan
 */
public class Panggil {
    public static void main(String[] args) {
        karyawan kywn1 = new karyawan () ;
        
        kywn1.setNip("123");
        kywn1.setNama("Lulu Zakiyah");
        kywn1.setGaji(10000000);
        
        System.out.println("nip :" +kywn1.getNip());
        System.out.println("nama :" +kywn1.getNama());
        System.out.println("gaji :" +kywn1.getGaji());
        
    }
    
}
