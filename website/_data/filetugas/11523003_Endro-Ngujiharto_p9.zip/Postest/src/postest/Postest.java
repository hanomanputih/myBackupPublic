/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 *
 * @author praktikan
 */
public class Postest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Map<Integer,String> mahasiswa = new HashMap<Integer,String>();
        
        mahasiswa.put(11523003, "Endro Ngujiharto");
        mahasiswa.put(11523005, "Djaka Umbara");
        mahasiswa.put(11523040,"Krisna Wirawan");
        
        
        Iterator<Map.Entry<Integer,String>> data = mahasiswa.entrySet().iterator();
        while(data.hasNext()){
            Map.Entry<Integer,String> e = data.next();
            System.out.println(e.getKey()+" "+e.getValue());
        }  
    }
}
