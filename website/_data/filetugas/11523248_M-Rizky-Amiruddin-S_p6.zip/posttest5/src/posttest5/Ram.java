/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest5;

/**
 *
 * @author Praktikan
 */
public class Ram {
    public String ukuranMemory;
    public Ram(String ukr){
        ukuranMemory = ukr;
    }
    public void tampil(){ 
    System.out.println (ukuranMemory);
   }
}



