/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest5;

/**
 *
 * @author Praktikan
 */
public class Komputer {
Ram r;
Prosesor p;


    public Komputer() {
        r=new Ram("4Gb");
        p=new Prosesor("Triple-core");
    }

 
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Komputer k = new Komputer();
        
        System.out.println("Komputer anda ukuran memory "+k.r.ukuranMemory+""+" dengan prosesor "+k.p.tipeProsesor);
    }
}
