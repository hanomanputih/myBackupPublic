/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest5;

/**
 *
 * @author Praktikan
 */
public class Prosesor {
    String tipeProsesor;
        public Prosesor(String type){
        tipeProsesor = type;
    }
        public void tampil(){ 
    System.out.println (tipeProsesor);
   }
}

