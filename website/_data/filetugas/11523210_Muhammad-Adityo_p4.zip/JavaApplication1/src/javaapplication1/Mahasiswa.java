/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
String nama, nim, fakultas, jurusan, angkatan;

void cetak(){
Scanner sc = new Scanner(System.in);

    System.out.print("nama : ");
    nama = sc.next();
    System.out.print("nim : ");
    nim = sc.next();
    System.out.print("fakultas : ");
    fakultas = sc.next();
    System.out.print("jurusan : ");
    jurusan = sc.next();
    System.out.print("angkatan : ");
    angkatan = sc.next();
}

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Mahasiswa mhs1 = new Mahasiswa();
        
        mhs1.cetak();
        
        System.out.println("nama kamu: " +mhs1.nama);
        System.out.println("panjang karakter: " +mhs1.nama.length());
        System.out.println("nim kamu: " +mhs1.nim);
        System.out.println("panjang karakter: " +mhs1.nim.length());
        System.out.println("fakultas kamu: " +mhs1.fakultas); 
        System.out.println("panjang karakter: " +mhs1.fakultas.length());
        System.out.println("jurusan kamu: " +mhs1.jurusan);
        System.out.println("panjang karakter: " +mhs1.jurusan.length());
        System.out.println("angkatan kamu: " +mhs1.angkatan);
        System.out.println("panjang karakter: " +mhs1.angkatan.length());
    }
}
