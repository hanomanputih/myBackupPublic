/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package PostTest;
import java.util.Collection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class Main {
    
    public static void main(String[] args) {
        
        Map mp = new HashMap ();
        
        mp.put("Nama", "Wildan");
        mp.put("NIM", new Integer (11523159));
        
        System.out.println(mp);
        System.out.println("Ukuran map :"+mp.size());
        
        boolean containKey = mp.containsKey("NIM");
        System.out.println("Has Key (NIM) :"+containKey );
        
        
       
        
    }
    
}
