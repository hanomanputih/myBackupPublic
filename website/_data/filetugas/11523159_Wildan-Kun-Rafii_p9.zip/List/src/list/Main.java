/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package list;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 *
 * @author Praktikan
 */
public class Main {
    public static void main(String[] args) {
        
        
        List<Integer> buku = new ArrayList<Integer>();
        
        buku.add(1);
        buku.add(2);
        buku.add(3);
        
        for (Integer i : buku){
            System.out.println(i);
        }
        
        System.out.println("====================================");
        
        Iterator<Integer> it = buku.iterator();
        
    }
}
