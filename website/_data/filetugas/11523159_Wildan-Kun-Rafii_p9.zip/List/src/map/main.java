/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package map;

import java.util.HashMap;
import java.util.*;

/**
 *
 * @author Praktikan
 */
public class main {
    public static void main(String[] args) {
        
        Map<Integer,String> nama = new HashMap <Integer,String >();
        
        nama.put(1, "Joko");
        
    }
}
