/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

/**
 *
 * @author PRAKTIKAN
 */
import java.util.ArrayList;
import java.util.List;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.HashMap;
import java.util.Scanner;

public class Postest {
    String nama;
    int nim;
    
                private static void loadData (List<String> list) {
        list.add("");
        list.add("");
    }
    
                
                    private static void tampilkanList (List<String> list) {
        for (int i=0; i<list.size(); i++) {
            System.out.print(list.get(i)+ " ");
            
        }
        System.out.println("");
    }
    
    public static void main(String[] args) {
        Scanner cin = new Scanner(System.in);
        
        System.out.print("input nama : ");
        String nama = cin.next();
        System.out.print("input NIM : ");
        int nim = cin.nextInt();
        
       List<String>list = new ArrayList<String>();
       loadData (list);
       tampilkanList(list);
//       for (int n=0; n<list.size(); n++){
        System.out.println("list di index ke  = "+list.get(1));
//       }
        
        HashMap map = new HashMap();
        map.put("nama", nama);
        map.put("NIM", nim);
        System.out.println(map);
        System.out.println("ukuran map " +map.size());
        boolean containKey = map.containsKey("NIM ");
        System.out.println("has key (NIM): " +containKey);
        Object removed = map.remove("NIM ");
        System.out.println("removed : " +removed);
        System.out.println(map);
        System.out.println("ukuran map baru : " + map.size());
    }
}
