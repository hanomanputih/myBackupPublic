/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package pretes;

/**
 *
 * @author praktikan
 */
public class prosesor {
    String namaProsesor;
    Kipas kipas;
    public prosesor(String namaProsesor,Kipas kipas) {
        this.namaProsesor=namaProsesor;
        this.kipas=kipas;
    }





}
