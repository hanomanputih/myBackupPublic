/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package pretes;

/**
 *
 * @author praktikan
 */
public class mainkomputer {

public static void main(String[] args) {


        ram rm = new ram();
        Kipas kipas = new Kipas("300/s");
        prosesor pro = new prosesor("venom",kipas);
        Komputer komputer = new Komputer("asus",rm,pro);
        System.out.println(""+komputer.ps.namaProsesor);
        System.out.println(""+komputer.rm.ukuranRam);
        System.out.println(""+komputer.ps.kipas.putaran);


    }

}
