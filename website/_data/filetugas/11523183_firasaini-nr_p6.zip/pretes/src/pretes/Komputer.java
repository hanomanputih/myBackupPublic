/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pretes;

/**
 *
 * @author praktikan
 */
public class Komputer {

    String namaKomputer;
    prosesor ps;
    ram rm;

     public Komputer(String namaKomputer,ram rm,prosesor ps){
        this.namaKomputer=namaKomputer;
        this.rm = rm;
        this.ps=ps;
    }


    
    
}
