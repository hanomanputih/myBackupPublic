/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package pretes;

/**
 *
 * @author praktikan
 */
public class ram {
    String ukuranRam="16 Gigabyte";

}
