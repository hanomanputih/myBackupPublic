/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Pc;

/**
 *
 * @author PRAKTIKAN
 */
public class Prosesor {
    String merekPros;
    
    public Prosesor (String P) {
        this.merekPros=P;
    }
}
