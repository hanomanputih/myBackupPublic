/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Pc;

/**
 *
 * @author PRAKTIKAN
 */
public class Komputer {
    
    String merekKom;
    private Prosesor p;
    private Ram r;
    
    public Komputer(String nama, String P, String R){
      this.merekKom = nama;
        if (merekKom.equals(nama));
          p=new Prosesor(P);
          r=new Ram(R);
    }

    public void tampil(){
        System.out.println("merk laptop = "+ merekKom);
        System.out.println("merk prosesor = "+p.merekPros);
        System.out.println("merk ram = "+r.merekRam);
    }
    
    public static void main(String[] args) {
        Komputer kmp = new Komputer("Vaio","Intel Core","WD");
        kmp.tampil();
        // TODO code application logic here
    }
    
}
