/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Pc;

/**
 *
 * @author PRAKTIKAN
 */
public class Ram {
    String merekRam;
    
    public Ram (String R){
        this.merekRam=R;
    }
}
