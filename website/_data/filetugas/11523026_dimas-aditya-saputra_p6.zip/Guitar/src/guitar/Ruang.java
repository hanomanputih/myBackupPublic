/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package guitar;

/**
 *
 * @author PRAKTIKAN
 */
public class Ruang {
    String ukuran;
    String isi;
    Kursi k;
    
    public Ruang (String U, String I, String K) {
        this.ukuran=U;
        this.isi=I;
        k=new Kursi(K);
    }
    public void Display() {
        System.out.println("ukuran ruangan: "+ukuran);
        System.out.println("isi ruangan 1: "+isi);
        System.out.println("isi ruangan 2: "+k.jenisKursi);
       
    }
    public static void main (String[]args){
    Ruang r=new Ruang("3 x 4","Lemari","kursi lonjong");
    r.Display();
    }
}
