/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package guitar;

/**
 *
 * @author PRAKTIKAN
 */
public class Kursi {
    String jenisKursi;
    
    public Kursi (String nama){
        this.jenisKursi=nama;
    }
    
}
