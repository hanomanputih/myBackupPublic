/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package posttest;

/**
 *
 * @author praktikan
 */
public class RAM {
    int ram = 512;
    public void setNama(int ram)
    {
        this.ram = ram;
    }

    public void tampil (){
        System.out.println("Kapasitas Ram :"+ ram);
    }
}
