/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package posttest;

/**
 *
 * @author praktikan
 */
public class Komputer {
    
    Prosessor pr;
    RAM r;
    public Komputer (String nama, int ram){
    if(nama.equals("3")){
        pr = new Prosessor();
        pr.setNama("intel");
        }
    if(ram == 1){
        r = new RAM ();
        r.setNama(512);
        }
    }
    public static void main(String[] args){
        Komputer k = new Komputer("3",1);
            k.pr.tampil();
            k.r.tampil();
    }
}
