/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package posttest;

/**
 *
 * @author praktikan
 */
public class Prosessor {

    String prosessor;
    public void setNama(String nama)
    {
        this.prosessor = nama;
    }
    public void tampil(){
        System.out.println("Nama Komputer :"+ prosessor);
    }

}
