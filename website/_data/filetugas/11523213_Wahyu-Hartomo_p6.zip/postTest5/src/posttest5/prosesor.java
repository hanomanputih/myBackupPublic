/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest5;

/**
 *
 * @author Praktikan
 */
public class prosesor {
    String nama;
  public prosesor(String nama){
      this.nama=nama;
  }
}
