/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author PRAKTIKAN
 */
public class Karyawan {

    private String nip;
    private String nama;
    private int gaji;

    /**
     * @param args the command line arguments
     */
    public void setNip(String nipKamu) {

        if (nipKamu.length() == 8) {
            nip = nipKamu;
        } else {
            System.out.println("Error");
        }
    }

    public String getNip() {
        return nip;
    }

    public void setNama(String namaKamu) {
        if (namaKamu.length() == 30) {
            nama = namaKamu;
        } else {
            System.out.println("Error");

        }
    }

    public String getNama() {
        return nama;
    }

    public void setGaji(int sgaji) {
        if (sgaji != 0) {
            int g = sgaji * 12;
            gaji = g;
        } else {
            System.out.println("Tidak boleh nol");
        }
    }

    public int getGaji() {
        return gaji;
    }
}
