/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author PRAKTIKAN
 */
public class pemanggilan1 {
    public static void main(String [] args) {
        Karyawan krw = new Karyawan();
       
        krw.setNama("Yat");
        krw.setNip("1152310");
        krw.setGaji(1000000);
        
        System.out.println("NIP :"+ krw.getNip());
        System.out.println("Nama :"+krw.getNama());
        System.out.println("gaji :" +krw.getGaji());
    }
    
}
