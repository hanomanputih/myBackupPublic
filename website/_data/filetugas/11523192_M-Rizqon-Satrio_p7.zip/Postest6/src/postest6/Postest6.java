/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest6;

/**
 *
 * @author Praktikan
 */
public class Postest6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       KaryawanTetap kt = new KaryawanTetap();
        System.out.println("Karyawan Tetap : ");
       kt.gaji();
       KaryawanKontrak kk = new KaryawanKontrak();
        System.out.println("Karyawan Kontrak : ");
       kk.gaji();
    }
}
