/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest6;

/**
 *
 * @author Praktikan
 */
public class KaryawanTetap extends Karyawan {

    @Override
    public void gaji() {
        int gaji = tunjangan + gajipokok + bonus;
    
        System.out.println("Gaji Pokok : "+gajipokok);
        System.out.println("Bonus : "+bonus);
        System.out.println("Tunjangan : "+tunjangan);
        System.out.println("Gaji Keseluruhan : "+gaji);
    }
    
}
