/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

import java.util.Scanner;

/**
 *
 * @author PRAKTIKAN
 */
public class Mahasiswa {
 static String nama,nim,fakultas,jurusan,angkatan;
 
 static void cetak() {
     System.out.println(nama);
     System.out.println(nim);
     System.out.println(fakultas);
     System.out.println(jurusan);
     System.out.println(angkatan);
 }
 /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner c = new Scanner(System.in);
        System.out.println("Masukkan Nama :");
        nama = c.next();
        System.out.println("Masukkan NIM :");
        nim = c.next();
        System.out.println("Masukkan Fakultas :");
        fakultas = c.next();
        System.out.println("Masukkan Jurusan :");
        jurusan = c.next();
        System.out.println("Masukkan Angkatan :");
        angkatan = c.next();
        cetak();
    }
}
