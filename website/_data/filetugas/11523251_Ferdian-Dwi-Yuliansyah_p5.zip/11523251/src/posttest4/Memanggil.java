/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest4;

/**
 *
 * @author Praktikan
 */
public class Memanggil {
    public static void main (String[] args){
        Karyawan kry = new Karyawan ();
        
        kry.setNip  ("11523251");
        kry.setNama ("Ferdian");
        kry.setGaji (1000000);
        
       
        
        System.out.println("nip          = "+kry.getNip());
        System.out.println("nama         = "+kry.getNama());
        System.out.println("gaji setahun = "+kry.getGaji());
    }
    
}
