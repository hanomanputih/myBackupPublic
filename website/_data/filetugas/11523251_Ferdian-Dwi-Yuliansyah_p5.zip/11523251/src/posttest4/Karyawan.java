/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest4;

/**
 *
 * @author Praktikan
 */
public class Karyawan {
    private String nip;
    private String nama;
    private int gaji;
    
    public void setNip(String nipKamu){
        if (nipKamu.length()==8){
            nip=nipKamu;
        }else{
            System.out.println("Error!!!");
        }
    }
    
    public String getNip(){
        return nip;
    }
    public void setNama(String namaKamu){
        nama = namaKamu;
    }
    
    public String getNama(){
        return nama;
    }
    public void setGaji(int gajiKamu){
        if (gajiKamu>=1000000){
            gaji=gajiKamu;
        }else{
            System.out.println("Error!!!");
        }
    }
    
    public int getGaji(){
        return gaji;
    }
}
