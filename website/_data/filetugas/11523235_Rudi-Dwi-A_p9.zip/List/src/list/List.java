/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package list;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;

/**
 *
 * @author Praktikan
 */
public class List {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList list = new ArrayList();
        HashMap map = new HashMap();
        //LinkedList list2 = new LinkedList();
        //LinkedList list3 = new LinkedList();

        list.add("11523235");
        list.add("11523237");
        list.add("11523240");
        list.add("Rudi Dwi A");
        list.add("Putra Bedul");
        list.add("Suhari kecepot");



        System.out.println("ukuran list : " + list.size());

        for (Iterator iterator = list.iterator(); iterator.hasNext();) {
            String ii = (String) iterator.next();
            System.out.println("isi : " + ii);
        }
        
        map.put("nama", "fadil");
        map.put("NIM", new Integer(11523235));
          System.out.println(map);

    }
}
