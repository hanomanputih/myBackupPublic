/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perusahaan;

/**
 *
 * @author Praktikan
 */
public abstract class Karyawan {
    
    int Gajipokok=30000000;
    
    
    
    
    
    
    
    
}
