/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perusahaan;

/**
 *
 * @author Praktikan
 */
public class KaryawanKontrak extends Karyawan{
    
    int bonus;
    int gaji;
    
    public KaryawanKontrak (int bonus){
    this.bonus = bonus;
  }
  
    public void gaji(){
        gaji = Gajipokok+bonus;
        System.out.println("gaji pokok adalah:" +gaji);
    }
    
    
    
}
