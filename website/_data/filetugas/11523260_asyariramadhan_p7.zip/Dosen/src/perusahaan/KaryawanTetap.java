/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perusahaan;

/**
 *
 * @author Praktikan
 */
public class KaryawanTetap extends Karyawan{
    
    int tunjangan;
    int bonus;
    int gaji;

    public KaryawanTetap(int tunjangan, int bonus){
    this.tunjangan=20*Gajipokok/100;;
    this.bonus= bonus;
    
    }
    
//    void setTunjangan (int tunjangan){
//        this.tunjangan = tunjangan;
//    }
//    
//    int getTunjangan (){
//        
//        return tunjangan;
//    }
//    
    
    
    public void gaji (){
        gaji = tunjangan+Gajipokok+bonus;
        System.out.println("gaji pokok adalah :" +gaji);
        
    }
    
    
}
