/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dosen;

/**
 *
 * @author Praktikan
 */
public abstract class Dosen {

    String nama= "irving";
    String Jurusan= "informatika";
    
//    Dosen(int no_p){
//    System.out.println("no p :"+no_p);
//    }
    public abstract void mengajar();
    protected void view(){
   
        
        System.out.println ("nama dosen :" +nama);
        System.out.println ("mengajar di jurusan" +Jurusan);
    }
}
