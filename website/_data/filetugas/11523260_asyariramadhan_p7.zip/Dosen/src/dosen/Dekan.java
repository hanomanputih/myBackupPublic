/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dosen;

/**
 *
 * @author Praktikan
 */
public class Dekan extends Dosen implements MakhlukHidup {
    String fakultas;
    
    @Override
    public void view (){
        fakultas= "fti";
        
        System.out.println("nama : "+nama); 
        System.out.println("jurusan "+Jurusan);
        System.out.println("fakultas :" +fakultas);
    }
    
    @Override
    public void mengajar(){
        String matakuliah="kalkulus";
        System.out.println("nama matakuliah " +matakuliah);
    }

    @Override
    public void makan() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void minum() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
    
    
}
