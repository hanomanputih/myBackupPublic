/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author praktikan
 */
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class main {
    public static void main(String[] args) {
        Map<Integer,String> nama = new HashMap<Integer,String>();

        nama.put(1,"NICK");
        nama.put(2, "UNAMED");
        nama.put(3, "Wahyu");

        for(Map.Entry<Integer,String> entry : nama.entrySet()){

            //System.out.println("===========");
            
            System.out.println(entry.getKey()+","+entry.getValue());
            //System.out.println(entry.getValue());
        }
        
    }
}
