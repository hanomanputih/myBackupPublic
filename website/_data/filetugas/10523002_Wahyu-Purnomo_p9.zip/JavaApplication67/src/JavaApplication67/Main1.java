/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package JavaApplication67;

    import java.util.ArrayList;
    import java.util.HashMap;
    import java.util.List;
    import java.util.Scanner;

public class Main1 {
    static int i;
    private static List List;
    static void LoadData(List list){
        list.add("Nama");
        list.add("NIM");
    }
    String Nama;
    int NIM;
    public static void tampilkanList(List  list){
       for (int i = 0; i < list.size(); i++);   {
            System.out.println(list.get(i) + " ");
    }
    System.out.println();
}
    public static void main(String[] args) {
       HashMap map = new HashMap();
       List list = new ArrayList();
       Scanner pembaca = new Scanner(System.in);
       map.put("Nama ", " Wahyu");
       map.put("NIM ", new Integer ( 10523002));
       LoadData(list);
       tampilkanList(list);

        System.out.println("Map");
        System.out.println("Ukuran Map : " + map.size());
        boolean containKey =  map.containsKey("NIM");
        System.out.println("Harum (NIM): " + containKey);
        Object removed =  map.remove("NIM");
        System.out.println("Removed : " + removed);
        System.out.println(map);
        System.out.println("Ukuran Map baru : "+map.size());
    }
}







