/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {

    /**
     * @param args the command line arguments
     */
    String nama,nim,fakultas,jurusan;
    int angkatan;
    void cetak(){
        nama = "Endro Ngujiharto";
        nim = "11523003";
        fakultas = "Teknologi Industri";
        jurusan = "Informatika";
        angkatan = 2011;
        System.out.println("nama: "+ nama);
        System.out.println("nim: "+ nim);
        System.out.println("fakultas: "+ fakultas);
        System.out.println("jurusan: "+ jurusan);
        System.out.println("angkatan: "+ angkatan);

    }
    public static void main(String[] args) {
        Mahasiswa mhs = new Mahasiswa();
        mhs.cetak();
        
    }
}
