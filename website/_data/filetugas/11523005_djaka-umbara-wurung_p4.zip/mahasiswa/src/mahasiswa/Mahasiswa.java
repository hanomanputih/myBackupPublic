/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {

    /**
     * @param args the command line arguments
     */


   
 String nama,nim,fakultas,jurusan,angkatan;
  
    void cetak () {
    Mahasiswa m = new Mahasiswa();
    m.nama ="djaka umbara";
    m.nim = "11523005";
    m.angkatan="2011";
    m.fakultas="industri";
    m.jurusan="informatika";
    System.out.println(m.nama);
    System.out.println(m.nim);
    System.out.println(m.angkatan);
    System.out.println(m.fakultas);
    System.out.println(m.jurusan);
  
    }
    public static void main(String[]args) {
       Mahasiswa mhs = new Mahasiswa();
       mhs.cetak();
    }
}
    