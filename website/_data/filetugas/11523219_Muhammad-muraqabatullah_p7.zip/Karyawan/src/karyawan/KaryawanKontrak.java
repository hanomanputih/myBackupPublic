/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package karyawan;

/**
 *
 * @author Praktikan
 */
public class KaryawanKontrak extends Karyawan {

    @Override
    public void gaji() {
      int  gaji=gajipokok+bonus;
    
        System.out.println("gaji karyawan kontrak");
        System.out.println("gajipokok   :"+gajipokok);
        System.out.println("bonus       :"+bonus);
//        throw new UnsupportedOperationException("Not supported yet.");
    }

}
