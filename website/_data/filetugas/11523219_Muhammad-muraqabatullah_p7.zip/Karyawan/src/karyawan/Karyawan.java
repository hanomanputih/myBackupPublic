/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package karyawan;

/**
 *
 * @author Praktikan
 */
public abstract class Karyawan {
 protected   int gajipokok =3000000;
 protected   int tunjangan = (int) ((0.2) * 3000000);
 protected   int bonus =1000000;

    public abstract void gaji();

}
