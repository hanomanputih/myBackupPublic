/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttestbab4;

/**
 *
 * @author PRAKTIKAN
 */
class karyawan {
    
}
