/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;
//import java.util.Scanner;
/**
 *
 * @author PRAKTIKAN
 */
public class Menampilkan {
    public static void main(String[] args) {
        Karyawan kyw =new Karyawan();
        kyw.setnip();
        kyw.setnama();
        kyw.setgaji();
        System.out.println("nip anda ="+kyw.getnip());
       
        System.out.println("nama anda ="+kyw.getnama());
        
         System.out.println("gaji setahun="+kyw.getgaji()*12);
    }
 
}
