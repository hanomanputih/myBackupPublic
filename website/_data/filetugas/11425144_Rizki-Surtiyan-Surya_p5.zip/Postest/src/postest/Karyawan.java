/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;
import java.util.Scanner;
/**
 *
 * @author PRAKTIKAN
 */
public class Karyawan {
   private String nip;
    private String nama;
    private int gaji;
    
    void setnip (){
        Scanner sc =new Scanner (System.in);
        System.out.println("nip=");
        nip =sc.next();
    }
    
    void setnama(){
        Scanner sc =new Scanner (System.in);
        System.out.println("nama=");
        nama= sc.next();
   
    }
    void setgaji(){
    Scanner sc =new Scanner (System.in);
        System.out.println("gaji =");
        gaji=sc.nextInt();
    }
    String getnip (){
        return nip;
    }
    String getnama (){
        return nama;
        }
    int getgaji(){
        return gaji;
    }
}
    

   
   
    
    
    
       
    

