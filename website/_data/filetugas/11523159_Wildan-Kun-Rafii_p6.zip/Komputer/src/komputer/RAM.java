/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class RAM {
     float ukuran;
     String merk;

    public String getMerk() {
        return merk;
    }

    public void setMerk(String merk) {
        this.merk = merk;
    }

    public float getUkuran() {
        return ukuran;
    }

    public void setUkuran(float ukuran) {
        this.ukuran = ukuran;
    }
    
}
