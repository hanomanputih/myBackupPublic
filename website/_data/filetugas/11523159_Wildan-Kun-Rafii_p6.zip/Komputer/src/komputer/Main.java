/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */


public class Main {
    public static void main(String[] args) {
        Prosesor p = new Prosesor ();
        RAM r = new RAM ();
        p.setHarga(1000);
        p.setMerk("hahaa");
        
        r.merk = "hehehe";
        r.ukuran = 2000000;
        Komputer komp1 = new Komputer(r, p);
        
        System.out.println("Merk Ram = " + komp1.getR().merk);
        System.out.println("Ukuran Ram =" + komp1.getR().ukuran);
        System.out.println(" Merk Prosesor =" + komp1.getP().getMerk());
        System.out.println("Ukuran Prosesor =" + komp1.getP().getHarga());
        
        
    }
}
