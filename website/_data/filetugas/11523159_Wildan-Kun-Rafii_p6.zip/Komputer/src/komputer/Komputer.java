/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class Komputer {
     RAM r ;
     Prosesor p ;

    public Prosesor getP() {
        return p;
    }

    public void setP(Prosesor p) {
        this.p = p;
    }

    public RAM getR() {
        return r;
    }

    public void setR(RAM r) {
        this.r = r;
    }
    public Komputer(RAM r,Prosesor p){
        this.p = p;
        this.r = r;
    }
    
    
    
    
    
        
        
        
    
    
        
    }

