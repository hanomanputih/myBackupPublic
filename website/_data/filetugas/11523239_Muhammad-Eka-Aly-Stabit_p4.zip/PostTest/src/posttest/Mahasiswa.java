/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

import java.util.Scanner;

/**
 *
 * @author PRAKTIKAN
 */
public class Mahasiswa {
    String nama, nim, fakultas, jurusan, angkatan;
    void masukkan(){
        Scanner sc = new Scanner(System.in);
        
        System.out.println("masukkan nama   : ");
        nama = sc.next();
        System.out.println("masukkan nim    : ");
        nim = sc.next();
        System.out.println("masukkan fakultas   : ");
        fakultas = sc.next();
        System.out.println("masukkan jurusan    : ");
        jurusan = sc.next();
        System.out.println("masukkan angkatan   : ");
        System.out.println("selamat datang di Universitas Islam Indonesia");
        angkatan = sc.next();
        System.out.println();
        System.out.println();
    }
    void cetak(){
        System.out.println("data anda sebagai berikut");
        System.out.println("nama anda adalah    : "+nama);
        System.out.println("nim anda adalah     : "+nim);
        System.out.println("fakultas anda adalah: "+fakultas);
        System.out.println("jurusan anda adalah : "+jurusan);
        System.out.println("angkatan anda adalah: "+angkatan);
        System.out.println();
        System.out.println();
    }
    void panjang(){
        System.out.println("panjang karakter");
        System.out.println(+nama.length());
        System.out.println(+nim.length());
        System.out.println(+fakultas.length());
        System.out.println(+jurusan.length());
        System.out.println(+angkatan.length());
    }
    public static void main(String[] args) {
        Mahasiswa mhs = new Mahasiswa();
        mhs.masukkan();
        mhs.cetak();
        mhs.panjang();

    }
}
