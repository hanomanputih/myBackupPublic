/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest5;

/**
 *
 * @author Praktikan
 */
public class CPU {
   String kodecpu;
   PROSESOR prosesor;
   RAM ram;
 
public CPU(String kodecpu,PROSESOR prosesor,RAM ram ){
    this.kodecpu = kodecpu;
    this.prosesor = prosesor;
    this.ram = ram ;
    
}
    public void tampil (){
        System.out.println(kodecpu);
        System.out.println(prosesor.getType());
        System.out.println(ram.getUkuran());
    

    
   
  
        
    }
}
