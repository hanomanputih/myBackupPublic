/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest5;

/**
 *
 * @author Praktikan
 */
public class main {
    
    public static void main(String[] args) {
        RAM r = new RAM();
        PROSESOR we = new PROSESOR();
        we.setType("intel");
        r.setUkuran("200");
    
        CPU cu = new CPU ("1234",we,r);
                
        cu.tampil() ;
        
       
    }
}
