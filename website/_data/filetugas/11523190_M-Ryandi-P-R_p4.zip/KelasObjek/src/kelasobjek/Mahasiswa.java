/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package kelasobjek;

import java.util.Scanner;

/**
 *
 * @author praktikan
 */
public class Mahasiswa {
    
    String nama, nim, fakultas, jurusan, angkatan;
    
    public void isi(){
        Scanner s = new Scanner(System.in);
        System.out.println("Masukkan nama anda       : ");
        nama = s.nextLine();
        System.out.println("Masukkan NIM anda         : ");
        nim = s.nextLine();
        System.out.println("Masukkan Fakultas anda    : ");
        fakultas = s.nextLine();
        System.out.println("Masukkan Jurusan anda     : ");
        jurusan = s.nextLine();
        System.out.println("Masukkan Angkatan anda    : ");
        angkatan = s.nextLine();
    }
    public void cetak() {
         System.out.println("Nama anda adalah "+nama+", dengan NIM = "+nim+". Berkuliah di Fakultas "+fakultas+" Jurusan "+jurusan+", angkatan "+angkatan+".");
    }
    
    public static void main(String[] args) {
    Mahasiswa m = new Mahasiswa();
    m.isi();
    m.cetak();
       
    }
}
