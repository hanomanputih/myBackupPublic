/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest3;

import java.util.Scanner;

/**
 *
 * @author PRAKTIKAN
 */
public class Mahasiswa {
    String nama ;
    String nim ;
    String fakultas ;
    String jurusan;
    String angkatan ;
    
    
    
    
   void cetak()
    
{
   Scanner cetak = new Scanner (System.in);
   
    System.out.println("Masukkan nama mahasiswa = ");
    nama=cetak.next();
    System.out.println("Masukkan nim mahasiswa = ");
    nim=cetak.next();
    System.out.println("Masukkan fakultas mahasiswa = ");
    fakultas=cetak.next();
    System.out.println("Masukkan jurusan mahasiswa = ");
    jurusan=cetak.next();
    System.out.println("Masukkan angkatan mahasiswa = ");
    angkatan=cetak.next();
}
   
    public static void main(String[] args) {
        Mahasiswa mhs1 = new Mahasiswa();
        
        mhs1.cetak();
    }
   
}
