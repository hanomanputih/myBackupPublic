/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes5;

/**
 *
 * @author Praktikan
 */
public class prosesor {
    String prosesor;
    public prosesor (String prosesor){
    this.prosesor = prosesor;
    }
    public void tampilprosesor(){
        System.out.println("prosesor : " + prosesor);
    }
}

