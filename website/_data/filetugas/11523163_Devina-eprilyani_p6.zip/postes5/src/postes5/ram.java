/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes5;

/**
 *
 * @author Praktikan
 */
public class ram {
    String ram;
    
    public ram (String ram){
    this.ram = ram;
    }
    
    public void tampilram(){
        System.out.println("ram : " + ram);
    }
}
