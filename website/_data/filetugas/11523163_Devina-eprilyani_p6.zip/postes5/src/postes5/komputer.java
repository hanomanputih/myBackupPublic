/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes5;

/**
 *
 * @author Praktikan
 */
public class komputer {
    private String namakomp;
    private ram r;
    private prosesor p;
    
    public komputer (String komp){
    
   namakomp = komp;
    if (namakomp.equals("compaq")){
        r = new ram ("2giga byte");
        p = new prosesor ("icore7");
    }
    }
    
//    public void tampilkomp(){
//        System.out.println("nama komputer : " + namakomp);
//        System.out.println("ram : " + ram);
//        
//    }
    public static void main(String[] args) {
         komputer k = new komputer ("compaq");
         System.out.println("namakomp : " + k.namakomp);
         System.out.println("ram : " + k.r.ram);
         System.out.println("prosesor : " + k.p.prosesor);
             }
}
