/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package posttest4;

/**
 *
 * @author Praktikan
 */
public class Karyawan {
    private String nip;
    private String nama;
    private int gaji;

    void setnip (String nip){
        this.nip=nip;
    }
    String getnip(){
        return nip;
    }
    void setnama (String nama){
        this.nama=nama;
    }
    String getnama(){
        return nama;
    }
    void setgaji (int gaji){
        this.gaji=gaji*12;
    }
    int getgaji(){
        return gaji;
    }
}
