/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package posttest4;

/**
 *
 * @author fitri
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Karyawan karyawan1=new Karyawan();
        karyawan1.setnip("10002335445");
        karyawan1.setnama("mahmudd");
        karyawan1.setgaji(1200000);
        System.out.println("nip karyawan  : "+karyawan1.getnip());
        System.out.println("nama karyawan : "+karyawan1.getnama());
        System.out.println("gaji karyawan : "+karyawan1.getgaji());
    }

}
