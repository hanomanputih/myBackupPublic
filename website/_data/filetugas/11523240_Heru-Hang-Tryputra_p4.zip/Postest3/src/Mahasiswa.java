
import java.util.Scanner;

public class Mahasiswa {
    String nama, nim, fakultas, jurusan, angkatan;

    void cetak(){
        System.out.println("Nama : " + nama);
        System.out.println("Jumlah karakter : " + nama.length());
        System.out.println("NIM : " + nim);
        System.out.println("Jumlah karakter : " + nim.length());
        System.out.println("Fakultas : " + fakultas);
        System.out.println("Jumlah karakter : " + fakultas.length());
        System.out.println("Jurusan : " + jurusan);
        System.out.println("Jumlah karakter : " + jurusan.length());
        System.out.println("Anda adalah angkatan " + angkatan);
        System.out.println("Jumlah karakter : " + angkatan.length());
       };   
    
    public static void main(String[] args) {
        Mahasiswa mahasiswa1 = new Mahasiswa();
        
        Scanner masukan=new Scanner(System.in);
        
        System.out.print("Masukan nama anda : " );
        
        mahasiswa1.nama=masukan.nextLine();
        
        System.out.print("Masukan NIM anda : " );
        mahasiswa1.nim=masukan.next();
        
        System.out.print("Masukan Fakultas anda : " );
        mahasiswa1.fakultas=masukan.next();
        
        System.out.print("Masukan Jurusan anda : " );
        
        mahasiswa1.jurusan=masukan.next();
        
        System.out.print("Angkatan berapa anda : " );
        mahasiswa1.angkatan=masukan.next();
        
        mahasiswa1.cetak();
 }
}
