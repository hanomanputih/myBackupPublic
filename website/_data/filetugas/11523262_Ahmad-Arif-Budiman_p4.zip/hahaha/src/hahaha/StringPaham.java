/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hahaha;

/**
 *
 * @author Praktikan
 */
public class StringPaham {

    String kelakuan = "Lagi Tidur Ni";
    public static void main(String[] args) {
        StringPaham sp = new StringPaham();

        System.out.println(sp.kelakuan.startsWith("Lagi"));
        System.out.println(sp.kelakuan.endsWith("Ni"));
        System.out.println(sp.kelakuan.length());
    }

}
