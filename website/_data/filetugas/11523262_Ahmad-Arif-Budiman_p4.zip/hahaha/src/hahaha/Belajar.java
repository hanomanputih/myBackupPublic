/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hahaha;

/**
 *
 * @author Praktikan
 */
import java.util.*;

public class Belajar {
    String nama = "arif";
    String nama2 = new String("arif");




}
