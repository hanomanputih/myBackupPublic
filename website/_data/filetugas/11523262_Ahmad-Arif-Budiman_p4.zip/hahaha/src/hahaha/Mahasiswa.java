/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hahaha;

/**
 *
 * @author Praktikan
 */

public class Mahasiswa {
    String nama, nim, fakultas, jurusan, angkatan;
    float jumlah1, jumlah2, jumlah3, jumlah4, jumlah5, jumlah;

    void cetak() {
        
        System.out.println(nim);
        System.out.println(nama);
        System.out.println(fakultas);
        System.out.println(jurusan);
        System.out.println(angkatan);
    }

    public static void main(String[] args) {
        Mahasiswa ms = new Mahasiswa ();

        ms.nim = "11523262";
        ms.nama = "Ahmad Arif Budiman";
        ms.fakultas = "Teknologi Industri";
        ms.jurusan = "Teknik Informatika";
        ms.angkatan = "2011";

        ms.jumlah1 = ms.nim.length();
        ms.jumlah2 = ms.nama.length();
        ms.jumlah3 = ms.fakultas.length();
        ms.jumlah4 = ms.jurusan.length();
        ms.jumlah5 = ms.angkatan.length();
        float jumlah = ms.jumlah1+ms.jumlah2+ms.jumlah3+ms.jumlah4+ms.jumlah5;
        ms.cetak();
        System.out.println("Jumlah huruf: "+jumlah); 
        

    }

}
