/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hahaha;

/**
 *
 * @author Praktikan
 */
public class Mobil {

    int ban;
    int spion;
    String merk;
    String plat;

    public static void main(String[] args) {
        Mobil mb = new Mobil();
        mb.ban = 4;
        mb.merk = "Honda";
        mb.plat = "AB 4121 F";
        mb.spion = 2;

        System.out.println("mobil dengan merk: "+mb.merk);
        System.out.println("plat: "+mb.plat);
        System.out.println("jumlah ban: "+mb.ban);
        System.out.println("dan spion: "+mb.spion);
        
    }

}
