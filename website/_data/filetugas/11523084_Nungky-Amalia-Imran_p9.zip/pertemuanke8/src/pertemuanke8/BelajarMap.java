/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package pertemuanke8;
import java.util.Map;
import java.util.HashMap;


/**
 *
 * @author praktikan
 */
public class BelajarMap {
    public static void main(String[] args) {
        Map<Integer, String> mhs = new HashMap<Integer, String>();

        mhs.put(11523084, "Nungky");
        mhs.put(11523070, "Maulia");
        mhs.put(11523106, "Brian");
        System.out.println(mhs);
        System.out.println(mhs.get(11523106));

        System.out.println("===========================");

        for(Map.Entry<Integer,String> e : mhs.entrySet()){
            System.out.println(e.getKey()+" , "+e.getValue());
        }
    }

}
