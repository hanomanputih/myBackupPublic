/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package pertemuanke8;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
/**
 *
 * @author praktikan
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        List nama = new ArrayList();

        nama.add("Nungky");
        nama.add("Brian");
        nama.add("Maulia");
        
        //System.out.println(nama);

        for(Object o : nama){
            System.out.println(o);
        }
        System.out.println("==================================");

        Iterator it = nama.iterator();
        while(it.hasNext()){
            System.out.println(it.next());
        }
    }

}
