/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cpu;

/**
 *
 * @author praktikan
 */
public class Prosesor {
     String corei7;
     
     Prosesor ( String corei7) {
         this.corei7 = corei7;
     }
}
