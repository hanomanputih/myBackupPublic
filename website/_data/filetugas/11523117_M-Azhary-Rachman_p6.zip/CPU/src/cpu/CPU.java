/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cpu;

/**
 *
 * @author praktikan
 */
public class CPU {

    private int produk;
    private Ram r;
    private Prosesor pro;
    
    
    public CPU (int produk){
        this.produk = produk;
        if (produk == 2){
        pro  = new Prosesor ("AMD");
        r = new Ram ("512");
        }
    }
    
    public void tampil (){
        
        System.out.println("no produksi: "+ produk);
        System.out.println("merk prosesor "+ pro.corei7);
        System.out.println("kapasitas ram "+ r.MerkA);
    }
}
          
    

    

