
package pewarisan;


public class KelasMain {
    
    
    public static void main(String[] args) {
      
      KaryawanTetap kt = new KaryawanTetap();
      KaryawanKontrak kk = new KaryawanKontrak();
      
      kt.gaji();
      kk.gaji();
    }
}
