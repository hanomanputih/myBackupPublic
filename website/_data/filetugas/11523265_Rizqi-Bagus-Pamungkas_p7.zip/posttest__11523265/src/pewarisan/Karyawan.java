/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pewarisan;

/**
 *
 * @author Praktikan
 */
public abstract class Karyawan {
    int bonus = 40000;
    int gajipokok = 3000000;
            
 public abstract void gaji();

}