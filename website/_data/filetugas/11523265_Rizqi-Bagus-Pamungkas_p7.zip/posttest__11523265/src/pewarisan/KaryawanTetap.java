/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pewarisan;

/**
 *
 * @author Praktikan
 */
public class KaryawanTetap extends Karyawan {
double tunjangan= 0.2*gajipokok;

int gaji = (int) (tunjangan+gajipokok+bonus);
    @Override
    public void gaji() {
        System.out.println("gaji karyawan tetap :"+gaji);
    }
    
    
    
}
