/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package post.test.pkg5.pkg11523092;

/**
 *
 * @author Praktikan
 */
public class Komputer {
    String jenengKom;
    Processor p;
    RAM r;
    
    public Komputer(String j, String P, String R) {
        this.jenengKom = j;
        p = new Processor(P);
        r = new RAM(R);
    }
    
    public void Tampilin(){
        System.out.println("Nama Komputer   : "+jenengKom);
        System.out.println("Jenis Processor : "+p.jenisProcessor);
        System.out.println("Besar RAM       : "+r.besarRAM);
    }
    
    public static void main (String[] args) {
        Komputer k = new Komputer("Star", "AMD", "2 GB");
        k.Tampilin();
    }
}
