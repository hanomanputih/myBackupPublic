/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package post.test.pkg5.pkg11523092;

/**
 *
 * @author Praktikan
 */
public class RAM {
    String besarRAM;
    
    public RAM(String muatan) {
        this.besarRAM = muatan;
    }
}
