/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package post.test.pkg5.pkg11523092;

/**
 *
 * @author Praktikan
 */

public class Processor {
    String jenisProcessor;
    
    public Processor(String jenis) {
        this.jenisProcessor = jenis;
    }
}
