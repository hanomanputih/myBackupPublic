/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package postest8;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
/**
 *
 * @author Praktikan
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        Scanner sc = new Scanner(System.in);
        String nim,nama;
        for (int i=0; i<nama.size(); i++){
            System.out.println(nama.p);
            
        }
//        System.out.print("NIM : ");
//            nim=sc.next();
//            System.out.print("Nama : ");
//            nama=sc.next();



    }
}
