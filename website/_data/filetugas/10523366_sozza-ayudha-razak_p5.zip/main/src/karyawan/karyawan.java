/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author PRAKTIKAN
 */
public class karyawan {
    public String nip;
    public String nama;
    public int gaji;
    
    void setNip(String np){
        nip = np;
    }
    
    String getNip() {
        return nip;
        
    }
    
    void setNama(String nm){
        nama = nm;
    
        
        
        
        if(nm.length() == 10){
        nama=nm;
    }else{
            System.out.println("nip tidak sesuai");
        }
    }
 
       
   
    void setGaji(int gj){
        
        if(gj >= 100000 && gj <=500000){
            gaji = gj;
        }else{
            System.out.println("saya bokek");
            
        }
    }int getGaji (){
        return gaji ;
    }
}
            
            
                
    
        
        
        

        
    
