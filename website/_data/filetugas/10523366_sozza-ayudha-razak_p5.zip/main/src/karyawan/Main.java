/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author PRAKTIKAN
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        karyawan m = new karyawan();
        m.setNip ("10523366") ;
        m.setNama ("Nama Saya");
        m.setGaji (200000);
        
        System.out.println("Nim :"+m.getNip());
        //System.out.println("Nama :"+m.getNama());
        System.out.println("Gaji :"+m.getGaji());
    }
}
