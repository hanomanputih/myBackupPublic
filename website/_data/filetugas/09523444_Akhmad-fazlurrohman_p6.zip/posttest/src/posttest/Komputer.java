/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author PRAKTIKAN
 */
public class Komputer {
    String komp;
    Prosesor pros;
    RAM ram;
    
    public Komputer (String komp){
        this.komp = komp;
        if (komp.equals("IFAZ")){
            pros = new Prosesor("PVY");
        }else{
            System.out.println("komputer");
        }
        
    }
    
    public void tampil (){
        System.out.println("komputer : " +komp);
        System.out.println("Prosesor nya : " + pros.pross);
         System.out.println("Ram : " + pros.ramm.ramm);
    }
    
    public static void main(String[] args) {
        Prosesor prosss= new Prosesor("AMD");
        prosss.Tampil();
        Komputer komp= new Komputer ("IFAZ");
        komp.tampil();
        
        
    }
}
