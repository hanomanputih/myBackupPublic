/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author PRAKTIKAN
 */
public class RAM {
    String ramm;
    
    public RAM (String ramm){
        this.ramm = ramm;
    }
}
