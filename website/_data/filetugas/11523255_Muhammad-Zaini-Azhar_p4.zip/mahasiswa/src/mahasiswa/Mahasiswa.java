/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

import java.util.Scanner;
public class Mahasiswa {

  String Nama;
  String nim;
  String fakultas;
  String jurusan;
  
  void cetakData (){
      System.out.println("nama saya adalah : " + Nama );
      System.out.println("nim saya adalah : " + nim );
      System.out.println("fakultas saya adalah : " + fakultas);
      System.out.println("jurusan saya adalah : " + jurusan);
      
      
  }
  
public static void main(String[] args) {
    Mahasiswa Mahasiswa27 = new Mahasiswa();
    Scanner baca = new Scanner(System.in);
    System.out.println("masukan nama anda : ");
    Mahasiswa27.Nama = baca.next();
    System.out.println("masukan nim anda : ");
    Mahasiswa27.nim = baca.next();
    System.out.println("masukan fakultas anda : ");
    Mahasiswa27.fakultas= baca.next();
    System.out.println("masukan jurusan anda : ");
    Mahasiswa27.jurusan=baca.next();
    Mahasiswa27.cetakData();
    
    
    
   
}
}
