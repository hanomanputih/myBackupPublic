/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package kelasobjek;

/**
 *
 * @author Praktikan
 */
public class kelasObjek {

    String nama = "dona haa hee";
    public static void main(String[] args) {
        kelasObjek cetak = new kelasObjek();
        System.out.println("kata depan "+cetak.nama.startsWith("dona"));
        System.out.println("kata tengah "+cetak.nama.endsWith("haa"));
        System.out.println("kata akhir "+cetak.nama.length());
    }


    }
}
