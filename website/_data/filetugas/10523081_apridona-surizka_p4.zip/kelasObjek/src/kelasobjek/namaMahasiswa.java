/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package kelasobjek;
import java.util.Scanner;


public class namaMahasiswa {
String nama;
int nim;
 void cetak(){
     Scanner cetak = new Scanner(System.in);
     
     System.out.println("nama saya : ");
     nama = cetak.next();
     
     System.out.println("nim saya : ");
     nim = cetak.nextInt();
     
     System.out.println("nama anda : " +nama+ " nim anda : "+nim);
        
    }
    public static void main(String[] args) {
        namaMahasiswa cetak = new namaMahasiswa ();
        cetak.cetak();
  }

}
