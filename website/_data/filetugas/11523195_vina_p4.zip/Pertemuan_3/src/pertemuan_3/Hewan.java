/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan_3;

import java.util.Scanner;

/**
 *
 * @author PRAKTIKAN
 */
public class Hewan {
     int jumlahKaki ;
     String nama;
    
   
      
    
    
    public static void main(String[] args) {
        Scanner baca = new Scanner (System.in);
        Hewan animal = new Hewan();
        System.out.println("sebutkan nama hewan=");
        animal.nama = baca.next();
        System.out.println("berapa jumlah kakinya = ");
        animal.jumlahKaki = baca.nextInt();
        System.out.println("Jadi Nama hewan terdapat "+animal.nama.length()+" huruf");
        
       
    }
}
