/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes;

/**
 *
 * @author praktikan
 */
public class KaryawanTetap extends Karyawan {
    public int tunjangan = 1000000;
    public int gajitetap;
    
    
    @Override
    public void gaji(){
        super.gaji();
        gajitetap=tunjangan+gajipokok+bonus;
        System.out.println("Nama Karyawan       : "+nama);
        System.out.println("Gaji tetap anda     : "+gajitetap);
    }
    
    
}
