/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes;

/**
 *
 * @author praktikan
 */
public class KaryawanKontrak extends Karyawan{
    
    @Override
    public void gaji(){
        super.gaji();
        gajikontrak = gajipokok+bonus;
        System.out.println("Gaji kontrak anda   : "+gajikontrak);
    }
}
