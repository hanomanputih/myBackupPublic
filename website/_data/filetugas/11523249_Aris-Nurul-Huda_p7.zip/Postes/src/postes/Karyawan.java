/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes;

/**
 *
 * @author praktikan
 */
public class Karyawan {
    public int gajipokok = 3000000;
    public String nama = "Lulung";
    public int bonus = 500000;
    public int gajikontrak;
    
    
    public void gaji(){
        System.out.println("Nama Karyawan   : "+nama);
        System.out.println("Gaji Pokok      : "+gajipokok);
    }
    
    
}
