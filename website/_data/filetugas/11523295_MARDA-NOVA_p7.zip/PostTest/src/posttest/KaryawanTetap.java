/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author Praktikan
 */
public class KaryawanTetap extends Karyawan {
    double tunjangan = 0.20*gajipokok;
    
   @Override
    public void gaji() {
    
       System.out.println("gaji karyawan tetap : "+tunjangan+gajipokok+bonus);
   }
}
