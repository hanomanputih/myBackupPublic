/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author Praktikan
 */
public class PostTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       KaryawanKontrak kt = new KaryawanKontrak();
       KaryawanTetap k = new KaryawanTetap();
       kt.gaji();
       k.gaji();
    }
}
