/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author Praktikan
 */
public abstract class Karyawan {

    int bonus = 100000;
    int gajipokok = 3000000;

  public abstract void gaji ();
}
