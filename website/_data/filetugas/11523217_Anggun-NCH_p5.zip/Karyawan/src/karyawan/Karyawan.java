/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class Karyawan {
private String nip,nama;
private int gaji;

   
         public void setnip(String nip){
          this.nip=nip;
        }
        public void  setNama(String nama){
            this.nama=nama;
        }
        public void setgaji(int gaji){
            this.gaji=gaji*12;
        }
         public String getNip(String nip){
          return nip;
        }
        public String getNama(String nama){
           return nama;
        }
        public int getgaji(){
           return gaji;
        }
       
    }

