/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package postest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Praktikan
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        List nama=new ArrayList();
        Iterator itt=nama.iterator();
        Map<Integer,String>sapi=new HashMap<Integer,String>();

        nama.add("mega");
        nama.add("11523244");

        System.out.println(nama);



        while(itt.hasNext()){
            System.out.println(itt.next());
        }


        sapi.put(11523244, "mega");

        for (Map.Entry<Integer,String>sp:sapi.entrySet()){
            System.out.println(sp.getKey()+"."+sp.getValue());
        }
    }

}
