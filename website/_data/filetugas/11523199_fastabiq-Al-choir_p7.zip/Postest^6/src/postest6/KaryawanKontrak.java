/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package postest6;

/**
 *
 * @author Praktikan
 */
public class KaryawanKontrak extends Karyawan{

    @Override
    public void gaji() {
        int gaji = gajipokok + bonus ;
        System.out.println("Bonus "+bonus);
        System.out.println("tunjangan "+tunjangan);
        System.out.println("gaji bersih "+gaji);
    }

}
