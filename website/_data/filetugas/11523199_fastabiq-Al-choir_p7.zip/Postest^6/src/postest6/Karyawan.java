/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package postest6;

/**
 *
 * @author Praktikan
 */
public abstract class Karyawan {
int gajipokok = 30000;
int tunjangan = (int) (0.2 * gajipokok) ;
int bonus = 23000000;
public abstract void gaji();
}
