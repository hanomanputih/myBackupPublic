/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package postest6;

/**
 *
 * @author Praktikan
 */
public class KaryawanTetap extends Karyawan {

    @Override
    public void gaji() {
       int gaji =  (gajipokok + bonus + tunjangan);
        System.out.println("Gaji pokok "+gajipokok);
        System.out.println("Bonus "+bonus);
        System.out.println("tunjangan "+tunjangan);
        System.out.println("gaji bersih "+gaji);

    }


}
