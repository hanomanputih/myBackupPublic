/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package latihan;
import java.util.Scanner;
/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
    String nama, nim, jurusan, fakultas;

    
     
     
     void cetak (){
         Scanner pembaca = new Scanner (System.in);
         System.out.println("siapa nama anda?");
         nama = pembaca.next();
         System.out.println("berapa nim anda?");
         nim = pembaca.next();
         System.out.println("apa jurusan anda?");
         jurusan = pembaca.next();
         System.out.println("dimana fakultas anda?");
         fakultas = pembaca.next();
         
         
         System.out.println("Jadi nama anda adalah "+nama);
         System.out.println("Jadi nim anda adalah "+nim); 
         System.out.println("jadi jurusan anda adalah "+jurusan);
         System.out.println("jadi fakultas anda adalah "+fakultas);
     
     }
         
     
     
    public static void main(String[] args) {
       
       
        Mahasiswa m = new Mahasiswa ();
       m.cetak();
        
        
       
        
        
    }
    
}
