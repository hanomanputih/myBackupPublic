/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class pemanggilanKaryawan {
   
  public static void main(String[] args) {

        
        Karyawan kry=new Karyawan();
        kry.setNip("11523226");
        System.out.println("Nim anda: "+kry.getNip());
        kry.setNama("rendy");
        System.out.println("Nama Anda: "+kry.getNama());
        kry.setGaji(11000000);
        System.out.println("Gaji Anda Sebulan: "+kry.getGaji());
        System.out.println("Gaji Anda Setahun: "+kry.getGaji()*12);
        
    }
}

