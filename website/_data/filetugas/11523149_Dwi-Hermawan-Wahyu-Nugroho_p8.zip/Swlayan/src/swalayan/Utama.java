/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package swalayan;

/**
 *
 * @author PRAKTIKAN
 */
public class Utama {
    public static void main (String [] args) {
        Swalayan s;
        Indomart i = new Indomart();
        s=i;
        s.tampil();
        
        TokoAgung t = new TokoAgung();
        s=t;
        s.tampil();
        
    }
    
}
