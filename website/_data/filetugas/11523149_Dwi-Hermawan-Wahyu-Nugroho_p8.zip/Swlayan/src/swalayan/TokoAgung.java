/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package swalayan;

/**
 *
 * @author PRAKTIKAN
 */
public class TokoAgung extends Swalayan {

    @Override
    void tampil() {

        sisa = (int) (harga % 25);
        bayar = (int) (harga - sisa);
        System.out.println("Pembayaran :" + bayar);

    }
}
