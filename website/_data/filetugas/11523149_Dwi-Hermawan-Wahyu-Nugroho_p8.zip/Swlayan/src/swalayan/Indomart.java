/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package swalayan;

/**
 *
 * @author PRAKTIKAN
 */
public class Indomart extends Swalayan {

    @Override
    void tampil() {
        if (harga % 25 == 0) {
            System.out.println("Pembayaran :" + harga);
        } else {
            sisa =  (int) (25 - (harga % 25));
            bayar = (int) (harga + sisa);
            System.out.println("Pembayaran :" + bayar);

        }
    }
}
