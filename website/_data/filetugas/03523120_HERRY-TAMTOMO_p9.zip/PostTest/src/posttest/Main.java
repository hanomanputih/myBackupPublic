/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 *
 * @author PRAKTIKAN
 */
public class Main {
    public static void main(String[] args) {
        List nama = new ArrayList();
        
        nama.add("Herry Tamtomo");
        nama.add(13523120);
        nama.add("informatika");
        
        System.out.println(nama);
        System.out.println("____________________________________________________________");
        
        for(Object ss : nama){
            System.out.println(ss);
        
         
    }
        System.out.println("____________________________________________________________");
        
    Iterator it = nama.iterator();
    while(it.hasNext()){
            System.out.println(it.next());
    }
    System.out.println("____________________________________________________________");
        
    for (int i=0; i<nama.size();i++){
        if(i==2){
            System.out.println(nama.get(i));
        
    
    } 
    System.out.println("____________________________________________________________");
        
     Map<Integer,String> aaa = new HashMap<Integer,String>();
        
        aaa.put(13523120, "Herry Tamtomo");
        aaa.put(13523122, "Herry Tam");
        aaa.put(12512333, "Al Ghazi");
        
        
        
        for (Map.Entry<Integer,String> rr : aaa.entrySet()){
            System.out.println(rr.getKey()+ " - "+rr.getValue());
        }
    }
    }
}