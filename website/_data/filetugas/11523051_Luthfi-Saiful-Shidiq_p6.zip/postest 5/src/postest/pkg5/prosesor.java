/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest.pkg5;

/**
 *
 * @author praktikan
 */
public class prosesor {
    public String harga;
    public prosesor (String mahal){
    harga = mahal;
    }
}
    

