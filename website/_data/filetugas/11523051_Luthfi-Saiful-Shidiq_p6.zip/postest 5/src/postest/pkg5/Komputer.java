/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest.pkg5;

/**
 *
 * @author praktikan
 */
public class Komputer {

RAM m;
prosesor p;
public String kualitas;
public Komputer (String ini){
        kualitas=ini;
        m = new RAM("besar");
        p = new prosesor ("mahal");
}
        

    public static void main(String[] args) {
        Komputer r= new Komputer("1");
        System.out.println("komputer ini memiliki ram yang "+r.m.jenis);
        System.out.println("dan memiliki prosesor yang "+r.p.harga);
       
    }
}
