/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest.pkg5;

/**
 *
 * @author praktikan
 */
public class RAM {
    public String jenis;
    public RAM (String besar){
    jenis = besar;
    }
}
