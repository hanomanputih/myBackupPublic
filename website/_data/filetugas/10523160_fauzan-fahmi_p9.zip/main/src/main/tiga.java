/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class tiga {
    private static int NIM;
    private static Object nama;
    public static void main(String[] args) {
        HashMap map=new HashMap();
        map.put("nama","blody");
    Scanner pembaca=new Scanner(System.in);
            int Nim;
            String Nama;
            Nama=pembaca.next();
            NIM = pembaca.nextInt();
       
            map.put("nama", nama);
            map.put("nim", new Integer(10523160));
            System.out.println(map);
            System.out.println("ukuran map :"+ Map.size());
            boolean containtKey=map.containsKey("nim");
                    object removed=(object) map.remove ("nim");
                    System.out.println("remove"+removed);
                    System.out.println(map);
                    System.out.println("ukuran map baru :"+map.size());
                          
    
            
            
   }
    
}
