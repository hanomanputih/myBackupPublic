/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javaapplication64;

/**
 *
 * @author praktikan
 */import java.util.Scanner;
public class Mahasiswa {

    public static void main(String[] args){

    String nama;
    int nim;
    String fakultas;
    String jurusan;
    int angkatan;


        Scanner baca = new Scanner(System.in);
        System.out.println("Masukan nama : ");
        nama = baca.next();
        System.out.println("Masukan nim : ");
        nim = baca.nextInt();
        System.out.println("Masukan fakultas : ");
        fakultas = baca.next();
        System.out.println("Masukan jurusan : ");
        jurusan =baca.next();
        System.out.println("Masukan angkatan : ");
        angkatan = baca.nextInt();
        System.out.println("Nama : "+nama);
        System.out.println("nim : "+nim);
        System.out.println("Fakultas :"+fakultas);
        System.out.println("Jurusan : "+jurusan);
        System.out.println("angkatan : "+angkatan);





    }

}
