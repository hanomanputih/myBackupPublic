/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javaapplication64;

/**
 *
 * @author praktikan
 */
import java.util.Scanner;

public class Main {
    

    /**
     * @param args the command line arguments
     */
    String nama;
    int jumlah;
  
    public static void main(String[] args) {
        Main m = new Main();
        Scanner baca = new Scanner(System.in);
        System.out.println("Masukan nama anda: ");
        m.nama =baca.next();
        m.jumlah = m.nama.length();
        System.out.println("Panjang karakter nama anda: "+m.jumlah);

    }
   

}
