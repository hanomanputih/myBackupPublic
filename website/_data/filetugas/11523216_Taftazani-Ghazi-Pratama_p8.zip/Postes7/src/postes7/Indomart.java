/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes7;

/**
 *
 * @author Praktikan
 */
public class Indomart extends Swalayan {
   
    @ Override
    
    public void caraPembayaran(){
        System.out.println("Indomart");
        System.out.println("Masukkan Pembayaran: ");
       
        if (harga % 25==0) {
          bayar=(int) harga;
          System.out.println("Anda harus membayar:"+bayar);
            
        } else{
            sisa= (int) (25-(harga% 25));
            bayar= (int) (harga+sisa);
            System.out.println("Anda harus membayar:"+bayar);
        }
            
            
      
    }    
    
}
