/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes7;

/**
 *
 * @author Praktikan
 */
public class Swalayan {
    
    public float harga=19212;
    int bayar;
    int sisa;
    
    public void caraPembayaran(){
        
    }
}
