/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes7;

/**
 *
 * @author Praktikan
 */
public class Postes7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Swalayan s;
        s = new Indomart();
        s.caraPembayaran();

        s = new tokoAgung();
        s.caraPembayaran();


    }
}
