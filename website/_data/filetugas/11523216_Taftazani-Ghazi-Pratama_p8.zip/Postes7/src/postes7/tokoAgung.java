/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes7;

/**
 *
 * @author Praktikan
 */
public class tokoAgung extends Swalayan {

    @Override
    public void caraPembayaran() {
        super.caraPembayaran();
        
        System.out.println("Toko Agung");
        
        System.out.println("Masukkan harga barang:");
        sisa= (int)harga% 25;
        bayar = (int)harga-sisa;
        System.out.println("Anda harus membayar:"+bayar);
        
    }
   
    
}
