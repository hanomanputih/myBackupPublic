/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Uwong;

/**
 *
 * @author Adipati
 */
public class postes {
    public static void main(String[] args) {
        Cpu cpu = new Cpu(1);
        cpu.tampil();
    }
}
