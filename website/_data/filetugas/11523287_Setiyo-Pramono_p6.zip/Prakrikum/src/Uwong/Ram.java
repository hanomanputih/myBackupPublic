/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Uwong;

/**
 *
 * @author Adipati
 */
public class Ram {
    int ukuran;

    public Ram(int ukr) {
        ukuran = ukr;
    }
    
}
