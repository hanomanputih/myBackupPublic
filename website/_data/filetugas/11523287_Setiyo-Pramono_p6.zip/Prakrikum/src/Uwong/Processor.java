/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Uwong;

/**
 *
 * @author Adipati
 */
public class Processor {
    String type;

    public Processor(String tp) {
        type=tp;
    }
    
    
 }
