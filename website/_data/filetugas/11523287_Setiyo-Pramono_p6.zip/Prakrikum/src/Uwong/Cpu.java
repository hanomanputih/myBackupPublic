/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Uwong;
import java.util.Scanner;
/**
 *
 * @author Adipati
 */
public class Cpu {
    int noProd;
    Processor pr;
    Ram ram;   
//    Scanner input = new Scanner(System.in);
    
    public Cpu (int nPro){
        noProd=nPro;
//        noProd = input
        if (nPro == 1){
            pr = new Processor("Intel");
            ram = new Ram(4);
        }
    }
    
    public void tampil()
    {
         System.out.println("Processor : "+pr.type);
         System.out.println("Ram : "+ram.ukuran);

    }
}
