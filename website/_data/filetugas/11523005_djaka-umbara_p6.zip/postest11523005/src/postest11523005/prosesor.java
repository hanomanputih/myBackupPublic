/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest11523005;

/**
 *
 * @author Praktikan
 */
public class prosesor {
    String NamaProsesor;
 public prosesor(String NamaProsesor ){
     this.NamaProsesor=NamaProsesor;
 }
    
}
