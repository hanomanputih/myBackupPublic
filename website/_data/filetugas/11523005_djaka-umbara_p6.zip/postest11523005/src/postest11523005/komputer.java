/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest11523005;

/**
 *
 * @author Praktikan
 */
public class komputer {

 String merk;
 prosesor pr ;
 ram rm ;
 
 public komputer (String merk){
     this.merk=merk;
  pr = new prosesor("z");
  rm = new ram("z");
 
System.out.println("merknya " + merk); 
 System.out.println("nama prosesor " + pr.NamaProsesor);
 System.out.println("kapasitasnya " + rm.kapasitas);
 }
    
    public static void main(String[] args) {
       
        // TODO code application logic here
        komputer kom = new komputer("manggo");
   
        
    }
}
