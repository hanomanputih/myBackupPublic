/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest11523005;

/**
 *
 * @author Praktikan
 */
public class ram {
    String kapasitas;
    public ram (String kapasitas){
        this.kapasitas=kapasitas;
    }
       
    
}
