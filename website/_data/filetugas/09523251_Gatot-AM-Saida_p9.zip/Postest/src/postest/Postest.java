/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

public class Postest {

    public static void main(String[] args) {
        ArrayList List = new ArrayList();
        Scanner sc = new Scanner(System.in);
        System.out.println("Masukkan Nama");
        String nama = sc.nextLine();
        System.out.println("Masukkan Nim");
        String nim = sc.nextLine();

        List.add(nama);
        List.add(nim);

        for (Iterator<String> iterator = List.iterator(); iterator.hasNext();) {
            String ii = (String) iterator.next();
            System.out.println("isi : " + ii);
        }
        
        Map<Integer,String> map = new HashMap();
        map.put(1, nama);
        map.put(2, nim);
        
        for(Map.Entry<Integer, String> entry : map.entrySet()){
            System.out.println(entry.getKey() + "," + entry.getValue());
        }
        
            
        }
        
    }
