/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

/**
 *
 * @author Praktikan
 */
public class komputer {
    private boolean exp;

    komputer(String string) {
        komputerrr();
    }

    private void komputerrr() throws UnsupportedOperationException {
        if (exp) {
        }
    }
    public void tampil1(){
    System.out.println("komputer");
    }
}
