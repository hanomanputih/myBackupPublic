/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

/**
 *
 * @author Praktikan
 */
public class Postest {
 private komputer k;
 private prosesor p;
 private ram r;
   private String nama;
    
 public kompi (String  nama){
     this.nama = nama;
     if (nama.equals("komputer")){
         k = new komputer("pentium");
     }
 }
 
    public static void main(String[] args) {
   public void tampil(){
   
    System.out.println ();
    System.out.println ();
    System.out.println ();
    }
}
