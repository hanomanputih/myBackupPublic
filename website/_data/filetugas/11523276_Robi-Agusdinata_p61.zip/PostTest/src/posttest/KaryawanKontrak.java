/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author PRAKTIKAN
 */
public class KaryawanKontrak extends Karyawan{

    @Override
    public void gaji() {
        System.out.println("Gaji Karyawan Kontrak : "+(gajiPokok+bonus));
    }
    
}
