/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author PRAKTIKAN
 */
public class KaryawanTetap extends Karyawan {
double tunjangan=0.20*gajiPokok;
    @Override
    public void gaji() {
        System.out.println("Gaji Karyawan Tetap : "+(gajiPokok+tunjangan+bonus));
    }
    
           
}
