/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

/**
 *
 * @author Praktikan
 */
import java.util.Scanner;

public class Mahasiswa {

    /**
     * @param args the command line arguments
     */
  
  String nama,fakultas,jurusan,nim,angkatan ;
  void cetak(){
      Scanner cetak = new Scanner(System.in);
      System.out.println ("nama");
      System.out.println("masukan nama anda");
      nama=cetak.next();
      System.out.println("fakultas");
      System.out.println("masukan fakultas anda");
      fakultas=cetak.next();
      System.out.println("jutrusan");
      System.out.println("masukan jurusan anda");
      jurusan=cetak.next();
      System.out.println("nim");
      System.out.println("masukan nim anda");
      nim=cetak.next();
      System.out.println("angkatan");
      System.out.println("masukan angkatan anda");
      angkatan=cetak.next();
  }
    
    public static void main (String[] args) {
        Mahasiswa m =new Mahasiswa();
        m.cetak();
    }}
  
