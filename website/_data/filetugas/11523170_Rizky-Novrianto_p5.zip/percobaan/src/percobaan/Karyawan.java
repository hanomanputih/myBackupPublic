/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package percobaan;

/**
 *
 * @author PRAKTIKAN
 */
public class Karyawan {

    private String nip;
    private String nama;
    private int gaji;

    void setnip(String n) {

        if (n.length() == 10) {
            nip = n;
        } else {
            System.out.println("nip gak sesuai");
        }
    }

    String getnip() {
        return nip;
    }

    void setNama(String n) {

        if (n.length() >= 8) {
            nama = n;
        } else {
            System.out.println("Nama anda gakjelas");
        }
    }

    String getnama() {
        return nama;
    }

    void setgaji(int g) {
        if (g > 100000 && g <= 500000) {
            gaji = g;
        } else {
            System.out.println("gaji tidak sesuai");
        }
    }

    int getgaji() {
        return gaji;
    }
}
