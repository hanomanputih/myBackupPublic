/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package percobaan;

/**
 *
 * @author PRAKTIKAN
 */
public class mahasiswa {
    private String nama;
    public String nim;
    
    void setNama (String n) {
        nama = n;
    }
    
    String getNama () {
        return nama;
       
    }
    
    void setNim(String nm) {
        nim = nm;
        if(nm.length() == 8 ) {
            System.out.println("");
        }else{
            System.out.println("nim tidak sesuai");
        }
    }
    
    String getNim (){
        return nim;
    }
}
