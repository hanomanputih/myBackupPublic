/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package percobaan;

/**
 *
 * @author PRAKTIKAN
 */
public class Percobaan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        mahasiswa m = new mahasiswa ();
        m.setNim ("11523170") ;
        m.setNama ("Rizky") ;
        
        
        System.out.println("Nim : "+m.getNim());
        System.out.println("Nama : "+m.getNama ());
    }
}
