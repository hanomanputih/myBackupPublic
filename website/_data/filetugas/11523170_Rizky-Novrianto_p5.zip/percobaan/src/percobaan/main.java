/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package percobaan;

/**
 *
 * @author PRAKTIKAN
 */
public class main {
    public static void main(String[] args) {
       Karyawan k = new Karyawan();
       k.setnip("1234567890");
       k.setNama("baranghajasudah");
       k.setgaji(300000);
        
        System.out.println("nip = "+k.getnip());
        System.out.println("nama = "+k.getnama());
        System.out.println("gaji setahun = "+k.getgaji());
    }
    
}
