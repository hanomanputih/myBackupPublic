/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author PRAKTIKAN
 */
public class main {
    
    public static void main(String[] args) {
        karyawan kry = new karyawan();
        
    }
}
