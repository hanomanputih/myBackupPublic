/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package potstest;

/**
 *
 * @author Praktikan
 */
public class komputer {
    String merek;
   prosesor ps;
   ram ukuran;
    
     public komputer(String merk, prosesor psr, ram ukrn){
       merek = merk;
       ps = psr;
       ukuran = ukrn;
}
public void tampil(ram ukuran, prosesor ps ){
    System.out.println("merek komputer : "+merek);
    System.out.println("ram : "+ukuran.ukuran);
    System.out.println("prosesor : "+ps.namaProsesor);
}
}
