/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package potstest;

/**
 *
 * @author Praktikan
 */
public class mainKomposisi {
     public static void main(String[] args){
    ram ukuran = new ram ("dua gb");
    prosesor ps = new prosesor("atom");
   komputer km =new komputer("baru",ps,ukuran);
   km.tampil(ukuran, ps);
     }}
