/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package potstest;

/**
 *
 * @author Praktikan
 */
public class prosesor {
    String namaProsesor;
    public prosesor(String ps){
        this.namaProsesor = ps;
    }
}
