/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest4;

/**
 *
 * @author Praktikan
 */
public class main {
    public static void main(String[]args){
        Posttest4 p4 = new Posttest4();
        p4.setNIP("11523258");
        p4.setNama("Iskandar Muda");
        p4.setGaji(50000);
        System.out.println("NAMA : "+p4.getNama());
        System.out.println("NIP : "+p4.getNIP());
        System.out.println("Gaji : "+p4.getGaji());
    }
}
