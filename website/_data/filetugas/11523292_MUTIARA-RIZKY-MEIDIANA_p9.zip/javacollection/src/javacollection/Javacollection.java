/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javacollection;
import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author Praktikan
 */
public class Javacollection {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc=new Scanner(System.in);
        List nim=new ArrayList();
        List nama=new ArrayList();
        
        nim.add(11523292);
        nim.add(11523293);
        nim.add(11523294);
        
        nama.add("riris");
        nama.add("iis");
        nama.add("rani");
        
           System.out.println(nim.get(2));
           System.out.println(nama.get(2));
       }
    }
