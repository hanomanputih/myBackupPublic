/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package multiclass;

/**
 *
 * @author Praktikan
 */
public class CPU {
  private String Merk;
  private int idProduk;
  private ram ram1;
  private processor P;

    public CPU(int idProduk){
        this.idProduk = idProduk ;
        if (idProduk == 1 ){
          ram1 = new ram(256);
          P = new processor("intel");
        }}


        public void Tampil(){
            System.out.println("ID produk " + idProduk);


        }
    public static void main(String[] args) {
        // TODO code application logic here
        CPU cpu1 = new CPU(1);
        cpu1.Tampil();
    }

}
