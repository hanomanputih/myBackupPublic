/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package multiclass;

/**
 *
 * @author Praktikan
 */
public class ram {
 int kapasitas ;

    ram (int kapasitas){

    }

}
