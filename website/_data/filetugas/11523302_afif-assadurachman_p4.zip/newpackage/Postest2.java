package newpackage;


public class Postest2 {
    
    String nama = "afif assadurachman";
    int nim = 11523302;
    public static void main (String [] args) {
    Postest2 p = new Postest2();
    }
    public void cetak ();
    { 
        
        System.out.print("nama saya adalah"+nama);
        System.out.print("NIM saya adalah"+nim);
    
    }
}
