
package posttest;

public class Posttest {


    public static void main(String[] args) {
        
        Komputer K = new Komputer("Toshiba");
        K.Tampil();
    }
}
