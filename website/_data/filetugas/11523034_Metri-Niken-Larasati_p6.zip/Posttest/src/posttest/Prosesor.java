
package posttest;


public class Prosesor {
        int type;
    
        void Tampil(){
          System.out.println("Tipe Prosesor : " +type);
             }
        public Prosesor (int tipe){
          this.type = tipe;
             }
    
}
