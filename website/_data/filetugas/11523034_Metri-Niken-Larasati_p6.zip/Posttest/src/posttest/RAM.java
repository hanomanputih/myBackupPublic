
package posttest;


public class RAM {
    int type;
    
    void Tampil(){
        System.out.println("Tipe RAM : " +type);
    }
          public RAM (int tipe){
          this.type = tipe;
    }
}
