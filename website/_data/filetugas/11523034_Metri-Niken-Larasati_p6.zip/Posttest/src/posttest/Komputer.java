
package posttest;


public class Komputer {
    String nama;
    
    private Prosesor p;
    private RAM R;
    
    public Komputer (String nama){
        this.nama = nama;
        if (nama.equals("Toshiba")){
            p = new Prosesor (142);
            R = new RAM (12);
        }

    }
    void Tampil(){
        System.out.println("Nama Komputer : " + nama);
        System.out.println("Tipe Prosesor : " + p.type);
        System.out.println("Tipe RAM : " + R.type);
        
    }
    
}
