/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

/**
 *
 * @author Praktikan
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Karyawan k = new Karyawan ();
       k.setNip("1234567891");
       k.setNama("Miftakhurrokhman");
       k.setGaji(300000);
       
        System.out.println("nip karyawan : "+k.getNip());
        System.out.println("nama karyawan : "+k.getNama());
        System.out.println("gaji karyawan : "+k.getGaji()*12);
    }
}
