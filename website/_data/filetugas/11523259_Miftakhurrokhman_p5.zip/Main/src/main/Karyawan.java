/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

/**
 *
 * @author Praktikan
 */
public class Karyawan {
    private String nip;
    private String nama;

    public int getGaji() {
        return gaji;
    }

    public void setGaji(int gj) {
        if ((gj >=100000) && (gj <= 500000)){
            this.gaji = gj;
        }else{
            System.out.println("Gaji tidak sesuai");
        }
        
    }
    private int gaji;
    
    void setNip(String Np){
        nip = Np;
       if (Np.length() == 10 ){
           System.out.println(nip);
       }else{ 
           System.out.println("nip tdak sesuai");
       }
    }
   String getNip(){
        return nip;
        
    }
    void setNama (String Nm){
        nama = Nm;
        if (Nm.length() >= 8){
            System.out.println(nama);
    }else{
            System.out.println("kurang dari delapan bos");
    }
    
}
 String getNama(){
        return nama;
 }
}



 
 
