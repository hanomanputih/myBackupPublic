/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author Praktikan
 */
public class Karyawan {
    private String nip;
    private String nama;
    private int gaji;
    
    public void setNIP(String n) {
        nip = n;
}
    
    public String getNIP(){
        return nip;
    }
    
    public void setNAMA(String m) {
        nama = m;
    }
    
    public String getNAMA(){
        return nama;
    }
    
    public void setGAJI(int o){
        gaji = o;
    }
    
    public int getGAJI(){
        return gaji;
    }
}


