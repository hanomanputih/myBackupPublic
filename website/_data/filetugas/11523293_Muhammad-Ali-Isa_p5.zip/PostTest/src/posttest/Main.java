/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author Praktikan
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    
    
    public static void main(String[] args) {
        // TODO code application logic here
        Karyawan kryw = new Karyawan();
        kryw.setNIP("1309069366");
        kryw.setNAMA("Agus");
        kryw.setGAJI(50000000);
        System.out.println("NIP   : "+kryw.getNIP());
        System.out.println("Nama  : "+kryw.getNAMA());
        System.out.println("Gaji  : "+kryw.getGAJI());
    }
}
