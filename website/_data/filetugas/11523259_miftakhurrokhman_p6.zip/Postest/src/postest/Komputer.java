/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

/**
 *
 * @author Praktikan
 */
public class Komputer {

    Ram rm;
    Prosesor pr;
  
    public Komputer (String nmRam, String nmPr){
        if (nmRam.equals("2")){
        rm = new Ram ("1024");
        }
        if (nmPr.equals("7")){
            pr = new Prosesor("amd turion");
        }
        else{
            System.out.println("Jangan Ngaco Deh....");
        }
    }
    public static void main(String[] args) {
       Komputer k = new Komputer ("2","7");
       k.rm.tampilRam();
       k.pr.tampilPros();
    }
}
