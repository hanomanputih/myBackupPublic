/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

/**
 *
 * @author Praktikan
 */
public class Ram {
     String namaRam;

public Ram (String namaRam){
    this.namaRam = namaRam;
    }

    public void tampilRam(){
        System.out.println("kapasitas ram = " + namaRam);
    }
}