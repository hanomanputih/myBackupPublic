/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gue;

/**
 *
 * @author Praktikan
 */
public class Gue {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Karyawan guwe = new Karyawan();
        guwe.setNama("Gue");
        guwe.setNip("123456789");
        guwe.setGaji(1234567);
        System.out.println("Nama : "+guwe.getNama());
        System.out.println("NIP : "+guwe.getNip());
        System.out.println("Gaji : "+guwe.getGaji());
    }
}
