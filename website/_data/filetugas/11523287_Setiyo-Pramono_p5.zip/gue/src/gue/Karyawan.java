/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gue;

/**
 *
 * @author Praktikan
 */
public class Karyawan {
    private String nip ;
    private String name ;
    private int gaji;
    
    public void setNip(String nip){
        this.nip = nip;
    }
    public void setNama(String nama){
        this.name = nama;
    }
    public void setGaji(int gaji){
        this.gaji = gaji;
    }
    
    public String getNip(){
        return nip;
    }
    public String getNama(){
        return name;
    }
    public int getGaji(){
        return gaji*12;
    }
}
