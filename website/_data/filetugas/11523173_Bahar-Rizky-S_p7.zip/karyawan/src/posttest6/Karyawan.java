/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest6;

/**
 *
 * @author Praktikan
 */
public abstract class Karyawan {
    public int gajipokok =3000000;
    public int tunjangan =600000;
    public int bonus =300000;
    public int gaji;
    public void view(){
        
    }
public abstract void gaji();     
}
