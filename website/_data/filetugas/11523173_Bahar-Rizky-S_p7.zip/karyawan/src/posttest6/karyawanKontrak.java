/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest6;

/**
 *
 * @author Praktikan
 */
public class karyawanKontrak extends Karyawan{
    
    @Override
    public void gaji() {
        gaji= gajipokok + bonus;
      System.out.println("Gaji Karyawan kontrak :"+ gaji);
    }
}
