;/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest6;

/**
 *
 * @author Praktikan
 */
public class classmain {
    
    
    public static void main(String[] args) {
        karyawanTetap kt = new karyawanTetap();
        kt.gaji();
        System.out.println("gaji pokok : "+kt.gajipokok); 
        System.out.println("tunjangan : "+kt.tunjangan);
        System.out.println("bonus : "+kt.bonus); 
        System.out.println("============================");
        karyawanKontrak kk = new karyawanKontrak();
        kk.gaji();
        System.out.println("gaji pokok : "+kt.gajipokok); 
        System.out.println("bonus : "+kt.bonus); 
        
    }
}
