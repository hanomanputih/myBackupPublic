/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest6;

/**
 *
 * @author Praktikan
 */
public class karyawanTetap extends Karyawan{

 
    @Override
    public void gaji() {
        gaji= tunjangan + gajipokok + bonus;
      System.out.println("Gaji Karyawan Tetap :"+ gaji);
    }
    
}
