/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author PRAKTIKAN
 */
public class main {
    public static void main(String[] args) {
        karyawan ma = new karyawan();
        ma.setNIP("11523140");
        System.out.println("NIP : "+ma.getNIP());
        ma.setNAMa("Azimatul Khusniah");
        System.out.println("NAMA : "+ma.getNAMA());
        ma.setGAJI(5000000);
        System.out.println("GAJI SETAHUN : "+ma.getGAJI());
        
    }
}
