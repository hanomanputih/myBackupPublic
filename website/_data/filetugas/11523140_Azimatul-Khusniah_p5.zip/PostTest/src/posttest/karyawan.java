/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author PRAKTIKAN
 */
public class karyawan {
    private String nip;
    private String nama;
    private int gaji;
    
  
    void setNIP(String ni){
      if(ni.length()==8){
          nip = ni;
      }else {
          System.out.println("Rusaaakkk..");
      }
  }
  void setNAMa (String nama){
      this.nama=nama;
  }
  void setGAJI (int gaji){
      this.gaji=gaji*12;
  }
String getNIP(){
    return nip;
}
String getNAMA(){
    return nama;
}
int getGAJI(){
    return gaji;
}
  
}