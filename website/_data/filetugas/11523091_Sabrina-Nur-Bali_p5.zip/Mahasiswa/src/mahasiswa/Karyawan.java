/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

/**
 *
 * @author Praktikan
 */
public class Karyawan {
    private String nip;
    public String nama;
    private int gaji;
 
public void setNip(String _nip){
    if (_nip.length() == 8 ){
        nip = _nip;
    } else {
        System.out.println("NIP tidak sesuai");
    }
}    

public void setNama(String _nama){
    if (_nama.length() <= 20){
        nama = _nama;        
    } else {
        System.out.println("Nama tidak boleh kosong");
    }
}

public void setGaji(int _gaji){
    if (_gaji >= 5000000){
        gaji = 12 * _gaji;
    } else {
        System.out.println("Gaji tidak sesuai");
    }
}

public String getNip(){
    return nip;
}

public String getNama(){
    return nama;
}

public int getGaji(){
    return gaji;
}
    
}