/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest11523234;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        List data = new ArrayList();
        System.out.print("NIM  : ");
        data.add(sc.nextInt());
        System.out.print("NAMA : ");
        data.add(sc.next());
        System.out.println(data);
        System.out.println("Index ke-2 : "+data.get(1));
        System.out.println("-------------------");
        Iterator it = data.iterator();
        while(it.hasNext()){
            System.out.println(it.next());
        }
        System.out.println("-------------------");
        Map<Integer,String> data2 = new HashMap<Integer,String>();
        data2.put(sc.nextInt(), sc.next());
        for(Map.Entry<Integer,String> tampil : data2.entrySet()){
            System.out.println(tampil.getKey()+". "+tampil.getValue());
            System.out.println(tampil.getValue());
        }
    }
}
