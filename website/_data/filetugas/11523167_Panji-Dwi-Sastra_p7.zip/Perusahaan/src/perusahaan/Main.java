/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package perusahaan;

/**
 *
 * @author PRAKTIKAN
 */
public class Main {
    
    public static void main(String[] args) {
    KaryawanTetap kt = new KaryawanTetap ();
    KaryawanKontrak kk = new KaryawanKontrak ();
   
        System.out.println("Gaji karyawan tetap: "+kt.gaji());
        System.out.println("Gaji karyawan kontrak: "+kk.gaji());
    }
}
