package perusahaan;

public abstract class Karyawan {

    int gajiPokok = 3000000 ;
    int bonus = 5123000;
        
public abstract int gaji(); 
    
}
