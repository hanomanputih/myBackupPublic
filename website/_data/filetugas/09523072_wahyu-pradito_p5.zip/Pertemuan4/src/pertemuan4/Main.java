/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan4;

/**
 *
 * @author PRAKTIKAN
 */
public class Main {
    public static void main(String[] args){
        Mahasiswa ma = new Mahasiswa();
        // ma.nim = "09523072565968675";
        ma.setNIM("095230728");
        System.out.println("NIM ="+ma.getNIM());
}
}