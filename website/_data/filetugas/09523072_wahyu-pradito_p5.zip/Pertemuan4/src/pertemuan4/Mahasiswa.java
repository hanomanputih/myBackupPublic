/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan4;

/**
 *
 * @author PRAKTIKAN
 */
public class Mahasiswa {
   private String nim;
   
   void setNIM(String ni){
       if(ni.length() == 8){
           nim = ni;
          
       }else {
           System.out.println("Error..");
       }
   }
   String getNIM(){
       return nim;
   }
}
