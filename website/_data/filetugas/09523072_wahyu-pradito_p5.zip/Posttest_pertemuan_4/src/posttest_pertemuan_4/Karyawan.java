/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest_pertemuan_4;

/**
 *
 * @author PRAKTIKAN
 */
public class Karyawan {
    private String nip;
    private String nama;
    private int gaji;
    
    public void setGAJI (double gaji){
        gaji = (int)gaji;
    }
    
}