package postest;

public class RAM {

    String NamaRAM;
    public RAM(String NamaRAM) {
       this.NamaRAM = NamaRAM;
    }
    public void tampiRAM() {
        System.out.println("Nama RAM : " + NamaRAM);
    }
}