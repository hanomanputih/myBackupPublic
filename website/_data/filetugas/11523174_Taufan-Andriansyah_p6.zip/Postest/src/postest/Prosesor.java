package postest;

public class Prosesor {

    String Prosesor;
    public Prosesor(String Prosesor) {
       this.Prosesor = Prosesor;
    }
    public void tampiProsesor() {
        System.out.println("Nama Prosesor : " + NamaProsesor);
    }
}