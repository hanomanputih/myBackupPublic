package postest;

public class Komputer {

    String NamaKom;
    public Komputer(String NamaKom) {
       this.NamaKom = NamaKom;
    }
    public void tampiKom() {
        System.out.println("Nama Komputer : " + NamaKom);
    }
}