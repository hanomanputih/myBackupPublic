package postest;

public class Postest {
    private String NamaKom;
    private Prosesor p;
    Private RAM r;

    public postest(String NamaKom) {
        this.NamaKom = NamaKom;
        if (NamaKom.equals("Prosesor")) {
            p = new Prosesor("RAM");
            
        }
    }
    
    public void TampilKom() {
        System.out.println("Nama Komputer : " + NamaKom);
        System.out.println("Nama Prosesor : " + p.Prosesor);
    }
}
