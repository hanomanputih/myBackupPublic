/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mahasiswa;

import java.util.Scanner;

public class Mahasiswa {

 String nama, nim, fakultas, jurusan, angkatan;
 
 void isi(){
    Scanner read= new Scanner(System.in);
    System.out.println("inputkan nama :");
    nama = read.next();
    System.out.println("inputkan nim :");
    nim=read.next();
     System.out.println("inputkan fakultas :");
     fakultas=read.next();
     System.out.println("inputkan jurusan :");
     jurusan=read.next();
     System.out.println("inputkan angkatan :");
     angkatan=read.next();
}
 
 void cetak(){
     System.out.println("nama : "+nama);
     System.out.println("nim : "+nim);
     System.out.println("fakultas : "+fakultas);
     System.out.println("jurusan : "+jurusan);
     System.out.println("angkatan : "+angkatan);
 }
 
    public static void main(String[] args) {
        Mahasiswa mhs= new Mahasiswa();
      
        
        mhs.isi();
        mhs.cetak();
    }
}
