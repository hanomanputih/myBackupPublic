/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes5;

/**
 *
 * @author Praktikan
 */
public class Prosesor {
    String NamaPro;
  
    public Prosesor (String NamaPro) {
        this.NamaPro = NamaPro;
    }
    public void tampilPro () {
        System.out.println("Nama Prosesor" + NamaPro);
    }
}

