/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postes5;

/**
 *
 * @author Praktikan
 */
public class Komputer {
    String namaKomp;
    private Prosesor p;
    private Ram r;
    
    public Komputer(String komp,String prosesor, String ram) {
        this.namaKomp= komp;
        if(prosesor.equals("intel") && ram.equals("vgen")){
        r = new Ram("vgen");
        p = new Prosesor("intel");
    }
    }
    
    public void TampilKomp(){
      System.out.println("Nama Kompuer :" +namaKomp);
      System.out.println("Nama Prosesor:" +p.NamaPro);
      System.out.println("Nama Ram:" +r.NamaRam);
    }
    public static void main(String[] args) {
        Komputer un = new Komputer("Komputer hebat","intel","vgen");
        
        un.TampilKomp();
        
    }
}
