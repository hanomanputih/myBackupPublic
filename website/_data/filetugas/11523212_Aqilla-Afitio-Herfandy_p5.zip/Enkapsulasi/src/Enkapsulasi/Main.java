/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Enkapsulasi;


public class Main {
    public static void main(String[] args) {
        Karyawan k = new Karyawan ();
        k.setGaji(200000);
        k.setNama("liobai");
        k.setNip("N1E3R4");
        
        System.out.println("Nama    =" +k.getNama());
        System.out.println("NIP     =" +k.getNip());
        System.out.println("gaji    =" +k.getGaji());
    }
}
