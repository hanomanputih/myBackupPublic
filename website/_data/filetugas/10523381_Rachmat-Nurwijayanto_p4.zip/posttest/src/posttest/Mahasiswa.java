/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

import java.util.Scanner;

/**
 *
 * @author PRAKTIKAN
 */
public class Mahasiswa {
    String nama, nim, fakultas, jurusan, angkatan;
    
    void s(){
        Scanner l =new Scanner(System.in);
        System.out.println("nama mahasiswa: ");
        nama = l.nextLine();
        System.out.println("nim mahasiswa: ");
        nim = l.nextLine();
        System.out.println("fakultas mahasiswa: ");
        fakultas = l.nextLine();
        System.out.println("jurusan mahasiswa: ");
        jurusan = l.nextLine();
        System.out.println("angkatan mahasiswa: ");
        angkatan = l.nextLine();
                
    }
    
    
    void cetak(){
        System.out.println("nama mahasiswa: "+nama);
        System.out.println("nim mahasiswa: "+nim);
        System.out.println("fakultas mahasiswa: "+fakultas);
        System.out.println("jurusan mahasiswa: "+jurusan);
        System.out.println("angkatan mahasiswa: "+angkatan);
    }
    
    public static void main(String[] args) {
        Mahasiswa s = new Mahasiswa();
        s.s();
        s.cetak();
        
    }
    
}
