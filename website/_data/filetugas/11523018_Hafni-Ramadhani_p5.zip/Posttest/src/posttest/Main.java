/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author Praktikan
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Karyawan kr = new Karyawan();
//        kr.setnip("11523279");
//        kr.setnama ("hafni");
        kr.setgaji (30000);
//        System.out.println("NIP = "+kr.getnip());
//        System.out.println("Nama = "+kr.getnama());
        System.out.println("Gaji = "+kr.getgaji());
    }
}
