/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author Praktikan
 */
public class Karyawan {
    private String nip;
    private String nama;
    private int gaji;
    
    void setnip (String uni){
    if (uni.length() == 8) {
        nip = uni;
    }
    else {
        System.out.println("salah wee");
    }
  }
    String getnip() {
        return nip;
    }
    
    void setnama (String cia){
    if (cia.length() == 5) {
        nama = cia;
    }
    else {
        System.out.println("salah wee");
    }
  }
    String getnama() {
        return nama;
    }
    
    void setgaji (int dede){
    if (dede < 3000000) {
        gaji = dede;
    }
    else {
        System.out.println("salah wee");
    }
  }
    int getgaji() {
        return gaji;
}
}
    