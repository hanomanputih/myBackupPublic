/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest8;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author Praktikan
 */
public class PostTest8 {
    private static void LoadData(List<String>list){
        list.add("mei");
        list.add("11523267");
    }
    private static void tampilkanList(List<String>list){
        for (Iterator<String> iterator= list.iterator();
        iterator.hasNext();) {
            String isi = iterator.next();
            System.out.println(isi);
        }
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        List<String>list = new ArrayList<String>();
LoadData(list);
tampilkanList(list);
        // TODO code application logic here
    }
}
