/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest8;
import java.util.HashMap;

/**
 *
 * @author Praktikan
 */
public class Map {
    public static void main(String[] args) {
        HashMap map = new HashMap();
        map.put ("Nama", "mei");
        map.put ("nim", new Integer(11523267));
        System.out.println(map);
        System.out.println("ukuran map: "+ map.size());
        boolean containKey = map.containsKey("nim");
        System.out.println("has key (nim): "+containKey);
        Object removed = map.remove ("nim");
        System.out.println("remove : "+removed);
        System.out.println(map);
        System.out.println("ukuran map baru: "+map.size());
    }
}
    

