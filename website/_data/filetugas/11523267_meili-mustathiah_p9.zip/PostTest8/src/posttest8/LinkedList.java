/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest8;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;


/**
 *
 * @author Praktikan
 */
public class LinkedList {
    public static void main(String[] args) {
        List<String> list = new java.util.LinkedList<String>();//deklarasi
        list.add("mei");
        list.add("11523267");//memasukkan data
        
        System.out.println("data List --> "+ list.size());//jumlah data
        Collections.sort(list);//mensortir data
        
        for (Iterator<String> iterator= list.iterator();
        iterator.hasNext();) {//untuk lihat isi list
            String isi = iterator.next();
            System.out.println(isi);
        }
    }
    
}
    

