/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.HashMap;
import java.util.Scanner;
/**
 *
 * @author Praktikan
 */
public class PostTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        List nama = new ArrayList();
        List alamat = new ArrayList();
        
        nama.add("budi");
        nama.add("anton");
        
        alamat.add("jalan durian runtuh");
        alamat.add("jalan mangga montong");
        
        Iterator it = nama.iterator();
        while(it.hasNext()){
            System.out.println(it.next());
        }
        System.out.println("----------------------------");
        Iterator ite = alamat.iterator();
        while(ite.hasNext()){
            System.out.println(ite.next());
        }
        System.out.println("---------------------------");
        Map<String,String> mhs = new HashMap<String,String>();
        mhs.put("budi","jalan durian runtuh");
        mhs.put("anton","jalan mangga montong");
        
        for(Map.Entry<String,String> e : mhs.entrySet()){
            System.out.println(e.getKey()+" , "+e.getValue());
        } 
        System.out.println("---------------------------");
        System.out.println(mhs);
        System.out.println(mhs.get("anton"));
        
        }
}
