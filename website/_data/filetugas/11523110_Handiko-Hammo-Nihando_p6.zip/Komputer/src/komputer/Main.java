/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class Main {
    
    public static void main(String[] args) {
        
        Processor p = new Processor();
        
        Komputer k = new Komputer(p);
        
        System.out.println("");
    }
}
