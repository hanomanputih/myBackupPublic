/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class Komputer {
    private Processor psr;
    private Ram ram;

    public Komputer(Processor psr){
    this.psr = psr;
    }
}
