/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mobil;

/**
 *
 * @author Praktikan
 */
public class Main {
    
    public static void main(String[] args) {
       
        Mesin m = new Mesin();
        
        Mobil m1 = new Mobil(m);
    }
}
