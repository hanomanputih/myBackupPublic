/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class Pemanggil {
 public static void main (String[]args){
    Karyawan kry = new Karyawan ();
         
         // mhs.setNim=11523219
         kry.setNama("wewe");
         
         kry.setNip ("11523219");
         
         kry.setGaji (1000);
                 
         System.out.println("nip :"+kry.getNip());
         System.out.println ("nama :"+kry.getNama());
         System.out.println ("gaji :"+kry.getGaji());

 }
}