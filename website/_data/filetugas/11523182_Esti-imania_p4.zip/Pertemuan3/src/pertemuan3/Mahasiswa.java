/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan3;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
   String NIM = "11523182";
   String nama = "Esti" ;
   String jurusan = "Teknik Informatika";
   String fakultas = "Teknik industri";
   String angkatan = "2011";
   
   
public void cetak (){
    System.out.println("NIM "+NIM);
    System.out.println("nama"+nama);
    System.out.println("jurusan"+jurusan);
    System.out.println("fakultas"+fakultas);
    System.out.println("angkatan"+angkatan);
    
}
    public static void main(String[] args) {
        Mahasiswa mh = new Mahasiswa();
        mh.cetak();
    }
        
    }
    
    
   
    }
    
        

}
