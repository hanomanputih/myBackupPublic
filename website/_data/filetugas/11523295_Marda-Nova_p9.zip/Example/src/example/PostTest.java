package example;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class PostTest {

    public static void loadData(List<String> list) {
    Scanner n = new Scanner(System.in);
    System.out.println("masukkan nama : ");
    list.add(n.next());
    System.out.println("masukkan nim : ");
    list.add(n.next());
    
    for (Iterator<String> iterator = list.iterator(); 
        iterator.hasNext();){
    String isi = iterator.next();
    System.out.println(isi);
    System.out.println("index ke 2"+list.get(1));
    
        HashMap map = new HashMap();
    map.put("Nama",n.next());
    map.put("NIM", n.next());
    System.out.println(map);
    System.out.println("Ukuran Map : " + map.get(1));
    System.out.println("nim : " + map.get("nim"));
    }
    }
    
     public static void main(String[] args) {
        List<String> list = new ArrayList<String>();
        loadData(list);
        tampilkanList (list);
        System.out.println("list di index ke 2 = " + list.get(1));
    }
    public static void tampilkanList(List<String> list) {
        for (int i = 0; i < list.size (); i++) {
            System.out.print(list.get(i) + " "); 
        }
         System.out.println();    
         
    }
    }
