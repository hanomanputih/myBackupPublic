/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class Komputer {

    /**
     * @param args the command line arguments
     */
    String merkom;
    private Prosessor p;
    
    public Komputer(String merkom){
    this.merkom=merkom;
    if(merkom.equals("HAND MADE")){
        p = new Prosessor("INTEL");
    }
    }
    public void tamkom(){
        System.out.println("merek komputer gue tu "+merkom);
        p.tampro();
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
    Komputer k= new Komputer("HAND MADE");
    k.tamkom();
    }
}
