/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class Ram {
    String merram;
    
    public Ram(String merram){
    this.merram=merram;}
    
   public void tamram(){
       System.out.println("RAM gue tu " +merram);
   }
}
