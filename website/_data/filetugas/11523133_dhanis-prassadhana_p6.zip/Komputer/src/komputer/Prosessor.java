/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package komputer;

/**
 *
 * @author Praktikan
 */
public class Prosessor {

    String merpro;
    private Ram r;

    public Prosessor(String merpro) {
        this.merpro = merpro;
        if (merpro.equals("INTEL")) {
        r = new Ram("QUADRA");
        }
    }
    public void tampro(){
        System.out.println("prosessor gue tu " +merpro);
        System.out.println("kalo RAM gue " +r.merram);
    }
    
}
