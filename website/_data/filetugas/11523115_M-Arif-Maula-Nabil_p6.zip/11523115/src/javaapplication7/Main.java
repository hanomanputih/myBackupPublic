/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javaapplication7;

/**
 *
 * @author Praktikan
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        RAM r = new RAM();
        r.kapasitas="5MB";
        PROSESOR p = new PROSESOR();
        p.tipe="DualCore";
        Komputer k = new Komputer(r , p);
k.tampil();
    }

}
