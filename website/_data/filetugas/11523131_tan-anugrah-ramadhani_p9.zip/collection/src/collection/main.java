/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package collection;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author PRAKTIKAN
 */
public class main {
    public static void main (String[] args){
        
        List <String> mahasiswa =new ArrayList <String>();
        List <Integer> nim = new ArrayList<Integer>();
        nim.add(11523131);
        mahasiswa.add ("tan");
        System.out.println(mahasiswa);
        System.out.println(nim);
        
    }
    
}
