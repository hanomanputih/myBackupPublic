/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package mahasiswa;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
    String nama, nim;

    void isi(){
    nama = "ilul";
    nim = "09523270";

    }
    void cetak(){
        System.out.println("nama "+ nama);
        System.out.println("nim "+ nim);
    }
    public static void main(String[] args) {
        Mahasiswa mhs = new Mahasiswa();
        mhs.isi();
        mhs.cetak();

    }

}
