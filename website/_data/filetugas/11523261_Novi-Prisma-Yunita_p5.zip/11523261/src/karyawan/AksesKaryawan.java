/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class AksesKaryawan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        KelasKaryawan kar = new KelasKaryawan ();
        
        kar.setNip("11923421");
        System.out.println("Nomor indukpegawai anda adalah "+kar.getNip());
        
        kar.setNama("Novi Prisma Yunita");
        System.out.println("Nama anda adalah "+kar.getNama());
        
        kar.setGaji(10000);
        System.out.println("Gaji anda adalah "+kar.getGaji());  
    }
}
