/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class KelasKaryawan {

    private String nip, nama;
    private int gaji;

    void setNip(String nip) {
        if (nip.length() == 8) {
            this.nip = nip;
        } else {
            System.out.println("Error");
        }
    }

    String getNip() {
        return nip;
    }

    void setNama(String nama) {
        if (nama.length() < 3) {
            System.out.println("Bukan nama nih");
        } else {
            this.nama = nama;
        }
    }

    String getNama() {
        return nama;
    }

    void setGaji(int gaji) {
        if (gaji < 10000) {
            System.out.println("Error");
        } else {
            this.gaji = gaji;
        }
    }

    int getGaji() {
        return gaji;
    }
}
