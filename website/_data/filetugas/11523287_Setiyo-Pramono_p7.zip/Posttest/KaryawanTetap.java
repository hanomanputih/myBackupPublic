/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Posttest;

/**
 *
 * @author Adipati
 */
public class KaryawanTetap extends Karyawan{
    int tunjangan = (int) (0.2*gajiPokok);
    int bonus = (int)(0.1*gajiPokok);
    int gaji = tunjangan+bonus+gajiPokok;
    
    @Override
    public void gaji() {
        System.out.println("Gaji Karyawan Tetap : "+gaji);
    }
    
    
}
