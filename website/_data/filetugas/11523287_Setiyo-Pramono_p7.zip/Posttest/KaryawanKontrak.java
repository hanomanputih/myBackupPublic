/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Posttest;

/**
 *
 * @author Adipati
 */
public class KaryawanKontrak extends Karyawan{
    int bonus = (int) (0.1*gajiPokok);
    int gaji = bonus+gajiPokok;
    @Override
    public void gaji() {
        System.out.println("Gaji Karyawan Kontrak : "+gaji);
    }
    
}
