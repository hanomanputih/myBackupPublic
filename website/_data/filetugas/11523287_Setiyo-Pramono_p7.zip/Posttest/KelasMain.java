package Posttest;

/**
 *
 * @author Adipati
 */
public class KelasMain {
    public static void main(String[] args) {
        KaryawanTetap karate = new KaryawanTetap();
        KaryawanKontrak kakont = new KaryawanKontrak();
        
        karate.gaji();
        kakont.gaji();
    }
}
