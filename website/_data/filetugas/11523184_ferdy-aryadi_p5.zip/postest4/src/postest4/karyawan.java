/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest4;

/**
 *
 * @author PRAKTIKAN
 */
public class karyawan {
    private String nip;
    private String nama;
    private int gaji;
    
    public void setNIP (String nip){
        this.nip = nip; 
    }
    public void setnama(String NM){
        nama = NM;
    }
    public void setgaji (int Gaji){
        gaji = 12*Gaji;
    }
    public String getNIP(){
        return nip;
    }
    public String getnama(){
        return nama;
    }
    public int getgaji(){
        return gaji;
    }
    public void tampil(){
        System.out.println("nama    ="+getnama());
        System.out.println("NIP     ="+getNIP());
        System.out.println("gaji    ="+getgaji());
    }
}
