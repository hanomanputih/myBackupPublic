/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest4;

/**
 *
 * @author PRAKTIKAN
 */
public class main {
    public static void main(String[] args) {
        karyawan k = new karyawan();
        k.setNIP("1153184");
        k.setnama("coba");
        k.setgaji(1000000);
        k.tampil();
    }
}
