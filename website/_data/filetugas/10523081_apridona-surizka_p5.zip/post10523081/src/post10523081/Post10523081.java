/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package post10523081;

/**
 *
 * @author Praktikan
 */
public class Post10523081 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        karayawan o = new karayawan();
        o.setnip ( "1000");
       o.setnama("MALEEESSSSS..!!! bangettzz");
       o.setgaji(1230000 *12);
       
        System.out.println("nip : "+o.getnip());
        System.out.println("nama : "+o.getnama());
        System.out.println("gaji setaun : "+o.getgaji());
    }
}
