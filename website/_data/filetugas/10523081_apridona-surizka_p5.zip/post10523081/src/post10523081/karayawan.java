/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package post10523081;

/**
 *
 * @author Praktikan
 */
public class karayawan {
    private String nama,nip;
    private int gaji;
    
    void setnama (String n){
        nama=n;
        
        if(n.length () ==8){
            System.out.println("nama benar");
            }
        else{
            System.out.println("nama situ kelebihan!! ");
            
        }
    }
    
    String getnama(){
        return nama;
    }
    

    void setnip (String n){
        nip=n;
        if(n.length () ==10){
            
            }else{
            System.out.println("nim salah :p ");
            
}
    }
    
    
    
    String getnip(){
        return nip;
    }
   
    void setgaji (int n){
        gaji=n;
        
    }
    
    
    
    int getgaji(){
        return gaji;}
        
        
        
        
   
}
  
