/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package postest;

/**
 *
 * @author Praktikan
 */
import java.util.Scanner;
public class Mahasiswa {
    String nama ;
    String NIM, fakultas, jurusan, angkatan;
    
    void cetak(){
        System.out.println("nama saya: "+nama);
        System.out.println("NIM saya: "+NIM);
        System.out.println("faklultas: "+fakultas);
        System.out.println("jurusan: "+jurusan);
        System.out.println("angkatan: "+angkatan);
    }
            
    public static void main(String[] args) {
        Mahasiswa gg=new Mahasiswa();
        Scanner mm=new Scanner(System.in);
        System.out.println("nama saya: ");
        gg.nama=mm.nextLine();
        System.out.println("NIM saya: ");
        gg.NIM=mm.nextLine();
        System.out.println("fakultas: ");
        gg.fakultas=mm.nextLine();
        System.out.println("jurusan: ");
        gg.jurusan=mm.nextLine();
        System.out.println("angkatan: ");
        gg.angkatan=mm.nextLine();
        gg.cetak();
        
    }
}
