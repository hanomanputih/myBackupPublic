/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pewarisan;

/**
 *
 * @author Praktikan
 */
public class KaryawanTetap extends Karyawan {

    int tunjangan = gajipokok*20/100;
    
    @Override
    public void gaji() {
        gaji = tunjangan + gajipokok + bonus;
        System.out.println("Gaji Karyawan Tetap adalah " + gaji);
    }
}