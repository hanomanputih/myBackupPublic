/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pewarisan;

/**
 *
 * @author Praktikan
 */
public abstract class Karyawan {
    int gajipokok = 3000000;
    int gaji;
    int bonus=200000;
    
public void gaji (){   
}
}