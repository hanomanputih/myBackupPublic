/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest7;

/**
 *
 * @author PRAKTIKAN
 */
public class PostTest7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Swalayan s;
        Indomaret i=new Indomaret();
        TokoAgung ta=new TokoAgung();
        
        s=i;
        s.pembayaran();
        System.out.println("Pembayran pada Toko Indomaret : "+s.bayar);

        
        s=ta;
        s.pembayaran();
        System.out.println("Pembayran pada Toko Agung : "+s.bayar);

    }
}
