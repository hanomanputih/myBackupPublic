/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest7;

/**
 *
 * @author PRAKTIKAN
 */
public class Indomaret extends Swalayan {
    
    
    @Override
    void pembayaran(){
        if (harga%25==0){
            harga=bayar;
        }
        else{
            sisa=(int) (25-(harga%25));
            bayar=(int) (harga+sisa);
        }
    }
    
}
