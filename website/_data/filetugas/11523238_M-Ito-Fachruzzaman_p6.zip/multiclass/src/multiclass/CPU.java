/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package multiclass;

/**
 *
 * @author PRAKTIKAN
 */
public class CPU {
    private int noProd;
    private Processor pr;
    private RAM r;
    
    public CPU(int noProd){
        this.noProd = noProd;
        if(noProd == 1){
            pr = new Processor(2);
            r = new RAM(2);
        }
    }
    public void cetak(){
        System.out.println("Nomor Produksi CPU: "+noProd);
        System.out.println("Nomor Produksi Processor: "+pr.no);
        System.out.println("Nomor Produksi RAM: "+r.no);
    }
}
