/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest5;

/**
 *
 * @author Praktikan
 */
public class KOMPUTER {
PROSESOR P;
RAM R;
public String nama;
public KOMPUTER(String ini){
    nama=ini;
    if(nama.equals("1")){
        P = new PROSESOR ("cepat");
        R = new RAM ("besar");
    }
   
}

    public static void main(String[] args) {
        KOMPUTER K=new KOMPUTER ("1");
        System.out.println("jadi PROSESOR KOMPUTER ini "+K.P.kecepatan);
        System.out.println("jadi RAM KOMPUTER ini "+K.R.kapasitas);
    }
}


