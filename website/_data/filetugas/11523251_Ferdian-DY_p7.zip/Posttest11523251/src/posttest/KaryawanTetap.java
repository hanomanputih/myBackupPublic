/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author PRAKTIKAN
 */
public class KaryawanTetap extends Karyawan{
    public String nama = "Ferdian";
    public int tunjangan = 2000000;
    public int gajiTetap;
  
    @Override
    public void Gaji(){
        gajiTetap = tunjangan + gajiPokok + bonus;
        System.out.println("Nama karyawan tetap     : "+nama);
        System.out.println("Gaji tetap anda         : "+gajiTetap);
    }
    
    
}
