/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest;

/**
 *
 * @author PRAKTIKAN
 */
public class KaryawanKontrak extends Karyawan{
    public String nama = "Yuliansyah";
    public int gajiKontrak;
    
    
    @Override
    public void Gaji(){
        gajiKontrak = gajiPokok + bonus;
        System.out.println("Nama karyawan kontrak   : "+nama);
        System.out.println("Gaji kontrak anda       : "+gajiKontrak);
    }  
}
