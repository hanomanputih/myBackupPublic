/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author praktikan
 */
public abstract class Karyawan {
    public abstract void gaji();
    
   
    }

