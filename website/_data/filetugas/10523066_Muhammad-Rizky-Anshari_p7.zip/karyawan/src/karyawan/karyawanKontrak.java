/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author praktikan
 */
public class karyawanKontrak extends Karyawan  {
    private int gaji;
    public int gajiPokok=3000000;
    public int bonus;
    @Override
    public void gaji() {
        gaji = gajiPokok+bonus;
    }
    void view(){
        System.out.println("Gaji Total Karyawan Kontrak : "+gaji);
    }
    
}
