/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author praktikan
 */
public class karyawanTetap extends Karyawan {
    public double gaji;
    public int gajiPokok=3000000;
    public int bonus;
    
    public void gaji(){
        gaji = ((0.2*gajiPokok)+gajiPokok+bonus);
    }
   void view(){
       System.out.println("Gaji Total Karyawan Tetap : "+gaji);
   } 
}
