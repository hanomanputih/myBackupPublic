/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author praktikan
 */
public class main {
    
    public static void main(String[] args) {
        karyawanTetap kT = new karyawanTetap();
        kT.bonus = 2000000;
        kT.gaji();
        kT.view();
        
        
        karyawanKontrak kK = new karyawanKontrak();
        kK.bonus=1000000;
        kK.gaji();
        kK.view();
    }
}
