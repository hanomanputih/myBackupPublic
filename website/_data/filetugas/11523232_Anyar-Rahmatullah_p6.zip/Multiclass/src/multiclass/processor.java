/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package multiclass;

/**
 *
 * @author Praktikan
 */
public class processor {
 String jenis ;

public processor (String jenis){


}

    public String getJenis() {
        return jenis;
    }

    public void setJenis(String jenis) {
        this.jenis = jenis;
    }

}
