/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package multiclass;

/**
 *
 * @author Praktikan
 */
public class Komputer {
  private String Merk;
  private int idProduk;
  private ram ram1;
  private processor P;

    public Komputer(int idProduk){
        this.idProduk = idProduk ;
        if (idProduk == 1 ){
          ram1 = new ram(16);
          P = new processor("intel");
        }}


        public void Tampil(){
            System.out.println("ID produk " + idProduk);


        }
    public static void main(String[] args) {
        // TODO code application logic here
        Komputer cpu1 = new Komputer(1);
        cpu1.Tampil();
    }

}
