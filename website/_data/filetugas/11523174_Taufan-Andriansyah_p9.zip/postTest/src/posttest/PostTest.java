package posttest;

import java.util.ArrayList;
import java.util.List;

public class PostTest {
    private static void loadData(List<String> list) {
        list.add("Taufan");
        list.add("11523174");
        list.add("Abi");
        list.add("11523006");
    }
        public static void tampilkanList(List<String> list) {
        for (int i = 0; i < list.size(); i++) {
            System.out.print(list.get(i) + " ");
    }
        System.out.println();
    }
    public static void main(String[] args) {
        List<String> list = new ArrayList<String>();
        loadData(list);
        tampilkanList(list);
        System.out.println("list di index ke 1 = " + list.get(0) );
    }
}