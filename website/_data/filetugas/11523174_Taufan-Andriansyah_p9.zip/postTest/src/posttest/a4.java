package posttest;

import java.util.HashMap;

public class a4 {
    
    public static void main(String[] args) {
        HashMap map = new HashMap ();
        map.put("Nama ", "Taufan");
        map.put(("Nim "), new Integer(11523174));
        System.out.println(map);
        System.out.println("Ukuran Map : " + map.size());
        boolean containKey = map.containsKey("NIM ");
        System.out.println("Has Key (NIM) : " + containKey);
        Object removed = map.containsKey("NIM");
        System.out.println("Removed : " + removed);
        System.out.println(map);
        System.out.println("Ukuran Map baru : " + map.size());
    }
}