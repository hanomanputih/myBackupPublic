package posttest;
    
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class a3 {
    
    public static void main(String[] args) {
        List<String> list = new LinkedList();
        list.add("-1. joko");
        list.add("-2. jono");
        
        System.out.println("Ukuran List --> " + list.size() );
        Collections.sort(list);
        
        for (Iterator<String> iterator = list.iterator(); iterator.hasNext();)
            {
            String isi = iterator.next();
            System.out.println(isi);
    }
    }
}
