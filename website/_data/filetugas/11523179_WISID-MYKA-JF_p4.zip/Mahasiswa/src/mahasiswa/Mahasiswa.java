
package mahasiswa;


import java.util.Scanner;
 
public class Mahasiswa {

    String nama;
    String nim;
    int jumlah;
    
    String fakultas,jurusan,angkatan;
    
    void cetak(){
        Scanner baca = new Scanner(System.in);
        System.out.println("Masukan Nama anda = ");
        nama = baca.nextLine();
        System.out.println("Masukan Nama NIM = ");
        nim = baca.nextLine();
        System.out.println("Masukan Nama Fakultasmu = ");
        fakultas = baca.nextLine();
        System.out.println("Masukan Nama Jurusanmu = ");
        jurusan = baca.nextLine();
        System.out.println("Masukan Nama Angkatan = ");
        angkatan = baca.nextLine();
        jumlah = nama.length()+fakultas.length()+nim.length()+angkatan.length()+jurusan.length();
         
        
        System.out.println("Nama : "+nama);
         System.out.println("NIM : "+nim);
          System.out.println("Fakultas : "+fakultas);
           System.out.println("Jurusan : "+jurusan);
            System.out.println("Angkatan : "+angkatan);
             System.out.println("Jumlah karakter : "+jumlah);
        
      
      
      
      
      
    }
    public static void main(String[] args) {
        Mahasiswa a = new Mahasiswa();
        a.cetak();
      
    }
     
      
    }

