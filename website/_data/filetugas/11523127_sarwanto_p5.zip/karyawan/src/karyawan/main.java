/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class main {
    public static void main(String[] args) {
        Karyawan k=new Karyawan();
        k.setNIP("11523127");
        k.setnama("sarwanto");
        k.setgaji(1000000);
        System.out.println("nama    "+k.getnama());
         System.out.println("nip    "+k.getNIP());
          System.out.println("gaji  "+k.getgaji());
    }
}
