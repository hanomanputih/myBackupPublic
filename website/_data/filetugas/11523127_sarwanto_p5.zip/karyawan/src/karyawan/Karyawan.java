/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Praktikan
 */
public class Karyawan {

    private String nip;
    private String nama;
    private int gaji;

    public void setNIP(String nip) {
        this.nip = nip;
    }

    public void setnama(String nama) {
        this.nama = nama;

    }
    public void setgaji(int gaji){
        this.gaji=gaji;
    }
public String getNIP(){
    return nip;
}
public String getnama(){
    return nama;
}
     public int getgaji (){
         return gaji*12;
     }  
    public static void main(String[] args) {
        // TODO code application logic here
        
        
    }
    }

/**
 * @param args the command line arguments
 */
