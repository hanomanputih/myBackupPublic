/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package postest;
import java.util.Scanner;
/**
 *
 * @author Praktikan
 */
public class Mahasiswa {
    String nama,fakultas,jurusan, nim;
    int angkatan;
    /**
     * @param args the command line arguments
     */
    void cetak(){
        System.out.println(nama);
        System.out.println(nim);
        System.out.println(jurusan);
        System.out.println(fakultas);
        System.out.println(angkatan);
    }
    public static void main(String[] args) {
        // TODO code application logic here
        Mahasiswa m = new Mahasiswa ();
        Scanner Mahasiswa = new Scanner (System.in);
        System.out.print("masukkan nama ");
        m.nama =Mahasiswa.nextLine();
        System.out.print("masukkan NIM ");
        m.nim =Mahasiswa.nextLine();
        System.out.print("masukkan jurusan ");
        m.jurusan =Mahasiswa.nextLine();
        System.out.print("masukkan fakultas ");
        m.fakultas =Mahasiswa.nextLine();
        System.out.print("masukkan angkatan ");
        m.angkatan =Mahasiswa.nextInt();
        System.out.println("data anda");
        m.cetak();

    }

}
