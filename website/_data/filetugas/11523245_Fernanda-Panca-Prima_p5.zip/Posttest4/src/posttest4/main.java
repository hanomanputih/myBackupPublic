/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest4;

/**
 *
 * @author Fernanda Panca Prima
 */
public class main {
    public static void main(String[] args) {
     karyawan kr = new karyawan();
     kr.setGaji(50000000);
     kr.setNIP("11523245");
     kr.setNama("Fernanda");
        System.out.println("NIP: "+kr.getNIP());
        System.out.println("Nama: "+kr.getNama());
        System.out.println("Gaji: "+kr.getGaji());
    }
    
}
