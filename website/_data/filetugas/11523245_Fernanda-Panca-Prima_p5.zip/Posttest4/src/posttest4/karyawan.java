/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest4;

import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author Fernanda Panca Prima
 */
public class karyawan {
 private String nip;
 private String nama;
 private int gaji;
 
 void setNIP (String nip) {
     this.nip=nip;
}
 
 void setNama (String nama) {
     this.nama=nama;
}
 
void setGaji (int gaji) {
     this.gaji=gaji;
}


    
    
String getNIP(){return nip;}
String getNama(){return nama;}
int getGaji(){return gaji*12;}
}
