/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest.pertemuan.pkg4;

/**
 *
 * @author Praktikan
 */
public class Main {
public static void main(String[] args) {
Karyawan ky= new Karyawan ();
ky.setNIP("11523165");
System.out.println ("NIP = "+ky.getNIP());
ky.setNama("Nabila Sholihah");
System.out.println ("Nama = "+ky.getNama());
ky.setGaji(100000000*12);
System.out.println ("Gaji Setahun = "+ky.getGaji());
}
    
    }

