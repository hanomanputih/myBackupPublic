/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package posttest.pertemuan.pkg4;

/**
 *
 * @author Praktikan
 */
public class PostTestPertemuan4 {
private String NIP;
private String nama;
private int gaji;

    
    public String getNIP() {
        return NIP;
    }

    public void setNIP(String NIP) {
        this.NIP = NIP;
    }

    public int getGaji() {
        return gaji;
    }

    public void setGaji(int gaji) {
        this.gaji = gaji;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }
    
    public static void main(String[] args) {
        
        
    }
}


