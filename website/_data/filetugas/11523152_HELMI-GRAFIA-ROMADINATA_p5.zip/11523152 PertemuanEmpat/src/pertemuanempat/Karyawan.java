/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuanempat;

/**
 *
 * @author Praktikan
 */
public class Karyawan {
    private String nip;
    private String nama;
    private int gaji;
    
public void setNIP (String nomer)
        {
            nip=nomer;
        }
public String getNIP ()
        {
            return nip;
        }
public void setNAMA (String nama)
        {
            this.nama=nama;
        }
public String setNAMA ()
        {
            return nama;
        }
public void setGaji (int gaji)
        {
            this.gaji=gaji;
        }
public int setGaji ()
        {
            return gaji;
        }
}
