/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuanempat;

/**
 *
 * @author Praktikan
 */
public class Panggil {
    public static void main(String[] args) {
        Karyawan kry = new Karyawan ();
        kry.setNIP("11523152");
        kry.setNAMA("Helmi");
        kry.setGaji(2000000);
        System.out.println(kry.getNIP());
        System.out.println(kry.setNAMA());
        System.out.println(kry.setGaji());
    }
}
