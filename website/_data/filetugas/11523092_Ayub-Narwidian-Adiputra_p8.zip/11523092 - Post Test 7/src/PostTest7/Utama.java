/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package PostTest7;

/**
 *
 * @author Praktikan
 */
public class Utama {
    public static void main(String[] args) {
        Swalayan s;
        
        Indomaret i = new Indomaret();
        s=i;
        s.caraPembayaran();
        
        TokoAgung t = new TokoAgung();
        s=t;
        s.caraPembayaran();
    }
}
