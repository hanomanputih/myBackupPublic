/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package PostTest7;

/**
 *
 * @author Praktikan
 */
public class Swalayan {
    float harga = 19315;
    int bayar, sisa;
    
    public void caraPembayaran(){
        
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
    }
}
