/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package PostTest7;

/**
 *
 * @author Praktikan
 */
public class Indomaret extends Swalayan {

    @Override
    public void caraPembayaran(){
        if (harga % 25 == 0){
            System.out.println("Harga Indomaret = "+harga);
        }
        else {
            sisa = (int) (25 - (harga % 25));
            bayar = (int) (harga + sisa);
            System.out.println("Harga Indomaret = "+bayar);
        }
    }
}
