/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication6;

import java.util.Scanner;

/**
 *
 * @author Praktikan
 */
public class mahasiswa {
    String nama;
    String nim,jurusan,angkatan,fakultas;
    
    void data(){ 
           Scanner baca = new Scanner(System.in);
           System.out.println("nama : " );
           nama = baca.next();
           System.out.println("nim : ");
           nim = baca.next();
           System.out.println("jurusan : ");
           jurusan = baca.next();
           System.out.println("angkatan : ");
           angkatan = baca.next();
           System.out.println("fakultas : ");
           fakultas = baca.next();
           System.out.println("nama anda : "+nama);
           System.out.println("nim anda : "+nim);
           System.out.println("jurusan anda : "+jurusan);
           System.out.println("fakultas anda : "+fakultas);
           System.out.println("angkatan : "+angkatan);
        
        
    }
   

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
mahasiswa m = new mahasiswa ();
m.data();
        
        
        // TODO code application logic here
    }
}
